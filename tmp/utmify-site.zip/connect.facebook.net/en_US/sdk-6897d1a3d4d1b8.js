/*1771371273,,JIT Construction: v1033555463,en_US*/

/**
 * Copyright (c) 2017-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to use,
 * copy, modify, and distribute this software in source code or binary form for use
 * in connection with the web services and APIs provided by Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use of
 * this software is subject to the Facebook Platform Policy
 * [http://developers.facebook.com/policy/]. This copyright notice shall be
 * included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
try {
    (window.FB && !window.FB.__buffer) || (function() {
        var apply = Function.prototype.apply;

        function bindContext(fn, thisArg) {
            return function _sdkBound() {
                return apply.call(fn, thisArg, arguments);
            };
        }
        var global = {
            __type: 'JS_SDK_SANDBOX',
            window: window,
            document: window.document
        };
        var sandboxSafelist = ['setTimeout', 'setInterval', 'clearTimeout', 'clearInterval'];
        for (var i = 0; i < sandboxSafelist.length; i++) {
            global[sandboxSafelist[i]] = bindContext(window[sandboxSafelist[i]], window);
        }(function() {
            var self = window;
            var globalThis = this;
            var __DEV__ = 0;

            function emptyFunction() {};
            var __transform_includes = {};
            var __annotator, __bodyWrapper;
            var __w, __t;
            var undefined;
            with(this) {
                (function(e) {
                    var t = {},
                        n = function(t, n) {
                            if (!t && !n) return null;
                            var e = {};
                            return typeof t != "undefined" && (e.type = t), typeof n != "undefined" && (e.signature = n), e
                        },
                        r = function(t, r) {
                            return n(t && /^[A-Z]/.test(t) ? t : void 0, r && (r.params && r.params.length || r.returns) ? "function(" + (r.params ? r.params.map(function(e) {
                                return /\?/.test(e) ? "?" + e.replace("?", "") : e
                            }).join(",") : "") + ")" + (r.returns ? ":" + r.returns : "") : void 0)
                        },
                        o = function(t, n, r) {
                            return t
                        },
                        a = function(t, n, o) {
                            if ("typechecks" in __transform_includes) {
                                var e = r(n ? n.name : void 0, o);
                                e && __w(t, e)
                            }
                            return t
                        },
                        i = function(t, n, r) {
                            return r.apply(t, n)
                        },
                        l = function(n, r, o, a, i) {
                            if (i) {
                                i.callId || (i.callId = i.module + ":" + (i.line || 0) + ":" + (i.column || 0));
                                var e = i.callId;
                                t[e] = (t[e] || 0) + 1
                            }
                            return o.apply(n, r)
                        };
                    typeof __transform_includes == "undefined" ? (e.__annotator = o, e.__bodyWrapper = i) : (e.__annotator = a, "codeusage" in __transform_includes ? (e.__annotator = o, e.__bodyWrapper = l, e.__bodyWrapper.getCodeUsage = function() {
                        return t
                    }, e.__bodyWrapper.clearCodeUsage = function() {
                        t = {}
                    }) : e.__bodyWrapper = i)
                })(typeof globalThis != "undefined" ? globalThis : typeof global != "undefined" ? global : typeof window != "undefined" ? window : typeof this != "undefined" ? this : typeof self != "undefined" ? self : {});
                (function(e) {
                    e.__t = function(e) {
                        return e[0]
                    }, e.__w = function(e) {
                        return e
                    }
                })(typeof globalThis != "undefined" ? globalThis : typeof global != "undefined" ? global : typeof window != "undefined" ? window : typeof this != "undefined" ? this : typeof self != "undefined" ? self : {});
                (function(e) {
                    var t = {},
                        n = ["global", "require", "requireDynamic", "requireLazy", "module", "exports"],
                        r = ["global", "require", "importDefault", "importNamespace", "requireLazy", "module", "exports"],
                        o = 1,
                        a = 32,
                        i = 64,
                        l = 256,
                        s = {},
                        u = Object.prototype.hasOwnProperty;

                    function c(o, l) {
                        if (!u.call(t, o)) {
                            if (l === !0) return null;
                            throw new Error("Module " + o + " has not been defined")
                        }
                        var s = t[o];
                        if (s.resolved) return s;
                        for (var c = s.special, _ = s.factory.length, f = c & a ? r.concat(s.deps) : n.concat(s.deps), g = [], h, y = 0; y < _; y++) {
                            switch (f[y]) {
                                case "module":
                                    h = s;
                                    break;
                                case "exports":
                                    h = s.exports;
                                    break;
                                case "global":
                                    h = e;
                                    break;
                                case "require":
                                    h = d;
                                    break;
                                case "requireDynamic":
                                    h = null;
                                    break;
                                case "requireLazy":
                                    h = null;
                                    break;
                                case "importDefault":
                                    h = m;
                                    break;
                                case "importNamespace":
                                    h = p;
                                    break;
                                default:
                                    typeof f[y] == "string" && (h = d.call(null, f[y]))
                            }
                            g.push(h)
                        }
                        var C = s.factory.apply(e, g);
                        return C && (s.exports = C), c & i ? s.exports != null && u.call(s.exports, "default") && (s.defaultExport = s.exports.default) : s.defaultExport = s.exports, s.resolved = !0, s
                    }

                    function d(e, t) {
                        var n = c(e, t);
                        if (n) return n.defaultExport !== s ? n.defaultExport : n.exports
                    }

                    function m(e) {
                        var t = c(e);
                        if (t) return t.defaultExport !== s ? t.defaultExport : null
                    }

                    function p(e) {
                        var t = c(e);
                        if (t) return t.exports
                    }

                    function _(e, n, r, a) {
                        if (u.call(t, e)) {
                            var i = t[e].special || 0;
                            if (i & l) return
                        }
                        typeof r == "function" ? (t[e] = {
                            factory: r,
                            deps: n,
                            defaultExport: s,
                            exports: {},
                            special: a || 0,
                            resolved: !1
                        }, a != null && a & o && d.call(null, e)) : t[e] = {
                            defaultExport: r,
                            exports: r,
                            resolved: !0
                        }
                    }

                    function f(e, t, n) {
                        var r = c(e, !0);
                        if (r) {
                            if (typeof t == "function") return t(d(e))
                        } else if (typeof n == "function") return n()
                    }
                    _("ifRequireable", [], function() {
                        return f
                    }, l), e.__d = _, e.require = d, e.importDefault = m, e.importNamespace = p, e.$RefreshReg$ = function() {}, e.$RefreshSig$ = function() {
                        return function(e) {
                            return e
                        }
                    }
                })(this);
                __d("ES5FunctionPrototype", [], (function(t, n, r, o, a, i) {
                    var e = {
                            bind: function(t) {
                                for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                                if (typeof this != "function") throw new TypeError("Bind must be called on a function");
                                var o = this;

                                function a() {
                                    return o.apply(t, n.concat(Array.prototype.slice.call(arguments)))
                                }
                                return a.displayName = "bound:" + (o.displayName || o.name || "(?)"), a.toString = function() {
                                    return "bound: " + o
                                }, a
                            }
                        },
                        l = e;
                    i.default = l
                }), 66);
                __d("ES5StringPrototype", [], (function(t, n, r, o, a, i) {
                    var e = {
                            startsWith: function(t) {
                                var e = String(this);
                                if (this == null) throw new TypeError("String.prototype.startsWith called on null or undefined");
                                var n = arguments.length > 1 ? Number(arguments[1]) : 0;
                                isNaN(n) && (n = 0);
                                var r = Math.min(Math.max(n, 0), e.length);
                                return e.indexOf(String(t), n) == r
                            },
                            endsWith: function(t) {
                                var e = String(this);
                                if (this == null) throw new TypeError("String.prototype.endsWith called on null or undefined");
                                var n = e.length,
                                    r = String(t),
                                    o = arguments.length > 1 ? Number(arguments[1]) : n;
                                isNaN(o) && (o = 0);
                                var a = Math.min(Math.max(o, 0), n),
                                    i = a - r.length;
                                return i < 0 ? !1 : e.lastIndexOf(r, i) == i
                            },
                            includes: function(t) {
                                if (this == null) throw new TypeError("String.prototype.contains called on null or undefined");
                                var e = String(this),
                                    n = arguments.length > 1 ? Number(arguments[1]) : 0;
                                return isNaN(n) && (n = 0), e.indexOf(String(t), n) !== -1
                            },
                            repeat: function(t) {
                                if (this == null) throw new TypeError("String.prototype.repeat called on null or undefined");
                                var e = String(this),
                                    n = t ? Number(t) : 0;
                                if (isNaN(n) && (n = 0), n < 0 || n === 1 / 0) throw RangeError();
                                if (n === 1) return e;
                                if (n === 0) return "";
                                for (var r = ""; n;) n & 1 && (r += e), (n >>= 1) && (e += e);
                                return r
                            }
                        },
                        l = e;
                    i.default = l
                }), 66);
                __d("ES6Array", [], (function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e) {
                        if (e == null) throw new TypeError("Object is null or undefined");
                        var t = arguments[1],
                            n = arguments[2],
                            r = this,
                            o = Object(e),
                            a = typeof Symbol == "function" && navigator.userAgent.indexOf("Trident/7.0") === -1 && typeof Symbol == "function" ? Symbol.iterator : "@@iterator",
                            i = typeof t == "function",
                            l = typeof o[a] == "function",
                            s = 0,
                            u, c;
                        if (l) {
                            u = typeof r == "function" ? new r : [];
                            for (var d = o[a](), m; !(m = d.next()).done;) c = m.value, i && (c = t.call(n, c, s)), u[s] = c, s += 1;
                            return u.length = s, u
                        }
                        var p = o.length;
                        for ((isNaN(p) || p < 0) && (p = 0), u = typeof r == "function" ? new r(p) : new Array(p); s < p;) c = o[s], i && (c = t.call(n, c, s)), u[s] = c, s += 1;
                        return u.length = s, u
                    }
                    var l = {
                            from: e
                        },
                        s = l;
                    i.default = s
                }), 66);
                __d("ES6ArrayPrototype", [], (function(t, n, r, o, a, i) {
                    var e = {
                            find: function(n, r) {
                                if (this == null) throw new TypeError("Array.prototype.find called on null or undefined");
                                if (typeof n != "function") throw new TypeError("predicate must be a function");
                                var t = e.findIndex.call(this, n, r);
                                return t === -1 ? void 0 : this[t]
                            },
                            findIndex: function(t, n) {
                                if (this == null) throw new TypeError("Array.prototype.findIndex called on null or undefined");
                                if (typeof t != "function") throw new TypeError("predicate must be a function");
                                for (var e = Object(this), r = e.length >>> 0, o = 0; o < r; o++)
                                    if (t.call(n, e[o], o, e)) return o;
                                return -1
                            },
                            fill: function(t, n, r) {
                                if (this == null) throw new TypeError("Array.prototype.fill called on null or undefined");
                                for (var e = Object(this), o = e.length >>> 0, a = arguments[1], i = a >> 0, l = i < 0 ? Math.max(o + i, 0) : Math.min(i, o), s = arguments[2], u = s === void 0 ? o : s >> 0, c = u < 0 ? Math.max(o + u, 0) : Math.min(u, o); l < c;) e[l] = t, l++;
                                return e
                            }
                        },
                        l = e;
                    i.default = l
                }), 66);
                __d("ES6Number", [], (function(t, n, r, o, a, i) {
                    var e = Math.pow(2, -52),
                        l = Math.pow(2, 53) - 1,
                        s = -1 * l,
                        u = {
                            isFinite: (function(e) {
                                function t(t) {
                                    return e.apply(this, arguments)
                                }
                                return t.toString = function() {
                                    return e.toString()
                                }, t
                            })(function(e) {
                                return typeof e == "number" && isFinite(e)
                            }),
                            isNaN: (function(e) {
                                function t(t) {
                                    return e.apply(this, arguments)
                                }
                                return t.toString = function() {
                                    return e.toString()
                                }, t
                            })(function(e) {
                                return typeof e == "number" && isNaN(e)
                            }),
                            isInteger: function(t) {
                                return u.isFinite(t) && Math.floor(t) === t
                            },
                            isSafeInteger: function(t) {
                                return this.isFinite(t) && t >= this.MIN_SAFE_INTEGER && t <= this.MAX_SAFE_INTEGER && Math.floor(t) === t
                            },
                            EPSILON: e,
                            MAX_SAFE_INTEGER: l,
                            MIN_SAFE_INTEGER: s
                        },
                        c = u;
                    i.default = c
                }), 66);
                __d("ES6Object", [], (function(t, n, r, o, a, i) {
                    var e = {}.hasOwnProperty,
                        l = {
                            assign: function(n) {
                                if (n == null) throw new TypeError("Object.assign target cannot be null or undefined");
                                n = Object(n);
                                for (var t = 0; t < (arguments.length <= 1 ? 0 : arguments.length - 1); t++) {
                                    var r = t + 1 < 1 || arguments.length <= t + 1 ? void 0 : arguments[t + 1];
                                    if (r != null) {
                                        r = Object(r);
                                        for (var o in r) e.call(r, o) && (n[o] = r[o])
                                    }
                                }
                                return n
                            },
                            is: function(t, n) {
                                return t === n ? t !== 0 || 1 / t === 1 / n : t !== t && n !== n
                            }
                        },
                        s = l;
                    i.default = s
                }), 66);
                __d("ES5Array", [], (function(t, n, r, o, a, i) {
                    var e = {
                            isArray: function(t) {
                                return Object.prototype.toString.call(t) === "[object Array]"
                            }
                        },
                        l = e;
                    i.default = l
                }), 66);
                __d("ES5ArrayPrototype", [], (function(t, n, r, o, a, i) {
                    var e = {
                            indexOf: function(t, n) {
                                var e = n,
                                    r = this.length;
                                for (e |= 0, e < 0 && (e += r); e < r; e++)
                                    if (e in this && this[e] === t) return e;
                                return -1
                            }
                        },
                        l = e;
                    i.default = l
                }), 66);
                __d("ES7ArrayPrototype", ["ES5Array", "ES5ArrayPrototype"], (function(t, n, r, o, a, i) {
                    var e = n("ES5Array").isArray,
                        l = n("ES5ArrayPrototype").indexOf;

                    function s(e) {
                        return Math.min(Math.max(u(e), 0), Number.MAX_SAFE_INTEGER)
                    }

                    function u(e) {
                        var t = Number(e);
                        return isFinite(t) && t !== 0 ? c(t) * Math.floor(Math.abs(t)) : t
                    }

                    function c(e) {
                        return e >= 0 ? 1 : -1
                    }

                    function d(t) {
                        "use strict";
                        if (t !== void 0 && e(this) && !(typeof t == "number" && isNaN(t))) return l.apply(this, arguments) !== -1;
                        var n = Object(this),
                            r = n.length ? s(n.length) : 0;
                        if (r === 0) return !1;
                        for (var o = arguments.length > 1 ? u(arguments[1]) : 0, a = o < 0 ? Math.max(r + o, 0) : o, i = isNaN(t) && typeof t == "number"; a < r;) {
                            var c = n[a];
                            if (c === t || typeof c == "number" && i && isNaN(c)) return !0;
                            a++
                        }
                        return !1
                    }
                    var m = {
                        includes: d
                    };
                    a.exports = m
                }), null);
                __d("ES7Object", [], (function(t, n, r, o, a, i) {
                    var e = {}.hasOwnProperty,
                        l = {
                            entries: function(n) {
                                if (n == null) throw new TypeError("Object.entries called on non-object");
                                var t = [];
                                for (var r in n) e.call(n, r) && t.push([r, n[r]]);
                                return t
                            },
                            values: function(n) {
                                if (n == null) throw new TypeError("Object.values called on non-object");
                                var t = [];
                                for (var r in n) e.call(n, r) && t.push(n[r]);
                                return t
                            }
                        },
                        s = l;
                    i.default = s
                }), 66);
                __d("ES7StringPrototype", [], (function(t, n, r, o, a, i) {
                    var e = {
                            trimLeft: function() {
                                return this.replace(/^\s+/, "")
                            },
                            trimRight: function() {
                                return this.replace(/\s+$/, "")
                            }
                        },
                        l = e;
                    i.default = l
                }), 66);
                /**
                 * License: https://www.facebook.com/legal/license/t3hOLs8wlXy/
                 */
                __d("json3-3.3.2", [], (function(t, n, r, o, a, i) {
                    "use strict";
                    var e = {},
                        l = {
                            exports: e
                        },
                        s;

                    function u() {
                        (function() {
                            var n = typeof s == "function",
                                r = {
                                    function: !0,
                                    object: !0
                                },
                                o = r[typeof e] && e && !e.nodeType && e,
                                a = r[typeof window] && window || this,
                                i = o && r[typeof l] && l && !l.nodeType && typeof t == "object" && t;
                            i && (i.global === i || i.window === i || i.self === i) && (a = i);

                            function u(e, t) {
                                e || (e = a.Object()), t || (t = a.Object());
                                var n = e.Number || a.Number,
                                    o = e.String || a.String,
                                    i = e.Object || a.Object,
                                    l = e.Date || a.Date,
                                    s = e.SyntaxError || a.SyntaxError,
                                    c = e.TypeError || a.TypeError,
                                    d = e.Math || a.Math,
                                    m = e.JSON || a.JSON;
                                typeof m == "object" && m && (t.stringify = m.stringify, t.parse = m.parse);
                                var p = i.prototype,
                                    _ = p.toString,
                                    f, g, h, y = new l(-0xc782b5b800cec);
                                try {
                                    y = y.getUTCFullYear() == -109252 && y.getUTCMonth() === 0 && y.getUTCDate() === 1 && y.getUTCHours() == 10 && y.getUTCMinutes() == 37 && y.getUTCSeconds() == 6 && y.getUTCMilliseconds() == 708
                                } catch (e) {}

                                function C(e) {
                                    if (C[e] !== h) return C[e];
                                    var r;
                                    if (e == "bug-string-char-index") r = !1;
                                    else if (e == "json") r = C("json-stringify") && C("json-parse");
                                    else {
                                        var a, i = '{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}';
                                        if (e == "json-stringify") {
                                            var s = t.stringify,
                                                u = typeof s == "function" && y;
                                            if (u) {
                                                (a = function() {
                                                    return 1
                                                }).toJSON = a;
                                                try {
                                                    u = s(0) === "0" && s(new n) === "0" && s(new o) == '""' && s(_) === h && s(h) === h && s() === h && s(a) === "1" && s([a]) == "[1]" && s([h]) == "[null]" && s(null) == "null" && s([h, _, null]) == "[null,null,null]" && s({
                                                        a: [a, !0, !1, null, "\0\b\n\f\r	"]
                                                    }) == i && s(null, a) === "1" && s([1, 2], null, 1) == "[\n 1,\n 2\n]" && s(new l(-864e13)) == '"-271821-04-20T00:00:00.000Z"' && s(new l(864e13)) == '"+275760-09-13T00:00:00.000Z"' && s(new l(-621987552e5)) == '"-000001-01-01T00:00:00.000Z"' && s(new l(-1)) == '"1969-12-31T23:59:59.999Z"'
                                                } catch (e) {
                                                    u = !1
                                                }
                                            }
                                            r = u
                                        }
                                        if (e == "json-parse") {
                                            var c = t.parse;
                                            if (typeof c == "function") try {
                                                if (c("0") === 0 && !c(!1)) {
                                                    a = c(i);
                                                    var d = a.a.length == 5 && a.a[0] === 1;
                                                    if (d) {
                                                        try {
                                                            d = !c('"	"')
                                                        } catch (e) {}
                                                        if (d) try {
                                                            d = c("01") !== 1
                                                        } catch (e) {}
                                                        if (d) try {
                                                            d = c("1.") !== 1
                                                        } catch (e) {}
                                                    }
                                                }
                                            } catch (e) {
                                                d = !1
                                            }
                                            r = d
                                        }
                                    }
                                    return C[e] = !!r
                                }
                                if (!C("json")) {
                                    var b = "[object Function]",
                                        v = "[object Date]",
                                        S = "[object Number]",
                                        R = "[object String]",
                                        L = "[object Array]",
                                        E = "[object Boolean]",
                                        k = C("bug-string-char-index");
                                    if (!y) var I = d.floor,
                                        T = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334],
                                        D = function(e, t) {
                                            return T[t] + 365 * (e - 1970) + I((e - 1969 + (t = +(t > 1))) / 4) - I((e - 1901 + t) / 100) + I((e - 1601 + t) / 400)
                                        };
                                    if ((f = p.hasOwnProperty) || (f = function(e) {
                                            var t = {},
                                                n;
                                            return (t.__proto__ = null, t.__proto__ = {
                                                toString: 1
                                            }, t).toString != _ ? f = function(e) {
                                                var t = this.__proto__,
                                                    n = e in (this.__proto__ = null, this);
                                                return this.__proto__ = t, n
                                            } : (n = t.constructor, f = function(e) {
                                                var t = (this.constructor || n).prototype;
                                                return e in this && !(e in t && this[e] === t[e])
                                            }), t = null, f.call(this, e)
                                        }), g = function(e, t) {
                                            var n = 0,
                                                o, a, i;
                                            (o = function() {
                                                this.valueOf = 0
                                            }).prototype.valueOf = 0, a = new o;
                                            for (i in a) f.call(a, i) && n++;
                                            return o = a = null, n ? n == 2 ? g = function(e, t) {
                                                var n = {},
                                                    r = _.call(e) == b,
                                                    o;
                                                for (o in e) !(r && o == "prototype") && !f.call(n, o) && (n[o] = 1) && f.call(e, o) && t(o)
                                            } : g = function(e, t) {
                                                var n = _.call(e) == b,
                                                    r, o;
                                                for (r in e) !(n && r == "prototype") && f.call(e, r) && !(o = r === "constructor") && t(r);
                                                (o || f.call(e, r = "constructor")) && t(r)
                                            } : (a = ["valueOf", "toString", "toLocaleString", "propertyIsEnumerable", "isPrototypeOf", "hasOwnProperty", "constructor"], g = function(e, t) {
                                                var n = _.call(e) == b,
                                                    o, i, l = !n && typeof e.constructor != "function" && r[typeof e.hasOwnProperty] && e.hasOwnProperty || f;
                                                for (o in e) !(n && o == "prototype") && l.call(e, o) && t(o);
                                                for (i = a.length; o = a[--i]; l.call(e, o) && t(o));
                                            }), g(e, t)
                                        }, !C("json-stringify")) {
                                        var x = {
                                                92: "\\\\",
                                                34: '\\"',
                                                8: "\\b",
                                                12: "\\f",
                                                10: "\\n",
                                                13: "\\r",
                                                9: "\\t"
                                            },
                                            $ = "000000",
                                            P = function(e, t) {
                                                return ($ + (t || 0)).slice(-e)
                                            },
                                            N = "\\u00",
                                            M = function(e) {
                                                for (var t = '"', n = 0, r = e.length, o = !k || r > 10, a = o && (k ? e.split("") : e); n < r; n++) {
                                                    var i = e.charCodeAt(n);
                                                    switch (i) {
                                                        case 8:
                                                        case 9:
                                                        case 10:
                                                        case 12:
                                                        case 13:
                                                        case 34:
                                                        case 92:
                                                            t += x[i];
                                                            break;
                                                        default:
                                                            if (i < 32) {
                                                                t += N + P(2, i.toString(16));
                                                                break
                                                            }
                                                            t += o ? a[n] : e.charAt(n)
                                                    }
                                                }
                                                return t + '"'
                                            },
                                            w = function(e, t, n, r, o, a, i) {
                                                var l, s, u, d, m, p, y, C, b, k, T, x, $, N, A, F;
                                                try {
                                                    l = t[e]
                                                } catch (e) {}
                                                if (typeof l == "object" && l)
                                                    if (s = _.call(l), s == v && !f.call(l, "toJSON"))
                                                        if (l > -1 / 0 && l < 1 / 0) {
                                                            if (D) {
                                                                for (m = I(l / 864e5), u = I(m / 365.2425) + 1970 - 1; D(u + 1, 0) <= m; u++);
                                                                for (d = I((m - D(u, 0)) / 30.42); D(u, d + 1) <= m; d++);
                                                                m = 1 + m - D(u, d), p = (l % 864e5 + 864e5) % 864e5, y = I(p / 36e5) % 24, C = I(p / 6e4) % 60, b = I(p / 1e3) % 60, k = p % 1e3
                                                            } else u = l.getUTCFullYear(), d = l.getUTCMonth(), m = l.getUTCDate(), y = l.getUTCHours(), C = l.getUTCMinutes(), b = l.getUTCSeconds(), k = l.getUTCMilliseconds();
                                                            l = (u <= 0 || u >= 1e4 ? (u < 0 ? "-" : "+") + P(6, u < 0 ? -u : u) : P(4, u)) + "-" + P(2, d + 1) + "-" + P(2, m) + "T" + P(2, y) + ":" + P(2, C) + ":" + P(2, b) + "." + P(3, k) + "Z"
                                                        } else l = null;
                                                else typeof l.toJSON == "function" && (s != S && s != R && s != L || f.call(l, "toJSON")) && (l = l.toJSON(e));
                                                if (n && (l = n.call(t, e, l)), l === null) return "null";
                                                if (s = _.call(l), s == E) return "" + l;
                                                if (s == S) return l > -1 / 0 && l < 1 / 0 ? "" + l : "null";
                                                if (s == R) return M("" + l);
                                                if (typeof l == "object") {
                                                    for (N = i.length; N--;)
                                                        if (i[N] === l) throw c();
                                                    if (i.push(l), T = [], A = a, a += o, s == L) {
                                                        for ($ = 0, N = l.length; $ < N; $++) x = w($, l, n, r, o, a, i), T.push(x === h ? "null" : x);
                                                        F = T.length ? o ? "[\n" + a + T.join(",\n" + a) + "\n" + A + "]" : "[" + T.join(",") + "]" : "[]"
                                                    } else g(r || l, function(e) {
                                                        var t = w(e, l, n, r, o, a, i);
                                                        t !== h && T.push(M(e) + ":" + (o ? " " : "") + t)
                                                    }), F = T.length ? o ? "{\n" + a + T.join(",\n" + a) + "\n" + A + "}" : "{" + T.join(",") + "}" : "{}";
                                                    return i.pop(), F
                                                }
                                            };
                                        t.stringify = function(e, t, n) {
                                            var o, a, i, l;
                                            if (r[typeof t] && t) {
                                                if ((l = _.call(t)) == b) a = t;
                                                else if (l == L) {
                                                    i = {};
                                                    for (var s = 0, u = t.length, c; s < u; c = t[s++], l = _.call(c), (l == R || l == S) && (i[c] = 1));
                                                }
                                            }
                                            if (n)
                                                if ((l = _.call(n)) == S) {
                                                    if ((n -= n % 1) > 0)
                                                        for (o = "", n > 10 && (n = 10); o.length < n; o += " ");
                                                } else l == R && (o = n.length <= 10 ? n : n.slice(0, 10));
                                            return w("", (c = {}, c[""] = e, c), a, i, o, "", [])
                                        }
                                    }
                                    if (!C("json-parse")) {
                                        var A = o.fromCharCode,
                                            F = {
                                                92: "\\",
                                                34: '"',
                                                47: "/",
                                                98: "\b",
                                                116: "	",
                                                110: "\n",
                                                102: "\f",
                                                114: "\r"
                                            },
                                            O, B, W = function() {
                                                throw O = B = null, s()
                                            },
                                            q = function() {
                                                for (var e = B, t = e.length, n, r, o, a, i; O < t;) switch (i = e.charCodeAt(O), i) {
                                                    case 9:
                                                    case 10:
                                                    case 13:
                                                    case 32:
                                                        O++;
                                                        break;
                                                    case 123:
                                                    case 125:
                                                    case 91:
                                                    case 93:
                                                    case 58:
                                                    case 44:
                                                        return n = k ? e.charAt(O) : e[O], O++, n;
                                                    case 34:
                                                        for (n = "@", O++; O < t;)
                                                            if (i = e.charCodeAt(O), i < 32) W();
                                                            else if (i == 92) switch (i = e.charCodeAt(++O), i) {
                                                            case 92:
                                                            case 34:
                                                            case 47:
                                                            case 98:
                                                            case 116:
                                                            case 110:
                                                            case 102:
                                                            case 114:
                                                                n += F[i], O++;
                                                                break;
                                                            case 117:
                                                                for (r = ++O, o = O + 4; O < o; O++) i = e.charCodeAt(O), i >= 48 && i <= 57 || i >= 97 && i <= 102 || i >= 65 && i <= 70 || W();
                                                                n += A("0x" + e.slice(r, O));
                                                                break;
                                                            default:
                                                                W()
                                                        } else {
                                                            if (i == 34) break;
                                                            for (i = e.charCodeAt(O), r = O; i >= 32 && i != 92 && i != 34;) i = e.charCodeAt(++O);
                                                            n += e.slice(r, O)
                                                        }
                                                        if (e.charCodeAt(O) == 34) return O++, n;
                                                        W();
                                                    default:
                                                        if (r = O, i == 45 && (a = !0, i = e.charCodeAt(++O)), i >= 48 && i <= 57) {
                                                            for (i == 48 && (i = e.charCodeAt(O + 1), i >= 48 && i <= 57) && W(), a = !1; O < t && (i = e.charCodeAt(O), i >= 48 && i <= 57); O++);
                                                            if (e.charCodeAt(O) == 46) {
                                                                for (o = ++O; o < t && (i = e.charCodeAt(o), i >= 48 && i <= 57); o++);
                                                                o == O && W(), O = o
                                                            }
                                                            if (i = e.charCodeAt(O), i == 101 || i == 69) {
                                                                for (i = e.charCodeAt(++O), (i == 43 || i == 45) && O++, o = O; o < t && (i = e.charCodeAt(o), i >= 48 && i <= 57); o++);
                                                                o == O && W(), O = o
                                                            }
                                                            return +e.slice(r, O)
                                                        }
                                                        if (a && W(), e.slice(O, O + 4) == "true") return O += 4, !0;
                                                        if (e.slice(O, O + 5) == "false") return O += 5, !1;
                                                        if (e.slice(O, O + 4) == "null") return O += 4, null;
                                                        W()
                                                }
                                                return "$"
                                            },
                                            U = function(e) {
                                                var t, n;
                                                if (e == "$" && W(), typeof e == "string") {
                                                    if ((k ? e.charAt(0) : e[0]) == "@") return e.slice(1);
                                                    if (e == "[") {
                                                        for (t = []; e = q(), e != "]"; n || (n = !0)) n && (e == "," ? (e = q(), e == "]" && W()) : W()), e == "," && W(), t.push(U(e));
                                                        return t
                                                    } else if (e == "{") {
                                                        for (t = {}; e = q(), e != "}"; n || (n = !0)) n && (e == "," ? (e = q(), e == "}" && W()) : W()), (e == "," || typeof e != "string" || (k ? e.charAt(0) : e[0]) != "@" || q() != ":") && W(), t[e.slice(1)] = U(q());
                                                        return t
                                                    }
                                                    W()
                                                }
                                                return e
                                            },
                                            V = function(e, t, n) {
                                                var r = H(e, t, n);
                                                r === h ? delete e[t] : e[t] = r
                                            },
                                            H = function(e, t, n) {
                                                var r = e[t],
                                                    o;
                                                if (typeof r == "object" && r)
                                                    if (_.call(r) == L)
                                                        for (o = r.length; o--;) V(r, o, n);
                                                    else g(r, function(e) {
                                                        V(r, e, n)
                                                    });
                                                return n.call(e, t, r)
                                            };
                                        t.parse = function(e, t) {
                                            var n, r;
                                            return O = 0, B = "" + e, n = U(q()), q() != "$" && W(), O = B = null, t && _.call(t) == b ? H((r = {}, r[""] = n, r), "", t) : n
                                        }
                                    }
                                }
                                return t.runInContext = u, t
                            }
                            if (o && !n) u(a, o);
                            else {
                                var c = a.JSON,
                                    d = a.JSON3,
                                    m = !1,
                                    p = u(a, a.JSON3 = {
                                        noConflict: function() {
                                            return m || (m = !0, a.JSON = c, a.JSON3 = d, c = d = null), p
                                        }
                                    });
                                a.JSON = {
                                    parse: p.parse,
                                    stringify: p.stringify
                                }
                            }
                        }).call(this)
                    }
                    var c = !1;

                    function d() {
                        return c || (c = !0, u()), l.exports
                    }

                    function m(e) {
                        switch (e) {
                            case void 0:
                                return d()
                        }
                    }
                    a.exports = m
                }), null);
                __d("json3", ["json3-3.3.2"], (function(t, n, r, o, a, i) {
                    a.exports = n("json3-3.3.2")()
                }), null);
                __d("ES", ["ES5FunctionPrototype", "ES5StringPrototype", "ES6Array", "ES6ArrayPrototype", "ES6Number", "ES6Object", "ES7ArrayPrototype", "ES7Object", "ES7StringPrototype", "json3"], (function(t, n, r, o, a, i, l) {
                    var e = {}.toString,
                        s = {
                            "JSON.stringify": r("json3").stringify,
                            "JSON.parse": r("json3").parse
                        },
                        u = {
                            "Function.prototype": r("ES5FunctionPrototype"),
                            "String.prototype": r("ES5StringPrototype")
                        },
                        c = {
                            Object: r("ES6Object"),
                            "Array.prototype": r("ES6ArrayPrototype"),
                            Number: r("ES6Number"),
                            Array: r("ES6Array")
                        },
                        d = {
                            Object: r("ES7Object"),
                            "String.prototype": r("ES7StringPrototype"),
                            "Array.prototype": r("ES7ArrayPrototype")
                        };

                    function m(e) {
                        for (var t in e)
                            if (Object.prototype.hasOwnProperty.call(e, t)) {
                                var n = e[t],
                                    r = t.split(".");
                                if (r.length === 2) {
                                    var o = r[0],
                                        a = r[1];
                                    if (!o || !a || !window[o] || !window[o][a]) {
                                        var i = o ? window[o] : "-",
                                            l = o && window[o] && a ? window[o][a] : "-";
                                        throw new Error("Unexpected state (t11975770): " + (o + ", " + a + ", " + i + ", " + l + ", " + t))
                                    }
                                }
                                var u = r.length === 2 ? window[r[0]][r[1]] : window[t];
                                for (var c in n)
                                    if (Object.prototype.hasOwnProperty.call(n, c)) {
                                        if (typeof n[c] != "function") {
                                            s[t + "." + c] = n[c];
                                            continue
                                        }
                                        var d = u[c];
                                        s[t + "." + c] = d && /\{\s+\[native code\]\s\}/.test(d) ? d : n[c]
                                    }
                            }
                    }
                    m(u), m(c), m(d);

                    function p(t, n, r) {
                        var o = r ? e.call(t).slice(8, -1) + ".prototype" : t,
                            a;
                        if (Array.isArray(t))
                            if (typeof o == "string") a = s[o + "." + n];
                            else throw new Error("Can't polyfill " + n + " directly on an Array.");
                        else if (typeof o == "string") a = s[o + "." + n];
                        else {
                            if (typeof t == "string") throw new Error("Can't polyfill " + n + " directly on a string.");
                            a = t[n]
                        }
                        if (typeof a == "function") {
                            for (var i = arguments.length, l = new Array(i > 3 ? i - 3 : 0), u = 3; u < i; u++) l[u - 3] = arguments[u];
                            return a.apply(t, l)
                        } else if (a) return a;
                        throw new Error("Polyfill " + o + " does not have implementation of " + n)
                    }
                    l.default = p
                }), 98);
                __d("ES5Object", [], (function(t, n, r, o, a, i) {
                    var e = {}.hasOwnProperty,
                        l = {
                            create: function(t) {
                                var e = typeof t;
                                if (e != "object" && e != "function") throw new TypeError("Object prototype may only be a Object or null");
                                var n = {};
                                return Object.setPrototypeOf(n, t), n
                            },
                            keys: function(n) {
                                var t = typeof n;
                                if (t != "object" && t != "function" || n === null) throw new TypeError("Object.keys called on non-object");
                                var r = [];
                                for (var o in n) e.call(n, o) && r.push(o);
                                return r
                            },
                            freeze: function(t) {
                                return t
                            },
                            isFrozen: function() {
                                return !1
                            },
                            seal: function(t) {
                                return t
                            }
                        },
                        s = l;
                    i.default = s
                }), 66);
                __d("sdk.babelHelpers", ["ES5FunctionPrototype", "ES5Object", "ES6Object"], (function(t, n, r, o, a, i) {
                    var e = {},
                        l = Object.prototype.hasOwnProperty;
                    e.inheritsLoose = function(e, t) {
                        return n("ES6Object").assign(e, t), e.prototype = n("ES5Object").create(t && t.prototype), e.prototype.constructor = e, e.__superConstructor__ = t, t
                    }, e.inherits = e.inheritsLoose, e.wrapNativeSuper = function(t) {
                        var n = typeof Map == "function" ? new Map : void 0;
                        return e.wrapNativeSuper = function(t) {
                            if (t === null) return null;
                            if (typeof t != "function") throw new TypeError("Super expression must either be null or a function");
                            if (n !== void 0) {
                                if (n.has(t)) return n.get(t);
                                n.set(t, r)
                            }
                            e.inheritsLoose(r, t);

                            function r() {
                                t.apply(this, arguments)
                            }
                            return r
                        }, e.wrapNativeSuper(t)
                    }, e.assertThisInitialized = function(e) {
                        if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return e
                    }, e._extends = n("ES6Object").assign, e.extends = e._extends, e.construct = function(e, t) {
                        var n = [null];
                        return n.push.apply(n, t), new(Function.prototype.bind.apply(e, n))
                    }, e.objectWithoutPropertiesLoose = function(e, t) {
                        var n = {};
                        for (var r in e) !l.call(e, r) || t.indexOf(r) >= 0 || (n[r] = e[r]);
                        return n
                    }, e.objectWithoutProperties = e.objectWithoutPropertiesLoose, e.taggedTemplateLiteralLoose = function(e, t) {
                        return t || (t = e.slice(0)), e.raw = t, e
                    }, e.bind = n("ES5FunctionPrototype").bind, a.exports = e
                }), null);
                var ES = require('ES');
                var babelHelpers = require('sdk.babelHelpers');
                (function(e, t) {
                    var n = "keys",
                        r = "values",
                        o = "entries",
                        a = (function() {
                            var e = l(Array),
                                a;
                            return e || (a = (function() {
                                "use strict";

                                function e(e, t) {
                                    this.$1 = e, this.$2 = t, this.$3 = 0
                                }
                                var a = e.prototype;
                                return a.next = function() {
                                    if (this.$1 == null) return {
                                        value: t,
                                        done: !0
                                    };
                                    var e = this.$1,
                                        a = this.$1.length,
                                        i = this.$3,
                                        l = this.$2;
                                    if (i >= a) return this.$1 = t, {
                                        value: t,
                                        done: !0
                                    };
                                    if (this.$3 = i + 1, l === n) return {
                                        value: i,
                                        done: !1
                                    };
                                    if (l === r) return {
                                        value: e[i],
                                        done: !1
                                    };
                                    if (l === o) return {
                                        value: [i, e[i]],
                                        done: !1
                                    }
                                }, a[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] = function() {
                                    return this
                                }, e
                            })()), {
                                keys: e ? function(e) {
                                    return e.keys()
                                } : function(e) {
                                    return new a(e, n)
                                },
                                values: e ? function(e) {
                                    return e.values()
                                } : function(e) {
                                    return new a(e, r)
                                },
                                entries: e ? function(e) {
                                    return e.entries()
                                } : function(e) {
                                    return new a(e, o)
                                }
                            }
                        })(),
                        i = (function() {
                            var e = l(String),
                                n;
                            return e || (n = (function() {
                                "use strict";

                                function e(e) {
                                    this.$1 = e, this.$2 = 0
                                }
                                var n = e.prototype;
                                return n.next = function() {
                                    if (this.$1 == null) return {
                                        value: t,
                                        done: !0
                                    };
                                    var e = this.$2,
                                        n = this.$1,
                                        r = n.length;
                                    if (e >= r) return this.$1 = t, {
                                        value: t,
                                        done: !0
                                    };
                                    var o, a = n.charCodeAt(e);
                                    if (a < 55296 || a > 56319 || e + 1 === r) o = n[e];
                                    else {
                                        var i = n.charCodeAt(e + 1);
                                        i < 56320 || i > 57343 ? o = n[e] : o = n[e] + n[e + 1]
                                    }
                                    return this.$2 = e + o.length, {
                                        value: o,
                                        done: !1
                                    }
                                }, n[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] = function() {
                                    return this
                                }, e
                            })()), {
                                keys: function() {
                                    throw TypeError("Strings default iterator doesn't implement keys.")
                                },
                                values: e ? function(e) {
                                    return e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"]()
                                } : function(e) {
                                    return new n(e)
                                },
                                entries: function() {
                                    throw TypeError("Strings default iterator doesn't implement entries.")
                                }
                            }
                        })();

                    function l(e) {
                        return typeof e.prototype[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] == "function" && typeof e.prototype.values == "function" && typeof e.prototype.keys == "function" && typeof e.prototype.entries == "function"
                    }
                    var s = (function() {
                            "use strict";

                            function e(e, t) {
                                this.$1 = e, this.$2 = t, this.$3 = Object.keys(e), this.$4 = 0
                            }
                            var a = e.prototype;
                            return a.next = function() {
                                var e = this.$3.length,
                                    a = this.$4,
                                    i = this.$2,
                                    l = this.$3[a];
                                if (a >= e) return this.$1 = t, {
                                    value: t,
                                    done: !0
                                };
                                if (this.$4 = a + 1, i === n) return {
                                    value: l,
                                    done: !1
                                };
                                if (i === r) return {
                                    value: this.$1[l],
                                    done: !1
                                };
                                if (i === o) return {
                                    value: [l, this.$1[l]],
                                    done: !1
                                }
                            }, a[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] = function() {
                                return this
                            }, e
                        })(),
                        u = {
                            keys: function(t) {
                                return new s(t, n)
                            },
                            values: function(t) {
                                return new s(t, r)
                            },
                            entries: function(t) {
                                return new s(t, o)
                            }
                        };

                    function c(e, t) {
                        return typeof e == "string" ? i[t || r](e) : Array.isArray(e) ? a[t || r](e) : e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] ? e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"]() : u[t || o](e)
                    }
                    ES("Object", "assign", !1, c, {
                        KIND_KEYS: n,
                        KIND_VALUES: r,
                        KIND_ENTRIES: o,
                        keys: function(t) {
                            return c(t, n)
                        },
                        values: function(t) {
                            return c(t, r)
                        },
                        entries: function(t) {
                            return c(t, o)
                        },
                        generic: u.entries
                    }), e.FB_enumerate = c
                })(typeof global == "object" ? global : typeof this == "object" ? this : typeof window == "object" ? window : typeof self == "object" ? self : {});
                (function(e, t) {
                    var n = e.window || e;

                    function r() {
                        return "f" + (Math.random() * (1 << 30)).toString(16).replace(".", "")
                    }

                    function o(e) {
                        var t = e ? e.ownerDocument || e : document,
                            r = t.defaultView || n;
                        return !!(e && (typeof r.Node == "function" ? e instanceof r.Node : typeof e == "object" && typeof e.nodeType == "number" && typeof e.nodeName == "string"))
                    }

                    function a(e) {
                        var t = n[e];
                        if (t == null || typeof n.Symbol != "function") return !0;
                        var r = t.prototype;
                        return t == null || typeof t != "function" || typeof r.clear != "function" || new t().size !== 0 || typeof r.keys != "function" || typeof r.forEach != "function"
                    }
                    var i = e.FB_enumerate,
                        l = (function() {
                            if (!a("Map")) return n.Map;
                            var e = "key",
                                l = "value",
                                s = "key+value",
                                u = "$map_",
                                c, d = "IE_HASH_",
                                m = (function() {
                                    "use strict";

                                    function n(e) {
                                        if (!h(this)) throw new TypeError("Wrong map object type.");
                                        if (g(this), e != null)
                                            for (var t = i(e), n; !(n = t.next()).done;) {
                                                if (!h(n.value)) throw new TypeError("Expected iterable items to be pair objects.");
                                                this.set(n.value[0], n.value[1])
                                            }
                                    }
                                    var r = n.prototype;
                                    return r.clear = function() {
                                        g(this)
                                    }, r.has = function(t) {
                                        var e = _(this, t);
                                        return !!(e != null && this._mapData[e])
                                    }, r.set = function(t, n) {
                                        var e = _(this, t);
                                        return e != null && this._mapData[e] ? this._mapData[e][1] = n : (e = this._mapData.push([t, n]) - 1, f(this, t, e), this.size += 1), this
                                    }, r.get = function(n) {
                                        var e = _(this, n);
                                        return e == null ? t : this._mapData[e][1]
                                    }, r.delete = function(n) {
                                        var e = _(this, n);
                                        return e != null && this._mapData[e] ? (f(this, n, t), this._mapData[e] = t, this.size -= 1, !0) : !1
                                    }, r.entries = function() {
                                        return new p(this, s)
                                    }, r.keys = function() {
                                        return new p(this, e)
                                    }, r.values = function() {
                                        return new p(this, l)
                                    }, r.forEach = function(n, r) {
                                        if (typeof n != "function") throw new TypeError("Callback must be callable.");
                                        for (var e = ES(n, "bind", !0, r || t), o = this._mapData, a = 0; a < o.length; a++) {
                                            var i = o[a];
                                            i != null && e(i[1], i[0], this)
                                        }
                                    }, r[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] = function() {
                                        return this.entries()
                                    }, n
                                })(),
                                p = (function() {
                                    "use strict";

                                    function n(t, n) {
                                        if (!(h(t) && t._mapData)) throw new TypeError("Object is not a map.");
                                        if ([e, s, l].indexOf(n) === -1) throw new Error("Invalid iteration kind.");
                                        this._map = t, this._nextIndex = 0, this._kind = n
                                    }
                                    var r = n.prototype;
                                    return r.next = function() {
                                        if (!this instanceof m) throw new TypeError("Expected to be called on a MapIterator.");
                                        var n = this._map,
                                            r = this._nextIndex,
                                            o = this._kind;
                                        if (n == null) return y(t, !0);
                                        for (var a = n._mapData; r < a.length;) {
                                            var i = a[r];
                                            if (r += 1, this._nextIndex = r, i) {
                                                if (o === e) return y(i[0], !1);
                                                if (o === l) return y(i[1], !1);
                                                if (o) return y(i, !1)
                                            }
                                        }
                                        return this._map = t, y(t, !0)
                                    }, r[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] = function() {
                                        return this
                                    }, n
                                })();

                            function _(e, n) {
                                if (h(n)) {
                                    var r = S(n);
                                    return r ? e._objectIndex[r] : t
                                } else {
                                    var o = u + n;
                                    return typeof n == "string" ? e._stringIndex[o] : e._otherIndex[o]
                                }
                            }

                            function f(e, t, n) {
                                var r = n == null;
                                if (h(t)) {
                                    var o = S(t);
                                    o || (o = R(t)), r ? delete e._objectIndex[o] : e._objectIndex[o] = n
                                } else {
                                    var a = u + t;
                                    typeof t == "string" ? r ? delete e._stringIndex[a] : e._stringIndex[a] = n : r ? delete e._otherIndex[a] : e._otherIndex[a] = n
                                }
                            }

                            function g(e) {
                                e._mapData = [], e._objectIndex = {}, e._stringIndex = {}, e._otherIndex = {}, e.size = 0
                            }

                            function h(e) {
                                return e != null && (typeof e == "object" || typeof e == "function")
                            }

                            function y(e, t) {
                                return {
                                    value: e,
                                    done: t
                                }
                            }
                            m.__isES5 = (function() {
                                try {
                                    return Object.defineProperty({}, "__.$#x", {}), !0
                                } catch (e) {
                                    return !1
                                }
                            })();

                            function C(e) {
                                return !m.__isES5 || !Object.isExtensible ? !0 : Object.isExtensible(e)
                            }

                            function b(e) {
                                var t;
                                switch (e.nodeType) {
                                    case 1:
                                        t = e.uniqueID;
                                        break;
                                    case 9:
                                        t = e.documentElement.uniqueID;
                                        break;
                                    default:
                                        return null
                                }
                                return t ? d + t : null
                            }
                            var v = r();

                            function S(e) {
                                if (e[v]) return e[v];
                                if (!m.__isES5 && e.propertyIsEnumerable && e.propertyIsEnumerable[v]) return e.propertyIsEnumerable[v];
                                if (!m.__isES5 && o(e) && b(e)) return b(e);
                                if (!m.__isES5 && e[v]) return e[v]
                            }
                            var R = (function() {
                                var e = Object.prototype.propertyIsEnumerable,
                                    t = 0;
                                return function(r) {
                                    if (C(r)) {
                                        if (t += 1, m.__isES5) Object.defineProperty(r, v, {
                                            enumerable: !1,
                                            writable: !1,
                                            configurable: !1,
                                            value: t
                                        });
                                        else if (r.propertyIsEnumerable) r.propertyIsEnumerable = function() {
                                            return e.apply(this, arguments)
                                        }, r.propertyIsEnumerable[v] = t;
                                        else if (o(r)) r[v] = t;
                                        else throw new Error("Unable to set a non-enumerable property on object.");
                                        return t
                                    } else throw new Error("Non-extensible objects are not allowed as keys.")
                                }
                            })();
                            return __annotator(m, {
                                name: "Map"
                            })
                        })(),
                        s = (function() {
                            if (!a("Set")) return n.Set;
                            var e = (function() {
                                "use strict";

                                function e(e) {
                                    if (this == null || typeof this != "object" && typeof this != "function") throw new TypeError("Wrong set object type.");
                                    if (t(this), e != null)
                                        for (var n = i(e), r; !(r = n.next()).done;) this.add(r.value)
                                }
                                var n = e.prototype;
                                return n.add = function(t) {
                                    return this._map.set(t, t), this.size = this._map.size, this
                                }, n.clear = function() {
                                    t(this)
                                }, n.delete = function(t) {
                                    var e = this._map.delete(t);
                                    return this.size = this._map.size, e
                                }, n.entries = function() {
                                    return this._map.entries()
                                }, n.forEach = function(t) {
                                    for (var e = arguments[1], n = this._map.keys(), r; !(r = n.next()).done;) t.call(e, r.value, r.value, this)
                                }, n.has = function(t) {
                                    return this._map.has(t)
                                }, n.values = function() {
                                    return this._map.values()
                                }, n.keys = function() {
                                    return this.values()
                                }, n[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] = function() {
                                    return this.values()
                                }, e
                            })();

                            function t(e) {
                                e._map = new l, e.size = e._map.size
                            }
                            return __annotator(e, {
                                name: "Set"
                            })
                        })();
                    e.Map = l, e.Set = s
                })(typeof globalThis != "undefined" ? globalThis : typeof global != "undefined" ? global : typeof window != "undefined" ? window : typeof this != "undefined" ? this : typeof self != "undefined" ? self : {});
                __d("cr:1126", [], function(g, r, rd, rl, m, e) {
                    m.exports = require("TimeSliceImpl");
                });
                __d("cr:986633", [], function(g, r, rd, rl, m, e) {
                    m.exports = require("setTimeoutAcrossTransitionsBlue");
                });
                __d("cr:7391", [], function(g, r, rd, rl, m, e) {
                    m.exports = require("setTimeoutAcrossTransitionsWWW");
                });
                __d("cr:6640", [], function(g, r, rd, rl, m, e) {
                    m.exports = require("PromiseImpl");
                });
                __d("PromiseUsePolyfillSetImmediateGK", [], {
                    "www_always_use_polyfill_setimmediate": false
                });
                __d("ImmediateImplementationExperiments", [], {
                    "prefer_message_channel": true
                });
                __d("JSSDKCanvasPrefetcherConfig", [], {
                    "enabled": true,
                    "excludedAppIds": [144959615576466, 768691303149786, 320528941393723],
                    "sampleRate": 500
                });
                __d("JSSDKConfig", [], {
                    "features": {
                        "allow_non_canvas_app_events": false,
                        "error_handling": {
                            "rate": 4
                        },
                        "e2e_ping_tracking": {
                            "rate": 0.1
                        },
                        "xd_timeout": {
                            "rate": 1,
                            "value": 60000
                        },
                        "use_bundle": false,
                        "should_log_response_error": true,
                        "popup_blocker_scribe_logging": {
                            "rate": 100
                        },
                        "https_only_enforce_starting": 2538809200000,
                        "https_only_learn_more": "https:\/\/developers.facebook.com\/blog\/post\/2018\/06\/08\/enforce-https-facebook-login\/",
                        "https_only_scribe_logging": {
                            "rate": 1
                        },
                        "log_perf": {
                            "rate": 0.001
                        },
                        "use_x_xd": {
                            "rate": 100
                        },
                        "cache_auth_response": {
                            "rate": 100
                        },
                        "oauth_funnel_logger_version": 1,
                        "force_popup_to_canvas_apps_with_id": [],
                        "force_popup_to_all_canvas_app": false,
                        "max_oauth_dialog_retries": {
                            "rate": 100,
                            "value": 10
                        },
                        "plugin_tags_blacklist": [],
                        "idle_callback_wait_time_ms": 3000,
                        "chat_plugin_facade_timeout_ms": 8000,
                        "chat_plugin_facade_enabled_pageids": ["102493178867330", "107331571710078", "1032787970130843", "107771111665395", "261907812360345", "101305975654752", "275483104252055", "101664622285042", "112682113428700", "271628573687012", "385757598521443", "100545935690488"],
                        "should_enable_ig_login_status_fetch": true,
                        "log_cookies_usage": {
                            "rate": 0.1
                        },
                        "allow_shadow_dom_for_apps_with_id": [520916077950649, 152351391599356, 132081130190180, 468663283258845, 409976882430412, 189845245141894, 360467581347, 274266067164],
                        "allow_shadow_dom": true,
                        "use_extended_dialog_path": {
                            "rate": 100
                        },
                        "use_oauth_subdomain": {
                            "rate": 100
                        }
                    }
                });
                __d("JSSDKCssConfig", [], {
                    "rules": ".fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0px;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:lucida grande,tahoma,verdana,arial,sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:400;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}\u0040keyframes fb_transform{0\u0025{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}\n\n.fb_dialog{background:#525252b3;position:absolute;top:-10000px;z-index:10001}.fb_dialog_advanced{border-radius:8px;padding:10px}.fb_dialog_content{background:#fff;color:#373737}.fb_dialog_close_icon{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/yq\/r\/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{left:5px;right:auto;top:5px}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/yq\/r\/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/yq\/r\/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:700;margin:0}.fb_dialog_content .dialog_title>span{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/yd\/r\/Cou7n-nqK52.gif) no-repeat 5px 50\u0025;float:left;padding:5px 0 7px 26px}body.fb_hidden{height:100\u0025;left:0;margin:0;overflow:visible;position:absolute;top:-10000px;transform:none;width:100\u0025}.fb_dialog.fb_dialog_mobile.loading{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/ya\/r\/3rhSv5V8j3o.gif) #fff no-repeat 50\u0025 50\u0025;min-height:100\u0025;min-width:100\u0025;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{background:none;height:auto;min-height:initial;min-width:initial;width:auto}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100\u0025}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{clear:both;color:#fff;display:block;font-size:18px;padding-top:20px}#fb-root #fb_dialog_ipad_overlay{background:#0006;inset:0;min-height:100\u0025;position:absolute;width:100\u0025;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_mobile .fb_dialog_iframe{position:sticky;top:0}.fb_dialog_content .dialog_header{background:linear-gradient(from(#738aba),to(#2c4987));border-bottom:1px solid;border-color:#043b87;box-shadow:#fff 0 1px 1px -1px inset;color:#fff;font:700 14px Helvetica,sans-serif;text-overflow:ellipsis;text-shadow:rgba(0,30,84,.296875) 0px -1px 0px;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{height:43px;width:100\u0025}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:linear-gradient(from(#4267B2),to(#2a4887));background-clip:padding-box;border:1px solid #29487d;border-radius:3px;display:inline-block;line-height:18px;margin-top:3px;max-width:85px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{background:none;border:none;color:#fff;font:700 12px Helvetica,sans-serif;margin:2px -12px;padding:2px 6px 3px;text-shadow:rgba(0,30,84,.296875) 0px -1px 0px}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:700;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/y9\/r\/jKEcVPZFk-2.gif) no-repeat 50\u0025 50\u0025;border:1px solid #4A4A4A;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f5f6f7;border:1px solid #4A4A4A;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https:\/\/connect.facebook.net\/rsrc.php\/v4\/y2\/r\/onuUJj0tCqE.png);background-position:50\u0025 50\u0025;background-repeat:no-repeat;height:24px;width:24px}\u0040keyframes rotateSpinner{0\u0025{transform:rotate(0)}to{transform:rotate(360deg)}}\n\n.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100\u0025}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100\u0025}\n",
                    "components": ["css:fb.css.base", "css:fb.css.dialog", "css:fb.css.iframewidget"]
                });
                __d("JSSDKRuntimeConfig", [], {
                    "locale": "en_US",
                    "revision": "1033555463",
                    "rtl": false,
                    "sdkab": null,
                    "sdkns": "",
                    "sdkurl": "https:\/\/connect.facebook.net\/en_US\/sdk.js",
                    "scribeurl": "https:\/\/www.facebook.com\/platform\/scribe_endpoint.php\/"
                });
                __d("JSSDKXDConfig", [], {
                    "XXdUrl": "\/x\/connect\/xd_arbiter\/?version=46",
                    "useCdn": true
                });
                __d("UrlMapConfig", [], {
                    "www": "www.facebook.com",
                    "m": "m.facebook.com",
                    "business": "business.facebook.com",
                    "api": "api.facebook.com",
                    "api_read": "api-read.facebook.com",
                    "graph": "graph.facebook.com",
                    "an": "an.facebook.com",
                    "oauth": "oauth.facebook.com",
                    "fbcdn": "static.xx.fbcdn.net",
                    "cdn": "staticxx.facebook.com",
                    "graph_facebook": "graph.facebook.com",
                    "graph_gaming": "graph.fb.gg",
                    "graph_instagram": "graph.instagram.com",
                    "www_instagram": "www.instagram.com",
                    "social_plugin": "socialplugin.facebook.net"
                });
                __d("JSSDKShadowCssConfig", [], {
                    "css:fb.shadow.css.fb_login_button": ".fb_login_button_container{align-content:center;align-items:center;border:0;color:#fff;display:flex;font-family:Roboto,Freight Sans LF Pro,Helvetica,Arial,Lucida Grande,sans-serif;font-weight:700;margin:auto}.fb-button-main-element{display:flex;flex-wrap:nowrap;overflow:hidden}.fb-iframe-overlay{display:flex}.fb-button-main-element:hover{cursor:pointer}.fb-button-main-element:focus{filter:brightness(80\u0025)}.fb_button_label_element{align-items:center;display:flex;font-weight:700;justify-content:center}.fb_button_label{margin:auto;pointer-events:none}.fb_button_svg_logo{height:1.33em;margin-left:.4em;margin-right:.4em;padding:.065em}.login_fb_logo .f_logo_f{fill:transparent}.single_button_svg_logo{margin-bottom:.08em}\n"
                });
                __d("Env", [], function(t, n, r, o, a, i) {
                    var e = {
                        ajaxpipe_token: null,
                        compat_iframe_token: null,
                        iframeKey: "",
                        iframeTarget: "",
                        iframeToken: "",
                        isCQuick: !1,
                        jssp_header_sent: !1,
                        jssp_targeting_enabled: !1,
                        loadHyperion: !1,
                        start: Date.now(),
                        nocatch: !1,
                        useTrustedTypes: !1,
                        isTrustedTypesReportOnly: !1,
                        enableDefaultTrustedTypesPolicy: !1,
                        ig_server_override: "",
                        barcelona_server_override: "",
                        ig_mqtt_wss_endpoint: "",
                        ig_mqtt_polling_endpoint: ""
                    };
                    t.Env && ES("Object", "assign", !1, e, t.Env), t.Env = e;
                    var l = e;
                    i.default = l
                }, 66);
                __d("performance", [], (function(t, n, r, o, a, i) {
                    "use strict";
                    var e = t.performance || t.msPerformance || t.webkitPerformance || {},
                        l = e;
                    i.default = l
                }), 66);
                __d("performanceNow", ["performance"], (function(t, n, r, o, a, i, l) {
                    var e, s;
                    if ((e || (e = r("performance"))).now) s = function() {
                        return (e || (e = r("performance"))).now()
                    };
                    else {
                        var u = t._cstart,
                            c = Date.now(),
                            d = typeof u == "number" && u < c ? u : c,
                            m = 0;
                        s = function() {
                            var e = Date.now(),
                                t = e - d;
                            return t < m && (d -= m - t, t = e - d), m = t, t
                        }
                    }
                    var p = s;
                    l.default = p
                }), 98);
                __d("removeFromArray", [], (function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e, t) {
                        var n = e.indexOf(t);
                        n !== -1 && e.splice(n, 1)
                    }
                    i.default = e
                }), 66);
                __d("fb-error", ["performanceNow", "removeFromArray"], function(t, n, r, o, a, i) {
                    "use strict";
                    var e, l = {
                        PREVIOUS_FILE: 1,
                        PREVIOUS_FRAME: 2,
                        PREVIOUS_DIR: 3,
                        FORCED_KEY: 4
                    };

                    function s(e) {
                        var t = new Error(e);
                        if (t.stack === void 0) try {
                            throw t
                        } catch (e) {}
                        t.messageFormat = e;
                        for (var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++) r[o - 1] = arguments[o];
                        return t.messageParams = r.map(function(e) {
                            return String(e)
                        }), t.taalOpcodes = [l.PREVIOUS_FRAME], t
                    }
                    var u = !1,
                        c = {
                            errorListener: function(n) {
                                var e = t.console,
                                    r = e[n.type] ? n.type : "error";
                                if (n.type === "fatal" || r === "error" && !u) {
                                    var o = n.message;
                                    e.error("ErrorUtils caught an error:\n\n" + o + "\n\nSubsequent non-fatal errors won't be logged; see https://fburl.com/debugjs.", n), u = !0
                                }
                            }
                        },
                        d = {
                            skipDupErrorGuard: !1
                        },
                        m = {
                            config: d,
                            setup: _
                        },
                        p = !1;

                    function _(e) {
                        p === !1 && (p = !0, m.config = Object.freeze(e))
                    }
                    var f = {
                            access_token: null
                        },
                        g = 6,
                        h = 6e4,
                        y = 10 * h,
                        C = new Map,
                        b = 0;

                    function v() {
                        var t = (e || (e = n("performanceNow")))();
                        if (t > b + h) {
                            var r = t - y;
                            for (var o of C) {
                                var a = o[0],
                                    i = o[1];
                                i.lastAccessed < r && C.delete(a)
                            }
                            b = t
                        }
                    }

                    function S(t) {
                        v();
                        var r = (e || (e = n("performanceNow")))(),
                            o = C.get(t);
                        if (o == null) return C.set(t, {
                            dropped: 0,
                            logged: [r],
                            lastAccessed: r
                        }), 1;
                        var a = o.dropped,
                            i = o.logged;
                        for (o.lastAccessed = r; i[0] < r - h;) i.shift();
                        return i.length < g ? (o.dropped = 0, i.push(r), a + 1) : (o.dropped++, null)
                    }
                    var R = {
                            shouldLog: function(t) {
                                return S(t.hash)
                            }
                        },
                        L = "RE_EXN_ID";

                    function E(e) {
                        var t = null;
                        return e == null || typeof e != "object" ? t = s("Non-object thrown: %s", String(e)) : Object.prototype.hasOwnProperty.call(e, L) ? t = s("Rescript exception thrown: %s", ES("JSON", "stringify", !1, e)) : typeof(e == null ? void 0 : e.then) == "function" ? t = s("Promise thrown: %s", ES("JSON", "stringify", !1, e)) : typeof e.message != "string" ? t = s("Non-error thrown: %s, keys: %s", String(e), ES("JSON", "stringify", !1, Object.keys(e).sort())) : e.messageFormat != null && typeof e.messageFormat != "string" ? t = s("Error with non-string messageFormat thrown: %s, %s, keys: %s", String(e.message), String(e), ES("JSON", "stringify", !1, Object.keys(e).sort())) : Object.isExtensible && !Object.isExtensible(e) && (t = s("Non-extensible thrown: %s", String(e.message))), t != null ? (t.taalOpcodes = t.taalOpcodes || [], t.taalOpcodes.push(l.PREVIOUS_FRAME), t) : e
                    }
                    var k = typeof window == "undefined" ? "<self.onerror>" : "<window.onerror>",
                        I;

                    function T(e) {
                        var t, n = e.error != null ? E(e.error) : s(e.message || "");
                        n.fileName == null && e.filename != null && (n.fileName = e.filename), n.line == null && e.lineno != null && (n.line = e.lineno), n.column == null && e.colno != null && (n.column = e.colno), n.guardList = [k], n.loggingSource = "ONERROR", (t = I) === null || t === void 0 || t.reportError(n)
                    }
                    var D = {
                            setup: function(n) {
                                typeof t.addEventListener == "function" && I == null && (I = n, t.addEventListener("error", T))
                            }
                        },
                        x = [],
                        $ = {
                            pushGuard: function(t) {
                                x.unshift(t)
                            },
                            popGuard: function() {
                                x.shift()
                            },
                            inGuard: function() {
                                return x.length !== 0
                            },
                            cloneGuardList: function() {
                                return x.map(function(e) {
                                    return e.name
                                })
                            },
                            findDeferredSource: function() {
                                for (var e of x)
                                    if (e.deferredSource != null) return e.deferredSource
                            }
                        };

                    function P(e) {
                        return e.type != null ? e.type : e.loggingSource == "GUARDED" || e.loggingSource == "ERROR_BOUNDARY" || e.name == "SyntaxError" ? "fatal" : e.loggingSource == "ONERROR" && e.message.indexOf("ResizeObserver loop") >= 0 || e.stack != null && e.stack.indexOf("chrome-extension://") >= 0 ? "warn" : "error"
                    }
                    var N = [],
                        M = (function() {
                            function e() {
                                this.metadata = [].concat(N)
                            }
                            var t = e.prototype;
                            return t.addEntries = function() {
                                var e;
                                return (e = this.metadata).push.apply(e, arguments), this
                            }, t.addEntry = function(t, n, r) {
                                return this.metadata.push([t, n, r]), this
                            }, t.isEmpty = function() {
                                return this.metadata.length === 0
                            }, t.clearEntries = function() {
                                this.metadata = []
                            }, t.format = function() {
                                var e = [];
                                return this.metadata.forEach(function(t) {
                                    if (t && t.length) {
                                        var n = t.map(function(e) {
                                            return e != null ? String(e).replace(/:/g, "_") : ""
                                        }).join(":");
                                        e.push(n)
                                    }
                                }), e
                            }, t.getAll = function() {
                                return this.metadata
                            }, e.addGlobalMetadata = function(t, n, r) {
                                N.push([t, n, r])
                            }, e.getGlobalMetadata = function() {
                                return N
                            }, e.unsetGlobalMetadata = function(t, n) {
                                N = N.filter(function(e) {
                                    return !(Array.isArray(e) && e[0] === t && e[1] === n)
                                })
                            }, e
                        })(),
                        w = {
                            debug: 1,
                            info: 2,
                            warn: 3,
                            error: 4,
                            fatal: 5
                        };

                    function A(e, t) {
                        var n, r;
                        if (!Object.isFrozen(e)) {
                            t.type && (!e.type || w[e.type] > w[t.type]) && (e.type = t.type);
                            var o = t.metadata;
                            if (o != null) {
                                var a, i = (a = e.metadata) !== null && a !== void 0 ? a : new M;
                                o != null && i.addEntries.apply(i, o.getAll()), e.metadata = i
                            }
                            t.project != null && (e.project = t.project), t.errorName != null && (e.errorName = t.errorName), t.componentStack != null && (e.componentStack = t.componentStack), t.deferredSource != null && (e.deferredSource = t.deferredSource), t.blameModule != null && (e.blameModule = t.blameModule), t.loggingSource != null && (e.loggingSource = t.loggingSource);
                            var l = (n = e.messageFormat) !== null && n !== void 0 ? n : e.message,
                                s = (r = e.messageParams) !== null && r !== void 0 ? r : [];
                            if (l !== t.messageFormat && t.messageFormat != null) {
                                var u;
                                l += " [Caught in: " + t.messageFormat + "]", s.push.apply(s, (u = t.messageParams) !== null && u !== void 0 ? u : [])
                            }
                            e.messageFormat = l, e.messageParams = s;
                            var c = t.forcedKey,
                                d = e.forcedKey,
                                m = c != null && d != null ? c + "_" + d : c != null ? c : d;
                            e.forcedKey = m
                        }
                    }

                    function F(e) {
                        var t;
                        return O((t = e.messageFormat) !== null && t !== void 0 ? t : e.message, e.messageParams || [])
                    }

                    function O(e, t) {
                        var n = 0,
                            r = String(e),
                            o = r.replace(/%s/g, function() {
                                return n < t.length ? t[n++] : "NOPARAM"
                            });
                        return n < t.length && (o += " PARAMS" + ES("JSON", "stringify", !1, t.slice(n))), o
                    }

                    function B(e) {
                        return (e != null ? e : []).map(function(e) {
                            return String(e)
                        })
                    }
                    var W = {
                            aggregateError: A,
                            toReadableMessage: F,
                            toStringParams: B
                        },
                        q = 5,
                        U = [];

                    function V(e) {
                        U.push(e), U.length > q && U.shift()
                    }

                    function H(e) {
                        var t = e.getAllResponseHeaders();
                        if (t != null && t.indexOf("X-FB-Debug") >= 0) {
                            var n = e.getResponseHeader("X-FB-Debug");
                            n && V(n)
                        }
                    }

                    function G() {
                        return U
                    }
                    var z = {
                            add: V,
                            addFromXHR: H,
                            getAll: G
                        },
                        j = "abcdefghijklmnopqrstuvwxyz012345";

                    function K() {
                        for (var e = 0, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                        for (var o of n)
                            if (o != null)
                                for (var a = o.length, i = 0; i < a; i++) e = (e << 5) - e + o.charCodeAt(i);
                        for (var l = "", s = 0; s < 6; s++) l = j.charAt(e & 31) + l, e >>= 5;
                        return l
                    }
                    var Q = [/\(([^\s\)\()]+):(\d+):(\d+)\)$/, /@([^\s\)\()]+):(\d+):(\d+)$/, /^([^\s\)\()]+):(\d+):(\d+)$/, /^at ([^\s\)\()]+):(\d+):(\d+)$/],
                        X = /^\w+:\s.*?\n/g;
                    Error.stackTraceLimit != null && Error.stackTraceLimit < 80 && (Error.stackTraceLimit = 80);

                    function Y(e) {
                        var t = e.message,
                            n = e.name,
                            r = e.stack;
                        if (r == null) return null;
                        if (n != null && t != null && t !== "") {
                            var o = n + ": " + t + "\n";
                            if (ES(r, "startsWith", !0, o)) return r.substr(o.length);
                            if (r === n + ": " + t) return null
                        }
                        if (n != null) {
                            var a = n + "\n";
                            if (ES(r, "startsWith", !0, a)) return r.substr(a.length)
                        }
                        if (t != null && t !== "") {
                            var i = ": " + t + "\n",
                                l = r.indexOf(i),
                                s = r.substring(0, l);
                            if (/^\w+$/.test(s)) return r.substring(l + i.length)
                        }
                        return r.replace(X, "")
                    }

                    function J(e) {
                        var t = e.trim(),
                            n = t,
                            r, o, a;
                        if (ES(t, "includes", !0, "charset=utf-8;base64,")) n = "<inlined-file>";
                        else {
                            var i;
                            for (var l of Q)
                                if (i = t.match(l), i != null) break;
                            i != null && i.length === 4 ? (r = i[1], o = parseInt(i[2], 10), a = parseInt(i[3], 10), n = t.substring(0, t.length - i[0].length)) : n = t, n = n.replace(/^at /, "").trim()
                        }
                        var s = {
                            identifier: n,
                            script: r,
                            line: o,
                            column: a
                        };
                        return s.text = ne(s), s
                    }

                    function Z(e) {
                        return e == null || e === "" ? [] : e.split(/\n\n/)[0].split("\n").map(J)
                    }

                    function ee(e) {
                        var t = Y(e);
                        return Z(t)
                    }

                    function te(e) {
                        if (e == null || e === "") return null;
                        var t = e.split("\n");
                        return t.splice(0, 1), t.map(function(e) {
                            return e.trim()
                        })
                    }

                    function ne(e) {
                        var t = e.column,
                            n = e.identifier,
                            r = e.line,
                            o = e.script,
                            a = "    at " + (n != null ? n : "<unknown>");
                        return o != null && r != null && t != null && (a += " (" + o + ":" + r + ":" + t + ")"), a
                    }

                    function re(r) {
                        var o, a, i, s, u, c, d, m, p, _, f = ee(r),
                            g = (o = r.taalOpcodes) !== null && o !== void 0 ? o : [],
                            h = r.framesToPop;
                        if (h != null)
                            for (h = Math.min(h, f.length); h-- > 0;) g.unshift(l.PREVIOUS_FRAME);
                        var y = (a = r.messageFormat) !== null && a !== void 0 ? a : r.message,
                            C = ((i = r.messageParams) !== null && i !== void 0 ? i : []).map(function(e) {
                                return String(e)
                            }),
                            b = te(r.componentStack),
                            v = b == null ? null : b.map(J),
                            S = r.metadata ? r.metadata.format() : new M().format();
                        S.length === 0 && (S = void 0);
                        var R = f.map(function(e) {
                                return e.text
                            }).join("\n"),
                            L = (s = r.errorName) !== null && s !== void 0 ? s : r.name,
                            E = P(r),
                            k = r.loggingSource,
                            I = r.project,
                            T = (u = r.lineNumber) !== null && u !== void 0 ? u : r.line,
                            D = (c = r.columnNumber) !== null && c !== void 0 ? c : r.column,
                            x = (d = r.fileName) !== null && d !== void 0 ? d : r.sourceURL,
                            $ = f.length > 0;
                        $ && T == null && (T = f[0].line), $ && D == null && (D = f[0].column), $ && x == null && (x = f[0].script);
                        var N = {
                            blameModule: r.blameModule,
                            cause: r.cause,
                            column: D == null ? null : String(D),
                            clientTime: Math.floor(Date.now() / 1e3),
                            componentStackFrames: v,
                            deferredSource: r.deferredSource != null ? re(r.deferredSource) : null,
                            extra: (m = r.extra) !== null && m !== void 0 ? m : {},
                            fbtrace_id: r.fbtrace_id,
                            guardList: (p = r.guardList) !== null && p !== void 0 ? p : [],
                            hash: K(L, R, E, I, k),
                            isNormalizedError: !0,
                            line: T == null ? null : String(T),
                            loggingSource: k,
                            message: W.toReadableMessage(r),
                            messageFormat: y,
                            messageParams: C,
                            metadata: S,
                            name: L,
                            page_time: Math.floor((e || (e = n("performanceNow")))()),
                            project: I,
                            reactComponentStack: b,
                            script: x,
                            serverHash: r.serverHash,
                            stack: R,
                            stackFrames: f,
                            type: E,
                            xFBDebug: z.getAll(),
                            tags: (_ = r.tags) !== null && _ !== void 0 ? _ : [],
                            operation: r.operation
                        };
                        r.forcedKey != null && (N.forcedKey = r.forcedKey), g.length > 0 && (N.taalOpcodes = g);
                        var w = t.location;
                        w && (N.windowLocationURL = w.href);
                        for (var A in N) N[A] == null && delete N[A];
                        return N
                    }

                    function oe(e) {
                        return e != null && typeof e == "object" && e.isNormalizedError === !0 ? e : null
                    }
                    var ae = {
                            formatStackFrame: ne,
                            normalizeError: re,
                            ifNormalizedError: oe
                        },
                        ie = "<global.react>",
                        le = [],
                        se = [],
                        ue = 50,
                        ce = !1,
                        de = {
                            history: se,
                            addListener: function(t, n) {
                                n === void 0 && (n = !1), le.push(t), n || se.forEach(function(e) {
                                    var n;
                                    return t(e, (n = e.loggingSource) !== null && n !== void 0 ? n : "DEPRECATED")
                                })
                            },
                            unshiftListener: function(t) {
                                le.unshift(t)
                            },
                            removeListener: function(t) {
                                n("removeFromArray")(le, t)
                            },
                            reportError: function(t) {
                                var e = ae.normalizeError(t);
                                de.reportNormalizedError(e)
                            },
                            reportNormalizedError: function(t) {
                                if (ce) return !1;
                                var e = $.cloneGuardList();
                                if (t.componentStackFrames && e.unshift(ie), e.length > 0 && (t.guardList = e), t.deferredSource == null) {
                                    var n = $.findDeferredSource();
                                    n != null && (t.deferredSource = ae.normalizeError(n))
                                }
                                se.length > ue && se.splice(ue / 2, 1), se.push(t), ce = !0;
                                for (var r = 0; r < le.length; r++) try {
                                    var o;
                                    le[r](t, (o = t.loggingSource) !== null && o !== void 0 ? o : "DEPRECATED")
                                } catch (e) {}
                                return ce = !1, !0
                            }
                        };
                    de.addListener(c.errorListener);
                    var me = "<anonymous guard>",
                        pe = !1,
                        _e = {
                            applyWithGuard: function(t, n, r, o) {
                                if (m.config.skipDupErrorGuard && "__isMetaErrorGuarded" in t) return t.apply(n, r);
                                if ($.pushGuard({
                                        name: ((o == null ? void 0 : o.name) != null ? o.name : null) || (t.name ? "func_name:" + t.name : null) || me,
                                        deferredSource: o == null ? void 0 : o.deferredSource
                                    }), pe) try {
                                    return t.apply(n, r)
                                } finally {
                                    $.popGuard()
                                }
                                try {
                                    return Function.prototype.apply.call(t, n, r)
                                } catch (n) {
                                    try {
                                        var e, a = o != null ? o : babelHelpers.extends({}, null),
                                            i = a.deferredSource,
                                            l = a.onError,
                                            s = a.onNormalizedError,
                                            u = E(n),
                                            c = {
                                                deferredSource: i,
                                                loggingSource: "GUARDED",
                                                project: (e = o == null ? void 0 : o.project) !== null && e !== void 0 ? e : "ErrorGuard",
                                                type: o == null ? void 0 : o.errorType
                                            };
                                        W.aggregateError(u, c);
                                        var d = ae.normalizeError(u);
                                        u == null && t && (d.extra[t.toString().substring(0, 100)] = "function", r != null && r.length && (d.extra[ES("Array", "from", !1, r).toString().substring(0, 100)] = "args")), d.guardList = $.cloneGuardList(), l && l(u), s && s(d), de.reportNormalizedError(d)
                                    } catch (e) {}
                                } finally {
                                    $.popGuard()
                                }
                            },
                            guard: function(t, n) {
                                function e() {
                                    for (var e = arguments.length, r = new Array(e), o = 0; o < e; o++) r[o] = arguments[o];
                                    return _e.applyWithGuard(t, this, r, n)
                                }
                                return e.__isMetaErrorGuarded = !0, t.__SMmeta && (e.__SMmeta = t.__SMmeta), e
                            },
                            inGuard: function() {
                                return $.inGuard()
                            },
                            skipGuardGlobal: function(t) {
                                pe = t
                            }
                        },
                        fe = 1024,
                        ge = [],
                        he = 0;

                    function ye(e) {
                        return String(e)
                    }

                    function Ce(e) {
                        return e == null ? null : String(e)
                    }

                    function be(e, t) {
                        var n = {};
                        return t && t.forEach(function(e) {
                            n[e] = !0
                        }), Object.keys(e).forEach(function(t) {
                            e[t] ? n[t] = !0 : n[t] && delete n[t]
                        }), Object.keys(n)
                    }

                    function ve(e) {
                        return (e != null ? e : []).map(function(e) {
                            return {
                                column: Ce(e.column),
                                identifier: e.identifier,
                                line: Ce(e.line),
                                script: e.script
                            }
                        })
                    }

                    function Se(e) {
                        var t = String(e);
                        return t.length > fe ? t.substring(0, fe - 3) + "..." : t
                    }

                    function Re(e, t) {
                        var n, r, o, a, i = {
                                appId: Ce(t.appId),
                                cavalry_lid: t.cavalry_lid,
                                access_token: f.access_token,
                                ancestor_hash: e.hash,
                                bundle_variant: (n = t.bundle_variant) !== null && n !== void 0 ? n : null,
                                clientTime: ye(e.clientTime),
                                column: e.column,
                                componentStackFrames: ve(e.componentStackFrames),
                                events: e.events,
                                extra: be(e.extra, t.extra),
                                forcedKey: e.forcedKey,
                                frontend_env: (r = t.frontend_env) !== null && r !== void 0 ? r : null,
                                guardList: e.guardList,
                                line: e.line,
                                loggingFramework: t.loggingFramework,
                                messageFormat: Se(e.messageFormat),
                                messageParams: e.messageParams.map(Se),
                                name: e.name,
                                sample_weight: Ce(t.sample_weight),
                                script: e.script,
                                site_category: t.site_category,
                                stackFrames: ve(e.stackFrames),
                                type: e.type,
                                page_time: Ce(e.page_time),
                                project: e.project,
                                push_phase: t.push_phase,
                                report_source: t.report_source,
                                report_source_ref: t.report_source_ref,
                                rollout_hash: (o = t.rollout_hash) !== null && o !== void 0 ? o : null,
                                script_path: t.script_path,
                                server_revision: Ce(t.server_revision),
                                spin: Ce(t.spin),
                                svn_rev: String(t.client_revision),
                                additional_client_revisions: ES("Array", "from", !1, (a = t.additional_client_revisions) !== null && a !== void 0 ? a : []).map(ye),
                                taalOpcodes: e.taalOpcodes == null ? null : e.taalOpcodes.map(function(e) {
                                    return e
                                }),
                                web_session_id: t.web_session_id,
                                version: "3",
                                xFBDebug: e.xFBDebug,
                                tags: e.tags
                            },
                            l = e.blameModule,
                            s = e.deferredSource;
                        return l != null && (i.blameModule = String(l)), s && s.stackFrames && (i.deferredSource = {
                            stackFrames: ve(s.stackFrames)
                        }), e.metadata && (i.metadata = e.metadata), e.loadingUrls && (i.loadingUrls = e.loadingUrls), e.serverHash != null && (i.serverHash = e.serverHash), e.windowLocationURL != null && (i.windowLocationURL = e.windowLocationURL), e.loggingSource != null && (i.loggingSource = e.loggingSource), i
                    }

                    function Le(e, t, n) {
                        var r;
                        if (he++, t.sample_weight === 0) return !1;
                        var o = R.shouldLog(e);
                        if (o == null || (r = t.projectBlocklist) !== null && r !== void 0 && ES(r, "includes", !0, e.project)) return !1;
                        var a = Re(e, t);
                        return ES("Object", "assign", !1, a, {
                            ancestors: ge.slice(),
                            clientWeight: ye(o),
                            page_position: ye(he)
                        }), ge.length < 15 && ES(["fatal", "error"], "includes", !0, e.type) && ge.push(e.hash), n(a), !0
                    }
                    var Ee = {
                            createErrorPayload: Re,
                            postError: Le
                        },
                        ke = null,
                        Ie = !1;

                    function Te(e) {
                        if (ke != null) {
                            var t = ke,
                                n = e.reason,
                                r, o = E(n),
                                a = null;
                            if (n !== o && typeof n == "object" && n !== null) {
                                if (r = Object.keys(n).sort().slice(0, 3), typeof n.message != "string" && typeof n.messageFormat == "string" && (n.message = n.messageFormat, o = E(n)), typeof n.message != "string" && typeof n.errorMsg == "string")
                                    if (/^\s*\<!doctype/i.test(n.errorMsg)) {
                                        var i = /<title>([^<]+)<\/title>(?:(?:.|\n)*<h1>([^<]+)<\/h1>)?/im.exec(n.errorMsg);
                                        if (i) {
                                            var l, u;
                                            o = s('HTML document with title="%s" and h1="%s"', (l = i[1]) !== null && l !== void 0 ? l : "", (u = i[2]) !== null && u !== void 0 ? u : "")
                                        } else o = s("HTML document sanitized")
                                    } else /^\s*<\?xml/i.test(n.errorMsg) ? o = s("XML document sanitized") : (n.message = n.errorMsg, o = E(n));
                                o !== n && typeof n.name == "string" && (a = n.name), typeof n.name != "string" && typeof n.errorCode == "string" && (a = "UnhandledRejectionWith_errorCode_" + n.errorCode), typeof n.name != "string" && typeof n.error == "number" && (a = "UnhandledRejectionWith_error_" + String(n.error))
                            }
                            o.loggingSource = "ONUNHANDLEDREJECTION";
                            try {
                                a = o === n && a != null && a !== "" ? a : typeof(n == null ? void 0 : n.name) == "string" && n.name !== "" ? n.name : r != null && r.length > 0 ? "UnhandledRejectionWith_" + r.join("_") : "UnhandledRejection_" + (n === null ? "null" : typeof n), o.name = a
                            } catch (e) {}
                            try {
                                var c = n == null ? void 0 : n.stack;
                                (typeof c != "string" || c === "") && (c = o.stack), (typeof c != "string" || c === "") && (c = s("").stack), o.stack = o.name + ": " + o.message + "\n" + c.split("\n").slice(1).join("\n")
                            } catch (e) {}
                            try {
                                var d = e.promise;
                                o.stack = o.stack + (d != null && typeof d.settledStack == "string" ? "\n    at <promise_settled_stack_below>\n" + d.settledStack : "") + (d != null && typeof d.createdStack == "string" ? "\n    at <promise_created_stack_below>\n" + d.createdStack : "")
                            } catch (e) {}
                            try {
                                var m = e.promise;
                                "__isPromiseWithTracing" in m && m.__isPromiseWithTracing === !0 && m.deferredError != null && (o.deferredSource = E(m.deferredError))
                            } catch (e) {}
                            t.reportError(o), e.preventDefault()
                        }
                    }

                    function De(e) {
                        ke = e, typeof t.addEventListener == "function" && !Ie && (Ie = !0, t.addEventListener("unhandledrejection", Te))
                    }
                    var xe = {
                            onunhandledrejection: Te,
                            setup: De
                        },
                        $e = {
                            preSetup: function(t) {
                                (t == null || t.ignoreOnError !== !0) && D.setup(de), (t == null || t.ignoreOnUnahndledRejection !== !0) && xe.setup(de)
                            },
                            setup: function(t, n, r) {
                                de.addListener(function(e) {
                                    var o, a = babelHelpers.extends({}, t, (o = r == null ? void 0 : r()) !== null && o !== void 0 ? o : {});
                                    Ee.postError(e, a, n)
                                })
                            }
                        },
                        Pe = 20,
                        Ne = (function() {
                            function e(e, t) {
                                var n = this;
                                t === void 0 && (t = []), this.FATAL = function(e) {
                                    for (var t = e.join("%s"), r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), a = 1; a < r; a++) o[a - 1] = arguments[a];
                                    n.fatal.apply(n, [t].concat(o))
                                }, this.MUSTFIX = function(e) {
                                    for (var t = n.getTagString() + e.join("%s"), r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), a = 1; a < r; a++) o[a - 1] = arguments[a];
                                    n.mustfix.apply(n, [t].concat(o))
                                }, this.WARN = function(e) {
                                    for (var t = n.getTagString() + e.join("%s"), r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), a = 1; a < r; a++) o[a - 1] = arguments[a];
                                    n.warn.apply(n, [t].concat(o))
                                }, this.INFO = function(e) {
                                    for (var t = n.getTagString() + e.join("%s"), r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), a = 1; a < r; a++) o[a - 1] = arguments[a];
                                    n.info.apply(n, [t].concat(o))
                                }, this.DEBUG = function(e) {
                                    for (var t = n.getTagString() + e.join("%s"), r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), a = 1; a < r; a++) o[a - 1] = arguments[a];
                                    n.debug.apply(n, [t].concat(o))
                                }, this.project = e, this.events = [], this.metadata = new M, this.taalOpcodes = [], this.loggerTags = new Set(t)
                            }
                            var t = e.prototype;
                            return t.$1 = function(n, r) {
                                for (var t = String(r), o = this.blameModule, a = this.events, i = this.forcedKey, s = this.metadata, u = this.project, c = this.error, d, m = arguments.length, p = new Array(m > 2 ? m - 2 : 0), _ = 2; _ < m; _++) p[_ - 2] = arguments[_];
                                if (this.normalizedError) d = babelHelpers.extends({}, this.normalizedError, {
                                    messageFormat: this.normalizedError.messageFormat + " [Caught in: " + t + "]",
                                    messageParams: W.toStringParams([].concat(this.normalizedError.messageParams, p)),
                                    project: u,
                                    type: n,
                                    loggingSource: "FBLOGGER"
                                }), d.message = W.toReadableMessage(d), i != null && (d.forcedKey = d.forcedKey != null ? i + "_" + d.forcedKey : i);
                                else if (c) this.taalOpcodes.length > 0 && new e("fblogger").blameToPreviousFrame().blameToPreviousFrame().warn("Blame helpers do not work with catching"), W.aggregateError(c, {
                                    messageFormat: t,
                                    messageParams: W.toStringParams(p),
                                    errorName: c.name,
                                    forcedKey: i,
                                    project: u,
                                    type: n,
                                    loggingSource: "FBLOGGER"
                                }), d = ae.normalizeError(c);
                                else {
                                    if (c = new Error(t), c.stack === void 0) try {
                                        throw c
                                    } catch (e) {}
                                    c.messageFormat = t, c.messageParams = W.toStringParams(p), c.blameModule = o, c.forcedKey = i, c.project = u, c.type = n, c.loggingSource = "FBLOGGER", c.taalOpcodes = [l.PREVIOUS_FRAME, l.PREVIOUS_FRAME].concat(this.taalOpcodes), d = ae.normalizeError(c), d.name = "FBLogger"
                                }
                                if (!s.isEmpty())
                                    if (d.metadata == null) d.metadata = s.format();
                                    else {
                                        var f = d.metadata.concat(s.format()),
                                            g = new Set(f);
                                        d.metadata = ES("Array", "from", !1, g.values())
                                    }
                                if (a.length > 0) {
                                    if (d.events != null) {
                                        var h;
                                        (h = d.events).push.apply(h, a)
                                    } else d.events = [].concat(a);
                                    if (d.events != null && d.events.length > Pe) {
                                        var y = d.events.length - Pe;
                                        d.events.splice(0, y + 1, "<first " + y + " events omitted>")
                                    }
                                }
                                return d.tags = ES("Array", "from", !1, this.loggerTags), de.reportNormalizedError(d), c
                            }, t.fatal = function(t) {
                                for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                                this.$1.apply(this, ["fatal", t].concat(n))
                            }, t.mustfix = function(t) {
                                for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                                this.$1.apply(this, ["error", t].concat(n))
                            }, t.warn = function(t) {
                                for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                                this.$1.apply(this, ["warn", t].concat(n))
                            }, t.info = function(t) {
                                for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                                this.$1.apply(this, ["info", t].concat(n))
                            }, t.debug = function(t) {}, t.mustfixThrow = function(t) {
                                for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                                var o = this.$1.apply(this, ["error", t].concat(n));
                                o || (o = s("mustfixThrow does not support catchingNormalizedError"), o.taalOpcodes = o.taalOpcodes || [], o.taalOpcodes.push(l.PREVIOUS_FRAME));
                                try {
                                    o.message = W.toReadableMessage(o)
                                } catch (e) {}
                                throw o.is_js_error = !0, o
                            }, t.catching = function(n) {
                                return n instanceof Error ? this.error = n : new e("fblogger").blameToPreviousFrame().warn("Catching non-Error object is not supported"), this
                            }, t.catchingNormalizedError = function(t) {
                                return this.normalizedError = t, this
                            }, t.event = function(t) {
                                return this.events.push(t), this
                            }, t.blameToModule = function(t) {
                                return this.blameModule = t, this
                            }, t.blameToPreviousFile = function() {
                                return this.taalOpcodes.push(l.PREVIOUS_FILE), this
                            }, t.blameToPreviousFrame = function() {
                                return this.taalOpcodes.push(l.PREVIOUS_FRAME), this
                            }, t.blameToPreviousDirectory = function() {
                                return this.taalOpcodes.push(l.PREVIOUS_DIR), this
                            }, t.addToCategoryKey = function(t) {
                                return this.forcedKey = t, this
                            }, t.addMetadata = function(t, n, r) {
                                return this.metadata.addEntry(t, n, r), this
                            }, t.tags = function(n) {
                                var t = n.concat(ES("Array", "from", !1, this.loggerTags)),
                                    r = new e(this.project, t);
                                return this.events.forEach(function(e) {
                                    return r.event(e)
                                }), this.metadata.getAll().forEach(function(e) {
                                    var t = e[0],
                                        n = e[1],
                                        o = e[2];
                                    return r.addMetadata(t, n, o)
                                }), r
                            }, t.getTagString = function() {
                                var e = this.loggerTags.size > 0 ? "[" + ES("Array", "from", !1, this.loggerTags).join("|") + "] " : "";
                                return e
                            }, e
                        })(),
                        Me = function(t, n) {
                            var e = new Ne(t);
                            return n != null ? e.event(t + "." + n) : e
                        };
                    Me.addGlobalMetadata = function(e, t, n) {
                        M.addGlobalMetadata(e, t, n)
                    };
                    var we = "<CUSTOM_NAME:",
                        Ae = ">";

                    function Fe(e, t) {
                        if (e != null && t != null) try {
                            Object.defineProperty(e, "name", {
                                value: we + " " + t + Ae
                            })
                        } catch (e) {}
                        return e
                    }
                    var Oe = {
                            blameToPreviousFile: function(t) {
                                var e;
                                return t.taalOpcodes = (e = t.taalOpcodes) !== null && e !== void 0 ? e : [], t.taalOpcodes.push(l.PREVIOUS_FILE), t
                            },
                            blameToPreviousFrame: function(t) {
                                var e;
                                return t.taalOpcodes = (e = t.taalOpcodes) !== null && e !== void 0 ? e : [], t.taalOpcodes.push(l.PREVIOUS_FRAME), t
                            },
                            blameToPreviousDirectory: function(t) {
                                var e;
                                return t.taalOpcodes = (e = t.taalOpcodes) !== null && e !== void 0 ? e : [], t.taalOpcodes.push(l.PREVIOUS_DIR), t
                            }
                        },
                        Be = {
                            err: s,
                            ErrorBrowserConsole: c,
                            ErrorConfig: m,
                            ErrorDynamicData: f,
                            ErrorFilter: R,
                            ErrorGlobalEventHandler: D,
                            ErrorGuard: _e,
                            ErrorGuardState: $,
                            ErrorMetadata: M,
                            ErrorNormalizeUtils: ae,
                            ErrorPoster: Ee,
                            ErrorPubSub: de,
                            ErrorSerializer: W,
                            ErrorSetup: $e,
                            ErrorXFBDebug: z,
                            FBLogger: Me,
                            getErrorSafe: E,
                            getSimpleHash: K,
                            TAAL: Oe,
                            TAALOpcode: l,
                            renameFunction: Fe
                        };
                    a.exports = Be
                }, null);
                __d("ErrorGuard", ["fb-error"], (function(t, n, r, o, a, i, l) {
                    "use strict";
                    l.default = r("fb-error").ErrorGuard
                }), 98);
                __d("FBLogger", ["fb-error"], (function(t, n, r, o, a, i, l) {
                    "use strict";
                    l.default = r("fb-error").FBLogger
                }), 98);
                __d("CircularBuffer", ["FBLogger"], (function(t, n, r, o, a, i, l) {
                    var e = (function() {
                        function e(e) {
                            if (e <= 0) throw r("FBLogger")("comet_infra").mustfixThrow("Buffer size should be a positive integer");
                            this.$1 = e, this.$2 = 0, this.$3 = [], this.$4 = []
                        }
                        var t = e.prototype;
                        return t.write = function(t) {
                            var e = this;
                            return this.$3.length < this.$1 ? this.$3.push(t) : (this.$4.forEach(function(t) {
                                return t(e.$3[e.$2])
                            }), this.$3[this.$2] = t, this.$2++, this.$2 %= this.$1), this
                        }, t.onEvict = function(t) {
                            return this.$4.push(t), this
                        }, t.read = function() {
                            return this.$3.slice(this.$2).concat(this.$3.slice(0, this.$2))
                        }, t.expand = function(t) {
                            if (t > this.$1) {
                                var e = this.read();
                                this.$2 = 0, this.$3 = e, this.$1 = t
                            }
                            return this
                        }, t.dropFirst = function(t) {
                            if (t <= this.$1) {
                                var e = this.read();
                                this.$2 = 0, e.splice(0, t), this.$3 = e
                            }
                            return this
                        }, t.clear = function() {
                            return this.$2 = 0, this.$3 = [], this
                        }, t.currentSize = function() {
                            return this.$3.length
                        }, t.lastElement = function() {
                            return this.$3[this.$2]
                        }, e
                    })();
                    l.default = e
                }), 98);
                __d("ErrorPubSub", ["fb-error"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    l.default = r("fb-error").ErrorPubSub
                }, 98);
                __d("IntervalTrackingBoundedBuffer", ["CircularBuffer", "ErrorPubSub"], (function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e, s = 5e3,
                        u = (function() {
                            function t(e) {
                                var t = this;
                                if (this.$6 = 0, e != null) {
                                    if (e <= 0) throw new Error("Size for a buffer must be greater than zero.")
                                } else e = s;
                                this.$4 = e, this.$1 = new(r("CircularBuffer"))(e), this.$1.onEvict(function() {
                                    t.$6++
                                }), this.$2 = [], this.$3 = 1, this.$5 = 0
                            }
                            var n = t.prototype;
                            return n.open = function() {
                                var e = this,
                                    t = this.$3++,
                                    n = !1,
                                    r, o = this.$5,
                                    a = {
                                        id: t,
                                        startIdx: o,
                                        hasOverflown: function() {
                                            return a.getOverflowSize() > 0
                                        },
                                        getOverflowSize: function() {
                                            return r != null ? r : Math.max(e.$6 - o, 0)
                                        },
                                        close: function() {
                                            return n ? [] : (n = !0, r = e.$6 - o, e.$7(t))
                                        }
                                    };
                                return this.$2.push(a), a
                            }, n.pushElement = function(t) {
                                return this.$2.length > 0 && (this.$1.write(t), this.$5++), this
                            }, n.isActive = function() {
                                return this.$2.length > 0
                            }, n.$8 = function(t) {
                                return Math.max(t - this.$6, 0)
                            }, n.$7 = function(n) {
                                for (var t, o, a, i, l = 0; l < this.$2.length; l++) {
                                    var s = this.$2[l],
                                        u = s.id,
                                        c = s.startIdx;
                                    u === n ? (a = l, i = c) : (o == null || c < o) && (o = c), (t == null || c < t) && (t = c)
                                }
                                if (a == null || t == null || i == null) return (e || (e = r("ErrorPubSub"))).reportError(new Error("messed up state inside IntervalTrackingBoundedBuffer")), [];
                                this.$2.splice(a, 1);
                                var d = this.$8(i),
                                    m = this.$1.read().slice(d),
                                    p = this.$8(o == null ? this.$5 : o) - this.$8(t);
                                return p > 0 && (this.$1.dropFirst(p), this.$6 += p), m
                            }, t
                        })();
                    l.default = u
                }), 98);
                __d("WorkerUtils", [], (function(t, n, r, o, a, i) {
                    "use strict";

                    function e() {
                        try {
                            return "WorkerGlobalScope" in t && t instanceof t.WorkerGlobalScope
                        } catch (e) {
                            return !1
                        }
                    }

                    function l() {
                        try {
                            return "SharedWorkerGlobalScope" in t && t instanceof t.SharedWorkerGlobalScope
                        } catch (e) {
                            return !1
                        }
                    }
                    i.isWorkerContext = e, i.isSharedWorkerContext = l
                }), 66);
                __d("getReusableTimeSliceContinuation", [], (function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e, t, n) {
                        var r = !1,
                            o = e.getGuardedContinuation(n),
                            a = function(a) {
                                o(function() {
                                    r || (o = e.getGuardedContinuation(n)), a()
                                })
                            };
                        a.last = function(e) {
                            var t = o;
                            i(), t(e)
                        }, a[t] = {};

                        function i() {
                            r = !0, o = function(t) {
                                t()
                            }
                        }
                        return a
                    }
                    i.default = e
                }), 66);
                __d("fb-error-lite", [], (function(t, n, r, o, a, i) {
                    "use strict";
                    var e = {
                        PREVIOUS_FILE: 1,
                        PREVIOUS_FRAME: 2,
                        PREVIOUS_DIR: 3,
                        FORCED_KEY: 4
                    };

                    function l(t) {
                        var n = new Error(t);
                        if (n.stack === void 0) try {
                            throw n
                        } catch (e) {}
                        n.messageFormat = t;
                        for (var r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), a = 1; a < r; a++) o[a - 1] = arguments[a];
                        return n.messageParams = o.map(function(e) {
                            return String(e)
                        }), n.taalOpcodes = [e.PREVIOUS_FRAME], n
                    }
                    var s = {
                        err: l,
                        TAALOpcode: e
                    };
                    i.default = s
                }), 66);
                __d("sprintf", [], (function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e) {
                        for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                        var o = 0;
                        return e.replace(/%s/g, function() {
                            return String(n[o++])
                        })
                    }
                    i.default = e
                }), 66);
                __d("invariant", ["Env", "fb-error-lite", "sprintf"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e;

                    function s(e, t) {
                        if (!e) {
                            for (var n = t, o = arguments.length, a = new Array(o > 2 ? o - 2 : 0), i = 2; i < o; i++) a[i - 2] = arguments[i];
                            if (typeof n == "number") {
                                var l = u(n, a),
                                    s = l.decoderLink,
                                    c = l.message;
                                n = c, a.unshift(s)
                            } else if (n === void 0) {
                                n = "Invariant: ";
                                for (var d = 0; d < a.length; d++) n += "%s,"
                            }
                            var m = n,
                                p = new Error(m);
                            throw p.name = "Invariant Violation", p.messageFormat = n, p.messageParams = a.map(function(e) {
                                return String(e)
                            }), p.taalOpcodes = [r("fb-error-lite").TAALOpcode.PREVIOUS_FRAME], p.stack, p
                        }
                    }

                    function u(t, n) {
                        var o = "Minified invariant #" + t + "; %s";
                        n.length > 0 && (o += " Params: " + n.map(function(e) {
                            return "%s"
                        }).join(", "));
                        var a = (e || (e = r("Env"))).show_invariant_decoder === !0 ? "visit " + c(t, n) + " to see the full message." : "";
                        return {
                            message: o,
                            decoderLink: a
                        }
                    }

                    function c(e, t) {
                        var n = "https://www.internalfb.com/intern/invariant/" + e + "/";
                        return t.length > 0 && (n += "?" + t.map(function(e, t) {
                            return "args[" + t + "]=" + encodeURIComponent(String(e))
                        }).join("&")), n
                    }
                    l.default = s
                }, 98);
                __d("SimpleHook", [], function(t, n, r, o, a, i) {
                    "use strict";
                    var e = (function() {
                        function e() {
                            this.__callbacks = [], this.call = this.$2
                        }
                        var t = e.prototype;
                        return t.hasCallback = function(t) {
                            var e = this.__callbacks;
                            return e.length > 0 && (t == null || e.some(function(e) {
                                return e === t || e.$1 === t
                            }))
                        }, t.add = function(t, n) {
                            var e = this,
                                r;
                            if ((n == null ? void 0 : n.once) === !0) {
                                var o = function() {
                                    e.remove(r), t.apply(null, arguments)
                                };
                                o.$1 = t, r = o
                            } else r = t;
                            return this.__callbacks.push(r), r
                        }, t.removeLast = function() {
                            return this.__callbacks.pop()
                        }, t.remove = function(t) {
                            return this.removeIf(function(e) {
                                return e === t
                            })
                        }, t.removeIf = function(t) {
                            var e = this.__callbacks;
                            return this.__callbacks = e.filter(function(e) {
                                return !t(e)
                            }), e.length > this.__callbacks.length
                        }, t.clear = function() {
                            this.__callbacks = []
                        }, t.$2 = function() {
                            for (var e = this.__callbacks, t = 0, n = e.length; t < n; ++t) {
                                var r = e[t];
                                r.apply(null, arguments)
                            }
                        }, e
                    })();
                    i.SimpleHook = e
                }, 66);
                __d("performanceAbsoluteNowOnAdjust", ["SimpleHook"], (function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = new(o("SimpleHook")).SimpleHook,
                        s = e;
                    l.default = s
                }), 98);
                __d("performanceAbsoluteNow", ["performance", "performanceAbsoluteNowOnAdjust"], function(t, n, r, o, a, i, l) {
                    var e, s = function() {
                        return Date.now()
                    };

                    function u(e) {
                        s = e
                    }
                    var c = 0,
                        d = -1,
                        m = typeof(e || (e = r("performance"))) == "object",
                        p = m && typeof(e || (e = r("performance"))).now == "function";
                    m && ((e || (e = r("performance"))).timeOrigin ? d = (e || (e = r("performance"))).timeOrigin : (e || (e = r("performance"))).timing && (e || (e = r("performance"))).timing.navigationStart && (d = (e || (e = r("performance"))).timing.navigationStart));
                    var _, f, g = function() {
                        return 0
                    };
                    if (p && d !== -1) {
                        if (_ = function() {
                                return (e || (e = r("performance"))).now() + d
                            }, f = function() {
                                return _() + c
                            }, g = function() {
                                var e = Date.now() - _();
                                return e > 500 && (c = e, r("performanceAbsoluteNowOnAdjust").call(e)), e
                            }, typeof window == "object" && typeof window.addEventListener == "function") {
                            var h = {
                                capture: !1,
                                passive: !0
                            };
                            window.addEventListener("blur", g, h), window.addEventListener("focus", g, h)
                        }
                    } else f = _ = function() {
                        return s()
                    };
                    var y = {
                            setFallback: u,
                            fromRelativeTime: (function() {
                                if (d === -1) {
                                    var t = p ? Date.now() - (e || (e = r("performance"))).now() : 0;
                                    return function(e) {
                                        return e + t
                                    }
                                } else return function(e) {
                                    return e + d
                                }
                            })(),
                            __adjust: g,
                            adjusted: f
                        },
                        C = ES("Object", "assign", !1, _, y),
                        b = C;
                    l.default = b
                }, 98);
                __d("wrapFunction", [], function(t, n, r, o, a, i) {
                    var e = {};

                    function l(t, n, r) {
                        var o = n in e ? e[n](t, r) : t;
                        return function() {
                            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            return o.apply(this, t)
                        }
                    }
                    l.setWrapper = function(t, n) {
                        e[n] = t
                    }, i.default = l
                }, 66);
                __d("TimeSliceImpl", ["invariant", "Env", "ErrorGuard", "FBLogger", "IntervalTrackingBoundedBuffer", "WorkerUtils", "getReusableTimeSliceContinuation", "performanceAbsoluteNow", "wrapFunction"], (function(t, n, r, o, a, i, l) {
                    var e, s, u, c, d = [],
                        m = [],
                        p = "key" + Math.random(),
                        _ = 1,
                        f = !1,
                        g = (e || (e = n("Env"))).timesliceBufferSize;
                    g == null && (g = 5e3);
                    var h = new(n("IntervalTrackingBoundedBuffer"))(g),
                        y = [],
                        C = [],
                        b = [];

                    function v() {
                        return S(y)
                    }

                    function S(e) {
                        return e.length > 0 ? e[e.length - 1] : null
                    }

                    function R(e, t) {
                        var r = {};
                        (s || (s = n("ErrorGuard"))).applyWithGuard(k, null, [e, t, r]), s.applyWithGuard(I, null, [e, t, r]), y.push(e), C.push(t), b.push(r)
                    }

                    function L(e, t, n) {
                        d.forEach(function(r) {
                            var o = r.onNewContextCreated(v(), t, n);
                            e[r.getBeforeID()] = o
                        })
                    }

                    function E(e, t, n) {
                        m.forEach(function(r) {
                            r.onAfterContextEnded(e, t[r.getBeforeID()], n[r.getBeforeID()], e.meta)
                        })
                    }

                    function k(e, t, n) {
                        d.forEach(function(r) {
                            var o = r.onBeforeContextStarted(e, t[r.getBeforeID()], e.meta);
                            n[r.getBeforeID()] = o
                        })
                    }

                    function I(e, t, n) {
                        d.forEach(function(r) {
                            var o = r.onAfterContextStarted(e, t[r.getBeforeID()], n[r.getBeforeID()], e.meta);
                            n[r.getBeforeID()] = o
                        })
                    }

                    function T() {
                        var e = v(),
                            t = S(C),
                            r = S(b);
                        if (e == null || t == null || r == null) {
                            n("FBLogger")("TimeSlice").mustfix("popped too many times off the timeslice stack"), f = !1;
                            return
                        }(s || (s = n("ErrorGuard"))).applyWithGuard(E, null, [e, t, r]), f = !e.isRoot, y.pop(), C.pop(), b.pop()
                    }
                    var D = {
                        PropagationType: {
                            CONTINUATION: 0,
                            EXECUTION: 1,
                            ORPHAN: 2
                        },
                        guard: function(t, r, o) {
                            typeof t == "function" || l(0, 3725), typeof r == "string" || l(0, 3726);
                            var e = x(o);
                            if (t[p]) return t;
                            var a;
                            f && (a = v());
                            var i = {},
                                d = 0,
                                m = function() {
                                    var o = (u || (u = n("performanceAbsoluteNow")))(),
                                        l = _++,
                                        m = {
                                            contextID: l,
                                            name: r,
                                            isRoot: !f,
                                            executionNumber: d++,
                                            meta: e,
                                            absBeginTimeMs: o
                                        };
                                    if (R(m, i), a != null) {
                                        var p = !!e.isContinuation;
                                        a.isRoot ? (m.indirectParentID = a.contextID, m.isEdgeContinuation = p) : (m.indirectParentID = a.indirectParentID, m.isEdgeContinuation = !!(p && a.isEdgeContinuation))
                                    }
                                    var g = (c || (c = n("WorkerUtils"))).isWorkerContext();
                                    f = !0;
                                    try {
                                        for (var y = arguments.length, C = new Array(y), b = 0; b < y; b++) C[b] = arguments[b];
                                        return !m.isRoot || g ? t.apply(this, C) : (s || (s = n("ErrorGuard"))).applyWithGuard(t, this, C, {
                                            name: "TimeSlice" + (r ? ": " + r : "")
                                        })
                                    } finally {
                                        var S = v();
                                        if (S == null) n("FBLogger")("TimeSlice").mustfix("timeslice stack misaligned, not logging the block"), f = !1;
                                        else {
                                            var L = S.contextID,
                                                E = S.indirectParentID,
                                                k = S.isEdgeContinuation,
                                                I = S.isRoot,
                                                D = (u || (u = n("performanceAbsoluteNow")))();
                                            if (S.absEndTimeMs = D, I && o != null) {
                                                var x = {
                                                    begin: o,
                                                    end: D,
                                                    id: L,
                                                    indirectParentID: E,
                                                    representsExecution: !0,
                                                    isEdgeContinuation: a && k,
                                                    guard: r
                                                };
                                                if (t.__SMmeta != null) {
                                                    var $ = t.__SMmeta.name,
                                                        P = t.__SMmeta.module;
                                                    $ != null && (x.name = $), P != null && (x.module = P)
                                                }
                                                h.pushElement(x)
                                            }
                                            T()
                                        }
                                    }
                                };
                            return m[p] = {}, (s || (s = n("ErrorGuard"))).applyWithGuard(L, null, [i, r, e]), m
                        },
                        copyGuardForWrapper: function(t, n) {
                            return t && t[p] && (n[p] = t[p]), n
                        },
                        getContext: function() {
                            return v()
                        },
                        getGuardedContinuation: function(t) {
                            function e(e) {
                                for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                                return e.apply(this, n)
                            }
                            return D.guard(e, t, {
                                propagationType: D.PropagationType.CONTINUATION
                            })
                        },
                        getReusableContinuation: function(t) {
                            return n("getReusableTimeSliceContinuation")(D, p, t)
                        },
                        getPlaceholderReusableContinuation: function() {
                            var e = function(t) {
                                return t()
                            };
                            return e.last = e, e
                        },
                        getGuardNameStack: function() {
                            return y.map(function(e) {
                                return e.name
                            })
                        },
                        registerExecutionContextObserver: function(t) {
                            for (var e = !1, n = 0; n < d.length; n++)
                                if (d[n].getBeforeID() > t.getBeforeID()) {
                                    d.splice(n, 0, t), e = !0;
                                    break
                                }
                            e || d.push(t);
                            for (var r = 0; r < m.length; r++)
                                if (m[r].getAfterID() > t.getAfterID()) {
                                    m.splice(r, 0, t);
                                    return
                                }
                            m.push(t)
                        },
                        catchUpOnDemandExecutionContextObservers: function(t) {
                            for (var e = 0; e < y.length; e++) {
                                var n = y[e],
                                    r = C[e],
                                    o = b[e] || {},
                                    a = t.onBeforeContextStartedWhileEnabled(n, r[t.getBeforeID()], n.meta);
                                o[t.getBeforeID()] = a, b[e] = o
                            }
                        },
                        getBuffer: function() {
                            return h
                        }
                    };

                    function x(e) {
                        var t = {};
                        switch (e && e.propagateCounterAttribution !== void 0 && (t.propagateCounterAttribution = e.propagateCounterAttribution), e && e.root !== void 0 && (t.root = e.root), e && e.propagationType) {
                            case D.PropagationType.CONTINUATION:
                                t.isContinuation = !0, t.extendsExecution = !0;
                                break;
                            case D.PropagationType.ORPHAN:
                                t.isContinuation = !1, t.extendsExecution = !1;
                                break;
                            case D.PropagationType.EXECUTION:
                            default:
                                t.isContinuation = !1, t.extendsExecution = !0
                        }
                        return t
                    }
                    n("wrapFunction").setWrapper(function(e, t) {
                        return D.guard(e, t, {
                            registerCallStack: !0
                        })
                    }, "entry"), t.TimeSlice = D, a.exports = D
                }), 6);
                __d("requireCond", [], (function(t, n, r, o, a, i) {
                    function e(e, t, n) {
                        throw new Error("Cannot use raw untransformed requireCond.")
                    }
                    var l = e;
                    i.default = l
                }), 66);
                __d("TimeSlice", ["cr:1126"], (function(t, n, r, o, a, i, l) {
                    l.default = n("cr:1126")
                }), 98);
                __d("setTimeoutAcrossTransitionsBlue", ["TimeSlice"], (function(t, n, r, o, a, i, l) {
                    var e = t.__fbNativeSetTimeout || t.setTimeout;

                    function s(n, o) {
                        for (var a = r("TimeSlice").guard(n, "setTimeout", {
                                propagationType: r("TimeSlice").PropagationType.CONTINUATION,
                                registerCallStack: !0
                            }), i = arguments.length, l = new Array(i > 2 ? i - 2 : 0), s = 2; s < i; s++) l[s - 2] = arguments[s];
                        return Function.prototype.apply.call(e, t, [a, o].concat(l))
                    }
                    l.default = s
                }), 98);
                __d("setTimeoutAcrossTransitionsWWW", ["cr:986633"], (function(t, n, r, o, a, i, l) {
                    l.default = n("cr:986633")
                }), 98);
                __d("err", ["fb-error"], (function(t, n, r, o, a, i, l) {
                    "use strict";
                    l.default = r("fb-error").err
                }), 98);
                /**
                 * License: https://www.facebook.com/legal/license/9KP1UIMf5Ez/
                 */
                __d("ImmediateImplementation", ["ImmediateImplementationExperiments"], (function(t, n, r, o, a, i) {
                    (function(e, t) {
                        "use strict";
                        var r = 1,
                            o = {},
                            a = {},
                            l = a,
                            s = !1,
                            u = e.document,
                            c, d, m, p = "setImmediate$" + Math.random() + "$";

                        function _() {
                            var t = e.event;
                            return t ? t.isTrusted && ["change", "click", "contextmenu", "dblclick", "mouseup", "pointerup", "reset", "submit", "touchend"].includes(t.type) || t.type === "message" && t.source === e && typeof t.data == "string" && t.data.indexOf(p) === 0 : !1
                        }

                        function f(e) {
                            var n = e[0];
                            return e = Array.prototype.slice.call(e, 1), o[r] = function() {
                                n.apply(t, e)
                            }, l = l.next = {
                                handle: r++
                            }, l.handle
                        }

                        function g() {
                            for (var e, t; !s && (e = a.next);)
                                if (a = e, t = o[e.handle]) {
                                    s = !0;
                                    try {
                                        t(), s = !1
                                    } finally {
                                        h(e.handle), s && (s = !1, a.next && c(g))
                                    }
                                }
                        }

                        function h(e) {
                            delete o[e]
                        }

                        function y() {
                            if (e.postMessage && !e.importScripts) {
                                var t = !0,
                                    n = function() {
                                        t = !1, e.removeEventListener ? e.removeEventListener("message", n, !1) : e.detachEvent("onmessage", n)
                                    };
                                if (e.addEventListener) e.addEventListener("message", n, !1);
                                else if (e.attachEvent) e.attachEvent("onmessage", n);
                                else return !1;
                                return e.postMessage("", "*"), t
                            }
                        }

                        function C() {
                            var t = function(n) {
                                n.source === e && typeof n.data == "string" && n.data.indexOf(p) === 0 && g()
                            };
                            e.addEventListener ? e.addEventListener("message", t, !1) : e.attachEvent("onmessage", t), c = function() {
                                var t = f(arguments);
                                return e.originalPostMessage ? e.originalPostMessage(p + t, "*") : e.postMessage(p + t, "*"), t
                            }, d = c
                        }

                        function b() {
                            var e = new MessageChannel,
                                t = !1;
                            e.port1.onmessage = function(e) {
                                t = !1, g()
                            }, c = function() {
                                var n = f(arguments);
                                return t || (e.port2.postMessage(n), t = !0), n
                            }, m = c
                        }

                        function v() {
                            var e = u.documentElement;
                            c = function() {
                                var t = f(arguments),
                                    n = u.createElement("script");
                                return n.onreadystatechange = function() {
                                    n.onreadystatechange = null, e.removeChild(n), n = null, g()
                                }, e.appendChild(n), t
                            }
                        }

                        function S() {
                            c = function() {
                                return setTimeout(g, 0), f(arguments)
                            }
                        }
                        y() ? e.MessageChannel && n("ImmediateImplementationExperiments").prefer_message_channel ? (C(), b(), c = function() {
                            return _() ? d.apply(null, arguments) : m.apply(null, arguments)
                        }) : C() : e.MessageChannel ? b() : u && u.createElement && "onreadystatechange" in u.createElement("script") ? v() : S(), i.setImmediate = c, i.clearImmediate = h
                    })(typeof self == "undefined" ? typeof t == "undefined" ? this : t : self)
                }), null);
                __d("setImmediatePolyfill", ["invariant", "ImmediateImplementation", "PromiseUsePolyfillSetImmediateGK"], (function(t, n, r, o, a, i, l) {
                    var e = t.setImmediate;
                    if (n("PromiseUsePolyfillSetImmediateGK").www_always_use_polyfill_setimmediate || !e) {
                        var s = n("ImmediateImplementation");
                        e = s.setImmediate
                    }

                    function u(t) {
                        typeof t == "function" || l(0, 5912);
                        for (var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++) r[o - 1] = arguments[o];
                        return e.apply(void 0, [t].concat(r))
                    }
                    a.exports = u
                }), null);
                __d("setImmediateAcrossTransitions", ["TimeSlice", "setImmediatePolyfill"], (function(t, n, r, o, a, i, l) {
                    function e(e) {
                        for (var t = r("TimeSlice").guard(e, "setImmediate", {
                                propagationType: r("TimeSlice").PropagationType.CONTINUATION,
                                registerCallStack: !0
                            }), n = arguments.length, o = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) o[a - 1] = arguments[a];
                        return r("setImmediatePolyfill").apply(void 0, [t].concat(o))
                    }
                    l.default = e
                }), 98);
                __d("setTimeoutAcrossTransitions", ["cr:7391"], (function(t, n, r, o, a, i, l) {
                    l.default = n("cr:7391")
                }), 98);
                __d("PromiseImpl", ["ErrorPubSub", "TimeSlice", "err", "setImmediateAcrossTransitions", "setTimeoutAcrossTransitions"], (function(t, n, r, o, a, i) {
                    "use strict";
                    var e;

                    function l() {}
                    var s = null,
                        u = {};

                    function c(e) {
                        try {
                            return e.then
                        } catch (e) {
                            return s = e, u
                        }
                    }

                    function d(e, t) {
                        try {
                            return e(t)
                        } catch (e) {
                            return s = e, u
                        }
                    }

                    function m(e, t, n) {
                        try {
                            e(t, n)
                        } catch (e) {
                            return s = e, u
                        }
                    }

                    function p(e) {
                        if (typeof this != "object") throw new TypeError("Promises must be constructed via new");
                        if (typeof e != "function") throw new TypeError("not a function");
                        this._state = 0, this._value = null, this._deferreds = [], e !== l && b(e, this)
                    }
                    p._noop = l, p.prototype.then = function(e, t) {
                        if (this.constructor !== p) return _(this, e, t);
                        var n = new p(l);
                        return f(this, new C(e, t, n)), n
                    };

                    function _(e, t, n) {
                        return new e.constructor(function(r, o) {
                            var a = new p(l);
                            a.then(r, o), f(e, new C(t, n, a))
                        })
                    }

                    function f(e, t) {
                        for (; e._state === 3;) e = e._value;
                        if (e._state === 0) {
                            e._deferreds.push(t);
                            return
                        }
                        n("setImmediateAcrossTransitions")(function() {
                            var n = e._state === 1 ? t.onFulfilled : t.onRejected;
                            if (n === null) {
                                t.continuation(function() {}), e._state === 1 ? g(t.promise, e._value) : h(t.promise, e._value);
                                return
                            }
                            var r = d(t.continuation.bind(null, n), e._value);
                            r === u ? h(t.promise, s) : g(t.promise, r)
                        })
                    }

                    function g(e, t) {
                        if (t === e) return h(e, new TypeError("A promise cannot be resolved with itself."));
                        if (t && (typeof t == "object" || typeof t == "function")) {
                            var n = c(t);
                            if (n === u) return h(e, s);
                            if (n === e.then && t instanceof p) {
                                e._state = 3, e._value = t, y(e);
                                return
                            } else if (typeof n == "function") {
                                b(n.bind(t), e);
                                return
                            }
                        }
                        e._state = 1, e._value = t, y(e)
                    }

                    function h(e, t) {
                        e._state = 2, e._value = t, y(e)
                    }

                    function y(e) {
                        for (var t = 0; t < e._deferreds.length; t++) f(e, e._deferreds[t]);
                        e._deferreds = null
                    }

                    function C(e, t, r) {
                        this.onFulfilled = typeof e == "function" ? e : null, this.onRejected = typeof t == "function" ? t : null, this.continuation = n("TimeSlice").getGuardedContinuation("Promise Handler"), this.promise = r
                    }

                    function b(e, t) {
                        var n = !1,
                            r = m(e, function(e) {
                                n || (n = !0, g(t, e))
                            }, function(e) {
                                n || (n = !0, h(t, e))
                            });
                        !n && r === u && (n = !0, h(t, s))
                    }
                    var v = I(!0),
                        S = I(!1),
                        R = I(null),
                        L = I(void 0),
                        E = I(0),
                        k = I("");

                    function I(e) {
                        var t = new p(p._noop);
                        return t._state = 1, t._value = e, t
                    }
                    p.resolve = function(e) {
                        if (e instanceof p) return e;
                        if (e === null) return R;
                        if (e === void 0) return L;
                        if (e === !0) return v;
                        if (e === !1) return S;
                        if (e === 0) return E;
                        if (e === "") return k;
                        if (typeof e == "object" || typeof e == "function") try {
                            var t = e.then;
                            if (typeof t == "function") return new p(t.bind(e))
                        } catch (e) {
                            return new p(function(t, n) {
                                n(e)
                            })
                        }
                        return I(e)
                    }, p.all = function(e) {
                        Array.isArray(e) || (e = [p.reject(new TypeError("Promise.all must be passed an array."))]);
                        var t = Array.prototype.slice.call(e);
                        return new p(function(e, n) {
                            if (t.length === 0) return e([]);
                            var r = t.length;

                            function o(a, i) {
                                if (i && (typeof i == "object" || typeof i == "function"))
                                    if (i instanceof p && i.then === p.prototype.then) {
                                        for (; i._state === 3;) i = i._value;
                                        if (i._state === 1) return o(a, i._value);
                                        i._state === 2 && n(i._value), i.then(function(e) {
                                            o(a, e)
                                        }, n);
                                        return
                                    } else {
                                        var l = i.then;
                                        if (typeof l == "function") {
                                            var s = new p(l.bind(i));
                                            s.then(function(e) {
                                                o(a, e)
                                            }, n);
                                            return
                                        }
                                    }
                                t[a] = i, --r === 0 && e(t)
                            }
                            for (var a = 0; a < t.length; a++) o(a, t[a])
                        })
                    }, p.reject = function(e) {
                        return new p(function(t, n) {
                            n(e)
                        })
                    }, p.race = function(e) {
                        return new p(function(t, n) {
                            e.forEach(function(e) {
                                p.resolve(e).then(t, n)
                            })
                        })
                    }, p.prototype.catch = function(e) {
                        return this.then(null, e)
                    }, p.prototype.done = function(t, r) {
                        (e || (e = n("ErrorPubSub"))).reportError(n("err")("Promise.done is deprecated. Please use promiseDone."));
                        var o = new Error("Promise.done"),
                            a = arguments.length ? this.then.apply(this, arguments) : this;
                        a.then(null, function(e) {
                            n("setTimeoutAcrossTransitions")(function() {
                                throw e instanceof Error ? e : (o.message = "" + e, o)
                            }, 0)
                        })
                    }, a.exports = p
                }), null);
                __d("DOMWrapper", [], (function(t, n, r, o, a, i) {
                    "use strict";
                    var e, l;

                    function s(t) {
                        e = t
                    }

                    function u() {
                        return e || document.body
                    }

                    function c(e) {
                        l = e
                    }

                    function d() {
                        return l || self
                    }
                    i.setRoot = s, i.getRoot = u, i.setWindow = c, i.getWindow = d
                }), 66);
                __d("dotAccess", [], function(t, n, r, o, a, i) {
                    function e(e, t, n) {
                        var r = t.split(".");
                        do {
                            var o = r.shift();
                            e = e[o] || n && (e[o] = {})
                        } while (r.length && e);
                        return e
                    }
                    i.default = e
                }, 66);
                __d("guid", [], (function(t, n, r, o, a, i) {
                    function e() {
                        if (typeof crypto == "object" && typeof crypto.getRandomValues == "function" && typeof String.prototype.padStart == "function") {
                            var e = crypto.getRandomValues(new Uint32Array(2));
                            return "f" + e[0].toString(16).padStart(8, "0") + e[1].toString(16).padStart(8, "0")
                        }
                        return "f" + (Math.random() * (1 << 30)).toString(16).replace(".", "")
                    }
                    i.default = e
                }), 66);
                __d("GlobalCallback", ["DOMWrapper", "dotAccess", "guid", "wrapFunction"], (function(t, n, r, o, a, i, l) {
                    var e, s;

                    function u(t) {
                        e = r("dotAccess")(o("DOMWrapper").getWindow(), t, !0), s = t
                    }

                    function c(t, n) {
                        e || u("__globalCallbacks");
                        var o = r("guid")();
                        return e[o] = r("wrapFunction")(t, "entry", n != null ? n : "GlobalCallback"), s + "." + o
                    }

                    function d(t) {
                        var n = t.substring(s.length + 1);
                        delete e[n]
                    }
                    l.setPrefix = u, l.create = c, l.remove = d
                }), 98);
                __d("Log", [], function(t, n, r, o, a, i) {
                    "use strict";
                    var e = -1,
                        l = {
                            DEBUG: 3,
                            INFO: 2,
                            WARNING: 1,
                            ERROR: 0
                        },
                        s = function(n, r, o) {
                            for (var t = arguments.length, a = new Array(t > 3 ? t - 3 : 0), i = 3; i < t; i++) a[i - 3] = arguments[i];
                            var l = 0,
                                s = o.replace(/%s/g, function() {
                                    return String(a[l++])
                                }),
                                u = window.console;
                            u && e >= r && u[n in u ? n : "log"](s)
                        };

                    function u(t) {
                        e = t
                    }
                    var c = ES(s, "bind", !0, null, "debug", l.DEBUG),
                        d = ES(s, "bind", !0, null, "info", l.INFO),
                        m = ES(s, "bind", !0, null, "warn", l.WARNING),
                        p = ES(s, "bind", !0, null, "error", l.ERROR);
                    i.Level = l, i.log = s, i.setLevel = u, i.debug = c, i.info = d, i.warn = m, i.error = p
                }, 66);
                __d("sdk.UA", [], function(t, n, r, o, a, i) {
                    var e = navigator.userAgent,
                        l = {
                            iphone: /\b(iPhone|iP[ao]d)/.test(e),
                            ipad: /\b(iP[ao]d)/.test(e),
                            android: /Android/i.test(e),
                            nativeApp: /FBAN\/\w+;/i.test(e) && !/FBAN\/mLite;/.test(e) || /MetaIAB/i.test(e) && /\b(iPhone|iP[ao]d)/.test(e),
                            nativeAndroidApp: /FB_IAB\/\w+;/i.test(e) || /MetaIAB/i.test(e) && /Android/i.test(e),
                            nativeInstagramApp: /Instagram/i.test(e),
                            nativeMetaIAB: /MetaIAB/i.test(e),
                            nativeMessengeriOSApp: /MessengerForiOS/i.test(e),
                            nativeMessengerAndroidApp: /Orca\-Android/i.test(e),
                            ucBrowser: /UCBrowser/i.test(e)
                        },
                        s = /Mobile/i.test(e),
                        u = {
                            ie: NaN,
                            firefox: NaN,
                            chrome: NaN,
                            webkit: NaN,
                            osx: NaN,
                            edge: NaN,
                            operaMini: NaN,
                            ucWeb: NaN
                        },
                        c = /(?:MSIE.(\d+\.\d+))|(?:(?:Firefox|GranParadiso|Iceweasel).(\d+\.\d+))|(?:AppleWebKit.(\d+(?:\.\d+)?))|(?:Trident\/\d+\.\d+.*rv:(\d+\.\d+))/.exec(e);
                    if (c && (u.ie = c[1] ? parseFloat(c[1]) : c[4] ? parseFloat(c[4]) : NaN, u.firefox = c[2] || "", u.webkit = c[3] || "", c[3])) {
                        var d = /(?:Chrome\/(\d+\.\d+))/.exec(e);
                        u.chrome = d ? d[1] : "";
                        var m = /(?:Edge\/(\d+\.\d+))/.exec(e);
                        u.edge = m ? m[1] : ""
                    }
                    var p = /(?:Mac OS X (\d+(?:[._]\d+)?))/.exec(e);
                    p && (u.osx = p[1]);
                    var _ = /(?:Opera Mini\/(\d+(?:\.\d+)?))/.exec(e);
                    _ && (u.operaMini = _[1]);
                    var f = /(?:UCWEB\/(\d+(?:\.\d+))?)/.exec(e);
                    f && (u.ucWeb = f[1] || "2.0");

                    function g(e) {
                        return String(e).split(".").map(function(e) {
                            return parseFloat(e)
                        })
                    }
                    var h = {};
                    Object.keys(u).map(function(e) {
                        var t = function() {
                            return parseFloat(u[e])
                        };
                        t.getVersionParts = function() {
                            return g(u[e])
                        }, h[e] = t
                    }), Object.keys(l).map(function(e) {
                        h[e] = function() {
                            return l[e]
                        }
                    }), h.mobile = function() {
                        return l.iphone || l.ipad || l.android || s
                    }, h.mTouch = function() {
                        return l.android || l.iphone || l.ipad
                    }, h.facebookInAppBrowser = function() {
                        return l.nativeApp || l.nativeAndroidApp
                    }, h.inAppBrowser = function() {
                        return l.nativeApp || l.nativeAndroidApp || l.nativeInstagramApp || l.nativeMetaIAB
                    }, h.mBasic = function() {
                        return !!(u.ucWeb || u.operaMini)
                    }, h.instagram = function() {
                        return l.nativeInstagramApp
                    }, h.messenger = function() {
                        return l.nativeMessengeriOSApp || l.nativeMessengerAndroidApp
                    }, h.isSupportedIABVersion = function(e) {
                        if (!h.facebookInAppBrowser()) return !1;
                        var t = /(?:FBAV\/(\d+(\.\d+)+))/.exec(navigator.userAgent);
                        if (t) {
                            var n = parseFloat(t[1]);
                            if (n >= e) return !0
                        }
                        return !1
                    };
                    var y = h;
                    i.default = y
                }, 66);
                __d("sdk.domReady", [], function(t, n, r, o, a, i) {
                    var e, l = "readyState" in document ? /loaded|complete/.test(document.readyState) : !!document.body;

                    function s() {
                        if (e) {
                            for (var t = e, n; n = t.shift();) n();
                            e = null
                        }
                    }

                    function u(t) {
                        if (e) {
                            e.push(t);
                            return
                        } else t()
                    }
                    l || (e = [], "addEventListener" in document ? (document.addEventListener("DOMContentLoaded", s, !1), window.addEventListener("load", s, !1)) : document.attachEvent && (document.attachEvent("onreadystatechange", s), window.attachEvent("onload", s))), i.default = u
                }, 67);
                __d("sdk.Content", ["Log", "sdk.UA", "sdk.domReady"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e, s;

                    function u(t, n) {
                        return n || (e ? n = e : (e = n = document.getElementById("fb-root"), n || (o("Log").warn('The "fb-root" div has not been created, auto-creating'), e = n = document.createElement("div"), n.id = "fb-root", r("sdk.UA").ie() || !document.body ? r("sdk.domReady")(function() {
                            n && document.body && document.body.appendChild(n)
                        }) : document.body.appendChild(n)), n.className += " fb_reset")), n.appendChild(t), t
                    }

                    function c(e) {
                        if (!s) {
                            s = document.createElement("div");
                            var t = s.style;
                            t.position = "absolute", t.top = "-10000px", t.width = "0", t.height = "0", s = u(s)
                        }
                        return u(e, s)
                    }

                    function d(e, t) {
                        var n = document.createElement("form");
                        n.action = e.url, n.target = e.target, n.method = t ? "GET" : "POST", c(n);
                        for (var r in e.params)
                            if (Object.prototype.hasOwnProperty.call(e.params, r)) {
                                var o = e.params[r];
                                if (o != null) {
                                    var a = document.createElement("input");
                                    a.name = r, a.value = o, n.appendChild(a)
                                }
                            }
                        n.submit(), n.parentNode && n.parentNode.removeChild(n)
                    }
                    l.append = u, l.appendHidden = c, l.submitToTarget = d
                }, 98);
                __d("getErrorSafe", ["fb-error"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    l.default = r("fb-error").getErrorSafe
                }, 98);
                __d("sdk.DOM", ["getErrorSafe", "guid", "sdk.domReady"], function(t, n, r, o, a, i, l) {
                    var e = {},
                        s = {};

                    function u(e, t) {
                        var n = e.getAttribute(t) || e.getAttribute(t.replace(/_/g, "-")) || e.getAttribute(t.replace(/-/g, "_")) || e.getAttribute(t.replace(/-/g, "")) || e.getAttribute(t.replace(/_/g, "")) || e.getAttribute("data-" + t) || e.getAttribute("data-" + t.replace(/_/g, "-")) || e.getAttribute("data-" + t.replace(/-/g, "_")) || e.getAttribute("data-" + t.replace(/-/g, "")) || e.getAttribute("data-" + t.replace(/_/g, ""));
                        return n != null ? String(n) : null
                    }

                    function c(e, t) {
                        var n = u(e, t);
                        return n != null ? /^(true|1|yes|on)$/.test(n) : null
                    }

                    function d(e, t) {
                        try {
                            e.innerHTML = t
                        } catch (e) {
                            var n = r("getErrorSafe")(e);
                            throw new Error("Could not set innerHTML : " + n.message)
                        }
                    }

                    function m(e, t) {
                        var n = " " + e.className + " ";
                        return n.indexOf(" " + t + " ") >= 0
                    }

                    function p(e, t) {
                        e != null && (m(e, t) || (e.className = e.className + " " + t))
                    }

                    function _(e, t) {
                        if (e != null) {
                            var n = new RegExp("\\s*" + t, "g");
                            e.className = e.className.replace(n, "").trim()
                        }
                    }

                    function f(e, t, n) {
                        n === void 0 && (n = "*");
                        var r = t || document.body;
                        if (r == null) return [];
                        var o = n || "*";
                        return ES("Array", "from", !1, r.querySelectorAll(o + "." + e))
                    }

                    function g(e, t) {
                        var n = E(t),
                            r = document.defaultView.getComputedStyle(e).getPropertyValue(n);
                        return r = e.style.getPropertyValue(n), /background-position?/.test(n) && /top|left/.test(r) && (r = "0%"), r
                    }

                    function h(e, t, n) {
                        e.style.setProperty(E(t), n)
                    }

                    function y(e, t, n, r, o) {
                        for (var a = e.styleSheets, i = 0; i < a.length; i++) {
                            var l;
                            if (a[i].ownerNode instanceof HTMLElement && a[i].ownerNode.dataset != null && ((l = a[i].ownerNode.dataset.fbcssmodules) == null ? void 0 : l.indexOf(t)) !== -1) {
                                var s = a[i];
                                if (s instanceof CSSStyleSheet) {
                                    for (var u = 0; u < s.cssRules.length; u++) {
                                        var c = s.cssRules[u];
                                        if (c instanceof CSSStyleRule && c.selectorText === n) {
                                            c.style.setProperty(E(r), o);
                                            return
                                        }
                                    }
                                    s.insertRule(n + "{" + E(r) + ":" + (o != null ? o : "") + "}", 0)
                                }
                            }
                        }
                    }

                    function C(t, n, o) {
                        var a;
                        if (o != null && o.nodeType === 11) {
                            var i = o;
                            i.host.id != null && s[i.host.id] != null ? a = s[i.host.id] : (i.host.id || (i.host.id = r("guid")()), a = {}, s[i.host.id] = a)
                        } else a = e;
                        for (var l = !0, u = 0, c; c = n[u++];) c in a || (l = !1, a[c] = !0);
                        if (!l) {
                            var d = document.createElement("style");
                            d.type = "text/css", d.textContent = t;
                            var m = "";
                            n.forEach(function(e) {
                                return m += e + " "
                            }), d.setAttribute("data-fbcssmodules", m.trim()), o == null ? document.getElementsByTagName("head")[0].appendChild(d) : o.appendChild(d)
                        }
                    }

                    function b(e) {
                        return !e || !e.parentNode ? null : e.parentNode.removeChild(e)
                    }

                    function v() {
                        var e, t, n = document.documentElement && document.compatMode == "CSS1Compat" ? document.documentElement : document.body;
                        return {
                            scrollTop: (n == null ? void 0 : n.scrollTop) || ((e = document.body) == null ? void 0 : e.scrollTop),
                            scrollLeft: (n == null ? void 0 : n.scrollLeft) || ((t = document.body) == null ? void 0 : t.scrollLeft),
                            width: window.innerWidth ? window.innerWidth : n == null ? void 0 : n.clientWidth,
                            height: window.innerHeight ? window.innerHeight : n == null ? void 0 : n.clientHeight
                        }
                    }
                    var S = /[A-Z]/g,
                        R = /^\([^-]\)-/,
                        L = ["o", "moz", "ms", "webkit"];

                    function E(e) {
                        var t = e.replace(S, "-$&").toLowerCase(),
                            n = t.match(R);
                        return n && L.indexOf(n[1]) !== -1 && (t = "-" + t), t
                    }
                    l.getAttr = u, l.getBoolAttr = c, l.dangerouslySetInnerHtml = d, l.containsCss = m, l.addCss = p, l.removeCss = _, l.getByClass = f, l.getStyle = g, l.setStyle = h, l.updateOrAddCssRule = y, l.addCssRules = C, l.remove = b, l.getViewportInfo = v, l.ready = r("sdk.domReady")
                }, 98);
                __d("ManagedError", [], function(t, n, r, o, a, i) {
                    var e = (function(e) {
                        function t(t, n) {
                            var r;
                            return r = e.call(this, t != null ? t : "") || this, t != null ? r.message = t : r.message = "", r.innerError = n, r
                        }
                        return babelHelpers.inheritsLoose(t, e), t
                    })(babelHelpers.wrapNativeSuper(Error));
                    i.default = e
                }, 66);
                __d("normalizeError", ["sdk.UA"], function(t, n, r, o, a, i, l) {
                    "use strict";

                    function e(e) {
                        var t = {
                            line: e.lineNumber || e.line,
                            message: e.message,
                            name: e.name,
                            script: e.fileName || e.sourceURL || e.script,
                            stack: e.stackTrace || e.stack
                        };
                        t._originalError = e;
                        var n = /([\w:\.\/]+\.js):(\d+)/.exec(e.stack);
                        return r("sdk.UA").chrome() && n && (t.script = n[1], t.line = parseInt(n[2], 10)), t.line == null && delete t.line, t.message == null && delete t.message, t.name == null && delete t.name, t.script == null && delete t.script, t.stack == null && delete t.stack, t._originalError == null && delete t._originalError, t
                    }
                    l.default = e
                }, 98);
                __d("ObservableMixin", [], function(t, n, r, o, a, i) {
                    function e() {
                        this.__observableEvents = {}
                    }
                    e.prototype = {
                        inform: function(t) {
                            for (var e = this, n = Array.prototype.slice.call(arguments, 1), r = Array.prototype.slice.call(this.getSubscribers(t)), o = function() {
                                    if (r[a] === null) return 1;
                                    try {
                                        r[a].apply(e, n)
                                    } catch (e) {
                                        window.setTimeout(function() {
                                            throw e
                                        }, 0)
                                    }
                                }, a = 0; a < r.length; a++) o();
                            return this
                        },
                        getSubscribers: function(t) {
                            return this.__observableEvents[t] || (this.__observableEvents[t] = [])
                        },
                        clearSubscribers: function(t) {
                            return t && (this.__observableEvents[t] = []), this
                        },
                        subscribe: function(t, n) {
                            var e = this.getSubscribers(t);
                            return e.push(n), this
                        },
                        unsubscribe: function(t, n) {
                            for (var e = this.getSubscribers(t), r = 0; r < e.length; r++)
                                if (e[r] === n) {
                                    e.splice(r, 1);
                                    break
                                }
                            return this
                        }
                    }, a.exports = e
                }, null);
                __d("AssertionError", ["ManagedError"], function(t, n, r, o, a, i, l) {
                    var e = (function(e) {
                        function t(t) {
                            return e.call(this, t) || this
                        }
                        return babelHelpers.inheritsLoose(t, e), t
                    })(r("ManagedError"));
                    l.default = e
                }, 98);
                __d("Assert", ["AssertionError", "sprintf"], function(t, n, r, o, a, i, l) {
                    function e(e, t) {
                        if (typeof e != "boolean" || e === !1) throw new(r("AssertionError"))(t);
                        return e
                    }

                    function s(t, n, o) {
                        var a;
                        if (n === void 0) a = "undefined";
                        else if (n === null) a = "null";
                        else {
                            var i = {}.toString.call(n),
                                l = /\s(\w*)/.exec(i);
                            a = l == null ? typeof l : l[1].toLowerCase()
                        }
                        return e(t.indexOf(a) !== -1, o != null ? o : r("sprintf")("Expression is of type %s, not %s", a, t)), n
                    }

                    function u(t, n, r) {
                        return e(n instanceof t, r != null ? r : "Expression not instance of type"), n
                    }
                    var c = {
                            isInstanceOf: u,
                            isTrue: e,
                            isTruthy: function(n, r) {
                                return e(!!n, r)
                            },
                            isBoolean: function(t, n) {
                                return s("boolean", t, n)
                            },
                            isFunction: function(t, n) {
                                return s("function", t, n)
                            },
                            isNumber: function(t, n) {
                                return s("number", t, n)
                            },
                            isObject: function(t, n) {
                                return s("object", t, n)
                            },
                            isString: function(t, n) {
                                return s("string", t, n)
                            },
                            isUndefined: function(t, n) {
                                return s("undefined", t, n)
                            },
                            maybeObject: function(t, n) {
                                return t == null ? t : s("object", t, n)
                            },
                            maybeNumber: function(t, n) {
                                return t == null ? t : s("number", t, n)
                            },
                            maybeFunction: function(t, n) {
                                return t == null ? t : s("function", t, n)
                            }
                        },
                        d = c;
                    l.default = d
                }, 98);
                __d("Type", ["Assert"], function(t, n, r, o, a, i) {
                    function e() {
                        var e = this.__mixins;
                        if (e)
                            for (var t = 0; t < e.length; t++) e[t].apply(this, arguments)
                    }

                    function l(t, n) {
                        if (n instanceof t) return !0;
                        if (n instanceof e) {
                            for (var r = 0; r < n.__mixins.length; r++)
                                if (n.__mixins[r] === t) return !0
                        }
                        return !1
                    }

                    function s(e, t) {
                        var n = e.prototype;
                        Array.isArray(t) || (t = [t]);
                        for (var r = function() {
                                var e = t[o];
                                typeof e == "function" && (n.__mixins.push(e), e = e.prototype), Object.keys(e).forEach(function(t) {
                                    n[t] = e[t]
                                })
                            }, o = 0; o < t.length; o++) r()
                    }

                    function u(t, r, o) {
                        var a = r && Object.prototype.hasOwnProperty.call(r, "constructor") ? r.constructor : function() {
                            this.parent.apply(this, arguments)
                        };
                        if (n("Assert").isFunction(a), t && !(t.prototype instanceof e)) throw new Error("parent type does not inherit from Type");
                        t = t || e;

                        function i() {}
                        return i.prototype = t.prototype, a.prototype = new i, r && ES("Object", "assign", !1, a.prototype, r), a.prototype.constructor = a, a.parent = t, a.prototype.__mixins = t.prototype.__mixins ? Array.prototype.slice.call(t.prototype.__mixins) : [], o && s(a, o), a.prototype.parent = function() {
                            this.parent = t.prototype.parent, t.apply(this, arguments)
                        }, a.prototype.parentCall = function(e) {
                            return t.prototype[e].apply(this, Array.prototype.slice.call(arguments, 1))
                        }, a.extend = function(e, t) {
                            return u(this, e, t)
                        }, a
                    }
                    ES("Object", "assign", !1, e.prototype, {
                        instanceOf: function(t) {
                            return l(t, this)
                        }
                    }), ES("Object", "assign", !1, e, {
                        extend: function(t, n) {
                            return typeof t == "function" ? u.apply(null, arguments) : u(null, t, n)
                        },
                        instanceOf: l
                    }), a.exports = e
                }, null);
                __d("sdk.Model", ["ObservableMixin", "Type"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = r("Type").extend({
                            constructor: function(t) {
                                this.parent();
                                var e = {},
                                    n = this;
                                Object.keys(t).forEach(function(r) {
                                    e[r] = t[r], n["set" + r] = function(t) {
                                        return t === e[r] || (e[r] = t, n.inform(r + ".change", t)), n
                                    }, n["get" + r] = function() {
                                        return e[r]
                                    }
                                })
                            }
                        }, r("ObservableMixin")),
                        s = e;
                    l.default = s
                }, 98);
                __d("sdk.Runtime", ["JSSDKRuntimeConfig", "sdk.Model"], function(t, n, r, o, a, i, l) {
                    var e, s = {
                            UNKNOWN: 0,
                            PAGETAB: 1,
                            CANVAS: 2,
                            PLATFORM: 4
                        },
                        u = new(r("sdk.Model"))({
                            AccessToken: "",
                            AutoLogAppEvents: !1,
                            ClientID: "",
                            CookieUserID: "",
                            EnforceHttps: !1,
                            Environment: s.UNKNOWN,
                            FamilyLoginLoaded: !1,
                            GraphDomain: "",
                            Initialized: !1,
                            IsSPIN: !!(e = o("JSSDKRuntimeConfig")).isSPIN,
                            IsVersioned: !1,
                            KidDirectedSite: void 0,
                            Locale: e.locale,
                            LoggedIntoFacebook: void 0,
                            LoginStatus: void 0,
                            Revision: e.revision,
                            Rtl: e.rtl,
                            Scope: void 0,
                            SDKAB: e.sdkab,
                            SDKUrl: e.sdkurl,
                            SDKNS: e.sdkns,
                            ShouldLoadFamilyLogin: !1,
                            UseCookie: !1,
                            UseLocalStorage: !0,
                            UserID: "",
                            Version: void 0
                        });
                    ES("Object", "assign", !1, u, {
                        ENVIRONMENTS: s,
                        isEnvironment: function(t) {
                            var e = this.getEnvironment();
                            return (t | e) === e
                        },
                        isCanvasEnvironment: function() {
                            return this.isEnvironment(s.CANVAS) || this.isEnvironment(s.PAGETAB)
                        }
                    }), (function() {
                        var e = /app_runner/.test(window.name) ? s.PAGETAB : /iframe_canvas/.test(window.name) ? s.CANVAS : s.UNKNOWN;
                        (e | s.PAGETAB) === e && (e |= s.CANVAS), u.setEnvironment(e)
                    })();
                    var c = u;
                    l.default = c
                }, 98);
                __d("sdk.ErrorHandler", ["ManagedError", "normalizeError", "sdk.Runtime", "wrapFunction"], function(t, n, r, o, a, i, l) {
                    function e(e, t) {
                        var n = "";

                        function o(e) {
                            var n = e._originalError;
                            throw delete e._originalError, t(e), n
                        }

                        function a(t, a) {
                            return function() {
                                if (!e) return t.apply(this, arguments);
                                try {
                                    return n = a, t.apply(this, arguments)
                                } catch (e) {
                                    if (e instanceof r("ManagedError")) throw e;
                                    var i = r("normalizeError")(e);
                                    if (!i.script) {
                                        var l = /.*\/([^?#]+)/.exec(r("sdk.Runtime").getSDKUrl());
                                        i.script = l !== null ? l[1] : ""
                                    }
                                    i.entry = a;
                                    var s = ES("Array", "from", !1, arguments).map(function(e) {
                                        var t = Object.prototype.toString.call(e);
                                        return /^\[object (String|Number|Boolean|Object|Date)\]$/.test(t) ? e : e.toString()
                                    });
                                    i.args = ES("JSON", "stringify", !1, s).substring(0, 200), o(i)
                                } finally {
                                    n = ""
                                }
                            }
                        }

                        function i(e) {
                            return e.__wrapper || (e.__wrapper = function() {
                                try {
                                    return e.apply(this, arguments)
                                } catch (e) {
                                    return window.setTimeout(function() {
                                        throw e
                                    }, 0), !1
                                }
                            }), e.__wrapper
                        }

                        function l(e) {
                            try {
                                return e && e.callee && e.callee.caller ? e.callee.caller.name : ""
                            } catch (e) {
                                return ""
                            }
                        }

                        function s(e, t) {
                            return function(o, a) {
                                var i = t + ":" + (n || "[global]") + ":" + (o.name || "[anonymous]" + l(arguments));
                                return e(r("wrapFunction")(o, "entry", i), a)
                            }
                        }
                        return e && (setTimeout = s(setTimeout, "setTimeout"), setInterval = s(setInterval, "setInterval"), r("wrapFunction").setWrapper(a, "entry")), {
                            guard: a,
                            unguard: i
                        }
                    }
                    l.create = e
                }, 98);
                __d("QueryString", [], (function(t, n, r, o, a, i) {
                    function e(e) {
                        var t = [];
                        return Object.keys(e).sort().forEach(function(n) {
                            var r = e[n];
                            if (r !== void 0) {
                                if (r === null) {
                                    t.push(n);
                                    return
                                }
                                t.push(encodeURIComponent(n) + "=" + encodeURIComponent(String(r)))
                            }
                        }), t.join("&")
                    }

                    function l(e, t) {
                        t === void 0 && (t = !1);
                        var n = {};
                        if (e === "") return n;
                        for (var r = e.split("&"), o = 0; o < r.length; o++) {
                            var a = r[o].split("=", 2),
                                i = decodeURIComponent(a[0]);
                            if (t && Object.prototype.hasOwnProperty.call(n, i)) throw new URIError("Duplicate key: " + i);
                            n[i] = a.length === 2 ? decodeURIComponent(a[1]) : null
                        }
                        return n
                    }

                    function s(t, n) {
                        return t + (t.indexOf("?") !== -1 ? "&" : "?") + (typeof n == "string" ? n : e(n))
                    }
                    var u = {
                        encode: e,
                        decode: l,
                        appendToUrl: s
                    };
                    i.default = u
                }), 66);
                __d("UrlMap", ["invariant", "UrlMapConfig", "sdk.Runtime"], (function(t, n, r, o, a, i, l, s) {
                    function e(e) {
                        var t = "https";
                        if (e === "graph_domain") {
                            var n = r("sdk.Runtime").getGraphDomain();
                            n ? e = "graph_".concat(n) : e = "graph"
                        }
                        return e in r("UrlMapConfig") ? t + "://" + r("UrlMapConfig")[e] : (e in r("UrlMapConfig") || s(0, 2511, e), "")
                    }
                    l.resolve = e
                }), 98);
                __d("sdk.Scribe", ["QueryString", "UrlMap", "sdk.Runtime"], function(t, n, r, o, a, i, l) {
                    var e = {};

                    function s(t, n, a) {
                        if (a === void 0 && (a = !1), t === "jssdk_error") {
                            var i = ES("JSON", "stringify", !1, n);
                            if (Object.prototype.hasOwnProperty.call(e, i)) return;
                            e[i] = !0
                        }
                        if (n.extra != null && typeof n.extra == "object") {
                            var l = n.extra;
                            l.revision = r("sdk.Runtime").getRevision()
                        }
                        var s = new Image,
                            u = o("UrlMap").resolve("www") + "/platform/scribe_endpoint.php/";
                        a || (s.crossOrigin = "anonymous"), s.src = r("QueryString").appendToUrl(u, {
                            c: t,
                            m: ES("JSON", "stringify", !1, babelHelpers.extends({}, n, {
                                isSPIN: r("sdk.Runtime").getIsSPIN()
                            }))
                        })
                    }
                    l.log = s
                }, 98);
                __d("sdk.FeatureFunctor", [], function(t, n, r, o, a, i) {
                    function e(e, t, n) {
                        if (e.features && t in e.features) {
                            var r = e.features[t];
                            return typeof r == "object" && typeof r.rate == "number" ? r.rate && Math.random() * 100 <= r.rate ? r.value || !0 : r.value ? null : !1 : r
                        }
                        return n
                    }

                    function l(t) {
                        return function() {
                            for (var n = arguments.length, r = new Array(n), o = 0; o < n; o++) r[o] = arguments[o];
                            if (r.length < 2) throw new Error("Default value is required");
                            var a = r[0],
                                i = r[1];
                            return e(t, a, i)
                        }
                    }
                    i.create = l
                }, 66);
                __d("sdk.feature", ["JSSDKConfig", "sdk.FeatureFunctor"], (function(t, n, r, o, a, i, l) {
                    var e = o("sdk.FeatureFunctor").create(r("JSSDKConfig"));
                    l.default = e
                }), 98);
                __d("sdk.ErrorHandling", ["sdk.ErrorHandler", "sdk.Runtime", "sdk.Scribe", "sdk.feature"], (function(t, n, r, o, a, i, l) {
                    var e = r("sdk.feature")("error_handling", !1),
                        s = o("sdk.ErrorHandler").create(e, function(e) {
                            o("sdk.Scribe").log("jssdk_error", {
                                appId: r("sdk.Runtime").getClientID(),
                                error: e.name || e.message,
                                extra: e
                            })
                        });
                    l.default = s
                }), 98);
                __d("FB", ["DOMWrapper", "GlobalCallback", "JSSDKCssConfig", "Log", "dotAccess", "sdk.Content", "sdk.DOM", "sdk.ErrorHandling", "sdk.domReady"], function(t, n, r, o, a, i, l) {
                    window.FB && window.FB.__buffer && (window.__buffer = babelHelpers.extends({}, window.FB.__buffer));
                    var e = window.FB = {},
                        s = {};
                    o("Log").setLevel(0), o("GlobalCallback").setPrefix("FB.__globalCallbacks");
                    var u = document.createElement("div");
                    o("DOMWrapper").setRoot(u), r("sdk.domReady")(function() {
                        o("Log").info("domReady"), o("sdk.Content").appendHidden(u), r("JSSDKCssConfig").rules && o("sdk.DOM").addCssRules(r("JSSDKCssConfig").rules, r("JSSDKCssConfig").components)
                    });

                    function c(e, t, n, o) {
                        return r("sdk.ErrorHandling").guard(function() {
                            function n(e) {
                                return Array.isArray(e) ? e.map(n) : e && typeof e == "object" && e.__wrapped ? e.__wrapped : typeof e == "function" && /^function/.test(e.toString()) ? r("sdk.ErrorHandling").unguard(e) : e
                            }
                            var a = Array.prototype.slice.call(arguments).map(n),
                                i = e.apply(o, a),
                                l, s = !0;
                            if (i && typeof i == "object") {
                                l = Object.create(i), l.__wrapped = i;
                                for (var u in i) {
                                    var d = i[u];
                                    typeof d != "function" || u === "constructor" || (s = !1, l[u] = c(d, t + ":" + u, u, i))
                                }
                            }
                            return s ? i : l
                        }, t)
                    }

                    function d(t, n) {
                        var o = t ? r("dotAccess")(e, t, !0) : e;
                        Object.keys(n).forEach(function(e) {
                            var r = n[e];
                            if (typeof r == "function") {
                                var a = (t ? t + "." : "") + e,
                                    i = c(r, a, e, n);
                                i && (o[e] = i)
                            } else(typeof r == "object" || typeof r == "number") && (o[e] = r)
                        })
                    }
                    ES("Object", "assign", !1, s, {
                        provide: d
                    });
                    var m = s;
                    l.default = m
                }, 98);
                __d("AppUserPropertyAPIBuiltinField", [], function(t, n, r, o, a, i) {
                    var e = Object.freeze({
                        GENDER: "$gender",
                        CITY: "$city",
                        STATE: "$state",
                        ZIPCODE: "$zipcode",
                        COUNTRY: "$country",
                        LANGUAGE: "$language",
                        CURRENCY: "$currency",
                        INSTALL_SOURCE: "$install_source",
                        USER_TYPE: "$user_type",
                        ACCOUNT_CREATED_TIME: "$account_created_time",
                        APP_ID: "$app_id"
                    });
                    i.default = e
                }, 66);
                __d("sdk.AppEvents", ["AppUserPropertyAPIBuiltinField", "Assert", "sdk.Model", "sdk.Runtime"], function(t, n, r, o, a, i, l) {
                    var e = Object.freeze({
                            COMPLETED_REGISTRATION: "fb_mobile_complete_registration",
                            VIEWED_CONTENT: "fb_mobile_content_view",
                            SEARCHED: "fb_mobile_search",
                            RATED: "fb_mobile_rate",
                            COMPLETED_TUTORIAL: "fb_mobile_tutorial_completion",
                            ADDED_TO_CART: "fb_mobile_add_to_cart",
                            ADDED_TO_WISHLIST: "fb_mobile_add_to_wishlist",
                            INITIATED_CHECKOUT: "fb_mobile_initiated_checkout",
                            ADDED_PAYMENT_INFO: "fb_mobile_add_payment_info",
                            ACHIEVED_LEVEL: "fb_mobile_level_achieved",
                            UNLOCKED_ACHIEVEMENT: "fb_mobile_achievement_unlocked",
                            PAGE_VIEW: "fb_page_view",
                            SPENT_CREDITS: "fb_mobile_spent_credits"
                        }),
                        s = Object.freeze({
                            ACTIVATED_APP: "fb_mobile_activate_app",
                            PURCHASED: "fb_mobile_purchase"
                        }),
                        u = Object.freeze({
                            APP_USER_ID: "_app_user_id",
                            APP_VERSION: "_appVersion",
                            CURRENCY: "fb_currency",
                            REGISTRATION_METHOD: "fb_registration_method",
                            CONTENT_TYPE: "fb_content_type",
                            CONTENT_ID: "fb_content_id",
                            SEARCH_STRING: "fb_search_string",
                            SUCCESS: "fb_success",
                            MAX_RATING_VALUE: "fb_max_rating_value",
                            PAYMENT_INFO_AVAILABLE: "fb_payment_info_available",
                            NUM_ITEMS: "fb_num_items",
                            LEVEL: "fb_level",
                            DESCRIPTION: "fb_description"
                        }),
                        c = /^[0-9a-zA-Z_][0-9a-zA-Z _-]{0,39}$/,
                        d = 40,
                        m = c,
                        p = d,
                        _ = 100,
                        f = 100,
                        g = 100,
                        h = 100,
                        y = ES("Object", "values", !1, r("AppUserPropertyAPIBuiltinField")),
                        C = new(r("sdk.Model"))({
                            UserID: "",
                            Version: ""
                        });

                    function b(e, t, n) {}

                    function v(e, t, n) {}

                    function S() {
                        s.ACTIVATED_APP
                    }

                    function R() {
                        e.PAGE_VIEW
                    }

                    function L(e) {
                        w(e), C.setUserID(e)
                    }

                    function E() {
                        return C.getUserID()
                    }

                    function k() {
                        C.setUserID("")
                    }

                    function I(e) {
                        M(e), C.setVersion(e)
                    }

                    function T() {
                        return C.getVersion()
                    }

                    function D() {
                        C.setVersion("")
                    }

                    function x(e, t) {
                        t && t(null)
                    }

                    function $() {
                        var e = r("sdk.Runtime").getClientID();
                        return r("Assert").isTrue(e !== null && e.length > 0, "You need to call FB.init() with App ID first."), e
                    }

                    function P(e) {
                        r("Assert").isTrue(Object.keys(e).length <= g, "The total number of user properties cannot exceed " + g + ".");
                        for (var t in e) r("Assert").isTrue(m.test(t) || ES(y, "includes", !0, t), "Invalid user properties key name: " + t + ". It must be between 1 and " + p + " characters, and must contain only alphanumerics, _, - or spaces, starting with alphanumeric or _. Or, it must be a pre-defined user property"), r("Assert").isTrue(e[t].toString().length <= h, "Invalid user properties value: " + e[t] + ". It must be no longer than " + h + " characters.")
                    }

                    function N(e) {
                        r("Assert").isTrue(c.test(e), "Invalid event name: " + e + ". It must be between 1 and " + d + " characters, and must be contain only alphanumerics, _, - or spaces, starting with alphanumeric or _.")
                    }

                    function M(e) {
                        r("Assert").isTrue(e.length <= f, "Invalid app version: " + e + ". It must be no longer than " + f + " characters.")
                    }

                    function w(e) {
                        r("Assert").isTrue(e.length !== 0, "User ID must be set before updateUserProperties can be called."), r("Assert").isTrue(e.length <= _, "Invalid user ID: " + e + ". It must be no longer than " + _ + " characters.")
                    }
                    var A = Object.freeze({
                        logEvent: b,
                        logPurchase: v,
                        activateApp: S,
                        logPageView: R,
                        setUserID: L,
                        getUserID: E,
                        clearUserID: k,
                        updateUserProperties: x,
                        setAppVersion: I,
                        getAppVersion: T,
                        clearAppVersion: D,
                        EventNames: e,
                        ParameterNames: u
                    });
                    l.assertGetValidAppID = $, l.assertValidUserProperties = P, l.assertValidEventName = N, l.assertValidAppVersion = M, l.assertValidUserID = w, l.AppEvents = A
                }, 98);
                __d("sdk.Event", [], function(t, n, r, o, a, i) {
                    "use strict";
                    var e = "event.subscribe",
                        l = "event.unsubscribe",
                        s;

                    function u() {
                        return s || (s = {}), s
                    }

                    function c(t, n) {
                        var r = u();
                        r[t] ? r[t].indexOf(n) === -1 && r[t].push(n) : r[t] = [n], t != e && t != l && _(e, t, r[t])
                    }

                    function d(t, n) {
                        var r = u()[t];
                        r && r.forEach(function(e, t) {
                            e === n && r.splice(t, 1)
                        }), t != e && t != l && _(l, t, r)
                    }

                    function m(e, t) {
                        var n = arguments;
                        if (!t()) {
                            var r = function() {
                                t.apply(t, n) && d(e, r)
                            };
                            c(e, r)
                        }
                    }

                    function p(e) {
                        delete u()[e]
                    }

                    function _(e) {
                        for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                        var o = u()[e];
                        o && o.forEach(function(e) {
                            e && e.apply(this, n)
                        })
                    }
                    i.SUBSCRIBE = e, i.UNSUBSCRIBE = l, i.subscribers = u, i.subscribe = c, i.unsubscribe = d, i.monitor = m, i.clear = p, i.fire = _
                }, 66);
                __d("sdk.AppEvents-public", ["Assert", "FB", "sdk.AppEvents", "sdk.Event", "sdk.Runtime"], function(t, n, r, o, a, i, l) {
                    function e() {
                        o("sdk.Event").subscribe("init:post", function(e) {
                            r("sdk.Runtime").getClientID() && (e.autoLogAppEvents !== void 0 && (r("Assert").isBoolean(e.autoLogAppEvents, "Type of property autoLogAppEvents must be boolean"), r("sdk.Runtime").setAutoLogAppEvents(e.autoLogAppEvents)), r("sdk.Runtime").getAutoLogAppEvents() && o("sdk.AppEvents").AppEvents.logPageView())
                        }), r("FB").provide("AppEvents", o("sdk.AppEvents").AppEvents)
                    }
                    var s = {
                            init: e
                        },
                        u = s;
                    l.default = u
                }, 98);
                __d("sdk.AuthState", ["sdk.AuthUtils"], (function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = s();

                    function s() {
                        var e = {
                            igAuthResponse: null,
                            fbAuthResponse: null,
                            fbLoginStatus: null,
                            igLoginStatus: null
                        };
                        return {
                            currentAuthResponse: null,
                            shouldSecondLoginRequestTimeOut: !1,
                            mixedAuthState: e,
                            loadState: null,
                            timer: null,
                            currentTimeOut: o("sdk.AuthUtils").AuthConstants.CONNECTED_REVALIDATE_PERIOD
                        }
                    }

                    function u() {
                        return babelHelpers.extends({}, s(), e)
                    }

                    function c(t) {
                        e = babelHelpers.extends({}, s(), e, t)
                    }
                    var d = {
                            getState: u,
                            setState: c
                        },
                        m = d;
                    l.default = m
                }), 98);
                __d("sdk.Cookie", ["QueryString", "sdk.Runtime", "sdk.Scribe", "sdk.feature"], function(t, n, r, o, a, i, l) {
                    var e = null,
                        s = ["fblo_", "fbsr_", "fbm_"];

                    function u(t, n, a, i) {
                        if (!(!ES(s, "includes", !0, t) && (o("sdk.Scribe").log("jssdk_error", {
                                appId: r("sdk.Runtime").getClientID(),
                                error: "unknown_cookie_prefix." + t
                            }), r("sdk.feature")("limit_unknown_cookie_setting", !1)))) {
                            var l = t + r("sdk.Runtime").getClientID(),
                                u = i ? "; SameSite=None;Secure" : "",
                                c = e !== null && e !== ".";
                            c && (document.cookie = l + "=; expires=Wed, 04 Feb 2004 08:00:00 GMT" + u, document.cookie = l + "=; expires=Wed, 04 Feb 2004 08:00:00 GMT;domain=" + location.hostname + u);
                            var d = new Date(a).toUTCString();
                            document.cookie = l + "=" + n + (n && a === 0 ? "" : "; expires=" + d) + "; path=/" + (c ? "; domain=" + (e != null ? e : "") : "") + u
                        }
                    }

                    function c(e) {
                        var t = e + r("sdk.Runtime").getClientID(),
                            n = new RegExp("\\b" + t + "=([^;]*)\\b"),
                            o = document.cookie.match(n);
                        return o == null ? null : o[1]
                    }

                    function d(t) {
                        e = t;
                        var n = r("QueryString").encode({
                                base_domain: e !== null && e !== "." ? e : ""
                            }),
                            o = new Date;
                        o.setFullYear(o.getFullYear() + 1), u("fbm_", n, o.getTime(), !0)
                    }

                    function m() {
                        return e
                    }

                    function p() {
                        var t = c("fbm_");
                        if (t != null && e === null) {
                            var n = r("QueryString").decode(t);
                            return e = n.base_domain, {
                                base_domain: e
                            }
                        }
                        return null
                    }

                    function _() {
                        return c("fbsr_")
                    }

                    function f(e, t) {
                        if (e === "") throw new Error("Value passed to Cookie.setSignedRequestCookie was empty.");
                        u("fbsr_", e, t, !0)
                    }

                    function g() {
                        p(), u("fbsr_", "", 0, !0)
                    }
                    l.setRaw = u, l.getRaw = c, l.setDomain = d, l.getDomain = m, l.loadMeta = p, l.loadSignedRequest = _, l.setSignedRequestCookie = f, l.clearSignedRequestCookie = g
                }, 98);
                __d("sdk.Observable", [], function(t, n, r, o, a, i) {
                    var e = function() {
                        var e = this;
                        this.getSubscribers = function(t) {
                            return e.$1[t] || (e.$1[t] = [])
                        }, this.clearSubscribers = function(t) {
                            t && (e.$1[t] = [])
                        }, this.subscribe = function(t, n) {
                            var r = e.getSubscribers(t);
                            r.push(n)
                        }, this.unsubscribe = function(t, n) {
                            for (var r = e.getSubscribers(t), o = 0; o < r.length; o++)
                                if (r[o] === n) {
                                    r.splice(o, 1);
                                    break
                                }
                        }, this.inform = function(t, n) {
                            for (var r = e.getSubscribers(t), o = function() {
                                    try {
                                        r[a].call(e, n)
                                    } catch (e) {
                                        window.setTimeout(function() {
                                            throw e
                                        }, 0)
                                    }
                                }, a = 0; a < r.length; a++) o()
                        }, this.$1 = {}
                    };
                    i.Observable = e
                }, 66);
                __d("sdk.AuthUtils", ["sdk.AuthState", "sdk.Cookie", "sdk.Observable", "sdk.Runtime"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = 1e3,
                        s = 60 * e,
                        u = 60 * s,
                        c = 24 * u,
                        d = 365 * c;

                    function m(e) {
                        return e != null && e.graphDomain != null ? e.graphDomain === "instagram" : !1
                    }

                    function p(e) {
                        r("sdk.Runtime").getUseCookie() && o("sdk.Cookie").getDomain() == null && o("sdk.Cookie").setDomain("." + e)
                    }

                    function _() {
                        var e = {
                                fbAuthResponse: null,
                                fbLoginStatus: null,
                                igAuthResponse: null,
                                igLoginStatus: null
                            },
                            t = !1;
                        r("sdk.AuthState").setState({
                            mixedAuthState: e,
                            shouldSecondLoginRequestTimeOut: t
                        })
                    }

                    function f(e) {
                        e != null ? (r("sdk.Runtime").setGraphDomain(e), e === "instagram" && r("sdk.Runtime").setIsVersioned(!1)) : r("sdk.Runtime").setGraphDomain("")
                    }

                    function g() {
                        o("sdk.Cookie").setRaw(I.LOGOUT_COOKIE_PREFIX, "y", Date.now() + d, !1)
                    }

                    function h(e) {
                        e === void 0 && (e = I.CONNECTED_REVALIDATE_PERIOD);
                        var t = r("sdk.AuthState").getState().timer;
                        t && window.clearTimeout(t);
                        var n = window.setTimeout(function() {
                            k.inform(I.REVALIDATE_TIMER_TIMEOUT)
                        }, e);
                        r("sdk.AuthState").setState({
                            timer: n
                        }), r("sdk.AuthState").setState({
                            currentTimeOut: e
                        })
                    }

                    function y() {
                        o("sdk.Cookie").setRaw(I.LOGOUT_COOKIE_PREFIX, "", 0, !1), o("sdk.Cookie").setRaw(I.LOGOUT_COOKIE_PREFIX, "", 0, !0)
                    }
                    var C = new(o("sdk.Observable")).Observable;

                    function b(e, t) {
                        C.inform(e, t)
                    }

                    function v(e, t) {
                        C.subscribe(e, t)
                    }

                    function S(e) {
                        C.clearSubscribers(e)
                    }

                    function R(e, t) {
                        C.unsubscribe(e, t)
                    }

                    function L(e) {
                        return C.getSubscribers(e)
                    }

                    function E() {
                        var e = navigator !== void 0 && navigator || null,
                            t = e && (e.userAgent || e.vendor || e.platform) || null;
                        if (t == null || typeof t != "string") return "unknown";
                        var n = t.toLowerCase();
                        if (ES(n, "includes", !0, "windows phone")) return "windows phone";
                        if (ES(n, "includes", !0, "android")) return "android";
                        if (ES(n, "includes", !0, "windows")) return "windows";
                        var r = /\b(iPad|iPhone|iPod)\b/i.test(t),
                            o = !r && e != null && (e.platform === "MacIntel" || e.platform === "MacPPC") && window !== void 0 && "ontouchend" in window;
                        return r || o ? "ios" : "unknown"
                    }
                    var k = {
                            inform: b,
                            subscribe: v,
                            clearSubscribers: S,
                            unsubscribe: R,
                            getSubscribers: L
                        },
                        I = {
                            LOCAL_STORAGE_TOKEN_PREFIX: "fblst_",
                            IG_LOCAL_STORAGE_TOKEN_PREFIX: "iglst_",
                            SESSION_STORAGE_LOGIN_STATUS_PREFIX: "fbssls_",
                            CONNECTED_REVALIDATE_PERIOD: s * 90,
                            DEFAULT_REVALIDATE_PERIOD: c,
                            LOGOUT_COOKIE_PREFIX: "fblo_",
                            CORS_FETCH_COMPLETED_EVENT: "cors_fetch_completed",
                            XFOA_FINAL_RESPONSE_EVENT: "xfoa_final_response",
                            LOAD_XFOA_SUBSCRIBERS: "load_xfoa_subscribers",
                            REVALIDATE_TIMER_TIMEOUT: "revalidate_timer_timeout"
                        };
                    l.isInstagramLogin = m, l.setBaseDomain = p, l.resetFBAndIGLoginStatus = _, l.setGraphDomain = f, l.setLogoutState = g, l.setRevalidateTimer = h, l.removeLogoutState = y, l.getMobileOperatingSystem = E, l.AuthInternalEvent = k, l.AuthConstants = I
                }, 98);
                __d("sdk.WebStorage", ["Log"], (function(t, n, r, o, a, i, l) {
                    "use strict";

                    function e() {
                        try {
                            return window.localStorage
                        } catch (e) {
                            o("Log").warn("Failed to get local storage")
                        }
                        return null
                    }

                    function s() {
                        try {
                            var e = window.localStorage;
                            if (e) {
                                var t = "__test__" + Date.now();
                                e.setItem(t, ""), e.removeItem(t)
                            }
                            return e
                        } catch (e) {
                            o("Log").warn("Failed to get local storage")
                        }
                        return null
                    }

                    function u() {
                        try {
                            return window.sessionStorage
                        } catch (e) {
                            o("Log").warn("Failed to get session storage")
                        }
                        return null
                    }

                    function c() {
                        try {
                            var e = window.sessionStorage;
                            if (e) {
                                var t = "__test__" + Date.now();
                                e.setItem(t, ""), e.removeItem(t)
                            }
                            return e
                        } catch (e) {
                            o("Log").warn("Failed to get session storage")
                        }
                        return null
                    }

                    function d(e, t, n) {
                        if (e != null) try {
                            e.setItem(t, n)
                        } catch (e) {}
                    }
                    l.getLocalStorage = e, l.getLocalStorageForRead = s, l.getSessionStorage = u, l.getSessionStorageForRead = c, l.setItemGuarded = d
                }), 98);
                __d("sdk.AuthStorageUtils", ["sdk.AuthUtils", "sdk.Runtime", "sdk.WebStorage", "sdk.feature"], function(t, n, r, o, a, i, l) {
                    "use strict";

                    function e(e, t) {
                        if (c() && t != null && t !== "") {
                            var n = o("sdk.WebStorage").getLocalStorage();
                            if (n) {
                                var a = o("sdk.AuthUtils").isInstagramLogin(e) ? o("sdk.AuthUtils").AuthConstants.IG_LOCAL_STORAGE_TOKEN_PREFIX : o("sdk.AuthUtils").AuthConstants.LOCAL_STORAGE_TOKEN_PREFIX;
                                n.setItem(a + r("sdk.Runtime").getClientID(), t)
                            }
                        }
                    }

                    function s(e) {
                        var t = o("sdk.WebStorage").getLocalStorage();
                        t && (e === "instagram" ? t.removeItem(o("sdk.AuthUtils").AuthConstants.IG_LOCAL_STORAGE_TOKEN_PREFIX + r("sdk.Runtime").getClientID()) : t.removeItem(o("sdk.AuthUtils").AuthConstants.LOCAL_STORAGE_TOKEN_PREFIX + r("sdk.Runtime").getClientID()))
                    }

                    function u(e, t) {
                        if (c()) {
                            var n = o("sdk.WebStorage").getSessionStorage();
                            n && n.setItem(o("sdk.AuthUtils").AuthConstants.SESSION_STORAGE_LOGIN_STATUS_PREFIX + r("sdk.Runtime").getClientID(), ES("JSON", "stringify", !1, {
                                authResponse: e,
                                status: t,
                                expiresAt: e != null && e.expiresIn && e.expiresIn !== 0 ? Date.now() + Math.min(e.expiresIn * .75 * 1e3, o("sdk.AuthUtils").AuthConstants.CONNECTED_REVALIDATE_PERIOD) : Date.now() + o("sdk.AuthUtils").AuthConstants.DEFAULT_REVALIDATE_PERIOD
                            }))
                        }
                    }

                    function c() {
                        return r("sdk.feature")("cache_auth_response", !1) && r("sdk.Runtime").getUseLocalStorage() && location.protocol === "https:"
                    }

                    function d() {
                        var e = null,
                            t = null;
                        if (r("sdk.Runtime").getUseLocalStorage()) {
                            var n = o("sdk.WebStorage").getLocalStorageForRead();
                            n && (e = n.getItem(o("sdk.AuthUtils").AuthConstants.LOCAL_STORAGE_TOKEN_PREFIX + r("sdk.Runtime").getClientID()), t = n.getItem(o("sdk.AuthUtils").AuthConstants.IG_LOCAL_STORAGE_TOKEN_PREFIX + r("sdk.Runtime").getClientID()))
                        }
                        return {
                            fbToken: e,
                            igToken: t
                        }
                    }

                    function m() {
                        if (!c()) return null;
                        var e = o("sdk.WebStorage").getSessionStorageForRead();
                        if (e) {
                            var t = e.getItem(o("sdk.AuthUtils").AuthConstants.SESSION_STORAGE_LOGIN_STATUS_PREFIX + r("sdk.Runtime").getClientID());
                            if (t != null) try {
                                var n = ES("JSON", "parse", !1, t);
                                if (n != null && n.expiresAt != null && n.expiresAt > Date.now()) return n
                            } catch (e) {
                                return null
                            }
                        }
                        return null
                    }
                    l.setLocalStorageToken = e, l.removeLocalStorageToken = s, l.setSessionStorage = u, l.getLocalStorageTokens = d, l.getCachedResponse = m
                }, 98);
                __d("Base64", [], function(t, n, r, o, a, i) {
                    "use strict";
                    var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

                    function l(t) {
                        var n = t.charCodeAt(0) << 16 | t.charCodeAt(1) << 8 | t.charCodeAt(2);
                        return String.fromCharCode(e.charCodeAt(n >>> 18), e.charCodeAt(n >>> 12 & 63), e.charCodeAt(n >>> 6 & 63), e.charCodeAt(n & 63))
                    }
                    var s = ">___?456789:;<=_______\0\x07\b	\n\v\f\r______\x1B !\"#$%&'()*+,-./0123";

                    function u(e) {
                        var t = s.charCodeAt(e.charCodeAt(0) - 43) << 18 | s.charCodeAt(e.charCodeAt(1) - 43) << 12 | s.charCodeAt(e.charCodeAt(2) - 43) << 6 | s.charCodeAt(e.charCodeAt(3) - 43);
                        return String.fromCharCode(t >>> 16, t >>> 8 & 255, t & 255)
                    }
                    var c = {
                            encode: function(t) {
                                var e = unescape(encodeURI(t)),
                                    n = (e.length + 2) % 3;
                                return e = (e + "\0\0".slice(n)).replace(/[\s\S]{3}/g, l), e.slice(0, e.length + n - 2) + "==".slice(n)
                            },
                            decode: function(t) {
                                var e = t.replace(/[^A-Za-z0-9+\/]/g, ""),
                                    n = e.length + 3 & 3;
                                e = (e + "AAA".slice(n)).replace(/..../g, u), e = e.slice(0, e.length + n - 3);
                                try {
                                    return decodeURIComponent(escape(e))
                                } catch (e) {
                                    throw new Error("Not valid UTF-8")
                                }
                            },
                            encodeObject: function(t) {
                                return c.encode(ES("JSON", "stringify", !1, t))
                            },
                            decodeObject: function(t) {
                                return ES("JSON", "parse", !1, c.decode(t))
                            },
                            encodeNums: function(n) {
                                return String.fromCharCode.apply(String, n.map(function(t) {
                                    return e.charCodeAt((t | -(t > 63 ? 1 : 0)) & -(t > 0 ? 1 : 0) & 63)
                                }))
                            }
                        },
                        d = c;
                    i.default = d
                }, 66);
                __d("sdk.SignedRequest", ["Base64"], function(t, n, r, o, a, i, l) {
                    function e(e) {
                        if (e == null || e === "") return null;
                        var t = e.split(".", 2)[1].replace(/\-/g, "+").replace(/\_/g, "/");
                        return r("Base64").decodeObject(t)
                    }
                    l.parse = e
                }, 98);
                __d("Miny", [], function(t, n, r, o, a, i) {
                    var e = "Miny1",
                        l = "wxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_".split(""),
                        s = {
                            encode: function(n) {
                                var t;
                                if (/^$|[~\\]|__proto__/.test(n)) return n;
                                var r = (t = n.match(/\w+|\W+/g)) != null ? t : [],
                                    o, a = Object.create(null);
                                for (o = 0; o < r.length; o++) a[r[o]] = (a[r[o]] || 0) + 1;
                                var i = Object.keys(a);
                                for (i.sort(function(e, t) {
                                        return parseInt(a[t], 10) - parseInt(a[e], 10)
                                    }), o = 0; o < i.length; o++) {
                                    var s = (o - o % 32) / 32;
                                    a[i[o]] = s ? s.toString(32) + l[o % 32] : l[o % 32]
                                }
                                var u = "";
                                for (o = 0; o < r.length; o++) u += a[r[o]];
                                return i.unshift(e, i.length), i.push(u), i.join("~")
                            }
                        },
                        u = s;
                    i.default = u
                }, 66);
                __d("getBlankIframeSrc", ["sdk.UA"], (function(t, n, r, o, a, i, l) {
                    function e() {
                        return r("sdk.UA").ie() < 10 ? "javascript:false" : "about:blank"
                    }
                    l.default = e
                }), 98);
                __d("insertIframe", ["GlobalCallback", "getBlankIframeSrc", "guid"], (function(t, n, r, o, a, i, l) {
                    function e(e) {
                        var t = e.id != null ? e.id : r("guid")(),
                            n = e.name != null ? e.name : r("guid")(),
                            a = !1,
                            i = !1,
                            l = function() {
                                a && !i && (i = !0, typeof e.onload == "function" && e.onload(e.root.firstChild))
                            },
                            s = o("GlobalCallback").create(l);
                        if (document.attachEvent) {
                            var u = '<iframe id="' + t + '" name="' + n + '"' + (e.title != null ? ' title="' + e.title + '"' : "") + (e.className != null ? ' class="' + e.className + '"' : "") + ' style="border:none;' + (e.width != null ? "width:" + e.width + "px;" : "") + (e.height != null ? "height:" + e.height + "px;" : "") + '" src="' + r("getBlankIframeSrc")() + '" frameborder="0" scrolling="no" allowtransparency="true" onload="' + s + '()"></iframe>';
                            e.root.innerHTML = '<iframe src="' + r("getBlankIframeSrc")() + '" frameborder="0" scrolling="no" style="height:1px"></iframe>', a = !0, window.setTimeout(function() {
                                e.root.innerHTML = u;
                                var t = e.root.firstChild;
                                t instanceof HTMLIFrameElement && (t.src = e.url), typeof e.onInsert == "function" && e.onInsert(e.root.firstChild)
                            }, 0)
                        } else {
                            var c = document.createElement("iframe");
                            c.id = t, c.name = n, c.onload = l, c.scrolling = "no", c.style.border = "none", c.style.overflow = "hidden", e.title != null && (c.title = e.title), e.className != null && (c.className = e.className), e.height !== void 0 && (c.style.height = e.height + "px"), e.width !== void 0 && (e.width === "100%" ? c.style.width = e.width : c.style.width = e.width + "px"), e.root.appendChild(c), a = !0, c.src = e.url, e.onInsert && e.onInsert(c)
                        }
                    }
                    l.default = e
                }), 98);
                __d("PromiseAnnotate", [], function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e, t) {
                        return e.displayName = t, e
                    }

                    function l(e) {
                        var t = e.displayName;
                        return typeof t == "string" ? t : null
                    }
                    i.setDisplayName = e, i.getDisplayName = l
                }, 66);
                __d("Promise", ["cr:6640"], function(t, n, r, o, a, i) {
                    "use strict";
                    var e, l = (e = n("cr:6640")) != null ? e : t.Promise;
                    l.allSettled || (l.allSettled = function(e) {
                        var t;
                        if ((typeof Symbol == "function" ? Symbol.iterator : "@@iterator") in e) t = ES("Array", "from", !1, e);
                        else return l.reject(new TypeError("Promise.allSettled must be passed an iterable."));
                        for (var n = Array(t.length), r = function() {
                                var e = t[o],
                                    r = typeof e == "object" && e !== null && typeof e.then == "function";
                                n[o] = r ? new l(function(t, n) {
                                    e.then(function(n) {
                                        t({
                                            status: "fulfilled",
                                            value: n
                                        })
                                    }, function(n) {
                                        t({
                                            status: "rejected",
                                            reason: n
                                        })
                                    })
                                }) : l.resolve({
                                    status: "fulfilled",
                                    value: e
                                })
                            }, o = 0, a = t.length; o < a; ++o) r();
                        return l.all(n)
                    }), l.prototype.finally || (l.prototype.finally = function(e) {
                        return this.then(function(t) {
                            return l.resolve(e()).then(function() {
                                return t
                            })
                        }, function(t) {
                            return l.resolve(e()).then(function() {
                                throw t
                            })
                        })
                    }), a.exports = l
                }, null);
                __d("asyncToGeneratorRuntime", ["Promise"], function(t, n, r, o, a, i) {
                    "use strict";
                    var e;

                    function l(t, r, o, a, i, l, s) {
                        try {
                            var u = t[l](s),
                                c = u.value
                        } catch (e) {
                            o(e);
                            return
                        }
                        u.done ? r(c) : (e || (e = n("Promise"))).resolve(c).then(a, i)
                    }

                    function s(t) {
                        return function() {
                            var r = this,
                                o = arguments;
                            return new(e || (e = n("Promise")))(function(e, n) {
                                var a = t.apply(r, o);

                                function i(t) {
                                    l(a, e, n, i, s, "next", t)
                                }

                                function s(t) {
                                    l(a, e, n, i, s, "throw", t)
                                }
                                i(void 0)
                            })
                        }
                    }
                    i.asyncToGenerator = s
                }, 66);
                __d("promiseDone", ["ErrorPubSub", "PromiseAnnotate", "asyncToGeneratorRuntime", "getErrorSafe"], function(t, n, r, o, a, i, l) {
                    var e, s;

                    function u(e) {
                        var t = r("getErrorSafe")(e);
                        t.loggingSource = "PROMISE_DONE", (s || (s = r("ErrorPubSub"))).reportError(t)
                    }

                    function c(e) {
                        return (function() {
                            var t = n("asyncToGeneratorRuntime").asyncToGenerator(function*(t) {
                                try {
                                    var n = yield e(t);
                                    return n
                                } catch (e) {
                                    u(e)
                                }
                            });
                            return function(e) {
                                return t.apply(this, arguments)
                            }
                        })()
                    }

                    function d(t, n, r) {
                        var a = r != null ? c(r) : null,
                            i = arguments.length > 1 ? t.then(n, a) : t;
                        r == null && i.then(null, u);
                        var l = (e || (e = o("PromiseAnnotate"))).getDisplayName(t);
                        l != null && (e || (e = o("PromiseAnnotate"))).setDisplayName(i, l)
                    }
                    l.default = d
                }, 98);
                __d("sdk.Impressions", ["Miny", "QueryString", "UrlMap", "getBlankIframeSrc", "guid", "insertIframe", "promiseDone", "sdk.Content", "sdk.Runtime"], function(t, n, r, o, a, i, l) {
                    function e(e, t) {
                        t === void 0 && (t = !1);
                        var n = r("sdk.Runtime").getClientID(),
                            a = r("sdk.Runtime").isEnvironment(r("sdk.Runtime").ENVIRONMENTS.CANVAS);
                        n && (typeof e.api_key != "string" || e.api_key === "") && (e.api_key = n), e.kid_directed_site = r("sdk.Runtime").getKidDirectedSite();
                        var i = o("UrlMap").resolve("www") + "/platform/impression.php/" + r("guid")() + "/";
                        a && (i = o("UrlMap").resolve("www") + "/platform/canvas_impression.php/" + r("guid")() + "/");
                        var l = r("QueryString").appendToUrl(i, e);
                        if (l.length > 2e3 && e.payload && typeof e.payload == "string") {
                            var c = e.payload,
                                d = r("Miny").encode(c);
                            d && d.length < c.length && (e.payload = d, l = r("QueryString").appendToUrl(i, e))
                        }
                        window.fetch ? s(i, l, e, t || a) : u(i, l, e, t || a)
                    }

                    function s(e, t, n, o) {
                        if (o === void 0 && (o = !1), t.length <= 2e3) o ? r("promiseDone")(window.fetch(t, {
                            mode: "no-cors",
                            credentials: "include"
                        })) : r("promiseDone")(window.fetch(t, {
                            mode: "no-cors",
                            credentials: "omit"
                        }));
                        else {
                            var a = new URLSearchParams;
                            for (var i in n)
                                if (Object.prototype.hasOwnProperty.call(n, i)) {
                                    var l = n[i];
                                    l != null && a.set(i, l)
                                }
                            o ? r("promiseDone")(window.fetch(e, {
                                method: "POST",
                                body: a,
                                mode: "no-cors",
                                credentials: "include"
                            })) : r("promiseDone")(window.fetch(e, {
                                method: "POST",
                                body: a,
                                mode: "no-cors",
                                credentials: "omit"
                            }))
                        }
                    }

                    function u(e, t, n, a) {
                        if (a === void 0 && (a = !1), t.length <= 2e3) {
                            var i = new Image;
                            a || (i.crossOrigin = "anonymous"), i.src = t
                        } else {
                            if (!a) return;
                            var l = r("guid")(),
                                s = o("sdk.Content").appendHidden(document.createElement("div"));
                            r("insertIframe")({
                                url: r("getBlankIframeSrc")(),
                                root: s,
                                name: l,
                                className: "fb_hidden fb_invisible",
                                onload: function() {
                                    s.parentNode != null && s.parentNode.removeChild(s)
                                }
                            }), o("sdk.Content").submitToTarget({
                                url: e,
                                target: l,
                                params: n
                            })
                        }
                    }

                    function c(t, n) {
                        (typeof n.source != "string" || n.source === "") && (n.source = "jssdk"), e({
                            lid: t,
                            payload: ES("JSON", "stringify", !1, n)
                        })
                    }
                    l.impression = e, l.log = c
                }, 98);
                __d("BaseDeserializePHPQueryData", [], (function(t, n, r, o, a, i) {
                    "use strict";
                    var e = /^([-_\w]+)((?:\[[-_\w]*\])+)=?(.*)/;

                    function l(e) {
                        return e === "hasOwnProperty" || e === "__proto__" ? "\uD83D\uDF56" : e
                    }

                    function s(t, n) {
                        if (t == null || t === "") return {};
                        for (var r = {}, o = t.replace(/%5B/gi, "[").replace(/%5D/gi, "]"), a = o.split("&"), i = Object.prototype.hasOwnProperty, s = 0, u = a.length; s < u; s++) {
                            var c = a[s].match(e);
                            if (c) {
                                var _ = c[2].split(/\]\[|\[|\]/).slice(0, -1),
                                    f = c[1],
                                    g = n(c[3] || "");
                                _[0] = f;
                                for (var h = r, y = 0; y < _.length - 1; y++) {
                                    var C = l(_[y]);
                                    if (C) {
                                        if (!i.call(h, C)) {
                                            var b = _[y + 1] && !_[y + 1].match(/^\d{1,3}$/) ? {} : [];
                                            if (h[C] = b, h[C] !== b) return r
                                        }
                                        h = h[C]
                                    } else _[y + 1] && !_[y + 1].match(/^\d{1,3}$/) ? h.push({}) : h.push([]), h = h[h.length - 1]
                                }
                                h instanceof Array && _[_.length - 1] === "" ? h.push(g) : h[l(_[_.length - 1])] = g
                            } else {
                                var d = a[s].indexOf("=");
                                if (d === -1) r[n(a[s])] = null;
                                else {
                                    var m = a[s].substring(0, d),
                                        p = a[s].substring(d + 1);
                                    r[n(m)] = n(p)
                                }
                            }
                        }
                        return r
                    }
                    i.deserialize = s
                }), 66);
                __d("flattenPHPQueryData", ["invariant"], (function(t, n, r, o, a, i, l, s) {
                    "use strict";

                    function e(e) {
                        return u(e, "", {})
                    }

                    function u(e, t, n) {
                        if (e == null) n[t] = void 0;
                        else if (typeof e == "object") {
                            typeof e.appendChild != "function" || s(0, 2616);
                            for (var r in e) r !== "$$typeof" && Object.prototype.hasOwnProperty.call(e, r) && e[r] !== void 0 && u(e[r], t ? t + "[" + r + "]" : r, n)
                        } else n[t] = e;
                        return n
                    }
                    l.default = e
                }), 98);
                __d("PHPQuerySerializer", ["BaseDeserializePHPQueryData", "flattenPHPQueryData"], (function(t, n, r, o, a, i, l) {
                    function e(e) {
                        var t = [],
                            n = r("flattenPHPQueryData")(e);
                        for (var o in n)
                            if (Object.prototype.hasOwnProperty.call(n, o)) {
                                var a = s(o);
                                n[o] === void 0 ? t.push(a) : t.push(a + "=" + s(String(n[o])))
                            }
                        return t.join("&")
                    }

                    function s(e) {
                        return encodeURIComponent(e).replace(/%5D/g, "]").replace(/%5B/g, "[")
                    }

                    function u(e) {
                        return o("BaseDeserializePHPQueryData").deserialize(e, c)
                    }

                    function c(e) {
                        try {
                            return decodeURIComponent(e.replace(/\+/g, " "))
                        } catch (t) {
                            return e
                        }
                    }
                    var d = {
                        decodeComponent: c,
                        deserialize: u,
                        encodeComponent: s,
                        serialize: e
                    };
                    i.exports = d
                }), 34);
                __d("PHPStrictQuerySerializer", ["PHPQuerySerializer", "flattenPHPQueryData"], function(t, n, r, o, a, i, l) {
                    var e;

                    function s(e) {
                        var t = [],
                            n = r("flattenPHPQueryData")(e);
                        for (var o in n)
                            if (Object.prototype.hasOwnProperty.call(n, o)) {
                                var a = u(o);
                                n[o] === void 0 ? t.push(a) : t.push(a + "=" + u(String(n[o])))
                            }
                        return t.join("&")
                    }

                    function u(e) {
                        return encodeURIComponent(e)
                    }
                    l.serialize = s, l.encodeComponent = u, l.deserialize = (e || (e = o("PHPQuerySerializer"))).deserialize, l.decodeComponent = e.decodeComponent
                }, 98);
                __d("URIRFC3986", [], function(t, n, r, o, a, i) {
                    "use strict";
                    var e = new RegExp("^([^:/?#]+:)?(//([^\\\\/?#@]*@)?(\\[[A-Fa-f0-9:.]+\\]|[^\\/?#:]*)(:[0-9]*)?)?([^?#]*)(\\?[^#]*)?(#.*)?");

                    function l(t) {
                        if (t.trim() === "") return null;
                        var n = t.match(e);
                        if (n == null) return null;
                        var r = n[2] ? n[2].substr(2) : null,
                            o = n[1] ? n[1].substr(0, n[1].length - 1) : null,
                            a = {
                                uri: n[0] ? n[0] : null,
                                scheme: o,
                                authority: r,
                                userinfo: n[3] ? n[3].substr(0, n[3].length - 1) : null,
                                host: n[2] ? n[4] : null,
                                port: n[5] && n[5].substr(1) ? parseInt(n[5].substr(1), 10) : null,
                                path: n[6] ? n[6] : null,
                                query: n[7] ? n[7].substr(1) : null,
                                fragment: n[8] ? n[8].substr(1) : null,
                                isGenericURI: r === null && !!o
                            };
                        return a
                    }
                    i.parse = l
                }, 66);
                __d("$InternalEnum", [], function(t, n, r, o, a, i) {
                    "use strict";
                    var e = Object.prototype.hasOwnProperty,
                        l = typeof WeakMap == "function" ? new WeakMap : new Map;

                    function s(e) {
                        var t = l.get(e);
                        if (t !== void 0) return t;
                        var n = new Map;
                        Object.getOwnPropertyNames(e).forEach(function(t) {
                            n.set(e[t], t)
                        });
                        try {
                            l.set(e, n)
                        } catch (e) {}
                        return n
                    }
                    var u = Object.freeze(Object.defineProperties(Object.create(null), {
                        isValid: {
                            value: function(t) {
                                return s(this).has(t)
                            }
                        },
                        cast: {
                            value: function(t) {
                                return this.isValid(t) ? t : void 0
                            }
                        },
                        members: {
                            value: function() {
                                return s(this).keys()
                            }
                        },
                        getName: {
                            value: function(t) {
                                return s(this).get(t)
                            }
                        }
                    }));

                    function c(t) {
                        var n = Object.create(u);
                        for (var r in t) e.call(t, r) && Object.defineProperty(n, r, {
                            value: t[r]
                        });
                        return Object.freeze(n)
                    }
                    var d = Object.freeze(Object.defineProperties(Object.create(null), {
                        isValid: {
                            value: function(n) {
                                return typeof n == "string" ? e.call(this, n) : !1
                            }
                        },
                        cast: {
                            value: u.cast
                        },
                        members: {
                            value: function() {
                                return Object.getOwnPropertyNames(this).values()
                            }
                        },
                        getName: {
                            value: function(t) {
                                return t
                            }
                        }
                    }));
                    c.Mirrored = function(t) {
                        for (var e = Object.create(d), n = 0, r = t.length; n < r; ++n) Object.defineProperty(e, t[n], {
                            value: t[n]
                        });
                        return Object.freeze(e)
                    }, Object.freeze(c.Mirrored), a.exports = Object.freeze(c)
                }, null);
                __d("URISchemes", ["$InternalEnum"], function(t, n, r, o, a, i) {
                    "use strict";
                    var e = new Set(["about", "accountscenter", "aidemos", "aistudio", "apk", "blob", "barcelona", "cmms", "fb", "fba", "fbatwork", "fb-ama", "fb-internal", "fb-workchat", "fb-workchat-secure", "fb-messenger", "fb-messenger-public", "fb-messenger-group-thread", "fb-page-messages", "fb-pma", "fbcf", "fbconnect", "fbinternal", "fbmobilehome", "fbrpc", "file", "flipper", "ftp", "gtalk", "http", "https", "mailto", "wss", "ms-app", "intent", "itms", "itms-apps", "itms-services", "lasso", "market", "svn+ssh", "fbstaging", "tel", "sms", "pebblejs", "sftp", "whatsapp", "moments", "flash", "fblite", "chrome-extension", "webcal", "instagram", "iglite", "fb124024574287414", "fb124024574287414rc", "fb124024574287414master", "fb1576585912599779", "fb929757330408142", "designpack", "fbpixelcloud", "fbapi20130214", "fb1196383223757595", "tbauth", "oculus", "oculus.store", "oculus.feed", "fb1680871178595114", "fb1543576032349914", "fb1635404796768116", "fb147781309031234", "oculusstore", "socialplatform", "odh", "com.oculus.rd", "aria", "skype", "ms-windows-store", "callto", "messenger", "workchat", "fb236786383180508", "fb1775440806014337", "data", "fb-mk", "munki", "origami-file", "fb-nimble-vrsrecorder", "fb-nimble-monohandtrackingvis", "together", "togetherbl", "horizonlauncher", "horizon", "venues", "whatsapp-consumer", "whatsapp-smb", "fb-ide-opener", "fb-vscode", "fb-vscode-insiders", "fb-vscode-dev", "editor", "spark-studio", "spark-player", "spark-simulator", "meta-spatial-editor", "cosmo-player", "arstudio", "manifold", "origami-internal", "origami-public", "stella", "mwa", "mattermost", "logaggregator", "pcoip", "cinema", "home", "oculus360photos", "systemux", "content", "moonstone", "hsr-asset-viewer", "upi", "phonepe", "gpay", "tez", "paytmmp", "bhim", "q4bconfigurator", "q4bnux", "fb-viewapp", "meta-ai", "vibes", "x-safari-https", "meta-bloks", "facebook-horizon", "fbboost", "ctrl-hub", "hsr-editor", "assethub", "gizmo"]),
                        l = n("$InternalEnum")({
                            EXPLICITLY_ALLOWED_SCHEMES_ONLY: "explicitly_allowed_schemes_only",
                            INCLUDE_DEFAULTS: "include_defaults"
                        });

                    function s(t, n, r) {
                        return n === void 0 && (n = l.INCLUDE_DEFAULTS), t == null || t === "" ? !0 : (r == null ? void 0 : r.has(t.toLowerCase())) || n === l.INCLUDE_DEFAULTS && e.has(t.toLowerCase())
                    }
                    i.Options = l, i.isAllowed = s
                }, 66);
                __d("isSameOrigin", [], function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e, t) {
                        return !e.getProtocol() || !e.getDomain() || !t.getProtocol() || !t.getDomain() ? !1 : e.getOrigin() === t.getOrigin()
                    }
                    i.default = e
                }, 66);
                __d("setHostSubdomain", [], (function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e, t) {
                        var n = e.split(".");
                        return n.length < 3 ? n.unshift(t) : n[0] = t, n.join(".")
                    }
                    i.default = e
                }), 66);
                __d("URIAbstractBase", ["invariant", "FBLogger", "PHPStrictQuerySerializer", "URIRFC3986", "URISchemes", "isSameOrigin", "setHostSubdomain"], function(t, n, r, o, a, i, l) {
                    var e, s, u = new RegExp("[\\x00-\\x2c\\x2f\\x3b-\\x40\\x5c\\x5e\\x60\\x7b-\\x7f\\uFDD0-\\uFDEF\\uFFF0-\\uFFFF\\u2047\\u2048\\uFE56\\uFE5F\\uFF03\\uFF0F\\uFF1F]"),
                        c = new RegExp("^(?:[^/]*:|[\\x00-\\x1f]*/[\\x00-\\x1f]*/)"),
                        d = [],
                        m = (function() {
                            "use strict";

                            function t(r, o, a, i) {
                                a === void 0 && (a = (e || (e = n("URISchemes"))).Options.INCLUDE_DEFAULTS), o || l(0, 2966), this.$9 = o, this.$7 = "", this.$1 = "", this.$6 = "", this.$5 = "", this.$3 = "", this.$4 = !1, this.$8 = {}, this.$2 = !1, this.$12 = a, this.$13 = i, t.parse(this, r, !0, o), this.$11 = !1
                            }
                            t.parse = function(o, a, i, l) {
                                if (!a) return !0;
                                if (a instanceof t) return o.setProtocol(a.getProtocol()), o.setDomain(a.getDomain()), o.setPort(a.getPort()), o.setPath(a.getPath()), o.setQueryData(l.deserialize(l.serialize(a.getQueryData()))), o.setFragment(a.getFragment()), o.setIsGeneric(a.getIsGeneric()), o.setForceFragmentSeparator(a.getForceFragmentSeparator()), o.setOriginalRawQuery(a.getOriginalRawQuery()), o.setQueryParamModified(!1), !0;
                                a = a.toString().trim();
                                var r = (s || (s = n("URIRFC3986"))).parse(a) || {
                                    fragment: null,
                                    scheme: null,
                                    query: null
                                };
                                if (!i && !(e || (e = n("URISchemes"))).isAllowed(r.scheme, o.$12, o.$13) || (o.setProtocol(r.scheme || ""), !i && u.test(r.host || ""))) return !1;
                                if (o.setDomain(r.host || ""), o.setPort(r.port || ""), o.setPath(r.path || ""), i) o.setQueryData(l.deserialize(r.query || "") || {});
                                else try {
                                    o.setQueryData(l.deserialize(r.query || "") || {})
                                } catch (e) {
                                    return !1
                                }
                                if (o.setFragment(r.fragment || ""), r.fragment === "" && o.setForceFragmentSeparator(!0), o.setIsGeneric(r.isGenericURI || !1), o.setOriginalRawQuery(r.query), o.setQueryParamModified(!1), r.userinfo !== null) {
                                    if (i) throw new Error("URI.parse: invalid URI (userinfo is not allowed in a URI): " + a);
                                    return !1
                                }
                                if (!o.getDomain() && o.getPath().indexOf("\\") !== -1) {
                                    if (i) throw new Error("URI.parse: invalid URI (no domain but multiple back-slashes): " + a);
                                    return !1
                                }
                                if (!o.getProtocol() && c.test(a)) {
                                    if (i) throw new Error("URI.parse: invalid URI (unsafe protocol-relative URLs): " + a + "'");
                                    return !1
                                }
                                if (o.getDomain() && o.getPath() && !ES(o.getPath(), "startsWith", !0, "/")) {
                                    if (i) throw new Error("URI.parse: invalid URI (domain and path where path lacks leading slash): " + a);
                                    return !1
                                }
                                if (o.getProtocol() && o.getProtocol() !== "file" && !o.getIsGeneric() && !o.getDomain() && o.getPath() !== "" && (n("FBLogger")("uri").warn('URI.parse: invalid URI (protocol "' + o.getProtocol() + '" with no domain)'), o.enforceProtocolRequiresDomain())) {
                                    if (i) throw new Error("URI.parse: invalid URI (protocol and path but no domain): " + a);
                                    return !1
                                }
                                return !0
                            }, t.tryParse = function(n, r, o, a) {
                                var e = new t(null, r, o, a);
                                return t.parse(e, n, !1, r) ? e : null
                            }, t.isValid = function(n, r, o, a) {
                                return !!t.tryParse(n, r, o, a)
                            };
                            var r = t.prototype;
                            return r.setProtocol = function(r) {
                                return (e || (e = n("URISchemes"))).isAllowed(r, this.$12, this.$13) || l(0, 11793, r), this.$7 = r, this
                            }, r.getProtocol = function() {
                                return (this.$7 || "").toLowerCase()
                            }, r.setSecure = function(t) {
                                return this.setProtocol(t ? "https" : "http")
                            }, r.isSecure = function() {
                                return this.getProtocol() === "https"
                            }, r.setDomain = function(t) {
                                if (u.test(t)) throw new Error("URI.setDomain: unsafe domain specified: " + t + " for url " + this.toString());
                                return this.$1 = t, this
                            }, r.getDomain = function() {
                                return this.$1
                            }, r.setPort = function(t) {
                                return this.$6 = t, this
                            }, r.getPort = function() {
                                return this.$6
                            }, r.setPath = function(t) {
                                return this.$5 = t, this
                            }, r.getPath = function() {
                                return this.$5
                            }, r.addQueryData = function(t, n) {
                                return Object.prototype.toString.call(t) === "[object Object]" ? ES("Object", "assign", !1, this.$8, t) : this.$8[t] = n, this.$11 = !0, this
                            }, r.setQueryData = function(t) {
                                return this.$8 = t, this.$11 = !0, this
                            }, r.getQueryData = function() {
                                return this.$8
                            }, r.setQueryString = function(t) {
                                return this.setQueryData(this.$9.deserialize(t))
                            }, r.getQueryString = function(t, n, r) {
                                return t === void 0 && (t = !1), n === void 0 && (n = function() {
                                    return !1
                                }), r === void 0 && (r = null), this.$14(!1, t, n, r)
                            }, r.$14 = function(t, n, r, o) {
                                if (t === void 0 && (t = !1), n === void 0 && (n = !1), r === void 0 && (r = function() {
                                        return !1
                                    }), o === void 0 && (o = null), !this.$11 && (n || r(this.getDomain()))) {
                                    var e;
                                    return (e = this.$10) != null ? e : ""
                                }
                                return (t && o ? o : this.$9).serialize(this.getQueryData())
                            }, r.removeQueryData = function(t) {
                                Array.isArray(t) || (t = [t]);
                                for (var e = 0, n = t.length; e < n; ++e) delete this.$8[t[e]];
                                return this.$11 = !0, this
                            }, r.setFragment = function(t) {
                                return this.$3 = t, this.setForceFragmentSeparator(!1), this
                            }, r.getFragment = function() {
                                return this.$3
                            }, r.setForceFragmentSeparator = function(t) {
                                return this.$2 = t, this
                            }, r.getForceFragmentSeparator = function() {
                                return this.$2
                            }, r.setIsGeneric = function(t) {
                                return this.$4 = t, this
                            }, r.getIsGeneric = function() {
                                return this.$4
                            }, r.getOriginalRawQuery = function() {
                                return this.$10
                            }, r.setOriginalRawQuery = function(t) {
                                return this.$10 = t, this
                            }, r.setQueryParamModified = function(t) {
                                return this.$11 = t, this
                            }, r.isEmpty = function() {
                                return !(this.getPath() || this.getProtocol() || this.getDomain() || this.getPort() || Object.keys(this.getQueryData()).length > 0 || this.getFragment())
                            }, r.toString = function(t, n) {
                                return t === void 0 && (t = function() {
                                    return !1
                                }), n === void 0 && (n = null), this.$15(!1, !1, t, n)
                            }, r.toStringRawQuery = function(t, n) {
                                return t === void 0 && (t = function() {
                                    return !1
                                }), n === void 0 && (n = null), this.$15(!0, !1, t, n)
                            }, r.toStringPreserveQuery = function(t, n) {
                                return t === void 0 && (t = function() {
                                    return !1
                                }), n === void 0 && (n = null), this.$15(!1, !0, t, n)
                            }, r.toStringStrictQueryEncoding = function(t) {
                                return t === void 0 && (t = function() {
                                    return !1
                                }), this.$15(!0, !1, t, n("PHPStrictQuerySerializer"))
                            }, r.$15 = function(t, n, r, o) {
                                t === void 0 && (t = !1), n === void 0 && (n = !1), r === void 0 && (r = function() {
                                    return !1
                                }), o === void 0 && (o = null);
                                for (var e = this, a = 0; a < d.length; a++) e = d[a](e);
                                return e.$16(t, n, r, o)
                            }, r.$16 = function(t, n, r, o) {
                                t === void 0 && (t = !1), n === void 0 && (n = !1), r === void 0 && (r = function() {
                                    return !1
                                }), o === void 0 && (o = null);
                                var e = "",
                                    a = this.getProtocol();
                                a && (e += a + ":" + (this.getIsGeneric() ? "" : "//"));
                                var i = this.getDomain();
                                i && (e += i);
                                var l = this.getPort();
                                l && (e += ":" + l);
                                var s = this.getPath();
                                s ? e += s : e && (e += "/");
                                var u = this.$14(t, n, r, o);
                                u && (e += "?" + u);
                                var c = this.getFragment();
                                return c ? e += "#" + c : this.getForceFragmentSeparator() && (e += "#"), e
                            }, t.registerFilter = function(t) {
                                d.push(t)
                            }, r.getOrigin = function() {
                                var e = this.getPort();
                                return this.getProtocol() + "://" + this.getDomain() + (e ? ":" + e : "")
                            }, r.isSameOrigin = function(t) {
                                return n("isSameOrigin")(this, t)
                            }, r.getQualifiedURIBase = function() {
                                return new t(this, this.$9).qualify()
                            }, r.qualify = function() {
                                if (!this.getDomain()) {
                                    var e = new t(window.location.href, this.$9);
                                    this.setProtocol(e.getProtocol()).setDomain(e.getDomain()).setPort(e.getPort())
                                }
                                return this
                            }, r.setSubdomain = function(t) {
                                var e = this.qualify(),
                                    r = e.getDomain();
                                return this.setDomain(n("setHostSubdomain")(r, t))
                            }, r.getSubdomain = function() {
                                if (!this.getDomain()) return "";
                                var e = this.getDomain().split(".");
                                return e.length <= 2 ? "" : e[0]
                            }, r.isSubdomainOfDomain = function(n) {
                                var e = this.getDomain();
                                return t.isDomainSubdomainOfDomain(e, n, this.$9)
                            }, t.isDomainSubdomainOfDomain = function(n, r, o) {
                                if (r === "" || n === "") return !1;
                                if (ES(n, "endsWith", !0, r)) {
                                    var e = n.length,
                                        a = r.length,
                                        i = e - a - 1;
                                    if (e === a || n[i] === ".") {
                                        var l = new t(null, o);
                                        return l.setDomain(r), t.isValid(l, o)
                                    }
                                }
                                return !1
                            }, r.enforceProtocolRequiresDomain = function() {
                                return !0
                            }, t
                        })();
                    a.exports = m
                }, null);
                __d("sdk.URI", ["QueryString", "URIAbstractBase", "sdk.feature"], function(t, n, r, o, a, i, l) {
                    var e = /\.facebook\.com$/,
                        s = {
                            serialize: function(t) {
                                return t ? r("QueryString").encode(t) : ""
                            },
                            deserialize: function(t) {
                                return t ? r("QueryString").decode(t) : {}
                            }
                        },
                        u = (function(t) {
                            function n(e) {
                                return t.call(this, e, s) || this
                            }
                            babelHelpers.inheritsLoose(n, t);
                            var o = n.prototype;
                            return o.isFacebookURI = function() {
                                return e.test(this.getDomain())
                            }, o.valueOf = function() {
                                return this.toString()
                            }, n.isValidURI = function(t) {
                                return r("URIAbstractBase").isValid(t, s)
                            }, o.enforceProtocolRequiresDomain = function() {
                                var e;
                                return (e = r("sdk.feature")("enforce_protocol_requires_domain", !0)) != null ? e : !0
                            }, n
                        })(r("URIAbstractBase"));
                    l.default = u
                }, 98);
                __d("sdk.getContextType", ["sdk.Runtime", "sdk.UA"], function(t, n, r, o, a, i, l) {
                    function e() {
                        return r("sdk.UA").nativeApp() ? 3 : r("sdk.UA").mobile() ? 2 : r("sdk.Runtime").isEnvironment(r("sdk.Runtime").ENVIRONMENTS.CANVAS) ? 5 : 1
                    }
                    l.default = e
                }, 98);
                __d("sdk.statusCORS", ["Log", "UrlMap", "sdk.AuthState", "sdk.AuthStorageUtils", "sdk.AuthUtils", "sdk.Impressions", "sdk.Runtime", "sdk.Scribe", "sdk.URI", "sdk.feature", "sdk.getContextType"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = 6e4,
                        s = 114;

                    function u(t, n, a, i) {
                        i === void 0 && (i = "facebook");
                        var l = p(n),
                            u = Date.now();

                        function m() {
                            var e = new XMLHttpRequest;
                            e && (e.open("GET", l.toString(), !0), e.withCredentials = !0, e.onreadystatechange = function() {
                                if (e.readyState === 4) {
                                    if (r("sdk.feature")("e2e_ping_tracking", !0)) {
                                        var n = {
                                            init: u,
                                            close: Date.now(),
                                            method: "cors"
                                        };
                                        o("Log").debug("e2e: %s", ES("JSON", "stringify", !1, n)), o("sdk.Impressions").log(s, {
                                            payload: n
                                        })
                                    }
                                    if (e.status === 200) {
                                        var l, m;
                                        c(t, (l = e.getResponseHeader("fb-s")) != null ? l : "unknown", (m = e.getResponseHeader("fb-ar")) != null ? m : "{}", i)
                                    } else d(t, e.status, a, i)
                                }
                            }, e.send())
                        }

                        function g() {
                            _(i) || window.setTimeout(function() {
                                f(i === "facebook" ? "instagram" : "facebook"), r("sdk.AuthState").setState({
                                    shouldSecondLoginRequestTimeOut: !0
                                })
                            }, e)
                        }

                        function h() {
                            window.fetch(l.toString(), {
                                referrer: "/",
                                mode: "cors",
                                credentials: "include"
                            }).then(function(e) {
                                if (r("sdk.AuthState").getState().shouldSecondLoginRequestTimeOut === !0) {
                                    r("sdk.AuthState").setState({
                                        shouldSecondLoginRequestTimeOut: !1
                                    });
                                    return
                                }
                                if (g(), e.status === 200) {
                                    var n, o;
                                    c(t, (n = e.headers.get("fb-s")) != null ? n : "unknown", (o = e.headers.get("fb-ar")) != null ? o : "{}", i)
                                } else d(t, e.status, a, i)
                            }).catch(function(e) {
                                if (r("sdk.AuthState").getState().shouldSecondLoginRequestTimeOut === !0) {
                                    r("sdk.AuthState").setState({
                                        shouldSecondLoginRequestTimeOut: !1
                                    });
                                    return
                                }
                                g(), d(t, 0, a, i)
                            })
                        }
                        typeof window.fetch == "function" ? h() : m()
                    }

                    function c(e, t, n, a) {
                        switch (a === void 0 && (a = "facebook"), t) {
                            case "connected":
                                var i = ES("JSON", "parse", !1, n),
                                    l = {
                                        accessToken: i.access_token,
                                        userID: i.user_id,
                                        expiresIn: Number(i.expires_in),
                                        signedRequest: i.signed_request,
                                        graphDomain: i.graph_domain
                                    };
                                i.enforce_https != null && r("sdk.Runtime").setEnforceHttps(!0), i.data_access_expiration_time != null && (l.data_access_expiration_time = Number(i.data_access_expiration_time)), i.base_domain != null && o("sdk.AuthUtils").setBaseDomain(i.base_domain), o("sdk.AuthUtils").setGraphDomain(i.graph_domain), o("sdk.AuthStorageUtils").setLocalStorageToken(l, i.long_lived_token), o("sdk.AuthUtils").removeLogoutState();
                                var s = {
                                    authResponse: l,
                                    status: t,
                                    loginSource: a,
                                    cb: e
                                };
                                o("sdk.AuthUtils").AuthInternalEvent.inform(o("sdk.AuthUtils").AuthConstants.CORS_FETCH_COMPLETED_EVENT, s);
                                break;
                            case "not_authorized":
                            case "unknown":
                            default:
                                var u = {
                                    authResponse: null,
                                    status: t,
                                    loginSource: a,
                                    cb: e
                                };
                                o("sdk.AuthUtils").AuthInternalEvent.inform(o("sdk.AuthUtils").AuthConstants.CORS_FETCH_COMPLETED_EVENT, u)
                        }
                    }

                    function d(e, t, n, a) {
                        a === void 0 && (a = "facebook"), t === 0 ? (r("sdk.feature")("cors_status_fetch_cancel_tracking", !1) && o("sdk.Scribe").log("jssdk_error", {
                            appId: r("sdk.Runtime").getClientID(),
                            error: "CORS_STATUS_FETCH_CANCELLED",
                            extra: {
                                message: "Status 0 returned."
                            }
                        }), o("Log").error("Error retrieving login status, fetch cancelled.")) : (o("sdk.Scribe").log("jssdk_error", {
                            appId: r("sdk.Runtime").getClientID(),
                            error: "CORS_STATUS_FETCH",
                            extra: {
                                message: "HTTP Status Code " + t
                            }
                        }), o("Log").error("Error retrieving login status, HTTP status code: " + t));
                        var i = m();
                        if (i && i === a) {
                            var l = {
                                authResponse: n,
                                status: r("sdk.Runtime").getLoginStatus(),
                                loginSource: a,
                                cb: e,
                                shouldSetAuthResponse: !1
                            };
                            o("sdk.AuthUtils").AuthInternalEvent.inform(o("sdk.AuthUtils").AuthConstants.CORS_FETCH_COMPLETED_EVENT, l)
                        } else {
                            var s = {
                                authResponse: null,
                                status: "unknown",
                                loginSource: a,
                                cb: e,
                                shouldSetAuthResponse: !1
                            };
                            o("sdk.AuthUtils").AuthInternalEvent.inform(o("sdk.AuthUtils").AuthConstants.CORS_FETCH_COMPLETED_EVENT, s)
                        }
                    }

                    function m() {
                        var e = r("sdk.AuthState").getState().currentAuthResponse;
                        return e ? o("sdk.AuthUtils").isInstagramLogin(e) ? "instagram" : "facebook" : null
                    }

                    function p(e) {
                        var t = new(r("sdk.URI"))(o("UrlMap").resolve("www").replace("web.", "www.") + "/x/oauth/status").addQueryData("client_id", r("sdk.Runtime").getClientID()).addQueryData("input_token", e).addQueryData("redirect_uri", window.location.href).addQueryData("origin", r("sdk.getContextType")()).addQueryData("sdk", "joey").addQueryData("wants_cookie_data", r("sdk.Runtime").getUseCookie());
                        if (window.location.ancestorOrigins) {
                            var n = window.location.ancestorOrigins;
                            if (n.length > 0) {
                                for (var a = "", i = 0; i < n.length; i++) a += n[i], a += ",";
                                t.addQueryData("ancestor_origins", a.slice(0, -1))
                            }
                        }
                        return t
                    }

                    function _(e) {
                        var t = r("sdk.AuthState").getState().mixedAuthState;
                        switch (e) {
                            case "facebook":
                                return (t == null ? void 0 : t.fbLoginStatus) === null && (t == null ? void 0 : t.igLoginStatus) !== null;
                            case "instagram":
                                return (t == null ? void 0 : t.igLoginStatus) === null && (t == null ? void 0 : t.fbLoginStatus) !== null;
                            default:
                                return !1
                        }
                    }

                    function f(e) {
                        var t = r("sdk.AuthState").getState().mixedAuthState;
                        if (!((t == null ? void 0 : t.fbLoginStatus) != null && (t == null ? void 0 : t.igLoginStatus) != null)) {
                            var n = {
                                authResponse: null,
                                status: "unknown",
                                loginSource: e
                            };
                            o("sdk.AuthUtils").AuthInternalEvent.inform("xFoAFetchCompleted", n)
                        }
                    }
                    var g = {
                            getLoginStatusCORS: u
                        },
                        h = g;
                    l.default = h
                }, 98);
                __d("sdk.Auth.LoginStatus", ["Log", "QueryString", "sdk.Auth", "sdk.AuthState", "sdk.AuthStorageUtils", "sdk.AuthUtils", "sdk.Cookie", "sdk.Runtime", "sdk.Scribe", "sdk.SignedRequest", "sdk.feature", "sdk.statusCORS"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = /^https?:\/\/([\w\.]+)?\.facebook\.com\/?/;
                    r("sdk.Runtime").subscribe("AccessToken.change", function(e) {
                        !e && r("sdk.Runtime").getLoginStatus() === "connected" && m(null, !0)
                    });

                    function s(e) {
                        if (e.legacyStatusInit ? _.getLoginStatus(function(e) {
                                e != null && e.status === "connected" && o("sdk.Scribe").log("jssdk_error", {
                                    appId: r("sdk.Runtime").getClientID(),
                                    error: "legacy_status_init_success"
                                })
                            }) : e.status && _.getLoginStatus(), r("sdk.Runtime").getClientID() && r("sdk.Runtime").getUseCookie()) {
                            r("sdk.feature")("log_cookies_usage", !1) && o("sdk.Scribe").log("jssdk_error", {
                                appId: r("sdk.Runtime").getClientID(),
                                error: "jssdk_cookie_toggled_on"
                            });
                            var t = o("sdk.Cookie").loadSignedRequest(),
                                n;
                            if (t) {
                                try {
                                    n = o("sdk.SignedRequest").parse(t)
                                } catch (e) {
                                    o("sdk.Cookie").clearSignedRequestCookie()
                                }
                                n != null && n.user_id != null && r("sdk.Runtime").setCookieUserID(n.user_id)
                            }
                        }
                    }

                    function u(e) {
                        if (window.location.protocol !== "https:") {
                            p(e);
                            return
                        }
                        var t = r("sdk.AuthState").getState().timer;
                        t && (window.clearTimeout(t), r("sdk.AuthState").setState({
                            timer: null
                        })), o("sdk.AuthUtils").resetFBAndIGLoginStatus();
                        var n = o("sdk.Cookie").getRaw(o("sdk.AuthUtils").AuthConstants.LOGOUT_COOKIE_PREFIX) === "y",
                            a = d(e),
                            i = a.access_token,
                            l = a.redirect_cancelled;
                        if (n || l) {
                            p(e);
                            return
                        }
                        var s = o("sdk.AuthStorageUtils").getLocalStorageTokens(),
                            u = s.fbToken,
                            m = s.igToken;
                        i != null && (ES(i, "startsWith", !0, "IG") ? m = i : u = i), r("sdk.Runtime").getShouldLoadFamilyLogin() && r("sdk.feature")("should_enable_ig_login_status_fetch", !1) ? r("sdk.Runtime").getFamilyLoginLoaded() ? o("sdk.AuthUtils").AuthInternalEvent.inform(o("sdk.AuthUtils").AuthConstants.LOAD_XFOA_SUBSCRIBERS) : r("sdk.Runtime").subscribe("FamilyLoginLoaded.change", function(e) {
                            e && o("sdk.AuthUtils").AuthInternalEvent.inform(o("sdk.AuthUtils").AuthConstants.LOAD_XFOA_SUBSCRIBERS)
                        }) : o("sdk.AuthUtils").AuthInternalEvent.subscribe(o("sdk.AuthUtils").AuthConstants.CORS_FETCH_COMPLETED_EVENT, r("sdk.Auth").setFinalAuthResponse), c(u, m, e)
                    }

                    function c(e, t, n) {
                        if (r("sdk.statusCORS").getLoginStatusCORS(n, e, r("sdk.AuthState").getState().currentAuthResponse, "facebook"), r("sdk.Runtime").getShouldLoadFamilyLogin() && r("sdk.feature")("should_enable_ig_login_status_fetch", !1))
                            if (t != null) r("sdk.statusCORS").getLoginStatusCORS(n, t, r("sdk.AuthState").getState().currentAuthResponse, "instagram");
                            else {
                                var a = {
                                    authResponse: null,
                                    status: "unknown",
                                    loginSource: "instagram",
                                    cb: n
                                };
                                o("sdk.AuthUtils").AuthInternalEvent.inform(o("sdk.AuthUtils").AuthConstants.CORS_FETCH_COMPLETED_EVENT, a)
                            }
                    }

                    function d(t) {
                        var n = null,
                            a = !1;
                        if (r("sdk.Runtime").getLoginStatus() !== "connected" && (document.referrer === "" || e.test(document.referrer))) {
                            var i = location.hash.substr(1);
                            if (i !== "") {
                                var l = r("QueryString").decode(i, !0);
                                n = l.access_token;
                                var s = l.signed_request;
                                if (n != null && o("sdk.AuthUtils").removeLogoutState(), window == top && n != null) {
                                    var u = t;
                                    t = function(t) {
                                        var e;
                                        t != null && t.status === "connected" && ((e = t.authResponse) == null ? void 0 : e.accessToken) === n && (delete l.access_token, delete l.code, delete l.signed_request, location.hash = r("QueryString").encode(l), s != null && t.authResponse != null && (t.authResponse.signedRequest = s)), u != null && u(t)
                                    }
                                }
                            }
                            var c = r("QueryString").decode(location.search);
                            c.error === "access_denied" && (a = !0)
                        }
                        return {
                            access_token: n,
                            redirect_cancelled: a
                        }
                    }

                    function m(t, n) {
                        n === void 0 && (n = !1);
                        var a = r("sdk.Runtime").getClientID();
                        if (a == null || a === "") {
                            o("Log").warn("FB.getLoginStatus() called before calling FB.init()."), p(t);
                            return
                        }
                        if (!(typeof a == "number" || typeof a == "string") || a === 0 || typeof a == "string" && (a === "0" || !/^\d+$/.test(a))) {
                            o("Log").warn("FB.getLoginStatus() not checked for an invalid client ID " + a), p(t);
                            return
                        }
                        var i = r("sdk.Runtime").getLoginStatus() !== "connected" && e.test(document.referrer) && location.hash.indexOf("cb=") > -1;
                        if (!i && !n) {
                            var l = o("sdk.AuthStorageUtils").getCachedResponse();
                            if (l != null) {
                                var s;
                                r("sdk.AuthState").setState({
                                    loadState: "loaded"
                                }), r("sdk.Auth").setAuthResponse(l.authResponse, (s = l.status) != null ? s : "unknown", "facebook", !0), o("sdk.AuthUtils").setRevalidateTimer(l.status === "connected" ? o("sdk.AuthUtils").AuthConstants.CONNECTED_REVALIDATE_PERIOD : o("sdk.AuthUtils").AuthConstants.DEFAULT_REVALIDATE_PERIOD)
                            }
                        }
                        if (!n) {
                            if (r("sdk.AuthState").getState().loadState === "loaded") {
                                if (t) {
                                    var c = {
                                        authResponse: r("sdk.Auth").getAuthResponse(),
                                        status: r("sdk.Runtime").getLoginStatus()
                                    };
                                    t(c)
                                }
                                return
                            } else if (r("sdk.AuthState").getState().loadState === "loading") {
                                t && o("sdk.AuthUtils").AuthInternalEvent.subscribe("FB.loginStatus", t);
                                return
                            }
                        }
                        t && o("sdk.AuthUtils").AuthInternalEvent.subscribe("FB.loginStatus", t), r("sdk.AuthState").setState({
                            loadState: "loading"
                        });
                        var d = function(t) {
                            r("sdk.AuthState").setState({
                                loadState: "loaded"
                            }), o("sdk.AuthUtils").AuthInternalEvent.inform("FB.loginStatus", t), o("sdk.AuthUtils").AuthInternalEvent.clearSubscribers("FB.loginStatus")
                        };
                        u(d)
                    }

                    function p(e) {
                        var t = "unknown";
                        r("sdk.Auth").setAuthResponse(null, t, null);
                        var n = {
                            authResponse: null,
                            status: t,
                            loginSource: null
                        };
                        e && e(n)
                    }
                    var _ = {
                            getLoginStatus: m,
                            fetchLoginStatus: u,
                            onSDKInit: s
                        },
                        f = _;
                    l.default = f
                }, 98);
                __d("isStringNullOrEmpty", [], function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e) {
                        return e == null || e === ""
                    }
                    i.default = e
                }, 66);
                __d("sdk.LoggingUtils", ["sdk.Impressions", "sdk.feature"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = {
                        buttonLoad: "client_login_button_load",
                        buttonClick: "client_login_click",
                        loginSuccess: "client_login_success",
                        loginCancel: "client_login_cancel",
                        popupHide: "client_login_popup_hide_xfoa",
                        popupShow: "client_login_popup_show_xfoa",
                        loginEnd: "client_login_end",
                        loginStart: "client_login_start",
                        loginDeniedResponse: "client_login_denied_response",
                        loginFastDeniedResponse: "client_login_fast_denied_response",
                        loginErrorResponse: "client_login_error_response",
                        loginUnexpectedResponse: "client_login_unexpected_response",
                        loginCompleteHeartbeat: "client_login_complete_heartbeat",
                        loginStatusPopupShowXfoa: "client_login_status_popup_show_xfoa",
                        loginStatusPopupHideXfoa: "client_login_status_popup_hide_xfoa",
                        loginStatusPopupClickXfoa: "client_login_status_popup_click_xfoa",
                        loginStatusPopupErrorXfoa: "client_login_status_popup_error_xfoa",
                        loginUsingOauthSubdomain: "client_login_using_oauth_subdomain"
                    };

                    function s(e, t, n) {
                        o("sdk.Impressions").log(117, {
                            payload: babelHelpers.extends({}, n || {}, {
                                logger_id: e,
                                action: t,
                                client_funnel_version: r("sdk.feature")("oauth_funnel_logger_version", 1)
                            })
                        })
                    }

                    function u(e, t) {
                        var n = e && e.cbt !== void 0 ? Number(e.cbt) : 0;
                        s(e == null ? void 0 : e.logger_id, t, {
                            cbt_delta: Date.now() - n
                        })
                    }

                    function c(e, t) {
                        t !== void 0 && s(e, t)
                    }

                    function d(t, n) {
                        t !== void 0 && s(n, e.loginStatusPopupErrorXfoa, {
                            message: t
                        })
                    }
                    l.logEventName = e, l.logEvent = s, l.logLoginEvent = u, l.logPopupEvent = c, l.logDisambiguationTrayEvent = d
                }, 98);
                __d("sdk.Auth", ["Log", "UrlMap", "isStringNullOrEmpty", "sdk.AuthState", "sdk.AuthStorageUtils", "sdk.AuthUtils", "sdk.Cookie", "sdk.Frictionless", "sdk.LoggingUtils", "sdk.Runtime", "sdk.Scribe", "sdk.SignedRequest", "sdk.URI", "sdk.ui"], function(t, n, r, o, a, i, l) {
                    n("sdk.Frictionless");
                    var e = 5 * 1e3;

                    function s(e, t) {
                        t && t.perms && !t.scope && (t.scope = t.perms, delete t.perms, o("Log").warn("OAuth2 specification states that 'perms' should now be called 'scope'.  Please update."));
                        var n = r("sdk.Runtime").isEnvironment(r("sdk.Runtime").ENVIRONMENTS.CANVAS) || r("sdk.Runtime").isEnvironment(r("sdk.Runtime").ENVIRONMENTS.PAGETAB);
                        r("sdk.ui")(babelHelpers.extends({
                            method: "permissions.oauth",
                            display: n ? "async" : "popup",
                            domain: location.hostname
                        }, t || {}), e)
                    }

                    function u(e) {
                        switch (e) {
                            case "connected":
                                return "connected";
                            case "not_authorized":
                                return "not_authorized";
                            default:
                                return "unknown"
                        }
                    }

                    function c(e) {
                        (e == null ? void 0 : e.shouldSetAuthResponse) !== !1 && ((e == null ? void 0 : e.status) === "connected" && o("sdk.AuthUtils").setRevalidateTimer(), d(e == null ? void 0 : e.authResponse, u(e == null ? void 0 : e.status), e == null ? void 0 : e.loginSource));
                        var t = e == null ? void 0 : e.cb;
                        if (t != null) {
                            var n = {
                                authResponse: e == null ? void 0 : e.authResponse,
                                status: u(e == null ? void 0 : e.status),
                                loginSource: e == null ? void 0 : e.loginSource
                            };
                            t(n)
                        }
                        o("sdk.AuthUtils").AuthInternalEvent.clearSubscribers(o("sdk.AuthUtils").AuthConstants.CORS_FETCH_COMPLETED_EVENT), o("sdk.AuthUtils").AuthInternalEvent.clearSubscribers(o("sdk.AuthUtils").AuthConstants.XFOA_FINAL_RESPONSE_EVENT)
                    }

                    function d(e, t, n, a) {
                        n === void 0 && (n = "facebook"), a === void 0 && (a = !1);
                        var i = r("sdk.Runtime").getUserID(),
                            l = r("sdk.Runtime").getLoginStatus(),
                            s = "";
                        if (e != null) {
                            if (r("sdk.AuthState").setState({
                                    loadState: "loaded"
                                }), e.userID != null && e.userID !== "") s = e.userID;
                            else if (e.signedRequest != null && e.signedRequest !== "") {
                                var u = o("sdk.SignedRequest").parse(e.signedRequest);
                                u != null && u.user_id != null && u.user_id !== "" && (s = u.user_id)
                            }
                            if (r("sdk.Runtime").getUseCookie()) {
                                var c = e.expiresIn === 0 ? 0 : Date.now() + e.expiresIn * 1e3;
                                o("sdk.Cookie").setSignedRequestCookie(e.signedRequest, c)
                            }
                        } else r("sdk.Runtime").getUseCookie() && o("sdk.Cookie").clearSignedRequestCookie(), r("sdk.Runtime").getUseLocalStorage() && o("sdk.AuthStorageUtils").removeLocalStorageToken(n != null ? n : "facebook");
                        var d = l === "unknown" && e != null || r("sdk.Runtime").getUseCookie() && r("sdk.Runtime").getCookieUserID() !== s,
                            m = !r("isStringNullOrEmpty")(i) && e == null,
                            p = e != null && i != null && i !== "" && i !== s,
                            _ = e !== r("sdk.AuthState").getState().currentAuthResponse,
                            f = t !== l;
                        r("sdk.Runtime").setLoginStatus(t), r("sdk.Runtime").setAccessToken(e && e.accessToken || null), r("sdk.Runtime").setUserID(s), r("sdk.Runtime").setGraphDomain(e && e.graphDomain || ""), r("sdk.AuthState").setState({
                            currentAuthResponse: e
                        });
                        var g = {
                            authResponse: e,
                            status: t,
                            loginSource: n
                        };
                        return (m || p) && o("sdk.AuthUtils").AuthInternalEvent.inform("logout", g), (d || p) && o("sdk.AuthUtils").AuthInternalEvent.inform("login", g), _ && o("sdk.AuthUtils").AuthInternalEvent.inform("authresponse.change", g), f && o("sdk.AuthUtils").AuthInternalEvent.inform("status.change", g), a || o("sdk.AuthStorageUtils").setSessionStorage(e, t), g
                    }

                    function m() {
                        return r("sdk.AuthState").getState().currentAuthResponse
                    }

                    function p(e) {
                        var t = m(),
                            n = o("sdk.AuthUtils").isInstagramLogin(t) ? "instagram" : "facebook";
                        if (d(null, "unknown", n), o("sdk.AuthUtils").setLogoutState(), t != null && t.accessToken != null) {
                            var a = new(r("sdk.URI"))(o("UrlMap").resolve("www").replace("web.", "www.") + "/x/oauth/logout").addQueryData("access_token", t.accessToken),
                                i = new XMLHttpRequest,
                                l = !1;
                            i && (i.open("GET", a.toString(), !0), i.withCredentials = !0, e && (i.onreadystatechange = function() {
                                if (i.readyState >= 2) {
                                    if (l) return;
                                    e({
                                        authResponse: m(),
                                        status: r("sdk.Runtime").getLoginStatus()
                                    }), l = !0
                                }
                            }), i.send())
                        }
                        o("sdk.Scribe").log("jssdk_error", {
                            appId: r("sdk.Runtime").getClientID(),
                            error: "PLATFORM_AUTH_LOGOUT",
                            extra: {
                                args: {
                                    fblo: !0
                                }
                            }
                        })
                    }

                    function _(e, t, n, a, i) {
                        return function(n) {
                            var l, s = o("sdk.LoggingUtils").logEventName.loginUnexpectedResponse;
                            if (n && (n.access_token || n.code)) {
                                var u = o("sdk.SignedRequest").parse(n.signed_request),
                                    c = u != null && u.user_id != null ? u.user_id : null;
                                t = {
                                    userID: c,
                                    expiresIn: Number(n.expires_in)
                                }, n.access_token && (t = babelHelpers.extends({}, t, {
                                    accessToken: n.access_token
                                })), n.code && (t = babelHelpers.extends({}, t, {
                                    code: n.code
                                })), n.signed_request && (t = babelHelpers.extends({}, t, {
                                    signedRequest: n.signed_request
                                })), n.graph_domain && (t = babelHelpers.extends({}, t, {
                                    graphDomain: n.graph_domain
                                })), n.asset_scopes && (t = babelHelpers.extends({}, t, {
                                    asset_scopes: ES("JSON", "parse", !1, n.asset_scopes)
                                })), t = h(t, n), o("sdk.AuthUtils").removeLogoutState(), l = "connected", d(t, l), s = o("sdk.LoggingUtils").logEventName.loginEnd
                            } else if (n && n.asset_scopes) t = {
                                asset_scopes: ES("JSON", "parse", !1, n.asset_scopes)
                            }, t = h(t, n), o("sdk.AuthUtils").removeLogoutState(), l = "connected", d(t, l), s = o("sdk.LoggingUtils").logEventName.loginEnd;
                            else if (n && (n.error || n.error_message || n.error_description || n.error_code || n.error_reason || n.result && n.result.closeWindow)) {
                                o("sdk.AuthUtils").setLogoutState(), l = "unknown", d(null, l);
                                var p = n.error_message || n.error_description,
                                    _ = {
                                        authResponse: m(),
                                        status: l,
                                        message: p
                                    };
                                if (n.error === "access_denied" || n.result && n.result.closeWindow) {
                                    o("sdk.AuthUtils").AuthInternalEvent.inform("loginDenied", _);
                                    var f = 500;
                                    i != null && Date.now() - i < f ? s = o("sdk.LoggingUtils").logEventName.loginFastDeniedResponse : s = o("sdk.LoggingUtils").logEventName.loginDeniedResponse
                                } else o("sdk.AuthUtils").AuthInternalEvent.inform("loginError", _), s = o("sdk.LoggingUtils").logEventName.loginErrorResponse
                            } else if (n && n.result) {
                                var y;
                                o("sdk.AuthUtils").removeLogoutState(), t = (y = n.result) == null ? void 0 : y.authResponse
                            }
                            if (g(a, s), e) {
                                var C = {
                                    authResponse: t,
                                    status: r("sdk.Runtime").getLoginStatus()
                                };
                                e(C)
                            }
                            return t
                        }
                    }

                    function f(e) {
                        return !!(e && e.tp && e.tp !== "unspecified")
                    }

                    function g(t, n) {
                        f(t) || (o("sdk.LoggingUtils").logLoginEvent(t, n), window.setTimeout(function() {
                            o("sdk.LoggingUtils").logLoginEvent(t, o("sdk.LoggingUtils").logEventName.loginCompleteHeartbeat)
                        }, e))
                    }

                    function h(e, t) {
                        return t.granted_scopes && (e = babelHelpers.extends({}, e, {
                            grantedScopes: t.granted_scopes
                        })), t.data_access_expiration_time && (e = babelHelpers.extends({}, e, {
                            data_access_expiration_time: Number(t.data_access_expiration_time)
                        })), t.base_domain != null && o("sdk.AuthUtils").setBaseDomain(t.base_domain), o("sdk.AuthUtils").setGraphDomain(t.graph_domain), t.enforce_https && r("sdk.Runtime").setEnforceHttps(!0), t.referred && (e = babelHelpers.extends({}, e, {
                            referred: t.referred
                        })), o("sdk.AuthStorageUtils").setLocalStorageToken(e, t.long_lived_token), e
                    }
                    var y = {
                            setFinalAuthResponse: c,
                            login: s,
                            logout: p,
                            setAuthResponse: d,
                            getAuthResponse: m,
                            parseSignedRequest: o("sdk.SignedRequest").parse,
                            xdResponseWrapper: _,
                            subscribe: o("sdk.AuthUtils").AuthInternalEvent.subscribe,
                            unsubscribe: o("sdk.AuthUtils").AuthInternalEvent.unsubscribe
                        },
                        C = y;
                    l.default = C
                }, 98);
                __d("dedupString", [], (function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e) {
                        var t;
                        return Object.keys((t = {}, t[e] = 0, t))[0]
                    }
                    i.default = e
                }), 66);
                __d("emptyFunction", [], function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e) {
                        return function() {
                            return e
                        }
                    }
                    var l = function() {};
                    l.thatReturns = e, l.thatReturnsFalse = e(!1), l.thatReturnsTrue = e(!0), l.thatReturnsNull = e(null), l.thatReturnsThis = function() {
                        return this
                    }, l.thatReturnsArgument = function(e) {
                        return e
                    };
                    var s = l;
                    i.default = s
                }, 66);
                __d("passiveEventListenerUtil", [], function(t, n, r, o, a, i) {
                    "use strict";
                    var e = !1;
                    try {
                        var l = Object.defineProperty({}, "passive", {
                            get: function() {
                                e = !0
                            }
                        });
                        window.addEventListener("test", null, l)
                    } catch (e) {}
                    var s = e;

                    function u(e) {
                        return s || typeof e == "boolean" ? e : e.capture || !1
                    }
                    i.isPassiveEventListenerSupported = s, i.makeEventOptions = u
                }, 66);
                __d("DOMEventListener", ["invariant", "dedupString", "emptyFunction", "passiveEventListenerUtil", "wrapFunction"], function(t, n, r, o, a, i, l) {
                    var e = n("passiveEventListenerUtil").isPassiveEventListenerSupported,
                        s, u;
                    window.addEventListener ? (s = function(r, o, a, i) {
                        i === void 0 && (i = !1), a.wrapper = n("wrapFunction")(a, "entry", n("dedupString")("DOMEventListener.add " + o)), r.addEventListener(o, a.wrapper, e ? i : !1)
                    }, u = function(n, r, o, a) {
                        a === void 0 && (a = !1), n.removeEventListener(r, o.wrapper, e ? a : !1)
                    }) : window.attachEvent ? (s = function(t, r, o, a) {
                        a === void 0 && (a = !1), o.wrapper = n("wrapFunction")(o, "entry", "DOMEventListener.add " + r), t.attachEvent || l(0, 2798), t.attachEvent("on" + r, o.wrapper)
                    }, u = function(t, n, r, o) {
                        o === void 0 && (o = !1), t.detachEvent || l(0, 2799), t.detachEvent("on" + n, r.wrapper)
                    }) : u = s = n("emptyFunction");
                    var c = {
                        add: function(t, n, r, o) {
                            return o === void 0 && (o = !1), s(t, n, r, o), {
                                remove: function() {
                                    u(t, n, r, typeof o == "boolean" ? o : o.capture)
                                }
                            }
                        },
                        remove: u
                    };
                    a.exports = c
                }, null);
                __d("JSONRPC", ["Log"], function(t, n, r, o, a, i) {
                    var e = (function() {
                        "use strict";

                        function e(e) {
                            var t = this;
                            this.$1 = 0, this.$2 = {}, this.remote = function(e) {
                                return t.$3 = e, t.remote
                            }, this.local = {}, this.$4 = e
                        }
                        var t = e.prototype;
                        return t.stub = function(t) {
                            var e = this;
                            this.remote[t] = function() {
                                for (var n = {
                                        jsonrpc: "2.0",
                                        method: t
                                    }, r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                                typeof o[o.length - 1] == "function" && (n.id = ++e.$1, e.$2[n.id] = o.pop()), n.params = o, e.$4(ES("JSON", "stringify", !1, n), e.$3 || {
                                    method: t
                                })
                            }
                        }, t.read = function(t, r) {
                            var e = ES("JSON", "parse", !1, t),
                                o = e.id;
                            if (!e.method) {
                                if (!this.$2[o]) {
                                    n("Log").warn("Could not find callback %s", o);
                                    return
                                }
                                var a = this.$2[o];
                                delete this.$2[o], delete e.id, delete e.jsonrpc, a(e);
                                return
                            }
                            var i = this,
                                l = this.local[e.method],
                                s;
                            if (o ? s = function(t, n) {
                                    var e = {
                                        jsonrpc: "2.0",
                                        id: o
                                    };
                                    e[t] = n, window.setTimeout(function() {
                                        i.$4(ES("JSON", "stringify", !1, e), r)
                                    }, 0)
                                } : s = function() {}, !l) {
                                n("Log").error('Method "%s" has not been defined', e.method), s("error", {
                                    code: -32601,
                                    message: "Method not found",
                                    data: e.method
                                });
                                return
                            }
                            e.params.push(ES(s, "bind", !0, null, "result")), e.params.push(ES(s, "bind", !0, null, "error"));
                            try {
                                var u = l.apply(r || null, e.params);
                                typeof u != "undefined" && s("result", u)
                            } catch (t) {
                                n("Log").error("Invokation of RPC method %s resulted in the error: %s", e.method, t.message), s("error", {
                                    code: -32603,
                                    message: "Internal error",
                                    data: t.message
                                })
                            }
                        }, e
                    })();
                    a.exports = e
                }, null);
                __d("Queue", [], function(t, n, r, o, a, i) {
                    var e = {},
                        l = (function() {
                            function t(e) {
                                this._timeout = null, this._interval = (e == null ? void 0 : e.interval) || 0, this._processor = e == null ? void 0 : e.processor, this._queue = [], this._stopped = !0
                            }
                            var n = t.prototype;
                            return n._dispatch = function(t) {
                                var e = this;
                                if (t === void 0 && (t = !1), !(this._stopped || this._queue.length === 0)) {
                                    var n = this._processor;
                                    if (n == null) throw this._stopped = !0, new Error("No processor available");
                                    var r = this._interval;
                                    if (r != null) n.call(this, this._queue.shift()), this._timeout = setTimeout(function() {
                                        return e._dispatch()
                                    }, r);
                                    else
                                        for (; this._queue.length;) n.call(this, this._queue.shift())
                                }
                            }, n.enqueue = function(t) {
                                return this._processor && !this._stopped ? this._processor(t) : this._queue.push(t), this
                            }, n.start = function(t) {
                                return t && (this._processor = t), this._stopped = !1, this._dispatch(), this
                            }, n.isStarted = function() {
                                return !this._stopped
                            }, n.dispatch = function() {
                                this._dispatch(!0)
                            }, n.stop = function(t) {
                                return this._stopped = !0, t && this._timeout != null && clearTimeout(this._timeout), this
                            }, n.merge = function(t, n) {
                                if (n) {
                                    var e;
                                    (e = this._queue).unshift.apply(e, t._queue)
                                } else {
                                    var r;
                                    (r = this._queue).push.apply(r, t._queue)
                                }
                                return t._queue = [], this._dispatch(), this
                            }, n.getLength = function() {
                                return this._queue.length
                            }, t.get = function(r, o) {
                                var n;
                                return r in e ? n = e[r] : n = e[r] = new t(o), n
                            }, t.exists = function(n) {
                                return n in e
                            }, t.remove = function(n) {
                                return delete e[n]
                            }, t
                        })();
                    i.default = l
                }, 66);
                __d("sdk.RPC", ["Assert", "JSONRPC", "Queue"], function(t, n, r, o, a, i, l) {
                    var e = new(r("Queue")),
                        s = new(r("JSONRPC"))(function(t) {
                            e.enqueue(t)
                        }),
                        u = {
                            local: s.local,
                            remote: s.remote,
                            stub: ES(s.stub, "bind", !0, s),
                            setInQueue: function(t) {
                                r("Assert").isInstanceOf(r("Queue"), t), t.start(function(e) {
                                    s.read(e)
                                })
                            },
                            getOutQueue: function() {
                                return e
                            }
                        },
                        c = u;
                    l.default = c
                }, 98);
                __d("sdk.Canvas.Environment", ["sdk.RPC"], (function(t, n, r, o, a, i, l) {
                    function e(e) {
                        r("sdk.RPC").remote.getPageInfo(function(t) {
                            e(t.result)
                        })
                    }

                    function s(e, t) {
                        r("sdk.RPC").remote.scrollTo({
                            x: e || 0,
                            y: t || 0
                        })
                    }
                    r("sdk.RPC").stub("getPageInfo"), r("sdk.RPC").stub("scrollTo");
                    var u = {
                            getPageInfo: e,
                            scrollTo: s
                        },
                        c = u;
                    l.default = c
                }), 98);
                __d("sdk.DialogUtils", ["DOMEventListener", "sdk.Content", "sdk.DOM", "sdk.UA"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = 590,
                        s = 240,
                        u = 575;

                    function c() {
                        return window.innerWidth < window.innerHeight
                    }

                    function d(e, t, n) {
                        var r = null;
                        return o("DOMEventListener").add(e, "click", function() {
                            r !== null && (window.clearTimeout(r), r = null, t()), r = window.setTimeout(function() {
                                r = null
                            }, n)
                        })
                    }

                    function m(e, t, n) {
                        var r, a, i = function() {
                            r = window.setTimeout(t, n)
                        };
                        return i(), o("DOMEventListener").add(e, "mouseenter", function() {
                            window.clearTimeout(r), a || (a = o("DOMEventListener").add(e, "mouseleave", function() {
                                i()
                            }))
                        })
                    }

                    function p(e) {
                        if (!r("sdk.UA").mobile()) return null;
                        var t = "onorientationchange" in window ? "orientationchange" : "resize",
                            n = function(n) {
                                return window.setTimeout(function(t) {
                                    return e(t)
                                }, 50)
                            };
                        return o("DOMEventListener").add(window, t, n)
                    }

                    function _(e) {
                        if (e != null) {
                            var t = o("sdk.DOM").getViewportInfo();
                            e.style.minHeight = t.height ? t.height + "px" : "", e.style.top = t.scrollTop ? t.scrollTop + "px" : ""
                        }
                    }

                    function f(t, n, a) {
                        var i, l, c, d, m, p, _ = function(t) {
                                return typeof t == "number" ? t : parseInt(t, 10)
                            },
                            f = o("sdk.DOM").getViewportInfo(),
                            g = _(t.offsetWidth),
                            h = _(t.offsetHeight),
                            y = ((i = f.scrollLeft) != null ? i : 0) + ((l = f.width) != null ? l : u - g) / 2,
                            C = ((c = f.height) != null ? c : s - h) / 2.5;
                        y < C && (C = y);
                        var b = (d = f.height) != null ? d : s - h - C,
                            v = ((m = f.height) != null ? m : s - h) / 2;
                        if (a && (v = a.scrollTop - a.offsetTop + (a.clientHeight - h) / 2), v < C ? v = C : v > b && (v = b), v += (p = f.scrollTop) != null ? p : 0, r("sdk.UA").mobile()) {
                            var S = 100;
                            if (n) {
                                var R;
                                S += ((R = f.height) != null ? R : e - h) / 2, o("sdk.DOM").addCss(document.body, "fb_reposition")
                            } else o("sdk.DOM").addCss(document.body, "fb_hidden"), document.body.style.width = "auto", v = 1e4;
                            var L = o("sdk.DOM").getByClass("fb_dialog_padding", t);
                            L.length && (L[0].style.height = S + "px")
                        }
                        t.style.left = (y > 0 ? y : 0) + "px", t.style.top = (v > 0 ? v : 0) + "px"
                    }

                    function g(t, n, r) {
                        var a, i;
                        f(t, n, r);
                        var l = o("sdk.DOM").getViewportInfo(),
                            s = (a = l.scrollTop) != null ? a : 0 + ((i = l.height) != null ? i : e - t.offsetHeight) * .05;
                        o("sdk.DOM").setStyle(t, "top", s + "px")
                    }

                    function h() {
                        var e = document.createElement("div");
                        return e.setAttribute("id", "fb_dialog_ipad_overlay"), _(e), e
                    }

                    function y(e) {
                        e = e || {};
                        var t = document.createElement("div"),
                            n = e,
                            a = n.onClose;
                        if (e.closeIcon && a) {
                            var i = document.createElement("a");
                            i.className = "fb_dialog_close_icon", o("DOMEventListener").add(i, "click", a), t.appendChild(i)
                        }
                        var l = "fb_dialog";
                        if (l += " " + (e.classes || ""), l += r("sdk.UA").mobile() ? " fb_dialog_mobile" : " fb_dialog_advanced", t.className = l, e.width) {
                            var s = parseInt(e.width, 10);
                            isNaN(s) || (t.style.width = s + "px")
                        }
                        var u = document.createElement("div");
                        if (e.content && o("sdk.Content").append(e.content, u), u.className = "fb_dialog_content", t.appendChild(u), r("sdk.UA").mobile()) {
                            var c = document.createElement("div");
                            c.className = "fb_dialog_padding", t.appendChild(c)
                        }
                        return {
                            dialogElement: t,
                            contentRoot: u
                        }
                    }

                    function C(e) {
                        var t = document.body;
                        e ? o("sdk.DOM").removeCss(t, "fb_reposition") : o("sdk.DOM").removeCss(t, "fb_hidden")
                    }
                    l.isOrientationPotrait = c, l.addDoubleClickAction = d, l.addIdleDesktopAction = m, l.addMobileOrientationChangeAction = p, l.applyScreenDimensions = _, l.setDialogPositionToCenter = f, l.setDialogPositionToTop = g, l.setupNewDarkOverlay = h, l.setupNewDialog = y, l.onDialogHideCleanup = C
                }, 98);
                __d("sdk.fbt", [], function(t, n, r, o, a, i) {
                    var e = function() {};
                    e._ = function(e) {
                        var t = typeof e == "string" ? e : e[0];
                        return t == null && typeof e == "object" && !Array.isArray(e) && "*" in e && (t = e["*"]), t
                    };
                    var l = e;
                    i.default = l
                }, 66);
                __d("sdk.Dialog", ["DOMEventListener", "ObservableMixin", "Type", "sdk.Canvas.Environment", "sdk.Content", "sdk.DOM", "sdk.DialogUtils", "sdk.Runtime", "sdk.UA", "sdk.fbt"], function(t, n, r, o, a, i, l) {
                    var e = 30,
                        s = 590,
                        u = 500,
                        c = 240,
                        d = 575;

                    function m() {
                        var e = o("sdk.DOM").getViewportInfo(),
                            t = e.height,
                            n = e.width;
                        return t != null && n != null ? {
                            width: Math.min(n, u),
                            height: Math.min(t, s)
                        } : null
                    }
                    var p = r("Type").extend({
                            constructor: function(t, n) {
                                this.parent(), this.id = t, this.display = n, this._e2e = {}, _._dialogs || (_._dialogs = {}, _._addOrientationHandler()), _._dialogs[t] = this, this.trackEvent("init")
                            },
                            trackEvent: function(t, n) {
                                return this._e2e[t] ? this : (this._e2e[t] = n || Date.now(), t == "close" && this.inform("e2e:end", this._e2e), this)
                            },
                            trackEvents: function(t) {
                                typeof t == "string" && (t = ES("JSON", "parse", !1, t));
                                for (var e in t) Object.prototype.hasOwnProperty.call(t, e) && this.trackEvent(e, t[e]);
                                return this
                            }
                        }, r("ObservableMixin")),
                        _ = {
                            newInstance: function(t, n) {
                                return new p(t, n)
                            },
                            _dialogs: null,
                            _lastYOffset: 0,
                            _availScreenWidth: null,
                            _overlayListeners: [],
                            _loaderEl: null,
                            _overlayEl: null,
                            _stack: [],
                            _active: null,
                            get: function(t) {
                                return _._dialogs[t]
                            },
                            _findRoot: function(t) {
                                for (var e = t; e;) {
                                    if (o("sdk.DOM").containsCss(e, "fb_dialog")) return e;
                                    e.parentElement instanceof HTMLElement && (e = e.parentElement)
                                }
                            },
                            _createWWWLoader: function(t) {
                                t = t || "460";
                                var e = document.createElement("div");
                                return e.innerHTML = '<div class="dialog_title">  <a id="fb_dialog_loader_close">    <div class="fb_dialog_close_icon"></div>  </a>  <span>Facebook</span>  <div style="clear:both;"></div></div><div class="dialog_content"></div><div class="dialog_footer"></div>', _.create({
                                    content: e,
                                    width: t
                                })
                            },
                            _createMobileLoader: function() {
                                var e = document.createElement("div");
                                return r("sdk.UA").nativeApp() ? e.innerHTML = '<div class="dialog_header"></div>' : _.isTabletStyle() ? e.innerHTML = '<div class="overlayLoader"><div id="fb_dialog_loader_spinner"></div><a id="fb_dialog_loader_close" href="#">' + r("sdk.fbt")._( /*BTDS*/ "Cancel") + "</a></div>" : e.innerHTML = '<div class="dialog_header"><table>  <tbody>    <tr>      <td class="header_left">        <label class="touchable_button">          <input type="submit" value="' + r("sdk.fbt")._( /*BTDS*/ "Cancel") + '"            id="fb_dialog_loader_close"/>        </label>      </td>      <td class="header_center">        <div>         ' + r("sdk.fbt")._( /*BTDS*/ "Loading...") + '        </div>      </td>      <td class="header_right">      </td>    </tr>  </tbody></table></div>', _.create({
                                    classes: "loading" + (_.isTabletStyle() ? " centered" : ""),
                                    content: e
                                })
                            },
                            _setDialogOverlayStyle: function() {
                                _._overlayEl != null && o("sdk.DialogUtils").applyScreenDimensions(_._overlayEl)
                            },
                            _showTabletOverlay: function(t) {
                                if (_.isTabletStyle())
                                    if (_._overlayEl == null) {
                                        var e = o("sdk.DialogUtils").setupNewDarkOverlay();
                                        e.className = "", _._overlayEl = e, o("sdk.Content").append(_._overlayEl, null)
                                    } else _._overlayEl.className = ""
                            },
                            _hideTabletOverlay: function() {
                                _.isTabletStyle() && (_._overlayEl != null && (_._overlayEl.className = "hidden"), _._overlayListeners.forEach(function(e) {
                                    return e.remove()
                                }), _._overlayListeners = [])
                            },
                            showLoader: function(t, n) {
                                t || (t = function() {});
                                var e = function() {
                                    _._hideLoader(), o("sdk.DialogUtils").onDialogHideCleanup(_.isTabletStyle()), _._hideTabletOverlay(), t != null && t()
                                };
                                _._showTabletOverlay(e), _._loaderEl || (_._loaderEl = _._findRoot(r("sdk.UA").mobile() ? _._createMobileLoader() : _._createWWWLoader(n)));
                                var a = document.getElementById("fb_dialog_loader_close");
                                if (a) {
                                    o("sdk.DOM").removeCss(a, "fb_hidden");
                                    var i = o("DOMEventListener").add(a, "click", e);
                                    _._overlayListeners.push(i)
                                }
                                _._loaderEl != null && _._makeActive(_._loaderEl)
                            },
                            _hideLoader: function() {
                                _._loaderEl && _._loaderEl == _._active && (_._loaderEl.style.top = "-10000px")
                            },
                            _makeActive: function(t) {
                                _._setDialogSizes(), _._lowerActive(), _._active = t, r("sdk.Runtime").isEnvironment(r("sdk.Runtime").ENVIRONMENTS.CANVAS) && r("sdk.Canvas.Environment").getPageInfo(function(e) {
                                    _._centerActive(e)
                                }), _._centerActive()
                            },
                            _lowerActive: function() {
                                _._active && (_._active.style.top = "-10000px", _._active = null)
                            },
                            _removeStacked: function(t) {
                                _._stack = _._stack.filter(function(e) {
                                    return e != t
                                })
                            },
                            _centerActive: function(t) {
                                var e = _._active;
                                e && o("sdk.DialogUtils").setDialogPositionToCenter(e, _.isTabletStyle(), t)
                            },
                            _setDialogSizes: function(t) {
                                if (t === void 0 && (t = !1), !!r("sdk.UA").mobile()) {
                                    for (var e in _._dialogs)
                                        if (Object.prototype.hasOwnProperty.call(_._dialogs, e)) {
                                            var n = document.getElementById(e);
                                            n && (n.style.width = _.getDefaultSize().width + "px", t || (n.style.height = _.getDefaultSize().height + "px"))
                                        }
                                }
                            },
                            getDefaultSize: function() {
                                if (r("sdk.UA").mobile()) {
                                    var t = m();
                                    if (t) {
                                        var n, a, i, l;
                                        if ((n = (a = o("sdk.DOM").getViewportInfo()) == null ? void 0 : a.width) != null ? n : u <= t.width) {
                                            var p, _;
                                            t.width = (p = (_ = o("sdk.DOM").getViewportInfo()) == null ? void 0 : _.width) != null ? p : u - e
                                        }
                                        if ((i = (l = o("sdk.DOM").getViewportInfo()) == null ? void 0 : l.height) != null ? i : s <= t.height) {
                                            var f, g;
                                            t.height = (f = (g = o("sdk.DOM").getViewportInfo()) == null ? void 0 : g.height) != null ? f : s - e
                                        }
                                        return t
                                    }
                                    if (r("sdk.UA").ipad()) return {
                                        width: u,
                                        height: s
                                    };
                                    if (r("sdk.UA").android()) return {
                                        width: screen.availWidth,
                                        height: screen.availHeight
                                    };
                                    var h = window.innerWidth,
                                        y = window.innerHeight,
                                        C = h / y > 1.2;
                                    return {
                                        width: h,
                                        height: Math.max(y, C ? screen.width : screen.height)
                                    }
                                }
                                return {
                                    width: d,
                                    height: c
                                }
                            },
                            _handleOrientationChange: function() {
                                var e, t;
                                if (_._availScreenWidth = (e = (t = o("sdk.DOM").getViewportInfo()) == null ? void 0 : t.width) != null ? e : u, _.isTabletStyle()) _._setDialogSizes(!0), _._centerActive(), _._setDialogOverlayStyle();
                                else {
                                    var n = _.getDefaultSize().width;
                                    for (var r in _._dialogs)
                                        if (Object.prototype.hasOwnProperty.call(_._dialogs, r)) {
                                            var a = document.getElementById(r);
                                            a && (a.style.width = n + "px")
                                        }
                                }
                            },
                            _addOrientationHandler: function() {
                                var e, t;
                                r("sdk.UA").mobile() && (_._availScreenWidth = (e = (t = o("sdk.DOM").getViewportInfo()) == null ? void 0 : t.width) != null ? e : u, o("sdk.DialogUtils").addMobileOrientationChangeAction(_._handleOrientationChange))
                            },
                            create: function(t) {
                                var e = o("sdk.DialogUtils").setupNewDialog(t);
                                return o("sdk.Content").append(e.dialogElement), t.visible && _.show(e.dialogElement), typeof t.styles == "object" && ES("Object", "assign", !1, e.dialogElement.style, t.styles), e.contentRoot
                            },
                            show: function(t) {
                                var e = _._findRoot(t);
                                e != null && (_._removeStacked(e), _._hideLoader(), _._makeActive(e), _._stack.push(e), "fbCallID" in t && _.get(t.fbCallID).inform("iframe_show").trackEvent("show"))
                            },
                            hide: function(t) {
                                var e = _._findRoot(t);
                                _._hideLoader(), e == _._active && (_._lowerActive(), o("sdk.DialogUtils").onDialogHideCleanup(_.isTabletStyle()), _._hideTabletOverlay(), "fbCallID" in t && _.get(t.fbCallID).inform("iframe_hide").trackEvent("hide"))
                            },
                            remove: function(t) {
                                var e = _._findRoot(t);
                                if (e) {
                                    var n = _._active == e;
                                    if (_._removeStacked(e), n)
                                        if (_._hideLoader(), _._stack.length > 0) {
                                            var r = _._stack.pop();
                                            r != null && _.show(r)
                                        } else _._lowerActive(), o("sdk.DialogUtils").onDialogHideCleanup(_.isTabletStyle()), _._hideTabletOverlay();
                                    else if (_._active === null && _._stack.length > 0) {
                                        var a = _._stack.pop();
                                        a != null && _.show(a)
                                    }
                                    window.setTimeout(function() {
                                        var t;
                                        (t = e.parentNode) == null || t.removeChild(e)
                                    }, 3e3)
                                }
                            },
                            isActive: function(t) {
                                var e = _._findRoot(t);
                                return e != null && e === _._active
                            },
                            isTabletStyle: function() {
                                if (!r("sdk.UA").mobile()) return !1;
                                var e = m();
                                return e != null && (e.height >= s || e.width >= u)
                            }
                        },
                        f = _;
                    l.default = f
                }, 226);
                __d("ArgumentError", ["ManagedError"], function(t, n, r, o, a, i, l) {
                    var e = (function(e) {
                        function t(t, n) {
                            return e.call(this, t, n) || this
                        }
                        return babelHelpers.inheritsLoose(t, e), t
                    })(r("ManagedError"));
                    l.default = e
                }, 98);
                __d("flattenObject", [], function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e) {
                        var t = {};
                        for (var n in e)
                            if (Object.prototype.hasOwnProperty.call(e, n)) {
                                var r = e[n];
                                if (r == null) continue;
                                if (typeof r == "string") t[n] = r;
                                else {
                                    var o;
                                    t[n] = (o = ES("JSON", "stringify", !1, r)) != null ? o : ""
                                }
                            }
                        return t
                    }
                    i.default = e
                }, 66);
                __d("ApiClientUtils", ["ArgumentError", "Assert", "Log", "flattenObject", "getErrorSafe", "sdk.URI", "sprintf"], function(t, n, r, o, a, i, l) {
                    var e = {
                        get: !0,
                        post: !0,
                        delete: !0,
                        put: !0
                    };

                    function s(t) {
                        var n = t.shift();
                        if (r("Assert").isString(n, "Invalid path"), typeof n != "string") throw new(r("ArgumentError"))("Invalid path", "Invalid path");
                        var a = n;
                        !/^https?/.test(a) && a.charAt(0) !== "/" && (a = "/" + a);
                        var i, l = {};
                        try {
                            i = new(r("sdk.URI"))(a)
                        } catch (e) {
                            var s = r("getErrorSafe")(e);
                            throw new(r("ArgumentError"))(s.message, s.message)
                        }
                        t.forEach(function(e) {
                            return l[typeof e] = e
                        });
                        var u = (l.string || "get").toLowerCase();
                        r("Assert").isTrue(Object.prototype.hasOwnProperty.call(e, u), r("sprintf")("Invalid method passed to ApiClient: %s", u));
                        var c = l.function;
                        c || o("Log").warn("No callback passed to the ApiClient"), l.object && i.addQueryData(r("flattenObject")(l.object));
                        var d = i.getQueryData();
                        return d.method = u, {
                            uri: i,
                            callback: c,
                            params: d
                        }
                    }
                    l.parseCallDataFromArgs = s
                }, 98);
                __d("errorCode", [], function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e) {
                        throw new Error('errorCode("' + e + '"): This should not happen. Oh noes!')
                    }
                    i.default = e
                }, 66);
                __d("nullthrows", [], (function(t, n, r, o, a, i) {
                    function e(e, t) {
                        if (t === void 0 && (t = "Got unexpected null or undefined"), e != null) return e;
                        var n = new Error(t);
                        throw n.framesToPop = 1, n
                    }
                    i.default = e
                }), 66);
                __d("sdk.safelyParseResponse", ["errorCode", "getErrorSafe", "nullthrows"], function(t, n, r, o, a, i, l, s) {
                    "use strict";
                    var e = function(t, n, r, o) {
                        return c
                    };

                    function u(t, n, o) {
                        n === void 0 && (n = null), o === void 0 && (o = null);
                        try {
                            return t === null ? c : ES("JSON", "parse", !1, r("nullthrows")(t))
                        } catch (i) {
                            var a = r("getErrorSafe")(i);
                            return e(a, t, n, o)
                        }
                    }
                    var c = {
                        error: {
                            code: 1,
                            error_subcode: 1357046,
                            message: "Received Invalid JSON reply.",
                            type: "http"
                        }
                    };
                    u.ERROR = c, u.setErrorHandler = function(t) {
                        e = t
                    };
                    var d = u;
                    l.default = d
                }, 98);
                __d("whitelistObjectKeys", [], function(t, n, r, o, a, i) {
                    function e(e, t) {
                        for (var n = {}, r = Array.isArray(t) ? t : Object.keys(t), o = 0; o < r.length; o++) typeof e[r[o]] != "undefined" && (n[r[o]] = e[r[o]]);
                        return n
                    }
                    i.default = e
                }, 66);
                __d("ApiBatcher", ["invariant", "ApiClientUtils", "QueryString", "sdk.safelyParseResponse", "whitelistObjectKeys"], function(t, n, r, o, a, i, l, s) {
                    "use strict";
                    var e = 50,
                        u = 105440539523,
                        c = (function() {
                            function t(e, t) {
                                this.$1 = [], this.$2 = [], this.$4 = null, this.executeRequest = e, this.$3 = t
                            }
                            var n = t.prototype;
                            return n.scheduleBatchCall = function() {
                                for (var n = this, r = arguments.length, o = new Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                                var i = t.prepareBatchParams(o),
                                    l = i.body,
                                    s = i.callback,
                                    u = i.method,
                                    c = i.relative_url,
                                    d = {
                                        method: u,
                                        relative_url: c
                                    };
                                l && (d.body = l), this.$1.push(d), this.$2.push(s), this.$1.length == e ? (this.$4 && window.clearTimeout(this.$4), this.$5()) : this.$4 || (this.$4 = window.setTimeout(function() {
                                    n.$5()
                                }, 0))
                            }, t.prepareBatchParams = function(t, n) {
                                n === void 0 && (n = []);
                                var e = o("ApiClientUtils").parseCallDataFromArgs(t),
                                    a = e.callback,
                                    i = e.params.method,
                                    l = e.uri,
                                    s, u = l.removeQueryData("method").toString();
                                if (i.toLowerCase() === "post") {
                                    var c = l.getQueryData();
                                    s = r("QueryString").encode(c);
                                    var d = r("whitelistObjectKeys")(c, n);
                                    u = l.setQueryData(d).toString()
                                }
                                return {
                                    body: s,
                                    callback: a,
                                    method: i,
                                    relative_url: u
                                }
                            }, n.$5 = function() {
                                this.$1.length > 0 || s(0, 4698), this.$1.length === this.$2.length || s(0, 4699);
                                var e = this.$1,
                                    t = this.$2;
                                if (this.$1 = [], this.$2 = [], this.$4 = null, e.length === 1) {
                                    var n = e[0],
                                        o = t[0],
                                        a = n.body ? r("QueryString").decode(n.body) : null;
                                    this.executeRequest(n.relative_url, n.method, a, o);
                                    return
                                }
                                this.executeRequest("/", "POST", {
                                    batch: e,
                                    include_headers: !1,
                                    batch_app_id: this.$3 || u
                                }, function(e) {
                                    Array.isArray(e) ? e.forEach(function(e, n) {
                                        t[n](r("sdk.safelyParseResponse")(e && e.body))
                                    }) : t.forEach(function(e) {
                                        return e({
                                            error: {
                                                message: "Fatal: batch call failed."
                                            }
                                        })
                                    })
                                })
                            }, t
                        })();
                    l.default = c
                }, 98);
                __d("RequestConstants", ["errorCode"], (function(t, n, r, o, a, i, l, s) {
                    var e = {
                        code: 1,
                        error_subcode: 1357045,
                        message: "unknown error (empty response)",
                        type: "http",
                        status: 0
                    };
                    l.PARSE_ERROR_TEMPLATE = e
                }), 98);
                __d("CORSRequest", ["Log", "QueryString", "RequestConstants", "sdk.safelyParseResponse", "wrapFunction"], function(t, n, r, o, a, i, l) {
                    function e(e, t, n) {
                        var o;
                        if (n === void 0 && (n = {
                                withCredentials: !1
                            }), !self.XMLHttpRequest) return null;
                        var a;
                        a = new XMLHttpRequest;
                        var i = function() {};
                        if ((o = n) != null && o.withCredentials && (a.withCredentials = !0), "withCredentials" in a) a.open(e, t, !0), a.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                        else if (self.XDomainRequest) {
                            a = new XDomainRequest;
                            try {
                                a.open(e === "get" || e === "GET" ? "GET" : "POST", t), a.onprogress = a.ontimeout = i
                            } catch (e) {
                                return null
                            }
                        } else return null;
                        var l = {
                                send: function(t) {
                                    a.send(t)
                                }
                            },
                            s = r("wrapFunction")(function() {
                                s = i, "onload" in l && l.onload(a)
                            }, "entry", "XMLHttpRequest:load"),
                            u = r("wrapFunction")(function() {
                                u = i, "onerror" in l && l.onerror(a)
                            }, "entry", "XMLHttpRequest:error");
                        return a.onload = function() {
                            s()
                        }, a.onerror = function() {
                            u()
                        }, a instanceof XMLHttpRequest && (a.onreadystatechange = function() {
                            a.readyState === 4 && (a.status === 200 ? s() : u())
                        }), l
                    }
                    var s = "for (;;);",
                        u = s.length;

                    function c(e) {
                        return e.substring(0, u) == s && (e = e.substring(u)), e
                    }

                    function d(t, n, a, i, l) {
                        if (l === void 0 && (l = {
                                withCredentials: !1
                            }), ES(t, "includes", !0, "/../") || ES(t, "includes", !0, "/..\\") || ES(t, "includes", !0, "\\../") || ES(t, "includes", !0, "\\..\\")) return o("Log").error("CORSRequest.execute(): path traversal is not allowed."), !1;
                        a.suppress_http_code = 1;
                        var s = r("QueryString").encode(a);
                        n === "get" && (t = r("QueryString").appendToUrl(t, s), s = "");
                        var u = e(n, t, l);
                        return u ? (u.onload = function(e) {
                            i(r("sdk.safelyParseResponse")(c(e.responseText), t, e.status))
                        }, u.onerror = function(e) {
                            e.responseText ? i(r("sdk.safelyParseResponse")(c(e.responseText), t, e.status)) : i({
                                error: babelHelpers.extends({}, o("RequestConstants").PARSE_ERROR_TEMPLATE, {
                                    status: e.status
                                })
                            })
                        }, u.send(s), !0) : !1
                    }
                    var m = {
                            execute: d
                        },
                        p = m;
                    l.default = p
                }, 98);
                __d("ApiClient", ["ApiBatcher", "ApiClientUtils", "Assert", "CORSRequest", "Log", "ObservableMixin", "QueryString", "UrlMap", "flattenObject"], function(t, n, r, o, a, i, l) {
                    var e, s, u, c = [],
                        d = !1,
                        m = 2e3,
                        p = {
                            fql_query: !0,
                            fql_multiquery: !0,
                            friends_get: !0,
                            notifications_get: !0,
                            stream_get: !0,
                            users_getinfo: !0
                        },
                        _ = ["cors"],
                        f = 0,
                        g = [],
                        h = 0,
                        y = 0,
                        C, b = o("Log");

                    function v(t, n, o, a) {
                        var i = h !== 0 && f >= h;
                        if (i) {
                            g.push(function() {
                                return v(t, n, o, a)
                            }), I.inform("request.queued", t, n, o);
                            return
                        }
                        f++;
                        var l = babelHelpers.extends({}, u, o);
                        l.pretty = l.pretty || 0, l = r("flattenObject")(l);
                        var s = {
                                cors: r("CORSRequest")
                            },
                            m = {},
                            p = l.access_token || e;
                        p && (m.access_token = p), n !== "get" && c.forEach(function(e) {
                            m[e] = l[e]
                        });
                        var y = Object.keys(m);
                        y.length > 0 && (t = r("QueryString").appendToUrl(t, m), delete l.access_token);
                        for (var C = _, b = 0; b < C.length; b++) {
                            var S = s[C[b]],
                                R = {
                                    withCredentials: d
                                },
                                L = babelHelpers.extends({}, l);
                            if (S.execute(t, n, L, a, R)) return
                        }
                        a({
                            error: {
                                type: "no-transport",
                                message: "Could not find a usable transport for request"
                            }
                        })
                    }

                    function S(e, t, n, r, o, a, i, l) {
                        if (r.transport && r.transport === "chunked" && l === !1) {
                            e(i, !1);
                            return
                        }
                        i && i.error && I.inform("request.error", t, n, r, i, Date.now() - o, a), I.inform("request.complete", t, n, r, i, Date.now() - o, a), f--, e && e(i);
                        var s = g.length > 0 && f < h;
                        if (s) {
                            var u = g.shift();
                            u != null && u()
                        }
                    }

                    function R() {
                        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                        var r = o("ApiClientUtils").parseCallDataFromArgs(t),
                            a = r.callback,
                            i = r.params,
                            l = r.uri,
                            s = i.method;
                        T(l, s) && (s = "post");
                        var u = l.getProtocol() && l.getDomain() ? l.setQueryData({}).toString() : o("UrlMap").resolve("graph_domain") + l.getPath(),
                            c = y++;
                        "_fb_domain" in i && I.setKeptQueryParams(["_fb_domain"]), I.inform("request.prepare", u, i, c), v(u, s === "get" ? "get" : s === "delete" ? "delete" : "post", i, function(e, t) {
                            return S(a, l.getPath(), s, i, Date.now(), c, e, t)
                        })
                    }

                    function L() {
                        var e;
                        C || (C = new(r("ApiBatcher"))(R, s)), (e = C).scheduleBatchCall.apply(e, arguments)
                    }

                    function E(e, t) {
                        r("Assert").isObject(e), r("Assert").isString(e.method, "method missing"), t || b.warn("No callback passed to the ApiClient");
                        var n = e.method.toLowerCase().replace(".", "_");
                        e.format = "json-strings", e.api_key = s;
                        var a = n in p ? "api_read" : "api",
                            i = o("UrlMap").resolve(a) + "/restserver.php",
                            l = y++,
                            u = function(r, o) {
                                return S(t, "/restserver.php", "get", e, Date.now(), l, r, o)
                            };
                        v(i, "get", e, u)
                    }

                    function k(e) {
                        return r("ApiBatcher").prepareBatchParams(e, c)
                    }
                    var I = ES("Object", "assign", !1, new(r("ObservableMixin")), {
                        setAccessToken: function(n) {
                            e && n && e !== n && b.error("You are overriding current access token, that means some other app is expecting different access token and you will probably break things. Please consider passing access_token directly to API parameters instead of overriding the global settings."), e = n
                        },
                        setAccessTokenForClientID: function(n, r) {
                            e && s && s !== r ? b.error("Not overriding access token since it was not initialized by your application.") : e = n
                        },
                        setWithCredentials: function(t) {
                            d = t
                        },
                        getWithCredentials: function() {
                            return d
                        },
                        getClientID: function() {
                            return s
                        },
                        getAccessToken: function() {
                            return e
                        },
                        setClientID: function(t) {
                            s && s !== t && b.warn("Warning: Two different applications have attempted to set the client ID. Overriding the previously set client ID."), s = t
                        },
                        setDefaultParams: function(t) {
                            u = t
                        },
                        getDefaultParams: function() {
                            return u
                        },
                        setDefaultTransports: function(t) {
                            _ = t
                        },
                        setLogger: function(t) {
                            b = t
                        },
                        setMaxConcurrentRequests: function(t) {
                            h = t
                        },
                        setKeptQueryParams: function(t) {
                            c = t
                        },
                        getCurrentlyExecutingRequestCount: function() {
                            return f
                        },
                        getQueuedRequestCount: function() {
                            return g.length
                        },
                        rest: E,
                        graph: R,
                        scheduleBatchCall: L,
                        prepareBatchParams: k
                    });

                    function T(e, t) {
                        return e.toString().length > m && t === "get"
                    }
                    var D = I;
                    l.default = D
                }, 98);
                __d("sdk.PlatformVersioning", ["ManagedError", "sdk.Runtime"], (function(t, n, r, o, a, i, l) {
                    var e = /^v\d+\.\d\d?$/;

                    function s() {
                        if (!r("sdk.Runtime").getVersion()) throw new(r("ManagedError"))("init not called with valid version")
                    }

                    function u(t) {
                        if (!e.test(t)) throw new(r("ManagedError"))("invalid version specified")
                    }
                    l.REGEX = e, l.assertVersionIsSet = s, l.assertValidVersion = u
                }), 98);
                __d("sdk.warnInsecure", ["Log", "sdk.Runtime", "sdk.Scribe", "sdk.feature"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = r("sdk.feature")("https_only_learn_more", ""),
                        s = {};

                    function u(t) {
                        return window.location.protocol !== "https:" && (o("Log").log("error", -1, "The method FB.%s can no longer be called from http pages. %s", t, e), r("sdk.feature")("https_only_scribe_logging", !0) && !Object.prototype.hasOwnProperty.call(s, t) && (o("sdk.Scribe").log("jssdk_error", {
                            appId: r("sdk.Runtime").getClientID(),
                            error: "HttpsOnly",
                            extra: {
                                message: t
                            }
                        }), s[t] = !0)), !0
                    }
                    l.default = u
                }, 98);
                __d("sdk.api", ["ApiClient", "sdk.PlatformVersioning", "sdk.Runtime", "sdk.URI", "sdk.warnInsecure"], (function(t, n, r, o, a, i, l) {
                    function e(e) {
                        for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++) n[a - 1] = arguments[a];
                        if (r("sdk.warnInsecure")("api"), typeof e == "string")
                            if (r("sdk.Runtime").getIsVersioned()) {
                                o("sdk.PlatformVersioning").assertVersionIsSet();
                                var i = e;
                                !/https?/.test(i) && i.charAt(0) !== "/" && (i = "/" + i), i = new(r("sdk.URI"))(i).setDomain("").setProtocol("").toString(), o("sdk.PlatformVersioning").REGEX.test(i.substring(1, i.indexOf("/", 1))) || (i = "/" + r("sdk.Runtime").getVersion() + i);
                                var l = [i].concat(n);
                                r("ApiClient").graph.apply(r("ApiClient"), l)
                            } else r("ApiClient").graph.apply(r("ApiClient"), arguments);
                        else r("ApiClient").rest.apply(r("ApiClient"), arguments)
                    }
                    l.default = e
                }), 98);
                __d("sdk.Frictionless", ["sdk.Auth.LoginStatus", "sdk.Dialog", "sdk.Event", "sdk.api"], function(t, n, r, o, a, i, l) {
                    var e = {
                            _allowedRecipients: {},
                            _useFrictionless: !1,
                            _updateRecipients: function() {
                                e._allowedRecipients = {}, r("sdk.api")("/me/apprequestformerrecipients", function(t) {
                                    if (!(!t || t.error != null)) {
                                        var n = t.data;
                                        Array.isArray(n) && n.forEach(function(t) {
                                            if (t != null && typeof t == "object" && !Array.isArray(t)) {
                                                var n = t,
                                                    r = n.recipient_id;
                                                typeof r == "string" && (e._allowedRecipients[r] = !0)
                                            }
                                        })
                                    }
                                })
                            },
                            init: function() {
                                e._useFrictionless = !0, r("sdk.Auth.LoginStatus").getLoginStatus(function(t) {
                                    (t == null ? void 0 : t.status) == "connected" && e._updateRecipients()
                                }), o("sdk.Event").subscribe("auth.login", function(t) {
                                    t.authResponse && e._updateRecipients()
                                })
                            },
                            _processRequestResponse: function(n, o) {
                                return function(t) {
                                    var a = t && t.updated_frictionless;
                                    e._useFrictionless && a !== null && e._updateRecipients(), t && (!o && t.frictionless !== null && r("sdk.Dialog")._hideLoader(), delete t.frictionless, delete t.updated_frictionless), n(t)
                                }
                            },
                            isAllowed: function(n) {
                                var t = n;
                                if (!t) return !1;
                                if (typeof t == "number") return t in e._allowedRecipients;
                                typeof t == "string" && (t = t.split(","));
                                var r = t.map(function(e) {
                                        return String(e).trim()
                                    }),
                                    o = !0,
                                    a = !1;
                                return r.forEach(function(t) {
                                    o = o && t in e._allowedRecipients, a = !0
                                }), o && a
                            }
                        },
                        s = e;
                    l.default = s
                }, 98);
                __d("createObjectFrom", [], function(t, n, r, o, a, i) {
                    "use strict";

                    function e(t, n) {
                        if (n === void 0) return e(t, !0);
                        var r = {};
                        if (Array.isArray(n))
                            for (var o = t.length - 1; o >= 0; o--) r[t[o]] = n[o];
                        else
                            for (var a = t.length - 1; a >= 0; a--) r[t[a]] = n;
                        return r
                    }
                    i.default = e
                }, 66);
                __d("resolveURI", [], (function(t, n, r, o, a, i) {
                    function e(e) {
                        if (e == null || e === "") return window.location.href;
                        var t = document.createElement("a");
                        return t.href = e, t.href
                    }
                    i.default = e
                }), 66);
                __d("sdk.NativeExtensions", ["DOMEventListener", "Log", "sdk.UA"], function(t, n, r, o, a, i, l) {
                    var e = "fbNativeExtensionsReady";

                    function s() {
                        return window._FBSdkExtensions && window._FBSdkExtensions.jsonRPC && window._FBSdkExtensions.initializeCallbackHandler && window._FBSdkExtensions.supportsDialog ? window._FBSdkExtensions : null
                    }

                    function u(t) {
                        if (!r("sdk.UA").facebookInAppBrowser()) {
                            o("Log").error("FB.NativeExtensions.onReady only works when the page is rendered in a WebView of the native Facebook app.");
                            return
                        }
                        var n = s();
                        if (n) {
                            t(n);
                            return
                        }
                        var a = !1,
                            i = function() {
                                var n = s();
                                a || !n || (a = !0, t(n), o("DOMEventListener").remove(window, e, i))
                            };
                        o("DOMEventListener").add(window, e, i)
                    }
                    l.onReady = u
                }, 98);
                __d("sdk.Extensions", ["JSONRPC", "Queue", "sdk.NativeExtensions", "sdk.UA"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = new(r("Queue")),
                        s = new(r("JSONRPC"))(function(t) {
                            e.enqueue(t)
                        }),
                        u = new(r("Queue"));
                    u.start(function(e) {
                        s.read(e)
                    });
                    var c = null;
                    r("sdk.UA").facebookInAppBrowser() && o("sdk.NativeExtensions").onReady(function(t) {
                        c = t, window._FBBrowserCallbackHandler = function(e) {
                            u.enqueue(ES("JSON", "stringify", !1, e))
                        }, t.initializeCallbackHandler(ES("JSON", "stringify", !1, {
                            name: "_FBBrowserCallbackHandler"
                        })), e.start(function(e) {
                            t.jsonRPC(e)
                        })
                    });
                    var d = s.local,
                        m = s.remote,
                        p = ES(s.stub, "bind", !0, s);

                    function _(e) {
                        return !!c && c.supportsDialog(e)
                    }
                    l.local = d, l.remote = m, l.stub = p, l.supportsDialog = _
                }, 98);
                __d("sdk.Popup", ["sdk.Content", "sdk.Runtime", "sdk.Scribe", "sdk.UA", "sdk.feature"], function(t, n, r, o, a, i, l) {
                    "use strict";

                    function e(e, t) {
                        var n = s({
                                name: e.name,
                                height: e.size.height,
                                width: e.size.width,
                                isOAuth: t
                            }),
                            a;
                        if (e.post ? (a = window.open("about:blank", e.id, n), a && o("sdk.Content").submitToTarget({
                                url: e.url,
                                target: e.id,
                                params: e.params
                            })) : a = window.open(e.url, e.id, n), !a && r("sdk.feature")("popup_blocker_scribe_logging", !0)) {
                            var i = t ? "POPUP_MAYBE_BLOCKED_OAUTH" : "POPUP_MAYBE_BLOCKED";
                            o("sdk.Scribe").log("jssdk_error", {
                                appId: r("sdk.Runtime").getClientID(),
                                error: i,
                                extra: {
                                    call: e.name
                                }
                            })
                        }
                        return a
                    }

                    function s(e) {
                        var t = window.screenX,
                            n = window.screenY,
                            o = window.outerWidth,
                            a = window.outerHeight,
                            i = r("sdk.UA").mobile() ? 0 : e.width,
                            l = r("sdk.UA").mobile() ? 0 : e.height,
                            s = t < 0 ? window.screen.width + t : t,
                            u = s + (o - i) / 2,
                            c = n + (a - l) / 2.5,
                            d = [];
                        return d.push("width=" + i), d.push("height=" + l), d.push("left=" + u), d.push("top=" + c), d.push("scrollbars=1"), e.isOAuth && (d.push("toolbar=0"), (!r("sdk.UA").chrome() || r("sdk.UA").chrome() < 59) && d.push("location=1")), d.join(",")
                    }
                    l.popup = e
                }, 98);
                __d("isFacebookDotNetURI", [], function(t, n, r, o, a, i) {
                    "use strict";

                    function e(e) {
                        if (e.getProtocol() !== "http" && e.getProtocol() !== "https") return !1;
                        var t = Number(e.getPort());
                        return t && t !== 80 && t !== 443 ? !1 : !!e.isSubdomainOfDomain("facebook.net")
                    }
                    i.default = e
                }, 66);
                __d("isFacebookURI", [], function(t, n, r, o, a, i) {
                    var e = null,
                        l = ["http", "https"];

                    function s(t) {
                        return e || (e = new RegExp("(^|\\.)facebook\\.com$", "i")), t.isEmpty() && t.toString() !== "#" ? !1 : !t.getDomain() && !t.getProtocol() ? !0 : l.indexOf(t.getProtocol()) !== -1 && e.test(t.getDomain())
                    }
                    s.setRegex = function(t) {
                        e = t
                    }, i.default = s
                }, 66);
                __d("isInstagramURI", [], function(t, n, r, o, a, i) {
                    var e = null;

                    function l(t) {
                        return t.isEmpty() && t.toString() !== "#" || !t.getDomain() && !t.getProtocol() || t.getProtocol() !== "https" ? !1 : (e || (e = new RegExp("(^|\\.)instagram\\.com$", "i")), e.test(t.getDomain()))
                    }
                    i.default = l
                }, 66);
                __d("resolveWindow", [], (function(t, n, r, o, a, i) {
                    function e(e) {
                        if (e == null) return null;
                        var t = window,
                            n = e.split(".");
                        try {
                            for (var r = 0; r < n.length; r++) {
                                var o = n[r],
                                    a = /^frames\[[\'\"]?([a-zA-Z0-9\-_]+)[\'\"]?\]$/.exec(o);
                                if (a) t = t.frames[a[1]];
                                else if (o === "opener" || o === "parent" || o === "top") t = t[o];
                                else return null
                            }
                        } catch (e) {
                            return null
                        }
                        return t
                    }
                    i.default = e
                }), 66);
                __d("sdk.XD", ["JSSDKXDConfig", "Log", "QueryString", "Queue", "UrlMap", "guid", "isFacebookDotNetURI", "isFacebookURI", "isInstagramURI", "resolveWindow", "sdk.Event", "sdk.RPC", "sdk.Runtime", "sdk.Scribe", "sdk.URI", "sdk.feature"], function(t, n, r, o, a, i, l) {
                    var e = new(r("Queue")),
                        s = "parent",
                        u = null,
                        c = /^https:\/\/.*\.(facebook|instagram)\.(com|net)$/,
                        d = o("JSSDKXDConfig").useCdn ? "cdn" : "www",
                        m = o("UrlMap").resolve(d) + o("JSSDKXDConfig").XXdUrl,
                        p = function() {
                            if ("origin" in location) {
                                if (location.origin && location.origin != "null") return location.origin;
                                if (window !== window.parent) try {
                                    var e = parent.location.origin;
                                    if (e && e != "null") return e
                                } catch (e) {}
                            }
                            return location.protocol + "//" + location.host
                        },
                        _ = r("guid")(),
                        f = p(),
                        g = !1,
                        h = new(r("Queue"));
                    r("sdk.RPC").setInQueue(h);

                    function y(e) {
                        o("Log").info("Remote XD can talk to facebook.com (%s)", e), r("sdk.Runtime").setEnvironment(e === "canvas" ? r("sdk.Runtime").ENVIRONMENTS.CANVAS : r("sdk.Runtime").ENVIRONMENTS.PAGETAB)
                    }

                    function C(e, t) {
                        if (!t) throw o("Log").error("No senderOrigin"), new Error;
                        switch (e.xd_action) {
                            case "plugin_ready":
                                if (typeof e.name == "string") {
                                    var n = e.name;
                                    if (o("Log").info("Plugin %s ready from %s", n, t), c.test(t)) {
                                        var a = r("Queue").get(n, {});
                                        a.start(function(e) {
                                            if (e == null) {
                                                o("Log").warn("Discarding null message from %s to %s on %s", t, n, f);
                                                return
                                            }
                                            window.frames[n] != null ? window.frames[n].postMessage({
                                                xdArbiterHandleMessage: !0,
                                                message: e,
                                                origin: f
                                            }, t) : o("Log").info("Message discarded for plugin at window.frames[%s] which may have been removed by a new XFBML.parse() call.", n)
                                        })
                                    } else {
                                        o("Log").error("Plugin attempted to register from non-Facebook domain %s", t);
                                        return
                                    }
                                } else o("Log").error("plugin_ready message received without a name");
                                break
                        }
                        e.data != null && (typeof e.data == "object" || typeof e.data == "string") && b(e.data, t)
                    }

                    function b(e, t) {
                        var n = new(r("sdk.URI"))(t);
                        if (!(t != null && t !== "native" && !r("isFacebookURI")(n) && !r("isFacebookDotNetURI")(n) && !r("isInstagramURI")(n))) {
                            if (typeof e == "string") {
                                if (/^FB_RPC:/.test(e)) {
                                    h.enqueue(e.substring(7));
                                    return
                                }
                                if (e.substring(0, 1) === "{") try {
                                    e = ES("JSON", "parse", !1, e)
                                } catch (t) {
                                    o("Log").warn("Failed to decode %s as JSON", e);
                                    return
                                } else e = r("QueryString").decode(e)
                            }
                            var a = e;
                            if (a.xd_action) {
                                C(a, t);
                                return
                            }
                            if (typeof a.cb == "string") {
                                var i = L._callbacks[a.cb];
                                L._forever[a.cb] || delete L._callbacks[a.cb], i && i(a)
                            }
                        }
                    }

                    function v(t, n) {
                        t == "facebook" ? (n.relation = s, e.enqueue(n), !r("sdk.Runtime").isCanvasEnvironment() && !e.isStarted() && R(u)) : r("Queue").get(t, {}).enqueue(n)
                    }
                    r("sdk.RPC").getOutQueue().start(function(t) {
                        e.enqueue("FB_RPC:" + t)
                    });

                    function S(t) {
                        g || (g = !0, window.addEventListener("message", function(t) {
                            var n = t.data,
                                a = t.origin || "native";
                            if (!/^(https?:\/\/|native$)/.test(a)) {
                                o("Log").debug("Received message from invalid origin type: %s", a);
                                return
                            }
                            if (c.test(a))
                                if (typeof n == "string") b(n, a);
                                else {
                                    if (t.source == parent && t.data.xdArbiterRegisterAck && c.test(a)) {
                                        typeof t.data.xdArbiterRegisterAck == "string" && t.data.xdArbiterRegisterAck !== "" && y(t.data.xdArbiterRegisterAck), e.isStarted() || e.start(function(e) {
                                            if (e == null) {
                                                o("Log").warn("Discarding null message from %s to %s", f, a);
                                                return
                                            }
                                            var t = parent;
                                            typeof e == "object" && typeof e.relation == "string" && (t = r("resolveWindow")(e.relation)), (t != null ? t : parent).postMessage({
                                                xdArbiterHandleMessage: !0,
                                                message: e,
                                                origin: f
                                            }, a)
                                        });
                                        return
                                    }
                                    return
                                }
                        }), r("sdk.Runtime").isCanvasEnvironment() && R(t))
                    }

                    function R(t) {
                        var n;
                        if (g || S(), window.parent != top) {
                            o("Log").warn("cannot deliver messages to facebook unless window.parent is top and facebook.com.");
                            return
                        }
                        var a = (n = r("sdk.feature")("xd_timeout", 6e4)) != null ? n : 6e4,
                            i = 200,
                            l = a / i,
                            s = function() {
                                return parent.postMessage({
                                    xdArbiterRegister: !0,
                                    xdProxyName: t,
                                    origin: f
                                }, "*")
                            },
                            u = window.setInterval(function() {
                                if (!e.isStarted() && l > 0) l--, o("Log").debug("resending xdArbiterRegister"), s();
                                else if (window.clearInterval(u), l === 0) {
                                    o("sdk.Scribe").log("jssdk_error", {
                                        appId: r("sdk.Runtime").getClientID(),
                                        error: "XD_FB_QUEUE_INITIALIZATION",
                                        extra: {
                                            message: "Failed to initialize in " + a + "ms"
                                        }
                                    }), o("Log").error("xdAbiterRegisterAck not received");
                                    return
                                }
                            }, i)
                    }
                    var L = {
                        rpc: r("sdk.RPC"),
                        _callbacks: {},
                        _forever: {},
                        _channel: _,
                        _origin: f,
                        onMessage: b,
                        init: S,
                        sendToFacebook: v,
                        inform: function(t, n, r, o) {
                            v("facebook", {
                                method: t,
                                params: ES("JSON", "stringify", !1, n || {}),
                                behavior: o || "p",
                                relation: r
                            })
                        },
                        handler: function(t, n, o, a) {
                            var e = "#" + r("QueryString").encode({
                                cb: L.registerCallback(t, o, a),
                                origin: f + "/" + _,
                                domain: location.hostname,
                                relation: n || "opener",
                                is_canvas: r("sdk.Runtime").isCanvasEnvironment()
                            });
                            return m + e
                        },
                        registerCallback: function(t, n, o) {
                            return o = o || r("guid")(), n && (L._forever[o] = !0), L._callbacks[o] = t, o
                        }
                    };
                    o("sdk.Event").subscribe("init:post", function(e) {
                        u = e.xdProxyName, S(e.xdProxyName)
                    }), i.exports = L
                }, 34);
                __d("sdk.modFeatureCheck", ["JSSDKConfig"], function(t, n, r, o, a, i, l) {
                    function e(e, t, n) {
                        if (n === void 0 && (n = !1), o("JSSDKConfig").features && e in o("JSSDKConfig").features) {
                            var r = o("JSSDKConfig").features[e];
                            if (typeof r == "object" && Array.isArray(r)) return t.some(function(e) {
                                return r.some(function(t) {
                                    return e % t === 0
                                })
                            })
                        }
                        return n
                    }
                    l.forIDs = e
                }, 98);
                __d("sdk.openMessenger", ["sdk.UA"], (function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = "https://itunes.apple.com/us/app/messenger/id454638411",
                        s = "https://play.google.com/store/apps/details?id=com.facebook.orca",
                        u = 3e3;

                    function c(t) {
                        var n, o, a = t.link,
                            i = t.app_id;
                        r("sdk.UA").android() ? (n = "intent://share/#Intent;package=com.facebook.orca;scheme=fb-messenger;S.android.intent.extra.TEXT=" + encodeURIComponent(a) + ";S.trigger=send_plugin;", i && (n += "S.platform_app_id=" + encodeURIComponent(i) + ";"), n += "end", o = s) : (n = "fb-messenger://share?link=" + encodeURIComponent(a), i && (n += "&app_id=" + encodeURIComponent(i)), o = e), setTimeout(function() {
                            window.location.href = o
                        }, u), window.location.href = n
                    }
                    l.default = c
                }), 98);
                __d("sdk.UIServer", ["Log", "QueryString", "UrlMap", "createObjectFrom", "flattenObject", "guid", "insertIframe", "resolveURI", "sdk.Auth", "sdk.Auth.LoginStatus", "sdk.AuthUtils", "sdk.Content", "sdk.DOM", "sdk.Dialog", "sdk.Event", "sdk.Extensions", "sdk.Frictionless", "sdk.LoggingUtils", "sdk.Popup", "sdk.RPC", "sdk.Runtime", "sdk.UA", "sdk.XD", "sdk.api", "sdk.fbt", "sdk.feature", "sdk.getContextType", "sdk.modFeatureCheck", "sdk.openMessenger"], function(t, n, r, o, a, i, l) {
                    var e = {
                        transform: function(t) {
                            return t.params.display === "touch" && g.canIframe(t.params) && window.postMessage ? (t.params.channel = g._xdChannelHandler(t.id, "parent"), r("sdk.UA").nativeApp() || (t.params.in_iframe = 1), t) : g.genericTransform(t)
                        },
                        getXdRelation: function(t) {
                            var e = t.display;
                            return e === "touch" && window.postMessage && t.in_iframe ? "parent" : g.getXdRelation(t)
                        }
                    };

                    function s(e) {
                        return g.isOAuth(e) && o("sdk.Extensions").supportsDialog("oauth")
                    }

                    function u(e) {
                        return g.isOAuth(e) && (e.is_account_link === !0 || e.is_account_link === "true") && o("sdk.Extensions").supportsDialog("accountLink")
                    }

                    function c(e) {
                        if (!r("sdk.Runtime").getClientID()) {
                            o("Log").error("FB.login() called before FB.init().");
                            return
                        }
                        if (r("sdk.Auth").getAuthResponse() && !e.params.scope && !e.params.config_id && !e.params.asset_scope && !e.params.auth_type) {
                            e.params.plugin_prepare || (o("Log").error("FB.login() called when user is already connected."), e.cb && (e == null || e.cb({
                                status: r("sdk.Runtime").getLoginStatus(),
                                authResponse: r("sdk.Auth").getAuthResponse()
                            })));
                            return
                        }
                        var t = e.cb,
                            n = e.id;
                        delete e.cb, e && e.params && !e.params.logger_id && (e.params.logger_id = r("guid")()), e && e.params && !e.params.cbt && (e.params.cbt = Date.now()), (e.params.fx_app === "instagram" || e.params.fx_app === "ig_single") && !e.params.scope && (e.params.scope = "public_profile");
                        var a = e.params.auth_type,
                            i = a && ES(a, "includes", !0, "reauthenticate"),
                            l = {
                                token: !0,
                                signed_request: !0,
                                graph_domain: !0
                            },
                            s = e.params.override_default_response_type === !0 ? e.params.response_type : Object.keys(ES("Object", "assign", !1, e.params.response_type ? r("createObjectFrom")(e.params.response_type.split(",")) : {}, l)).join(",");
                        e.params.display === "async" ? (ES("Object", "assign", !1, e.params, {
                            client_id: r("sdk.Runtime").getClientID(),
                            origin: r("sdk.getContextType")(),
                            response_type: s,
                            domain: location.hostname
                        }), e.cb = r("sdk.Auth").xdResponseWrapper(t, r("sdk.Auth").getAuthResponse(), "permissions.oauth", e.params, Date.now())) : (i && g._xdNextHandler(function(e) {
                            t({
                                authResponse: null,
                                status: "not_authorized"
                            })
                        }, n, e.params.plugin_prepare ? "opener.parent" : "opener", !0), ES("Object", "assign", !1, e.params, {
                            client_id: r("sdk.Runtime").getClientID(),
                            redirect_uri: r("resolveURI")(g.xdHandler(t, n, e.params.plugin_prepare ? "opener.parent" : "opener", r("sdk.Auth").getAuthResponse(), "permissions.oauth", !i, e.params)),
                            origin: r("sdk.getContextType")(),
                            response_type: s,
                            domain: location.hostname
                        }));
                        var u = e.params && e.params.tp && e.params.tp !== "unspecified";
                        return !e.params.plugin_prepare && !u && (o("sdk.LoggingUtils").logEvent(e.params.logger_id, o("sdk.LoggingUtils").logEventName.loginStart, {
                            cbt_delta: 0
                        }), typeof(e == null ? void 0 : e.url) == "string" && e.url.indexOf("://oauth.") !== -1 && o("sdk.LoggingUtils").logLoginEvent(e.params, o("sdk.LoggingUtils").logEventName.loginUsingOauthSubdomain)), e
                    }
                    var d = {
                            "stream.share": {
                                size: {
                                    width: 670,
                                    height: 340
                                },
                                url: "sharer.php",
                                transform: function(t) {
                                    return t.params.u || (t.params.u = window.location.toString()), t.params.display = "popup", t
                                }
                            },
                            gaming_friendfinder: {
                                url: "gaming/me/friendfinder/",
                                transform: function(t) {
                                    if (!r("sdk.Runtime").getClientID()) {
                                        o("Log").error("FriendFinder called before FB.init().");
                                        return
                                    }
                                    return t.url += r("sdk.Runtime").getClientID(), t.size = {
                                        width: 400,
                                        height: 800
                                    }, t
                                }
                            },
                            gaming_media_library: {
                                url: "gaming/me/media_asset/",
                                transform: function(t) {
                                    return t.url += t.params.media_id, t.size = {
                                        width: 400,
                                        height: 800
                                    }, t
                                }
                            },
                            apprequests: {
                                transform: function(n) {
                                    return n = e.transform(n), n.size = {
                                        width: 445,
                                        height: 635
                                    }, n.params.display = "popup", n.params.in_iframe = !1, n.params.frictionless = r("sdk.Frictionless") && r("sdk.Frictionless")._useFrictionless, n.params.frictionless && (r("sdk.Frictionless").isAllowed(n.params.to) && (n.hideLoader = !0), n.cb = r("sdk.Frictionless")._processRequestResponse(n.cb, n.hideLoader)), n.closeIcon = !1, n
                                },
                                getXdRelation: e.getXdRelation
                            },
                            "permissions.oauth": {
                                url: "dialog/oauth",
                                size: {
                                    width: r("sdk.UA").mobile() ? null : 600,
                                    height: r("sdk.UA").mobile() ? null : 679
                                },
                                transform: function(t) {
                                    return c(t)
                                }
                            },
                            "permissions.ig_oauth": {
                                url: "oauth/authorize",
                                size: {
                                    width: r("sdk.UA").mobile() ? null : 600,
                                    height: r("sdk.UA").mobile() ? null : 679
                                },
                                transform: function(t) {
                                    return c(t)
                                }
                            },
                            photo_picker: {
                                url: "dialog/photo_picker",
                                size: {
                                    width: r("sdk.UA").mobile() ? null : 600,
                                    height: r("sdk.UA").mobile() ? null : 679
                                },
                                transform: function(t) {
                                    if (!r("sdk.Runtime").getClientID()) {
                                        o("Log").error("Photo Picker was called before FB.init().");
                                        return
                                    }
                                    var e = t.cb,
                                        n = t.id;
                                    return delete t.cb, ES("Object", "assign", !1, t.params, {
                                        client_id: r("sdk.Runtime").getClientID(),
                                        redirect_uri: r("resolveURI")(g.xdHandlerPhotoPicker(e, n, t.params.plugin_prepare ? "opener.parent" : "opener", "photo_picker", t.params)),
                                        origin: r("sdk.getContextType")(),
                                        domain: location.hostname
                                    }), t
                                }
                            },
                            "auth.logout": {
                                transform: function(t) {
                                    r("sdk.Runtime").getClientID() ? r("sdk.Auth").getAuthResponse() ? r("sdk.Auth").logout(t.cb) : o("Log").error("FB.logout() called without an access token.") : o("Log").error("FB.logout() called before calling FB.init().")
                                }
                            },
                            "login.status": {
                                transform: function(t) {
                                    r("sdk.Auth.LoginStatus").getLoginStatus(t.cb)
                                }
                            },
                            pay: {
                                size: {
                                    width: 555,
                                    height: 120
                                },
                                connectDisplay: "popup"
                            },
                            live_broadcast: {
                                transform: function(t) {
                                    return t.params.phase === "create" && (t.size = {
                                        width: 480,
                                        height: 280
                                    }), t.params.phase === "publish" && (t.size = {
                                        width: 772,
                                        height: 540
                                    }), t
                                },
                                require_access_token: !0
                            },
                            boost: {
                                transform: function(t) {
                                    return t.size = {
                                        width: 960,
                                        height: 760
                                    }, t.params.display = "popup", t
                                }
                            },
                            share_referral: {
                                size: {
                                    width: 482,
                                    height: 725
                                }
                            }
                        },
                        m = {},
                        p = 0;

                    function _(e, t) {
                        return m[t] = !0,
                            function(n) {
                                delete m[t], e(n)
                            }
                    }

                    function f(e) {
                        var t = e.method.toLowerCase();
                        return t === "pay" && e.display === "async"
                    }
                    var g = {
                        Methods: d,
                        _oauthMethodNameSet: new Set(["permissions.oauth", "permissions.request", "permissions.ig_oauth"]),
                        _loadedNodes: {},
                        _defaultCb: {},
                        _resultToken: '"xxRESULTTOKENxx"',
                        _popupInterval: null,
                        genericTransform: function(t) {
                            return (t.params.display == "dialog" || t.params.display == "iframe") && ES("Object", "assign", !1, t.params, {
                                display: "iframe",
                                channel: g._xdChannelHandler(t.id, "parent.parent")
                            }, !0), t
                        },
                        isOAuth: function(t) {
                            return g._oauthMethodNameSet.has(t.method) || t.method == "oauth"
                        },
                        checkOauthDisplay: function(t) {
                            var e = t.scope || t.perms || r("sdk.Runtime").getScope();
                            return e ? "popup" : t.display
                        },
                        prepareCall: function(t, n) {
                            var e, a, i = t.method.toLowerCase(),
                                l = Object.prototype.hasOwnProperty.call(g.Methods, i) ? babelHelpers.extends({}, g.Methods[i]) : {},
                                s = t.id || r("guid")();
                            if (ES("Object", "assign", !1, t, {
                                    app_id: r("sdk.Runtime").getClientID(),
                                    locale: r("sdk.Runtime").getLocale(),
                                    sdk: "joey",
                                    access_token: r("sdk.Runtime").getAccessToken() || void 0
                                }), t.display = g.getDisplayMode(l, t), l.url || (l.url = "dialog/" + i), (l.url === "dialog/oauth" || l.url === "dialog/permissions.request") && (t.display === "iframe" || t.display === "touch" && t.in_iframe) && (t.display = g.checkOauthDisplay(t)), l.url == "dialog/oauth") {
                                var u;
                                if (p >= ((u = r("sdk.feature")("max_oauth_dialog_retries", 100)) != null ? u : 100)) {
                                    o("Log").error("Your request to oauth has exceeded the rate limit, please try again later");
                                    return
                                }
                                p++
                            }
                            t.display === "popup" && !l.require_access_token && delete t.access_token;
                            var c = !1;
                            if (r("sdk.Runtime").getIsVersioned() && l.url.substring(0, 7) === "dialog/") {
                                var d = t.version || r("sdk.Runtime").getVersion();
                                d != null && d !== "" && d !== "null" && (l.url = d + "/" + l.url, c = !0)
                            }
                            if (!c && ((e = r("sdk.feature")("use_extended_dialog_path", !1)) != null && e) && l.url && typeof l.url == "string" && ES(l.url, "includes", !0, "dialog/oauth") && o("sdk.AuthUtils").getMobileOperatingSystem() === "android" && (l.url += "/index.php"), f(t)) {
                                if (m[i]) {
                                    var h = 'Dialog "' + i + '" is trying to run more than once.';
                                    o("Log").warn(h), n({
                                        error_code: -100,
                                        error_message: h
                                    });
                                    return
                                }
                                n = _(n, i)
                            }
                            var y = ((a = r("sdk.feature")("use_oauth_subdomain", !1)) != null ? a : !1) && t.display === "touch" && l.url && typeof l.url == "string" && ES(l.url, "includes", !0, "dialog/oauth") && o("sdk.AuthUtils").getMobileOperatingSystem() === "android",
                                C = {
                                    cb: n,
                                    id: s,
                                    size: l.size || g.getDefaultSize(),
                                    url: o("UrlMap").resolve(t.fx_app === "instagram" || t.fx_app === "ig_single" ? "www_instagram" : y ? "oauth" : t.display === "touch" ? "m" : "www") + "/" + l.url,
                                    params: t,
                                    name: i,
                                    dialog: r("sdk.Dialog").newInstance(s, t.display)
                                },
                                b = l.transform ? l.transform : g.genericTransform;
                            if (!(b && (C = b(C), !C))) {
                                t.display === "touch" && t.in_iframe && (C.params.parent_height = window.innerHeight);
                                var v = l.getXdRelation || g.getXdRelation,
                                    S = v(C.params);
                                return !(C.id in g._defaultCb) && !("next" in C.params) && !("redirect_uri" in C.params) && (C.params.next = g._xdResult(C.cb, C.id, S, !0)), (S === "parent" || S === "opener") && ES("Object", "assign", !1, C.params, {
                                    channel_url: g._xdChannelHandler(s, S === "parent" ? "parent.parent" : "opener")
                                }, !0), C = g.prepareParams(C), C
                            }
                        },
                        prepareParams: function(t) {
                            t.params.display !== "async" && delete t.params.method, t.params.kid_directed_site = r("sdk.Runtime").getKidDirectedSite() || t.params.kid_directed_site, t.params = r("flattenObject")(t.params);
                            var e = r("QueryString").encode(t.params);
                            return !r("sdk.UA").nativeApp() && g.urlTooLongForIE(t.url + "?" + e) ? t.post = !0 : e && (t.url += "?" + e), t
                        },
                        urlTooLongForIE: function(t) {
                            return r("sdk.UA").ie() != null && r("sdk.UA").ie() <= 8 && t.length > 2048
                        },
                        getDisplayMode: function(t, n) {
                            if (n.display === "hidden" || n.display === "none" || n.display === "native") return n.display;
                            var e = r("sdk.Runtime").isEnvironment(r("sdk.Runtime").ENVIRONMENTS.CANVAS) || r("sdk.Runtime").isEnvironment(r("sdk.Runtime").ENVIRONMENTS.PAGETAB);
                            return e && (o("sdk.modFeatureCheck").forIDs("force_popup_to_canvas_apps_with_id", [r("sdk.Runtime").getClientID()]) || r("sdk.feature")("force_popup_to_all_canvas_app", !1)) ? "popup" : e && !n.display || s(n) || u(n) ? "async" : r("sdk.UA").mobile() || n.display === "touch" ? "touch" : (n.display == "iframe" || n.display == "dialog") && !g.canIframe(n) ? (o("Log").error('"dialog" mode can only be used when the user is connected.'), "popup") : t.connectDisplay && !e ? t.connectDisplay : n.display || (g.canIframe(n) ? "dialog" : "popup")
                        },
                        canIframe: function(t) {
                            return r("sdk.Runtime").getAccessToken()
                        },
                        getXdRelation: function(t) {
                            var e = t.display;
                            return e === "popup" || e === "touch" ? "opener" : e === "dialog" || e === "iframe" || e === "hidden" || e === "none" ? "parent" : e === "async" ? "parent.frames[" + window.name + "]" : ""
                        },
                        popup: function(t) {
                            var e = o("sdk.Popup").popup(t, g.isOAuth({
                                method: t.name
                            }));
                            e && (g.setLoadedNode(t, e, "popup"), t.id in g._defaultCb && g._popupMonitor())
                        },
                        setLoadedNode: function(t, n, r) {
                            r === "iframe" && (n.fbCallID = t.id), n = {
                                node: n,
                                type: r,
                                fbCallID: t.id,
                                method: t.name,
                                params: t.params
                            }, g._loadedNodes[t.id] = n
                        },
                        getLoadedNode: function(t) {
                            var e = typeof t == "object" ? t.id : t,
                                n = g._loadedNodes[e];
                            return n ? n.node : null
                        },
                        hidden: function(t) {
                            t.className = "FB_UI_Hidden", t.root = o("sdk.Content").appendHidden(document.createElement("div")), g._insertIframe(t)
                        },
                        iframe: function(t) {
                            t.className = "FB_UI_Dialog";
                            var e = function() {
                                    var e = ES("JSON", "stringify", !1, {
                                        error_code: 4201,
                                        error_message: r("sdk.fbt")._( /*BTDS*/ "User canceled the Dialog flow")
                                    });
                                    g._triggerDefault(t.id, e)
                                },
                                n = {
                                    onClose: e,
                                    closeIcon: t.closeIcon === void 0 ? !0 : t.closeIcon,
                                    classes: r("sdk.Dialog").isTabletStyle() ? "centered" : ""
                                };
                            t.root = r("sdk.Dialog").create(n), t.hideLoader || r("sdk.Dialog").showLoader(e, t.size.width), o("sdk.DOM").addCss(t.root, "fb_dialog_iframe"), g._insertIframe(t)
                        },
                        touch: function(t) {
                            t.params && t.params.in_iframe ? t.ui_created ? r("sdk.Dialog").showLoader(function() {
                                g._triggerDefault(t.id, null)
                            }, "") : g.iframe(t) : t.ui_created || g.popup(t)
                        },
                        async: function(t) {
                            t.params.redirect_uri = location.protocol + "//" + location.host + location.pathname, delete t.params.access_token, t.params.is_canvas = r("sdk.Runtime").isCanvasEnvironment();
                            var e = function(n) {
                                var e = n.result;
                                if (e && e.e2e) {
                                    var o = r("sdk.Dialog").get(t.id);
                                    o.trackEvents(e.e2e), o.trackEvent("close"), delete e.e2e
                                }
                                t.cb(e)
                            };
                            s(t.params) || u(t.params) ? (t.params.method = "oauth", t.params.redirect_uri = t.params.next, o("sdk.Extensions").remote.showDialog(t.params, e)) : r("sdk.RPC").remote.showDialog(t.params, e)
                        },
                        native: function(t) {
                            r("sdk.openMessenger")(t.params)
                        },
                        getDefaultSize: function() {
                            return r("sdk.Dialog").getDefaultSize()
                        },
                        _insertIframe: function(t) {
                            g._loadedNodes[t.id] = !1;
                            var e = function(n) {
                                t.id in g._loadedNodes && g.setLoadedNode(t, n, "iframe")
                            };
                            t.post ? r("insertIframe")({
                                url: "about:blank",
                                root: t.root,
                                className: t.className,
                                width: t.size.width,
                                height: t.size.height,
                                id: t.id,
                                onInsert: e,
                                onload: function(n) {
                                    o("sdk.Content").submitToTarget({
                                        url: t.url,
                                        target: n.name,
                                        params: t.params
                                    })
                                }
                            }) : r("insertIframe")({
                                url: t.url,
                                root: t.root,
                                className: t.className,
                                width: t.size.width,
                                height: t.size.height,
                                id: t.id,
                                name: t.frameName,
                                onInsert: e
                            })
                        },
                        _handleResizeMessage: function(t, n) {
                            var e = g.getLoadedNode(t);
                            e && (n.height && (e.style.height = n.height + "px"), n.width && n.width !== 0 && (e.style.width = n.width + "px"), r("sdk.XD").inform("resize.ack", n || {}, "parent.frames[" + e.name + "]"), r("sdk.Dialog").isActive(e) ? r("sdk.Dialog")._centerActive() : r("sdk.Dialog").show(e))
                        },
                        _triggerDefault: function(t, n) {
                            var e = {
                                frame: t,
                                result: ""
                            };
                            n && (e.result = n), g._xdRecv(e, g._defaultCb[t] || function() {})
                        },
                        _popupMonitor: function() {
                            var e, t = function(n) {
                                if (Object.prototype.hasOwnProperty.call(g._loadedNodes, n) && n in g._defaultCb) {
                                    var t = g._loadedNodes[n];
                                    if (t.type != "popup" && t.type != "native") return 1;
                                    var o = t.node;
                                    try {
                                        o.closed ? g.isOAuth(t) ? r("sdk.Auth.LoginStatus").getLoginStatus(function(e) {
                                            (e == null ? void 0 : e.status) === "connected" && t.params != null && t.params.return_scopes ? r("sdk.api")("/me/permissions", function(t) {
                                                (!t || t.error) && g._triggerDefault(n, e);
                                                for (var r = "", o = t && t.data ? t.data : [], a = 0; a < o.length; a++) o[a].status === "granted" && (r !== "" && (r += ","), r += o[a].permission);
                                                e.authResponse && e.authResponse.grantedScopes && (e.authResponse.grantedScopes = r), g._triggerDefault(n, e)
                                            }) : ((e == null ? void 0 : e.status) !== "connected" && (e.closeWindow = !0), g._triggerDefault(n, e))
                                        }, !0) : g._triggerDefault(n, null) : e = !0
                                    } catch (e) {}
                                }
                            };
                            for (var n in g._loadedNodes) t(n);
                            e && !g._popupInterval ? g._popupInterval = window.setInterval(g._popupMonitor, 100) : !e && g._popupInterval && (window.clearInterval(g._popupInterval), g._popupInterval = null)
                        },
                        _xdChannelHandler: function(t, n) {
                            return r("sdk.XD").handler(function(e) {
                                var n = g.getLoadedNode(t);
                                if (n)
                                    if (e.type === "resize") g._handleResizeMessage(t, e);
                                    else if (e.type === "hide") r("sdk.Dialog").hide(n);
                                else if (e.type === "rendered") {
                                    var a = r("sdk.Dialog")._findRoot(n);
                                    r("sdk.Dialog").show(a)
                                } else e.type === "fireevent" && o("sdk.Event").fire(e.event, e)
                            }, n, !0, null)
                        },
                        _xdNextHandler: function(t, n, o, a) {
                            return a && (g._defaultCb[n] = t), r("sdk.XD").handler(function(e) {
                                g._xdRecv(e, t)
                            }, o) + "&frame=" + n
                        },
                        _xdRecv: function(t, n) {
                            var e = g.getLoadedNode(t.frame);
                            if (e)
                                if (e.close) try {
                                    e.close(), /iPhone.*Version\/(5|6)/.test(navigator.userAgent) && RegExp.$1 !== "5" && window.focus(), g._popupCount--
                                } catch (e) {} else o("sdk.DOM").containsCss(e, "FB_UI_Hidden") ? window.setTimeout(function() {
                                    e.parentNode.parentNode.removeChild(e.parentNode)
                                }, 3e3) : o("sdk.DOM").containsCss(e, "FB_UI_Dialog") && r("sdk.Dialog").remove(e);
                            if (delete g._loadedNodes[t.frame], delete g._defaultCb[t.frame], t.e2e) {
                                var a = r("sdk.Dialog").get(t.frame);
                                a.trackEvents(t.e2e), a.trackEvent("close"), delete t.e2e
                            }
                            n(t)
                        },
                        _xdResult: function(t, n, r, o) {
                            return g._xdNextHandler(function(e) {
                                t && t(e.result && e.result != g._resultToken && ES("JSON", "parse", !1, e.result))
                            }, n, r, o) + "&result=" + encodeURIComponent(g._resultToken)
                        },
                        xdHandler: function(t, n, o, a, i, l, s) {
                            return g._xdNextHandler(r("sdk.Auth").xdResponseWrapper(t, a, i, s, Date.now()), n, o, l)
                        },
                        xdHandlerPhotoPicker: function(t, n, r, o, a) {
                            return g._xdNextHandler(g.xdResponseWrapperPhotoPicker(t), n, r, !1)
                        },
                        xdResponseWrapperPhotoPicker: function(t) {
                            return function(e) {
                                var n;
                                return e && e.result && e.result.closeWindow ? n = "Photo picker call was cancelled by the user" : n = e.photos, t && t(n), null
                            }
                        }
                    };
                    o("sdk.Extensions").stub("showDialog"), r("sdk.RPC").stub("showDialog");
                    var h = g;
                    l.default = h
                }, 226);
                __d("sdk.ui", ["Assert", "Log", "sdk.Impressions", "sdk.PlatformVersioning", "sdk.Runtime", "sdk.UIServer", "sdk.feature"], function(t, n, r, o, a, i, l) {
                    function e(e, t) {
                        if (r("Assert").isObject(e), r("Assert").maybeFunction(t), r("sdk.Runtime").getIsVersioned() && (o("sdk.PlatformVersioning").assertVersionIsSet(), e.version ? o("sdk.PlatformVersioning").assertValidVersion(e.version) : e.version = r("sdk.Runtime").getVersion()), e = babelHelpers.extends({}, e), !e.method) return o("Log").error('"method" is a required parameter for FB.ui().'), null;
                        e.method === "pay.prompt" && (e.method = "pay");
                        var n = e.method;
                        if (e.redirect_uri && (o("Log").warn("When using FB.ui, you should not specify a redirect_uri."), delete e.redirect_uri), e.fallback_redirect_uri || (e.fallback_redirect_uri = document.location.href), r("sdk.UIServer").isOAuth(n) && (e.display === "iframe" || e.display === "dialog") && (e.display = r("sdk.UIServer").checkOauthDisplay(e)), e.display === "native" && n !== "send") return o("Log").error('display type "native" not supported'), null;
                        var a = r("sdk.feature")("e2e_tracking", !0);
                        a && (e.e2e = {});
                        var i = r("sdk.UIServer").prepareCall(e, t || function() {});
                        if (!i) return null;
                        var l = i.params.display;
                        l === "dialog" ? l = "iframe" : l === "none" && (l = "hidden");
                        var s = r("sdk.UIServer")[l];
                        return s ? (a && i.dialog.subscribe("e2e:end", function(e) {
                            e.method = n, e.display = l, o("Log").debug("e2e: %s", ES("JSON", "stringify", !1, e)), o("sdk.Impressions").log(114, {
                                payload: e
                            })
                        }), s(i), i.dialog) : (o("Log").error('"display" must be one of "popup", "dialog", "iframe", "touch", "async", "hidden", or "none"'), null)
                    }
                    l.default = e
                }, 98);
                __d("sdk.Auth-public", ["FB", "sdk.Auth", "sdk.Auth.LoginStatus", "sdk.AuthUtils", "sdk.Event", "sdk.Runtime", "sdk.ui", "sdk.warnInsecure"], function(t, n, r, o, a, i, l) {
                    "use strict";

                    function e() {
                        var e, t;
                        r("FB").provide("", {
                            getLoginStatus: function() {
                                return r("sdk.warnInsecure")("getLoginStatus"), r("sdk.Auth.LoginStatus").getLoginStatus.apply(r("sdk.Auth"), arguments)
                            },
                            getAuthResponse: function() {
                                return r("sdk.warnInsecure")("getAuthResponse"), r("sdk.Auth").getAuthResponse()
                            },
                            getAccessToken: function() {
                                return r("sdk.warnInsecure")("getAccessToken"), r("sdk.Runtime").getAccessToken() || null
                            },
                            getUserID: function() {
                                return r("sdk.warnInsecure")("getUserID"), r("sdk.Runtime").getUserID() || r("sdk.Runtime").getCookieUserID()
                            },
                            login: function(t, n) {
                                r("sdk.warnInsecure")("login"), r("sdk.Auth").login(t, n)
                            },
                            logout: function(t) {
                                r("sdk.ui")({
                                    method: "auth.logout",
                                    display: "hidden"
                                }, t)
                            }
                        }), (t = r("sdk.Auth")).subscribe("logout", function() {
                            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            return o("sdk.Event").fire.apply(o("sdk.Event"), ["auth.logout"].concat(t))
                        }), t.subscribe("login", function() {
                            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            return o("sdk.Event").fire.apply(o("sdk.Event"), ["auth.login"].concat(t))
                        }), t.subscribe("authresponse.change", function() {
                            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            return o("sdk.Event").fire.apply(o("sdk.Event"), ["auth.authResponseChange"].concat(t))
                        }), t.subscribe("status.change", ES((e = o("sdk.Event")).fire, "bind", !0, e, "auth.statusChange")), t.subscribe("loginDenied", ES(e.fire, "bind", !0, e, "auth.denied")), t.subscribe("loginError", ES(e.fire, "bind", !0, e, "auth.error")), r("sdk.Runtime").subscribe("AccessToken.change", function(e) {
                            !e && r("sdk.Runtime").getLoginStatus() === "connected" && r("sdk.Auth.LoginStatus").getLoginStatus(null, !0)
                        }), o("sdk.AuthUtils").AuthInternalEvent.subscribe(o("sdk.AuthUtils").AuthConstants.REVALIDATE_TIMER_TIMEOUT, function(e) {
                            r("sdk.Auth.LoginStatus").fetchLoginStatus(function() {})
                        }), e.subscribe("init:post", function(e) {
                            r("sdk.Auth.LoginStatus").onSDKInit(e)
                        })
                    }
                    var s = {
                            init: e
                        },
                        u = s;
                    l.default = u
                }, 98);
                __d("sdk.Canvas.IframeHandling", ["DOMWrapper", "sdk.RPC"], (function(t, n, r, o, a, i, l) {
                    var e = null,
                        s;

                    function u() {
                        var e = o("DOMWrapper").getWindow().document,
                            t = e.body,
                            n = e.documentElement,
                            r = Math.max(t.offsetTop, 0),
                            a = Math.max(n.offsetTop, 0),
                            i = t.scrollHeight + r,
                            l = t.offsetHeight + r,
                            s = n.scrollHeight + a,
                            u = n.offsetHeight + a;
                        return Math.max(i, l, s, u)
                    }

                    function c(e) {
                        typeof e != "object" && (e = {});
                        var t = 0,
                            n = 0;
                        if (e.height || (e.height = u(), t = 16, n = 4), e.frame || (e.frame = window.name || "iframe_canvas"), s) {
                            var o = s.height,
                                a = e.height - o;
                            if (a <= n && a >= -t) return !1
                        }
                        return s = e, r("sdk.RPC").remote.setSize(e), !0
                    }

                    function d(t, n) {
                        n === void 0 && typeof t == "number" && (n = t, t = !0), t || t === void 0 ? (e === null && (e = window.setInterval(function() {
                            c()
                        }, n || 100)), c()) : e !== null && (window.clearInterval(e), e = null)
                    }
                    r("sdk.RPC").stub("setSize");
                    var m = {
                            setSize: c,
                            setAutoGrow: d
                        },
                        p = m;
                    l.default = p
                }), 98);
                __d("sdk.Canvas.Navigation", ["sdk.RPC"], (function(t, n, r, o, a, i) {
                    function e(e) {
                        n("sdk.RPC").local.navigate = function(t) {
                            e({
                                path: t
                            })
                        }, n("sdk.RPC").remote.setNavigationEnabled(!0)
                    }
                    n("sdk.RPC").stub("setNavigationEnabled");
                    var l = {
                            setUrlHandler: e
                        },
                        s = l;
                    i.default = s
                }), 66);
                __d("sdk.Canvas.Plugin", ["Log", "sdk.Runtime", "sdk.UA", "sdk.api"], function(t, n, r, o, a, i, l) {
                    var e = "CLSID:D27CDB6E-AE6D-11CF-96B8-444553540000",
                        s = "CLSID:444785F1-DE89-4295-863A-D46C3A781394",
                        u = null,
                        c = r("sdk.UA").osx() && r("sdk.UA").osx.getVersionParts(),
                        d = !(c && c[0] > 10 && c[1] > 10 && (r("sdk.UA").chrome() >= 31 || r("sdk.UA").webkit() >= 537.71 || r("sdk.UA").firefox() >= 25));

                    function m(e) {
                        e._hideunity_savedstyle = {}, e._hideunity_savedstyle.left = e.style.left, e._hideunity_savedstyle.position = e.style.position, e._hideunity_savedstyle.width = e.style.width, e._hideunity_savedstyle.height = e.style.height, e.style.left = "-10000px", e.style.position = "absolute", e.style.width = "1px", e.style.height = "1px"
                    }

                    function p(e) {
                        e._hideunity_savedstyle && (e.style.left = e._hideunity_savedstyle.left, e.style.position = e._hideunity_savedstyle.position, e.style.width = e._hideunity_savedstyle.width, e.style.height = e._hideunity_savedstyle.height)
                    }

                    function _(e) {
                        e._old_visibility = e.style.visibility, e.style.visibility = "hidden"
                    }

                    function f(e) {
                        e.style.visibility = e._old_visibility || "", delete e._old_visibility
                    }

                    function g(t) {
                        var n = t.type ? t.type.toLowerCase() : null,
                            r = n === "application/x-shockwave-flash" || t.classid && t.classid.toUpperCase() == e;
                        if (!r) return !1;
                        var o = /opaque|transparent/i;
                        if (o.test(t.getAttribute("wmode"))) return !1;
                        for (var a = 0; a < t.childNodes.length; a++) {
                            var i = t.childNodes[a];
                            if (/param/i.test(i.nodeName) && /wmode/i.test(i.name) && o.test(i.value)) return !1
                        }
                        return !0
                    }

                    function h(e) {
                        var t = e.type ? e.type.toLowerCase() : null;
                        return t === "application/vnd.unity" || e.classid && e.classid.toUpperCase() == s
                    }

                    function y(e) {
                        var t = ES("Array", "from", !1, window.document.getElementsByTagName("object"));
                        t = t.concat(ES("Array", "from", !1, window.document.getElementsByTagName("embed")));
                        var n = !1,
                            a = !1;
                        if (t.forEach(function(t) {
                                var r = g(t),
                                    i = d && h(t);
                                if (!(!r && !i)) {
                                    n = n || r, a = a || i;
                                    var l = function() {
                                        e.state === "opened" ? r ? _(t) : m(t) : r ? f(t) : p(t)
                                    };
                                    if (u) {
                                        o("Log").info("Calling developer specified callback");
                                        var s = {
                                            state: e.state,
                                            elem: t
                                        };
                                        u(s), window.setTimeout(l, 200)
                                    } else l()
                                }
                            }), Math.random() <= 1 / 1e3) {
                            var i = {
                                unity: a,
                                flash: n
                            };
                            r("sdk.api")(r("sdk.Runtime").getClientID() + "/occludespopups", "post", i)
                        }
                    }

                    function C() {
                        _(), m()
                    }

                    function b() {
                        f(), p()
                    }
                    var v = {
                            _setHidePluginCallback: function(t) {
                                u = t
                            },
                            hidePluginCallback: y,
                            hidePluginElement: C,
                            showPluginElement: b
                        },
                        S = v;
                    l.default = S
                }, 98);
                __d("sdk.Canvas.Prefetcher", ["JSSDKCanvasPrefetcherConfig", "sdk.Runtime", "sdk.api"], function(t, n, r, o, a, i, l) {
                    var e, s = {
                            AUTOMATIC: 0,
                            MANUAL: 1
                        },
                        u = (e = o("JSSDKCanvasPrefetcherConfig").excludedAppIds) != null ? e : [],
                        c = s.AUTOMATIC,
                        d = [];

                    function m() {
                        c == s.AUTOMATIC && (ES("Array", "from", !1, document.getElementsByTagName("object")).forEach(function(e) {
                            e.data && d.push(e.data)
                        }), ES("Array", "from", !1, document.getElementsByTagName("link")).forEach(function(e) {
                            e.href && d.push(e.href)
                        }), ES("Array", "from", !1, document.getElementsByTagName("script")).forEach(function(e) {
                            e.src && d.push(e.src)
                        })), d.length !== 0 && (r("sdk.api")(r("sdk.Runtime").getClientID() + "/staticresources", "post", {
                            urls: ES("JSON", "stringify", !1, d),
                            is_https: location.protocol === "https:"
                        }), d = [])
                    }

                    function p() {
                        !r("sdk.Runtime").isEnvironment(r("sdk.Runtime").ENVIRONMENTS.CANVAS) || !r("sdk.Runtime").getClientID() || !o("JSSDKCanvasPrefetcherConfig").sampleRate || Math.random() >= 1 / o("JSSDKCanvasPrefetcherConfig").sampleRate || !o("JSSDKCanvasPrefetcherConfig").enabled || ES(u, "includes", !0, r("sdk.Runtime").getClientID()) || setTimeout(m, 3e4)
                    }

                    function _(e) {
                        c = e
                    }

                    function f(e) {
                        d.push(e)
                    }
                    var g = {
                            COLLECT_AUTOMATIC: s.AUTOMATIC,
                            COLLECT_MANUAL: s.MANUAL,
                            addStaticResource: f,
                            setCollectionMode: _,
                            _maybeSample: p
                        },
                        h = g;
                    l.default = h
                }, 98);
                __d("sdk.Canvas.Tti", ["sdk.RPC", "sdk.Runtime"], (function(t, n, r, o, a, i, l) {
                    function e(e, t) {
                        var n = {
                                appId: r("sdk.Runtime").getClientID(),
                                time: Date.now(),
                                name: t
                            },
                            o = [n];
                        e && o.push(function(t) {
                            e(t.result)
                        }), r("sdk.RPC").remote.logTtiMessage.apply(null, o)
                    }

                    function s() {
                        e(null, "StartIframeAppTtiTimer")
                    }

                    function u(t) {
                        e(t, "StopIframeAppTtiTimer")
                    }

                    function c(t) {
                        e(t, "RecordIframeAppTti")
                    }
                    r("sdk.RPC").stub("logTtiMessage");
                    var d = {
                            setDoneLoading: c,
                            startTimer: s,
                            stopTimer: u
                        },
                        m = d;
                    l.default = m
                }), 98);
                __d("sdk.Canvas-public", ["Assert", "FB", "Log", "sdk.Canvas.Environment", "sdk.Canvas.IframeHandling", "sdk.Canvas.Navigation", "sdk.Canvas.Plugin", "sdk.Canvas.Prefetcher", "sdk.Canvas.Tti", "sdk.Event", "sdk.RPC", "sdk.Runtime"], function(t, n, r, o, a, i, l) {
                    function e() {
                        r("FB").provide("Canvas", {
                            setSize: function(t) {
                                return r("Assert").maybeObject(t, "Invalid argument"), r("sdk.Canvas.IframeHandling").setSize.apply(null, arguments)
                            },
                            setAutoGrow: function() {
                                return r("sdk.Canvas.IframeHandling").setAutoGrow.apply(null, arguments)
                            },
                            getPageInfo: function(t) {
                                return r("Assert").isFunction(t, "Invalid argument"), r("sdk.Canvas.Environment").getPageInfo.apply(null, arguments)
                            },
                            scrollTo: function(t, n) {
                                return r("Assert").maybeNumber(t, "Invalid argument"), r("Assert").maybeNumber(n, "Invalid argument"), r("sdk.Canvas.Environment").scrollTo.apply(null, arguments)
                            },
                            setDoneLoading: function(t) {
                                return r("Assert").maybeFunction(t, "Invalid argument"), r("sdk.Canvas.Tti").setDoneLoading.apply(null, arguments)
                            },
                            startTimer: function() {
                                return r("sdk.Canvas.Tti").startTimer.apply(null, arguments)
                            },
                            stopTimer: function(t) {
                                return r("Assert").maybeFunction(t, "Invalid argument"), r("sdk.Canvas.Tti").stopTimer.apply(null, arguments)
                            },
                            setUrlHandler: function(t) {
                                return r("Assert").isFunction(t, "Invalid argument"), r("sdk.Canvas.Navigation").setUrlHandler.apply(null, arguments)
                            }
                        }), r("sdk.RPC").local.fireEvent = o("sdk.Event").fire, o("sdk.Event").subscribe("init:post", function(e) {
                            r("sdk.Runtime").isEnvironment(r("sdk.Runtime").ENVIRONMENTS.CANVAS) && (r("Assert").isTrue(!e.hideFlashCallback || !e.hidePluginCallback, "cannot specify deprecated hideFlashCallback and new hidePluginCallback"), r("sdk.Canvas.Plugin")._setHidePluginCallback(e.hidePluginCallback || e.hideFlashCallback))
                        })
                    }

                    function s() {
                        var e;
                        (e = r("sdk.RPC")).local.hidePluginObjects = function() {
                            o("Log").info("hidePluginObjects called"), r("sdk.Canvas.Plugin").hidePluginCallback({
                                state: "opened"
                            })
                        }, e.local.showPluginObjects = function() {
                            o("Log").info("showPluginObjects called"), r("sdk.Canvas.Plugin").hidePluginCallback({
                                state: "closed"
                            })
                        }, e.local.showFlashObjects = e.local.showPluginObjects, e.local.hideFlashObjects = e.local.hidePluginObjects
                    }

                    function u() {
                        s(), r("FB").provide("Canvas.Plugin", r("sdk.Canvas.Plugin"))
                    }

                    function c() {
                        r("FB").provide("Canvas.Prefetcher", r("sdk.Canvas.Prefetcher")), o("sdk.Event").subscribe("init:post", function(e) {
                            r("sdk.Runtime").isEnvironment(r("sdk.Runtime").ENVIRONMENTS.CANVAS) && r("sdk.Canvas.Prefetcher")._maybeSample()
                        })
                    }

                    function d() {
                        var e;
                        (e = o("sdk.Event")).subscribe(e.SUBSCRIBE, t), e.subscribe(e.UNSUBSCRIBE, n), r("sdk.RPC").stub("useFriendsOnline");

                        function t(e, t) {
                            e == "canvas.friendsOnlineUpdated" && t.length === 1 && r("sdk.RPC").remote.useFriendsOnline(!0)
                        }

                        function n(e, t) {
                            e == "canvas.friendsOnlineUpdated" && t.length === 0 && r("sdk.RPC").remote.useFriendsOnline(!1)
                        }
                    }
                    var m = {
                            init: e,
                            initCanvasPlugin: u,
                            initCanvasPrefetcher: c,
                            initCanvasPresence: d,
                            initRPC: s
                        },
                        p = m;
                    l.default = p
                }, 98);
                __d("sdk.Event-public", ["FB", "Log", "sdk.Event"], function(t, n, r, o, a, i, l) {
                    function e() {
                        var e = function(t) {
                            return o("Log").error("FB.Event." + t + "() has been deprecated")
                        };
                        r("FB").provide("Event", {
                            subscribe: function(t, n) {
                                return o("sdk.Event").subscribe(t, n)
                            },
                            unsubscribe: o("sdk.Event").unsubscribe,
                            clear: ES(e, "bind", !0, null, "clear"),
                            fire: ES(e, "bind", !0, null, "fire")
                        })
                    }
                    var s = {
                            init: e
                        },
                        u = s;
                    l.default = u
                }, 98);
                __d("sdk.Frictionless-public", ["FB", "sdk.Event", "sdk.Frictionless"], (function(t, n, r, o, a, i, l) {
                    "use strict";

                    function e() {
                        o("sdk.Event").subscribe("init:post", function(e) {
                            e.frictionlessRequests === !0 && r("sdk.Frictionless").init()
                        }), r("FB").provide("Frictionless", r("sdk.Frictionless"))
                    }
                    var s = {
                            init: e
                        },
                        u = s;
                    l.default = u
                }), 98);
                __d("sdk.GamingServices", ["sdk.api", "sdk.ui"], function(t, n, r, o, a, i, l) {
                    function e(e) {
                        r("sdk.ui")({
                            display: "touch",
                            method: "gaming_friendfinder"
                        }, e)
                    }

                    function s(e, t, n, o) {
                        r("sdk.api")("me/photos", "POST", {
                            caption: t,
                            url: e
                        }, function(e) {
                            if (n === !1 || !e || e.error) o !== null && o(e);
                            else {
                                var t = e.id;
                                r("sdk.ui")({
                                    display: "touch",
                                    method: "gaming_media_library",
                                    media_id: t
                                }, function(t) {
                                    o !== null && o(e)
                                })
                            }
                        })
                    }
                    var u = {
                            friendFinder: e,
                            uploadImageToMediaLibrary: s
                        },
                        c = u;
                    l.default = c
                }, 98);
                __d("sdk.GamingServices-public", ["FB", "sdk.GamingServices"], (function(t, n, r, o, a, i, l) {
                    "use strict";

                    function e() {
                        r("FB").provide("", {
                            gamingservices: r("sdk.GamingServices")
                        })
                    }
                    var s = {
                            init: e
                        },
                        u = s;
                    l.default = u
                }), 98);
                __d("sdk.PluginUtils", ["resolveURI", "sdk.Event"], function(t, n, r, o, a, i, l) {
                    var e = {
                        string: function(t) {
                            return t
                        },
                        bool: function(t) {
                            return t != null ? /^(?:true|1|yes|on)$/i.test(t) : void 0
                        },
                        url: function(t) {
                            return r("resolveURI")(t)
                        },
                        url_maybe: function(t) {
                            return t != null && t !== "" ? r("resolveURI")(t) : void 0
                        },
                        hostname: function(t) {
                            return t != null && t !== "" ? t : "window.location.hostname"
                        },
                        px: function(t) {
                            if (typeof t == "string") {
                                var e = t.match(/^(\d+)(?:px)?$/);
                                return e != null ? parseInt(e[0], 10) : void 0
                            } else return typeof t == "number" ? t : void 0
                        },
                        text: function(t) {
                            return t
                        }
                    };

                    function s(e, t) {
                        var n, r, o, a, i, l;
                        return (n = (r = (o = (a = (i = (l = e[t]) != null ? l : e[t.replace(/_/g, "-")]) != null ? i : e[t.replace(/_/g, "")]) != null ? a : e["data-" + t]) != null ? o : e["data-" + t.replace(/_/g, "-")]) != null ? r : e["data-" + t.replace(/_/g, "")]) != null ? n : void 0
                    }

                    function u(t, n, r, o) {
                        Object.keys(t).forEach(function(a) {
                            if (t[a] === "text" && !r[a]) {
                                var i, l;
                                r[a] = (i = (l = n.textContent) != null ? l : n.innerText) != null ? i : void 0, n.setAttribute(a, r[a])
                            }
                            o[a] = e[t[a]](s(r, a))
                        })
                    }

                    function c(e, t, n) {
                        t === "100%" ? e.style.width = "100%" : t != null && t !== "" && (e.style.width = t + "px"), (n != null && n !== "" || n === 0) && (e.style.height = n + "px")
                    }

                    function d(e) {
                        return function(t) {
                            var n = {
                                width: t.width,
                                height: t.height,
                                pluginID: e
                            };
                            o("sdk.Event").fire("xfbml.resize", n)
                        }
                    }

                    function m(e) {
                        return e === "100%" ? "100%" : e != null ? parseInt(e, 10) : void 0
                    }

                    function p(e) {
                        e != null && c(e, 0, 0)
                    }
                    var _ = {
                        skin: "string",
                        font: "string",
                        width: "string",
                        height: "px",
                        ref: "string",
                        lazy: "bool",
                        color_scheme: "string"
                    };
                    l.getVal = s, l.validate = u, l.resize = c, l.resizeBubbler = d, l.parse = m, l.collapseIframe = p, l.baseParams = _
                }, 98);
                __d("isNumberLike", [], function(t, n, r, o, a, i) {
                    function e(e) {
                        return !isNaN(parseFloat(e)) && isFinite(e)
                    }
                    i.default = e
                }, 66);
                __d("sdk.createIframe", ["DOMEventListener", "getBlankIframeSrc", "guid", "isNumberLike"], function(t, n, r, o, a, i, l) {
                    function e(e, t, n) {
                        n === void 0 && (n = !1);
                        var a = ES("Object", "assign", !1, {}, e),
                            i, l = a.name || r("guid")(),
                            s = a.root,
                            u = a.style || {
                                border: "none"
                            },
                            c = a.url,
                            d = a.onload,
                            m = a.onerror;
                        i = document.createElement("iframe"), i.name = l, delete a.style, delete a.name, delete a.url, delete a.root, delete a.onload, delete a.onerror, delete a.height, delete a.width, a.frameBorder === void 0 && (a.frameBorder = 0), a.allowTransparency === void 0 && (a.allowTransparency = !0), a.allowFullscreen === void 0 && (a.allowFullscreen = !0), a.scrolling === void 0 && (a.scrolling = "no"), a.allow === void 0 && (a.allow = "encrypted-media"), a.lazy && (a.loading = "lazy", u.visibility && delete u.visibility), delete a.lazy;
                        var p = e.width;
                        p != null && r("isNumberLike")(p) && (i.width = p + "px");
                        var _ = e.height;
                        _ != null && r("isNumberLike")(_) && (i.height = _ + "px"), a.testid && i.dataset != null && (i.dataset.testid = a.testid, delete a.testid);
                        for (var f in a) Object.prototype.hasOwnProperty.call(a, f) && i.setAttribute(f, a[f]);
                        if (ES("Object", "assign", !1, i.style, u), i.src = r("getBlankIframeSrc")(), s != null && s.appendChild(i), d) var g = o("DOMEventListener").add(i, "load", function() {
                            g.remove(), d()
                        });
                        if (m) var h = o("DOMEventListener").add(i, "error", function() {
                            h.remove(), m()
                        });
                        if (t) {
                            var y = document.createElement("form");
                            y.method = "POST", y.action = c, y.target = l;
                            for (var C in t) {
                                var b = document.createElement("input");
                                b.type = "hidden", b.name = C, b.value = t[C], y.appendChild(b)
                            }
                            document.body.appendChild(y), n ? window.setTimeout(function() {
                                return y.submit()
                            }, 0) : y.submit()
                        } else i.src = c;
                        return i
                    }
                    l.default = e
                }, 98);
                __d("IframePlugin", ["Log", "ObservableMixin", "QueryString", "Type", "UrlMap", "guid", "sdk.Auth.LoginStatus", "sdk.AuthUtils", "sdk.DOM", "sdk.Event", "sdk.PlatformVersioning", "sdk.PluginUtils", "sdk.Runtime", "sdk.UA", "sdk.URI", "sdk.XD", "sdk.createIframe"], function(t, n, r, o, a, i, l) {
                    var e = r("Type").extend({
                        constructor: function(t, n, a, i) {
                            var e = this,
                                l;
                            this.parent(), a = a.replace(/-/g, "_");
                            var s = (l = o("sdk.PluginUtils")).getVal(i, "plugin_id");
                            this.subscribe("xd.resize", l.resizeBubbler(s)), this.subscribe("xd.resize.flow", l.resizeBubbler(s)), this.subscribe("xd.resize.flow", function(t) {
                                ES("Object", "assign", !1, e._iframeOptions.root.style, {
                                    verticalAlign: "bottom",
                                    overflow: ""
                                }), o("sdk.PluginUtils").resize(e._iframeOptions.root, o("sdk.PluginUtils").parse(t.width), o("sdk.PluginUtils").parse(t.height)), e.updateLift(), window.clearTimeout(e._timeoutID)
                            }), this.subscribe("xd.resize", function(t) {
                                var n;
                                ES("Object", "assign", !1, e._iframeOptions.root.style, {
                                    verticalAlign: "bottom",
                                    overflow: ""
                                }), (n = o("sdk.PluginUtils")).resize(e._iframeOptions.root, n.parse(t.width), n.parse(t.height)), n.resize(e._iframe, n.parse(t.width), n.parse(t.height)), e._isIframeResized = !0, e.updateLift(), window.clearTimeout(e._timeoutID)
                            }), this.subscribe("xd.resize.iframe", function(t) {
                                o("sdk.PluginUtils").resize(e._iframe, o("sdk.PluginUtils").parse(t.width), o("sdk.PluginUtils").parse(t.height)), e._isIframeResized = !0, e.updateLift(), window.clearTimeout(e._timeoutID)
                            }), this.subscribe("xd.sdk_event", function(e) {
                                var n = ES("JSON", "parse", !1, e.data);
                                n.pluginID = s, o("sdk.Event").fire(e.event, n, t)
                            });
                            var u = o("UrlMap").resolve("www") + "/plugins/" + a + ".php?",
                                c = {};
                            l.validate(this.getParams(), t, i, c), l.validate(l.baseParams, t, i, c), ES("Object", "assign", !1, c, {
                                app_id: r("sdk.Runtime").getClientID(),
                                locale: r("sdk.Runtime").getLocale(),
                                sdk: "joey",
                                kid_directed_site: r("sdk.Runtime").getKidDirectedSite(),
                                channel: o("sdk.XD").handler(function(t) {
                                    t != null && e.inform("xd." + t.type, t)
                                }, "parent.parent", !0)
                            }), this.shouldIgnoreWidth() && (c.width = void 0), c.container_width = t.offsetWidth, o("sdk.DOM").addCss(t, "fb_iframe_widget");
                            var d = r("guid")();
                            this.subscribe("xd.verify", function(e) {
                                o("sdk.XD").sendToFacebook(d, {
                                    method: "xd/verify",
                                    params: ES("JSON", "stringify", !1, e.token)
                                })
                            }), this.subscribe("xd.refreshLoginStatus", function() {
                                o("sdk.AuthUtils").removeLogoutState(), r("sdk.Auth.LoginStatus").getLoginStatus(ES(e.inform, "bind", !0, e, "login.status"), !0)
                            });
                            var m = document.createElement("span");
                            ES("Object", "assign", !1, m.style, {
                                verticalAlign: "top",
                                width: c.lazy ? "1px" : "0px",
                                height: c.lazy ? "1px" : "0px",
                                overflow: "hidden"
                            }), this._element = t, this._ns = n, this._tag = a, this._params = c, this._config = this.getConfig(), this._iframeOptions = {
                                root: m,
                                url: u + r("QueryString").encode(c),
                                name: d,
                                width: this._config.mobile_fullsize && r("sdk.UA").mobile() ? void 0 : c.width || 1e3,
                                height: c.height || 1e3,
                                style: {
                                    border: "none",
                                    visibility: "hidden"
                                },
                                title: this._ns + ":" + this._tag + " Facebook Social Plugin",
                                testid: this._ns + ":" + this._tag + " Facebook Social Plugin",
                                onload: function() {
                                    return e.inform("render")
                                },
                                onerror: function() {
                                    return o("sdk.PluginUtils").collapseIframe(e._iframe)
                                },
                                lazy: c.lazy
                            }, this.isFluid() && c.width !== "auto" && (o("sdk.DOM").addCss(this._element, "fb_iframe_widget_fluid_desktop"), !c.width && this._config.full_width && (this._element.style.width = "100%", this._iframeOptions.root.style.width = "100%", this._iframeOptions.style.width = "100%", this._params.container_width = this._element.offsetWidth, this._iframeOptions.url = u + r("QueryString").encode(this._params)))
                        },
                        shouldIgnoreWidth: function() {
                            return r("sdk.UA").mobile() && this.getConfig().mobile_fullsize
                        },
                        useInlineHeightForMobile: function() {
                            return !0
                        },
                        process: function() {
                            var e = this;
                            if (r("sdk.Runtime").getIsVersioned()) {
                                o("sdk.PlatformVersioning").assertVersionIsSet();
                                var t = new(r("sdk.URI"))(this._iframeOptions.url);
                                this._iframeOptions.url = t.setPath("/" + r("sdk.Runtime").getVersion() + t.getPath()).toString()
                            }
                            var n = babelHelpers.extends({}, this._params);
                            delete n.channel;
                            var a = r("QueryString").encode(n);
                            if (this._element.getAttribute("fb-iframe-plugin-query") == a) {
                                o("Log").info("Skipping render: %s:%s %s", this._ns, this._tag, a), this.inform("render");
                                return
                            }
                            for (this._element.setAttribute("fb-iframe-plugin-query", a), this.subscribe("render", function() {
                                    o("sdk.Event").fire("iframeplugin:onload"), e._iframe.style.visibility = "visible", e._isIframeResized || o("sdk.PluginUtils").collapseIframe(e._iframe)
                                }); this._element.firstChild;) this._element.removeChild(this._element.firstChild);
                            this._element.appendChild(this._iframeOptions.root);
                            var i = r("sdk.UA").mobile() ? 120 : 45;
                            if (this._timeoutID = window.setTimeout(function() {
                                    o("sdk.PluginUtils").collapseIframe(e._iframe), o("Log").warn("%s:%s failed to resize in %ss", e._ns, e._tag, i)
                                }, i * 1e3), this._iframe = r("sdk.createIframe")(this._iframeOptions), o("sdk.Event").fire("iframeplugin:create"), (r("sdk.UA").mobile() || n.width === "auto") && (this.useInlineHeightForMobile() && o("sdk.DOM").addCss(this._element, "fb_iframe_widget_fluid"), !this._iframeOptions.width)) {
                                ES("Object", "assign", !1, this._element.style, {
                                    display: "block",
                                    width: "100%",
                                    height: "auto"
                                }), ES("Object", "assign", !1, this._iframeOptions.root.style, {
                                    width: "100%",
                                    height: "auto"
                                });
                                var l = {
                                    height: "auto",
                                    position: "static",
                                    width: "100%"
                                };
                                (r("sdk.UA").iphone() || r("sdk.UA").ipad()) && (l.width = "220px", l["min-width"] = "100%"), ES("Object", "assign", !1, this._iframe.style, l)
                            }
                        },
                        getConfig: function() {
                            return {}
                        },
                        isFluid: function() {
                            var e = this.getConfig();
                            return e.fluid
                        },
                        updateLift: function() {
                            var e = this._iframe.style.width === this._iframeOptions.root.style.width && this._iframe.style.height === this._iframeOptions.root.style.height,
                                t = this._iframe;
                            e ? o("sdk.DOM").removeCss(t, "fb_iframe_widget_lift") : o("sdk.DOM").addCss(t, "fb_iframe_widget_lift")
                        }
                    }, r("ObservableMixin"));
                    e.withParams = function(t, n) {
                        return e.extend({
                            getParams: function() {
                                return t
                            },
                            getConfig: function() {
                                return n || {}
                            }
                        })
                    };
                    var s = e;
                    l.default = s
                }, 98);
                __d("PluginConfig", ["sdk.feature"], (function(t, n, r, o, a, i, l) {
                    var e = {
                            mobile_fullsize: !0
                        },
                        s = {
                            mobile_fullsize: !0
                        },
                        u = {
                            mobile_fullsize: !0
                        },
                        c = {
                            mobile_fullsize: !0
                        },
                        d = {
                            mobile_fullsize: !0
                        },
                        m = {
                            fluid: r("sdk.feature")("fluid_embed", !1),
                            mobile_fullsize: !0
                        },
                        p = {
                            comment_embed: e,
                            messengerpreconfirmation: s,
                            messengeraccountconfirmation: u,
                            messengerbusinesslink: c,
                            messengertoggle: d,
                            post: m
                        },
                        _ = p;
                    l.default = _
                }), 98);
                __d("PluginAttrTypes", [], (function(t, n, r, o, a, i) {
                    "use strict";
                    var e = "string",
                        l = "bool",
                        s = "url";
                    i.string = e, i.bool = l, i.url = s
                }), 66);
                __d("PluginTags", ["PluginAttrTypes"], function(t, n, r, o, a, i, l) {
                    var e, s = {
                            ad_library_spend_tracker: {
                                country: (e = o("PluginAttrTypes")).string,
                                time_preset: e.string,
                                custom_start_date: e.string,
                                custom_end_date: e.string,
                                race_type: e.string,
                                state: e.string,
                                district: e.string,
                                page_ids: e.string,
                                include_vps: e.bool
                            },
                            comment_embed: {
                                href: e.url,
                                include_parent: e.bool
                            },
                            composer: {
                                action_type: e.string,
                                action_properties: e.string
                            },
                            create_event_button: {},
                            group: {
                                href: e.url,
                                show_social_context: e.bool,
                                show_group_info: e.bool,
                                show_metadata: e.bool
                            },
                            like: {
                                href: e.url,
                                layout: e.string,
                                show_faces: e.bool,
                                share: e.bool,
                                action: e.string,
                                send: e.bool,
                                size: e.string
                            },
                            like_box: {
                                href: e.string,
                                show_faces: e.bool,
                                header: e.bool,
                                stream: e.bool,
                                force_wall: e.bool,
                                show_border: e.bool,
                                id: e.string,
                                connections: e.string,
                                profile_id: e.string,
                                name: e.string
                            },
                            page: {
                                href: e.string,
                                hide_cta: e.bool,
                                hide_cover: e.bool,
                                small_header: e.bool,
                                adapt_container_width: e.bool,
                                show_facepile: e.bool,
                                show_posts: e.bool,
                                tabs: e.string
                            },
                            page_events: {
                                href: e.url
                            },
                            post: {
                                href: e.url,
                                show_text: e.bool
                            },
                            profile_pic: {
                                uid: e.string,
                                linked: e.bool,
                                href: e.string,
                                size: e.string,
                                facebook_logo: e.bool
                            },
                            send_to_mobile: {
                                max_rows: e.string,
                                show_faces: e.bool,
                                size: e.string
                            }
                        },
                        u = {
                            fan: "like_box",
                            likebox: "like_box"
                        };
                    Object.keys(u).forEach(function(e) {
                        s[e] = s[u[e]]
                    });
                    var c = s;
                    l.default = c
                }, 98);
                __d("runOnce", [], (function(t, n, r, o, a, i) {
                    function e(e) {
                        var t = !1,
                            n;
                        return function() {
                            return t || (t = !0, n = e()), n
                        }
                    }
                    i.default = e
                }), 66);
                __d("XFBML", ["Assert", "Log", "runOnce", "sdk.Observable"], function(t, n, r, o, a, i, l) {
                    var e = {},
                        s = {},
                        u = 0,
                        c = new(o("sdk.Observable")).Observable;

                    function d(e, t) {
                        return String(e[t]).trim()
                    }

                    function m(t) {
                        return e[d(t, "nodeName").toLowerCase()]
                    }

                    function p(e) {
                        var t = d(e, "className").split(/\s+/).filter(function(e) {
                            return Object.prototype.hasOwnProperty.call(s, e)
                        });
                        if (t.length !== 0 && (e.getAttribute("fb-xfbml-state") || !e.childNodes || e.childNodes.length === 0 || e.childNodes.length === 1 && e.childNodes[0].nodeType === 3 || e.children.length === 1 && d(e.children[0], "className") === "fb-xfbml-parse-ignore")) return s[t[0]]
                    }

                    function _(e) {
                        var t = {};
                        return ES("Array", "from", !1, e.attributes).forEach(function(e) {
                            t[d(e, "name")] = d(e, "value")
                        }), t
                    }

                    function f(e, t, n) {
                        if (r("Assert").isTrue(e && e.nodeType && e.nodeType === 1 && !!e.getElementsByTagName, "Invalid DOM node passed to FB.XFBML.parse()"), r("Assert").isFunction(t, "Invalid callback passed to FB.XFBML.parse()"), e != null) {
                            var a = ++u;
                            o("Log").info("XFBML Parsing Start %s", a);
                            var i = 1,
                                l = 0,
                                s = function() {
                                    i--, i === 0 && (o("Log").info("XFBML Parsing Finish %s, %s tags found", a, l), t != null && t(), c.inform("render", [a, l])), r("Assert").isTrue(i >= 0, "onrender() has been called too many times")
                                };
                            ES("Array", "from", !1, e.getElementsByTagName("*")).forEach(function(e) {
                                if (!(n !== !0 && e.getAttribute("fb-xfbml-state")) && e.nodeType === 1) {
                                    var t = m(e) || p(e);
                                    if (t != null) {
                                        i++, l++;
                                        var o = new t.ctor(e, t.xmlns, t.localName, _(e));
                                        o.subscribe("render", r("runOnce")(function() {
                                            e.setAttribute("fb-xfbml-state", "rendered"), s()
                                        }));
                                        var a = function() {
                                            e.getAttribute("fb-xfbml-state") == "parsed" ? c.subscribe("render.queue", a) : (e.setAttribute("fb-xfbml-state", "parsed"), o.process())
                                        };
                                        a()
                                    }
                                }
                            }), c.inform("parse", [a, l]);
                            var d = 3e4;
                            window.setTimeout(function() {
                                i > 0 && o("Log").warn("%s tags failed to render in %s ms", i, d)
                            }, d), s()
                        }
                    }
                    c.subscribe("render", function() {
                        var e = c.getSubscribers("render.queue");
                        c.clearSubscribers("render.queue"), e.forEach(function(e) {
                            e([])
                        })
                    });
                    var g = {
                            registerTag: function(n) {
                                var t = n.xmlns + ":" + n.localName;
                                t === "fb:customerchat" && e[t] != null || (r("Assert").isUndefined(e[t], t + " already registered"), e[t] = n, s[n.xmlns + "-" + n.localName] = n)
                            },
                            parse: function(t, n) {
                                f(t != null ? t : document.body, n != null ? n : function() {}, !0)
                            },
                            parseNew: function() {
                                f(document.body, function() {}, !1)
                            },
                            subscribe: c.subscribe,
                            unsubscribe: c.unsubscribe
                        },
                        h = g;
                    l.default = h
                }, 98);
                __d("sdk.XFBML.Comments", ["IframePlugin", "QueryString", "UrlMap", "sdk.DOM", "sdk.Event", "sdk.PluginUtils", "sdk.Runtime", "sdk.UA", "sdk.URI"], function(t, n, r, o, a, i, l) {
                    var e = 320,
                        s = babelHelpers.extends({
                            numposts: "string",
                            href: "url",
                            permalink: "bool",
                            order_by: "string",
                            mobile: "bool",
                            version: "string",
                            hide_post_profile: "bool",
                            limit: "string",
                            offset: "string",
                            view: "string",
                            fb_comment_id: "string",
                            from_mod_tool: "bool",
                            migrated: "string",
                            xid: "string",
                            title: "string",
                            url: "string",
                            quiet: "string",
                            reverse: "string",
                            simple: "string",
                            css: "string",
                            notify: "string",
                            count: "bool",
                            skin: "string",
                            font: "string",
                            width: "string",
                            height: "px",
                            ref: "string",
                            lazy: "bool",
                            color_scheme: "string"
                        }, o("sdk.PluginUtils").baseParams);

                    function u(t, n) {
                        if (Object.keys(s).forEach(function(e) {
                                var r = o("sdk.DOM").getAttr(t, e);
                                r !== null && (n[e] = r)
                            }), Object.keys(n).forEach(function(e) {
                                ES(e, "startsWith", !0, "data-") && delete n[e]
                            }), r("sdk.UA").mobile() && n.mobile !== !1 && (n.mobile = !0), n.skin || (n.skin = n.colorscheme), n.href) {
                            var i = n.fb_comment_id;
                            i || (i = r("QueryString").decode(document.URL.substring(document.URL.indexOf("?") + 1)).fb_comment_id, i && i.indexOf("#") > 0 && (i = i.substring(0, i.indexOf("#")))), i && (n.fb_comment_id = i)
                        } else {
                            if (n.title = n.title || document.title, n.url = n.url || document.URL, !n.xid) {
                                var a = document.URL.indexOf("#");
                                a > 0 ? n.xid = encodeURIComponent(document.URL.substring(0, a)) : n.xid = encodeURIComponent(document.URL)
                            }
                            n.migrated && (n.href = o("UrlMap").resolve("www") + "/plugins/comments_v1.php?app_id=" + r("sdk.Runtime").getClientID() + "&xid=" + encodeURIComponent(n.xid) + "&url=" + encodeURIComponent(n.url))
                        }
                        if (n.version || (n.version = r("sdk.Runtime").getVersion()), n.permalink || (n.width = n.mobile || n.width === "auto" || n.width === "100%" ? "" : n.width ? Math.max(n.width, e) : 550, n.height = 100), n.href != null) {
                            var l = new(r("sdk.URI"))(n.href);
                            l.getProtocol() || (n.href = l.setProtocol("http").toString())
                        }
                        return n
                    }
                    var c = r("IframePlugin").extend({
                            constructor: function(t, n, r, a) {
                                a = u(t, a), this.parent(t, n, r, a), this.subscribe("xd.sdk_event", function(e) {
                                    o("sdk.Event").fire(e.event, ES("JSON", "parse", !1, e.data))
                                })
                            },
                            getConfig: function() {
                                return {
                                    fluid: !0,
                                    full_width: !0
                                }
                            },
                            getParams: function() {
                                return s
                            }
                        }),
                        d = c;
                    l.default = d
                }, 98);
                __d("sdk.XFBML.CommentsCount", ["sdk.DOM", "sdk.XFBML.Comments", "sprintf"], function(t, n, r, o, a, i, l) {
                    var e = r("sdk.XFBML.Comments").extend({
                            constructor: function(t, n, a, i) {
                                o("sdk.DOM").addCss(t, "fb_comments_count_zero"), i.count = 1, this.parent(t, n, "comments", i), this.subscribe("xd.comment_count", function(e) {
                                    var n = ES("JSON", "parse", !1, e.data);
                                    o("sdk.DOM").dangerouslySetInnerHtml(t, r("sprintf")('<span class="fb_comments_count">%s</span>', n.count)), n.count > 0 && o("sdk.DOM").removeCss(t, "fb_comments_count_zero"), o("sdk.DOM").removeCss(t, "fb_iframe_widget")
                                })
                            }
                        }),
                        s = e;
                    l.default = s
                }, 98);
                __d("sdk.XFBML.LWIAdsCreation", ["IframePlugin", "sdk.createIframe"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = r("IframePlugin").extend({
                            constructor: function(t, n, r, o) {
                                this.parent(t, n, r, o), this._setUpSubscriptions()
                            },
                            getParams: function() {
                                return {
                                    fbe_extras: "string",
                                    fbe_redirect_uri: "string",
                                    fbe_scopes: "string",
                                    fbe_state: "string",
                                    hide_manage_button: "bool",
                                    hide_explore_more_options: "bool",
                                    preferred_ad_options: "string"
                                }
                            },
                            _setUpSubscriptions: function() {
                                var e = this;
                                this.subscribe("xd.lwiadscreation.load", function(t) {
                                    e._createIframe(t)
                                })
                            },
                            _createIframe: function(t) {
                                r("sdk.createIframe")({
                                    url: t.iframeURL,
                                    name: "LWIAdsCreationRootIframe",
                                    root: document.body,
                                    height: 300,
                                    width: 950
                                })
                            }
                        }),
                        s = e;
                    l.default = s
                }, 98);
                __d("sdk.XFBML.LWIAdsInsights", ["IframePlugin", "sdk.createIframe"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = r("IframePlugin").extend({
                            constructor: function(t, n, r, o) {
                                this.parent(t, n, r, o), this._setUpSubscriptions()
                            },
                            getParams: function() {
                                return {
                                    fbe_extras: "string",
                                    fbe_redirect_uri: "string",
                                    fbe_scopes: "string",
                                    fbe_state: "string"
                                }
                            },
                            _setUpSubscriptions: function() {
                                var e = this;
                                this.subscribe("xd.lwiadsinsights.load", function(t) {
                                    e._createIframe(t)
                                })
                            },
                            _createIframe: function(t) {
                                r("sdk.createIframe")({
                                    url: t.iframeURL,
                                    name: "LWIAdsInsightsRootIframe",
                                    root: document.body,
                                    height: 800,
                                    width: 1050
                                })
                            }
                        }),
                        s = e;
                    l.default = s
                }, 98);
                __d("safeEval", ["sdk.Runtime", "sdk.Scribe"], function(t, n, r, o, a, i, l) {
                    function e(e, t) {
                        if (!(e === null || typeof e == "undefined")) return typeof e != "string" ? e : /^\w+$/.test(e) && typeof window[e] == "function" ? window[e].apply(null, t || []) : (o("sdk.Scribe").log("jssdk_error", {
                            appId: r("sdk.Runtime").getClientID(),
                            error: "USE_OF_EVAL_FUNCTION",
                            extra: {
                                message: "Developer used an eval function"
                            }
                        }), Function('return eval("' + e.replace(/\"/g, '\\"') + '");').apply(null, t || []))
                    }
                    i.exports = e
                }, 34);
                __d("DOMPlugin", ["JSSDKShadowCssConfig", "Log", "QueryString", "sdk.DOM", "sdk.Observable", "sdk.PluginUtils", "sdk.Runtime", "sdk.XD", "sdk.feature"], function(t, n, r, o, a, i, l) {
                    function e(e) {
                        var t = e;
                        return typeof t.attachShadow == "function"
                    }
                    var s = (function(e) {
                        function t(t, n, a, i, l, s) {
                            var u;
                            return u = e.call(this) || this, u.shadowCss = [], u.element = t, u.tag = a.replace(/-/g, "_"), u.ns = n, u.config = s != null ? s : {}, u.params = {}, o("sdk.PluginUtils").validate(l, t, i, u.params), o("sdk.PluginUtils").validate(o("sdk.PluginUtils").baseParams, t, i, u.params), ES("Object", "assign", !1, u.params, {
                                app_id: r("sdk.Runtime").getClientID(),
                                locale: r("sdk.Runtime").getLocale(),
                                sdk: "joey",
                                kid_directed_site: r("sdk.Runtime").getKidDirectedSite(),
                                channel: o("sdk.XD").handler(function(e) {
                                    e != null && u.inform("xd." + e.type, e)
                                }, "parent.parent", !0)
                            }), u
                        }
                        babelHelpers.inheritsLoose(t, e);
                        var n = t.prototype;
                        return n.render = function(t) {}, n.process = function() {
                            var e = babelHelpers.extends({}, this.params);
                            delete e.channel;
                            var t = r("QueryString").encode(e);
                            if (this.element.getAttribute("fb-iframe-plugin-query") === t) {
                                o("Log").info("Skipping render: %s:%s %s", this.ns, this.tag, t), this.inform("render");
                                return
                            }
                            this.element.setAttribute("fb-iframe-plugin-query", t), u(this.element, ES(this.render, "bind", !0, this), this.shadowCss), this.inform("render")
                        }, t
                    })(o("sdk.Observable").Observable);

                    function u(t, n, a) {
                        for (a === void 0 && (a = []); t.firstChild;) t.removeChild(t.firstChild);
                        if (e(t)) {
                            var i = document.createElement("div");
                            t.appendChild(i);
                            var l = r("sdk.feature")("shadow_dom_plugin_mode", "closed");
                            typeof jest != "undefined" && (l = "open");
                            var s = i.attachShadow({
                                mode: l
                            });
                            a.forEach(function(e) {
                                return o("sdk.DOM").addCssRules(r("JSSDKShadowCssConfig")[e], [e], s)
                            }), s.appendChild(n(s))
                        } else a.forEach(function(e) {
                            return o("sdk.DOM").addCssRules(r("JSSDKShadowCssConfig")[e], [e])
                        }), t.appendChild(n(document))
                    }
                    l.DOMPlugin = s, l.maybeCreateShadowRootAndRenderInDOM = u
                }, 98);
                __d("sdk.SVGLogos", ["guid"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = "M90,212v-75h-27v-31h27v-25q0,-40 40,-40q15,0 24,2v26h-14q-16,0 -16,16v21h30l-5,31h-27v75",
                        s = "a106 106,0,1,0,-32 0",
                        u = "a106 106,1,0,1,-32 0";

                    function c(e, t) {
                        return Object.getOwnPropertyNames(t).forEach(function(n) {
                            return e.setAttribute(n, t[n])
                        }), e
                    }

                    function d(e, t, n) {
                        var r = c(document.createElementNS("http://www.w3.org/2000/svg", t), n);
                        return e == null || e.appendChild(r), r
                    }
                    var m = function(t) {
                            var e = {
                                    viewBox: "0 0 100 100",
                                    preserveAspectRatio: "xMinYMin"
                                },
                                n = t ? babelHelpers.extends({}, t, {
                                    viewBox: "0 0 100 100",
                                    preserveAspectRatio: "xMinYMin"
                                }) : e,
                                r = d(null, "svg", n);
                            return d(r, "line", {
                                x1: "0",
                                y1: "100",
                                x2: "100",
                                y2: "0",
                                "stroke-width": "12"
                            }), d(r, "line", {
                                x1: "0",
                                y1: "0",
                                x2: "100",
                                y2: "100",
                                "stroke-width": "12"
                            }), r
                        },
                        p = function(n) {
                            var t = {
                                    viewBox: "0 0 213 213",
                                    preserveAspectRatio: "xMinYMin"
                                },
                                r = d(null, "svg", babelHelpers.extends({}, n != null ? n : {}, t));
                            return d(r, "path", {
                                d: e + s,
                                class: "f_logo_circle"
                            }), d(r, "path", {
                                d: e + u,
                                class: "f_logo_f"
                            }), r
                        },
                        _ = function(n) {
                            var t = {
                                    viewBox: "0 0 213 213",
                                    preserveAspectRatio: "xMinYMin"
                                },
                                r = d(null, "svg", babelHelpers.extends({}, n != null ? n : {}, t));
                            return d(r, "path", {
                                d: e + s,
                                class: "f_logo_circle",
                                fill: "white"
                            }), d(r, "path", {
                                d: e + u,
                                class: "f_logo_f",
                                fill: "white"
                            }), r
                        },
                        f = function(t) {
                            var e = {
                                    viewBox: "-2 -2 104 104",
                                    preserveAspectRatio: "xMinYMin"
                                },
                                n = d(null, "svg", babelHelpers.extends({}, t != null ? t : {}, e));
                            return d(n, "rect", {
                                x: "5",
                                y: "5",
                                width: "91",
                                height: "91",
                                "stroke-width": "9",
                                rx: "23",
                                class: "ig_logo_body"
                            }), d(n, "circle", {
                                cx: "77",
                                cy: "23",
                                r: "6",
                                class: "ig_logo_flash"
                            }), d(n, "circle", {
                                cx: "50",
                                cy: "50",
                                r: "21",
                                "stroke-width": "9",
                                class: "ig_logo_lens"
                            }), n
                        },
                        g = function(t) {
                            var e = r("guid")(),
                                n = {
                                    viewBox: "-2 -2 104 104",
                                    preserveAspectRatio: "xMinYMin"
                                },
                                o = d(null, "svg", babelHelpers.extends({}, t != null ? t : {}, n)),
                                a = d(o, "defs", {}),
                                i = d(a, "mask", {
                                    id: e
                                });
                            d(i, "circle", {
                                cx: "77",
                                cy: "23",
                                r: "6",
                                fill: "white"
                            }), d(i, "circle", {
                                cx: "50",
                                cy: "50",
                                r: "21",
                                "stroke-width": "9",
                                stroke: "white"
                            }), d(i, "rect", {
                                x: "5",
                                y: "5",
                                width: "91",
                                height: "91",
                                "stroke-width": "9",
                                rx: "23",
                                stroke: "white",
                                fill: "none"
                            });
                            var l = d(a, "linearGradient", {
                                id: "purplepink",
                                x1: "0",
                                x2: ".15",
                                y1: "0",
                                y2: ".6"
                            });
                            d(l, "stop", {
                                offset: "12%",
                                "stop-color": "rgb(88,85,214)"
                            }), d(l, "stop", {
                                offset: "85%",
                                "stop-color": "rgb(215,27,122)"
                            });
                            var s = d(a, "radialGradient", {
                                id: "yelloworange",
                                cx: ".35",
                                cy: "1",
                                r: "2"
                            });
                            return d(s, "stop", {
                                offset: "7%",
                                "stop-color": "rgb(252,215,114)"
                            }), d(s, "stop", {
                                offset: "20%",
                                "stop-color": "rgb(244,102,37)"
                            }), d(s, "stop", {
                                offset: "38%",
                                "stop-color": "rgb(225,37,122)",
                                "stop-opacity": "0"
                            }), d(o, "rect", {
                                x: "1",
                                y: "1",
                                width: "99",
                                height: "99",
                                "stroke-width": "0",
                                rx: "23",
                                fill: "url(#purplepink)",
                                style: "mask: url(#" + e + ")"
                            }), d(o, "rect", {
                                x: "1",
                                y: "1",
                                width: "99",
                                height: "99",
                                "stroke-width": "0",
                                rx: "23",
                                fill: "url(#yelloworange)",
                                style: "mask: url(#" + e + ")"
                            }), o
                        };
                    l.close = m, l.facebook = p, l.facebookWhite = _, l.instagram = f, l.instagramColor = g
                }, 98);
                __d("sdk.SharedStringConstants", ["sdk.fbt"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e, s = {
                        continueWith: (e = r("sdk.fbt"))._( /*BTDS*/ "Continue with {facebook_app_name} or {instagram_app_name}"),
                        continueWithShort: e._( /*BTDS*/ "{facebook_app_name} or {instagram_app_name}"),
                        loginButtonAriaLabel: e._( /*BTDS*/ "Continue with Facebook or Instagram"),
                        logout: e._( /*BTDS*/ "Logout"),
                        logoutButtonAriaLabel: e._( /*BTDS*/ "Logout the current website"),
                        titleText: e._( /*BTDS*/ "Choose Account"),
                        promptText: e._( /*BTDS*/ "Which account would you like to use to log in?"),
                        facebookText: e._( /*BTDS*/ "Log in with Facebook"),
                        facebookTextShort: e._( /*BTDS*/ "Log in"),
                        instagramText: e._( /*BTDS*/ "Log in with Instagram"),
                        disambiguationDialogAriaLabelText: e._( /*BTDS*/ "Log in with Facebook or Instagram"),
                        fbButtonText: e._( /*BTDS*/ "Continue with Facebook"),
                        igButtonText: e._( /*BTDS*/ "Continue with Instagram")
                    };
                    l.buttonStringsFBT = s
                }, 226);
                __d("sdk.XFBML.ShadowDOMLoginButton", ["DOMPlugin", "UrlMap", "sdk.Auth", "sdk.Event", "sdk.LoggingUtils", "sdk.PluginUtils", "sdk.Runtime", "sdk.SVGLogos", "sdk.SharedStringConstants", "sdk.createIframe", "sdk.ui"], function(t, n, r, o, a, i, l) {
                    var e = {
                            small: "11px",
                            medium: "13px",
                            large: "16px"
                        },
                        s = {
                            small: "20px",
                            medium: "30px",
                            large: "40px"
                        },
                        u = "{facebook_app_name}",
                        c = (function(t) {
                            function n(e, n, a, i, l) {
                                var s;
                                return s = t.call(this, e, n, a, i, l) || this, s.stateObservers = [], s.shadowCss = ["css:fb.shadow.css.fb_login_button"], s.container = document.createElement("div"), s.container.classList.add("fb_login_button_container"), s.container.dir = "auto", s.loginButtonText = s.updateLabel(), s.fbLoginButton = document.createElement("button"), s.borderRadius = s.updateRadius(s.params), s.fbLoginButton = s.createSingleButton(s.loginButtonText), s.createFBButton("fb-button-main-element", o("sdk.SharedStringConstants").buttonStringsFBT.logout, o("sdk.SharedStringConstants").buttonStringsFBT.logoutButtonAriaLabel, C, function(e) {
                                    this.style.display = e.status === "connected" ? "flex" : "none"
                                }, ES(function(e) {
                                    r("sdk.Auth").logout(), e && e.detail === 0 && this.fbLoginButton && this.fbLoginButton.style.display !== "none" && this.fbLoginButton.focus()
                                }, "bind", !0, s)), s
                            }
                            babelHelpers.inheritsLoose(n, t);
                            var a = n.prototype;
                            return a.render = function(t) {
                                var e = this;
                                return this.updateDisplay({
                                    shouldHideDisambiguation: !0,
                                    status: r("sdk.Runtime").getLoginStatus()
                                }), o("sdk.Event").subscribe("auth.statusChange", function(t) {
                                    var n = {
                                        shouldHideDisambiguation: !0,
                                        status: t.status,
                                        fxApp: t.loginSource
                                    };
                                    e.updateDisplay(n)
                                }), this.container
                            }, a.createSingleButton = function(t) {
                                return this.createFBButton("fb-button-main-element", t, t, y, function(e) {
                                    this.style.display = e.status === "connected" ? "none" : "flex"
                                }, ES(function(e) {
                                    e.stopPropagation(), o("sdk.LoggingUtils").logLoginEvent(this.params, o("sdk.LoggingUtils").logEventName.buttonClick + "_single_fb"), this.loginTrigger()
                                }, "bind", !0, this))
                            }, a.loginTrigger = function() {
                                var e = "";
                                r("sdk.ui")({
                                    method: "permissions.oauth",
                                    display: "popup",
                                    scope: e
                                }, this.loginCb())
                            }, a.createFBButton = function(t, n, r, o, a, i) {
                                var e = document.createElement("button");
                                e.classList.add(t), e.setAttribute("aria-label", r);
                                var l = document.createElement("span");
                                return l.classList.add("fb_button_label_element"), l.classList.add("fb_button_label"), this.applyStyles(e, this.params), this.use_continue_as === !0 ? l.append(this.createIframeOverlay(this.container, this.params)) : o(this.params, n, l), e.appendChild(l), e.addEventListener("click", function(t) {
                                    i(t), e.blur()
                                }), e.updateDisplay = ES(a, "bind", !0, e), this.stateObservers.push(e), this.container.appendChild(e), e
                            }, a.loginCb = function() {
                                var e = this;
                                return function(t) {
                                    t.authResponse != null && t.status === "connected" ? o("sdk.LoggingUtils").logLoginEvent(e.params, o("sdk.LoggingUtils").logEventName.loginSuccess + "_single_fb") : o("sdk.LoggingUtils").logLoginEvent(e.params, o("sdk.LoggingUtils").logEventName.loginCancel + "_single_fb")
                                }
                            }, a.updateDisplay = function(t) {
                                this.stateObservers.forEach(function(e) {
                                    return e.updateDisplay(t)
                                })
                            }, a.updateLabel = function() {
                                var e = this.params["button-type"] === "login_with" ? o("sdk.SharedStringConstants").buttonStringsFBT.facebookText : o("sdk.SharedStringConstants").buttonStringsFBT.fbButtonText,
                                    t = f(this.params, e);
                                return this.params["button-type"] === "login_with" && (e = t ? e : o("sdk.SharedStringConstants").buttonStringsFBT.facebookTextShort), e
                            }, a.updateRadius = function(t) {
                                var e, n = (e = o("sdk.PluginUtils").getVal(t, "layout")) != null ? e : "default",
                                    r = String(o("sdk.PluginUtils").getVal(t, "size")),
                                    a = r !== "" ? r : "small",
                                    i = a === "large" ? "4px" : "3px";
                                return n === "rounded" ? "20px" : i
                            }, a.applyStyles = function(n, r) {
                                var t, a = String(o("sdk.PluginUtils").getVal(r, "size")),
                                    i = a !== "" ? a : "small";
                                n.style.borderRadius = this.borderRadius;
                                var l = (t = o("sdk.PluginUtils").getVal(r, "width")) != null ? t : null;
                                n.style.width = d(i, l).toString(), (i === "small" || i === "medium" || i === "large") && (n.style.fontSize = e[i], n.style.height = s[i]), n.style.backgroundColor = "rgb(26,119,242)", n.style.color = "#fff", n.style.border = "0", n.style.fontWeight = "bold"
                            }, a.createIframeOverlay = function(t, n) {
                                var e, a, i = String(o("sdk.PluginUtils").getVal(n, "size")),
                                    l = i !== "" ? i : "small",
                                    s = r("sdk.Runtime").getClientID(),
                                    u = String(o("sdk.PluginUtils").getVal(n, "layout")),
                                    c = u !== "" ? u : "default",
                                    m = (e = o("sdk.PluginUtils").getVal(n, "width")) != null ? e : null,
                                    p = d(l, m).toString(),
                                    _ = o("UrlMap").resolve("www") + ("/plugins/login_button_overlay/" + s + "/" + p + "/" + l + "/" + c + "/"),
                                    f = {
                                        root: t,
                                        url: _,
                                        borderRadius: (a = o("sdk.PluginUtils").getVal(n, "layout")) != null ? a : "default",
                                        width: p
                                    },
                                    g = r("sdk.createIframe")(f);
                                return g.classList.add("fb-iframe-overlay"), g
                            }, n
                        })(o("DOMPlugin").DOMPlugin);

                    function d(e, t) {
                        var n = e != null ? e : "small";
                        return t === "" || t == null ? p(n) : m(n, t)
                    }

                    function m(e, t) {
                        var n = isNaN(t) ? 0 : Number(t),
                            r = p(e),
                            o = _(e);
                        return n < p(e) ? r : n > _(e) ? o : n
                    }

                    function p(e) {
                        switch (e) {
                            case "large":
                                return 240;
                            case "medium":
                                return 200;
                            default:
                                return 200
                        }
                    }

                    function _(e) {
                        switch (e) {
                            case "large":
                                return 400;
                            case "medium":
                                return 320;
                            default:
                                return 300
                        }
                    }

                    function f(e, t) {
                        var n, r, a = t.replace(/\s?{facebook_app_name}\s?/, ""),
                            i = (n = o("sdk.PluginUtils").getVal(e, "width")) != null ? n : null,
                            l = (r = o("sdk.PluginUtils").getVal(e, "size")) != null ? r : "large",
                            s = d(l, i),
                            u = h(a) ? h(a) : 0;
                        return u < s
                    }
                    var g = null;

                    function h(e) {
                        var t, n = g != null ? g : g = document.createElement("canvas"),
                            r = n.getContext("2d"),
                            o = r == null ? void 0 : r.measureText(e);
                        return (t = o == null ? void 0 : o.width) != null ? t : 0
                    }

                    function y(e, t, n) {
                        var r = document.createElement("span"),
                            o = b();
                        o.classList.add("single_button_svg_logo"), n.append(o), r.textContent = f(e, t) ? t : "", n.append(r)
                    }

                    function C(e, t, n) {
                        n.textContent = "";
                        var r = t.search(u),
                            o = r + u.length,
                            a = Math.min(r),
                            i = Math.min(o),
                            l = Math.max(r),
                            s = Math.max(o),
                            c = b(),
                            d = document.createElement("span");
                        d.style.whiteSpace = "nowrap", d.append(t.substring(0, a));
                        var m = document.createElement("span");
                        m.style.whiteSpace = "nowrap", m.append(t.substring(i, l));
                        var p = document.createElement("span");
                        p.style.whiteSpace = "nowrap", p.append(t.substring(s, t.length)), n.append(c), n.append(d), n.append(m), n.append(p)
                    }

                    function b() {
                        return o("sdk.SVGLogos").facebookWhite({
                            class: "fb_button_svg_logo login_fb_logo"
                        })
                    }
                    l.default = c
                }, 98);
                __d("sdk.XFBML.LoginButton", ["IframePlugin", "Log", "guid", "safeEval", "sdk.Auth", "sdk.Auth.LoginStatus", "sdk.Dialog", "sdk.ErrorHandling", "sdk.Impressions", "sdk.PluginUtils", "sdk.Runtime", "sdk.Scribe", "sdk.UIServer", "sdk.XD", "sdk.XFBML.ShadowDOMLoginButton", "sdk.feature", "sdk.getContextType", "sdk.modFeatureCheck", "sdk.ui"], function(t, n, r, o, a, i, l) {
                    var e = r("sdk.feature")("https_only_learn_more", "");

                    function s(e, t, n) {
                        e && (typeof e == "string" ? r("sdk.ErrorHandling").unguard(r("safeEval"))(e, n) : e.apply && r("sdk.ErrorHandling").unguard(e).apply(t, n || []))
                    }

                    function u(e, t, n) {
                        e.id = r("guid")(), e.plugin_prepare = !0, e.origin = r("sdk.getContextType")(), e.domain = location.hostname, e.fallback_redirect_uri = document.location.href;
                        var a = r("sdk.feature")("e2e_tracking", !0);
                        a && (e.e2e = {});
                        var i = function(a) {
                                l != null && o("sdk.XD").sendToFacebook(t, {
                                    method: "loginComplete",
                                    params: ES("JSON", "stringify", !1, {
                                        frame_name: l.id,
                                        status: r("sdk.Runtime").getLoginStatus()
                                    })
                                }), n(a)
                            },
                            l = r("sdk.UIServer").prepareCall(e, i);
                        l != null && (l.dims = {
                            screenX: window.screenX,
                            screenY: window.screenY,
                            outerWidth: window.outerWidth,
                            outerHeight: window.outerHeight,
                            screenWidth: window.screen.width
                        }), o("sdk.XD").sendToFacebook(t, {
                            method: "loginButtonStateInit",
                            params: ES("JSON", "stringify", !1, {
                                call: l
                            })
                        })
                    }
                    var c = r("IframePlugin").extend({
                            constructor: function(n, a, i, l) {
                                if ((o("sdk.modFeatureCheck").forIDs("allow_shadow_dom_for_apps_with_id", [r("sdk.Runtime").getClientID()]) || l["data-shadow-test"] != null && l["data-shadow-test"] === "true") && r("sdk.feature")("allow_shadow_dom", !1) === !0 && l["data-use-continue-as"] !== "true") return new(r("sdk.XFBML.ShadowDOMLoginButton"))(n, a, i, l, {
                                    width: "string",
                                    size: "string",
                                    "button-type": "string",
                                    layout: "string",
                                    "auto-logout-link": "bool",
                                    "use-continue-as": "bool"
                                });
                                if (location.protocol !== "https:") {
                                    var t = "The Login Button plugin no longer works on http pages. Please update your site to use https for Facebook Login. %s";
                                    o("Log").log("error", -1, t, e), r("sdk.feature")("https_only_scribe_logging", !0) && o("sdk.Scribe").log("jssdk_error", {
                                        appId: r("sdk.Runtime").getClientID(),
                                        error: "HttpsOnly",
                                        extra: {
                                            message: "LoginButton"
                                        }
                                    })
                                }
                                this.parent(n, a, i, l);
                                var c = o("sdk.PluginUtils").getVal(l, "on_login"),
                                    d = null,
                                    m = this._iframeOptions.name;
                                c && (d = function(t) {
                                    if (t.error_code) {
                                        o("Log").debug("Plugin Return Error (%s): %s", t.error_code, t.error_message || t.error_description);
                                        return
                                    }
                                    s(c, null, [t])
                                }, this.subscribe("login.status", d));
                                var p = function(t) {
                                    s(d, null, [t]), o("sdk.XD").sendToFacebook(m, {
                                        method: "loginReload",
                                        params: ES("JSON", "stringify", !1, t)
                                    })
                                };
                                this.subscribe("xd.login_button_dialog_open", function(e) {
                                    r("sdk.ui")(ES("JSON", "parse", !1, e.params), function(e) {
                                        o("sdk.XD").sendToFacebook(m, {
                                            method: "loginComplete",
                                            params: "{}"
                                        }), p(e)
                                    })
                                }), this.subscribe("xd.login_button_prepare_call", function(e) {
                                    var t = ES("JSON", "parse", !1, e.params),
                                        n = e.params;
                                    u(t, m, p), r("sdk.Auth").subscribe("status.change", function(e) {
                                        var t = ES("JSON", "parse", !1, n);
                                        t.logger_id = r("guid")(), e != null && e.status != null && e.status !== "connected" && u(t, m, p)
                                    })
                                }), this.subscribe("xd.login_button_click", function(e) {
                                    var t = ES("JSON", "parse", !1, e.params);
                                    if (t.popup) {
                                        if (r("sdk.feature")("e2e_tracking", !0)) {
                                            var n = r("sdk.Dialog").get(t.call.id);
                                            n.subscribe("e2e:end", function(e) {
                                                e.method = t.call.params.method, e.display = t.call.params.display, o("Log").debug("e2e: %s", ES("JSON", "stringify", !1, e)), o("sdk.Impressions").log(114, {
                                                    payload: e
                                                })
                                            })
                                        }
                                    } else r("sdk.feature")("popup_blocker_scribe_logging", !0) && o("sdk.Scribe").log("jssdk_error", {
                                        appId: r("sdk.Runtime").getClientID(),
                                        error: "POPUP_MAYBE_BLOCKED_NEW",
                                        extra: {
                                            call: t.call.name
                                        }
                                    })
                                });
                                var _ = function() {
                                    s(d, null, [{
                                        status: r("sdk.Runtime").getLoginStatus(),
                                        authResponse: r("sdk.Auth").getAuthResponse()
                                    }])
                                };
                                this.subscribe("xd.login_button_connected", _), this.subscribe("xd.login_button_popup_closed", function() {
                                    r("sdk.Auth.LoginStatus").getLoginStatus(_, !0)
                                })
                            },
                            shouldIgnoreWidth: function() {
                                return !1
                            },
                            getParams: function() {
                                return {
                                    scope: "string",
                                    asset_scope: "string",
                                    perms: "string",
                                    size: "string",
                                    login_text: "text",
                                    show_faces: "bool",
                                    max_rows: "string",
                                    show_login_face: "bool",
                                    show_login_numbers: "bool",
                                    registration_url: "url_maybe",
                                    auto_logout_link: "bool",
                                    one_click: "bool",
                                    show_banner: "bool",
                                    auth_type: "string",
                                    default_audience: "string",
                                    use_continue_as: "bool",
                                    layout: "string",
                                    button_type: "string",
                                    width: "px",
                                    height: "px",
                                    force_confirmation: "bool",
                                    messenger_page_id: "string",
                                    reset_messenger_state: "bool",
                                    config_id: "string"
                                }
                            }
                        }),
                        d = c;
                    l.default = d
                }, 98);
                __d("IframePluginClass", ["Log", "QueryString", "UrlMap", "guid", "sdk.Auth.LoginStatus", "sdk.AuthUtils", "sdk.DOM", "sdk.Event", "sdk.Observable", "sdk.PlatformVersioning", "sdk.PluginUtils", "sdk.Runtime", "sdk.UA", "sdk.URI", "sdk.XD", "sdk.createIframe"], function(t, n, r, o, a, i, l) {
                    var e = window.setTimeout,
                        s = window.clearTimeout,
                        u = (function(t) {
                            function n(e, n, a, i, l, u, c) {
                                var d;
                                l === void 0 && (l = null), u === void 0 && (u = void 0), c === void 0 && (c = !1), d = t.call(this) || this, d.postBodyParams = u, d.deferPostRequest = c, a = a.replace(/-/g, "_"), d.$IframePluginClass$p_2 = !1, d.config = l != null ? l : {
                                    fluid: !1,
                                    mobile_fullsize: !1,
                                    full_width: !1
                                };
                                var m = o("sdk.PluginUtils").getVal(i, "plugin_id"),
                                    p = o("sdk.PluginUtils").getVal(i, "iframe_name");
                                d.subscribe("xd.resize", o("sdk.PluginUtils").resizeBubbler(m)), d.subscribe("xd.resize.flow", o("sdk.PluginUtils").resizeBubbler(m)), d.subscribe("xd.resize.flow", function(e) {
                                    ES("Object", "assign", !1, d.iframeOptions.root.style, {
                                        verticalAlign: "bottom",
                                        overflow: ""
                                    }), o("sdk.PluginUtils").resize(d.iframeOptions.root, o("sdk.PluginUtils").parse(e.width), o("sdk.PluginUtils").parse(e.height)), d.updateLift(), s(d.$IframePluginClass$p_1)
                                }), d.subscribe("xd.resize", function(e) {
                                    var t;
                                    ES("Object", "assign", !1, d.iframeOptions.root.style, {
                                        verticalAlign: "bottom",
                                        overflow: ""
                                    }), (t = o("sdk.PluginUtils")).resize(d.iframeOptions.root, t.parse(e.width), t.parse(e.height)), t.resize(d.iframe, t.parse(e.width), t.parse(e.height)), d.$IframePluginClass$p_2 = !0, d.updateLift(), s(d.$IframePluginClass$p_1)
                                }), d.subscribe("xd.resize.iframe", function(e) {
                                    o("sdk.PluginUtils").resize(d.iframe, o("sdk.PluginUtils").parse(e.width), o("sdk.PluginUtils").parse(e.height)), d.$IframePluginClass$p_2 = !0, d.updateLift(), s(d.$IframePluginClass$p_1)
                                }), d.subscribe("xd.sdk_event", function(t) {
                                    var n = ES("JSON", "parse", !1, t.data);
                                    n.pluginID = m, o("sdk.Event").fire(t.event, n, e)
                                });
                                var _ = i.should_use_new_domain ? o("UrlMap").resolve("social_plugin") + "/" + a + ".php?" : o("UrlMap").resolve("www") + "/plugins/" + a + ".php?",
                                    f = {};
                                o("sdk.PluginUtils").validate(d.getParams(), e, i, f), o("sdk.PluginUtils").validate(o("sdk.PluginUtils").baseParams, e, i, f), ES("Object", "assign", !1, f, {
                                    app_id: r("sdk.Runtime").getClientID(),
                                    locale: r("sdk.Runtime").getLocale(),
                                    sdk: "joey",
                                    kid_directed_site: r("sdk.Runtime").getKidDirectedSite(),
                                    channel: o("sdk.XD").handler(function(e) {
                                        e != null && d.inform("xd." + e.type, e)
                                    }, "parent.parent", !0)
                                }), d.shouldIgnoreWidth() && (f.width = void 0), f.container_width = e.offsetWidth, o("sdk.DOM").addCss(e, "fb_iframe_widget");
                                var g = p != null ? String(p) : r("guid")();
                                d.subscribe("xd.verify", function(e) {
                                    o("sdk.XD").sendToFacebook(g, {
                                        method: "xd/verify",
                                        params: ES("JSON", "stringify", !1, e.token)
                                    })
                                }), d.subscribe("xd.refreshLoginStatus", function() {
                                    o("sdk.AuthUtils").removeLogoutState(), r("sdk.Auth.LoginStatus").getLoginStatus(ES(d.inform, "bind", !0, d, "login.status"), !0)
                                });
                                var h = document.createElement("span");
                                return ES("Object", "assign", !1, h.style, {
                                    verticalAlign: "top",
                                    width: f.lazy ? "1px" : "0px",
                                    height: f.lazy ? "1px" : "0px",
                                    overflow: "hidden"
                                }), d.element = e, d.ns = n, d.tag = a, d.params = f, d.iframeOptions = {
                                    root: h,
                                    url: _ + r("QueryString").encode(f),
                                    name: g,
                                    width: d.config.mobile_fullsize && r("sdk.UA").mobile() ? void 0 : f.width || 1e3,
                                    height: f.height || 1e3,
                                    style: {
                                        border: "none",
                                        visibility: "hidden"
                                    },
                                    title: d.ns + ":" + d.tag + " Facebook Social Plugin",
                                    testid: d.ns + ":" + d.tag + " Facebook Social Plugin",
                                    onload: function() {
                                        return d.inform("render")
                                    },
                                    onerror: function() {
                                        return o("sdk.PluginUtils").collapseIframe(d.iframe)
                                    },
                                    lazy: f.lazy,
                                    allow: o("sdk.PluginUtils").getVal(i, "allow")
                                }, d.config.fluid && f.width !== "auto" && (o("sdk.DOM").addCss(d.element, "fbiframe_widget_fluid_desktop"), !f.width && d.config.full_width && (d.element.style.width = "100%", d.iframeOptions.root.style.width = "100%", d.iframeOptions.style.width = "100%", d.params.container_width = d.element.offsetWidth, d.iframeOptions.url = _ + r("QueryString").encode(d.params))), d
                            }
                            babelHelpers.inheritsLoose(n, t);
                            var a = n.prototype;
                            return a.shouldIgnoreWidth = function() {
                                return r("sdk.UA").mobile() && this.config.mobile_fullsize
                            }, a.useInlineHeightForMobile = function() {
                                return !0
                            }, a.process = function() {
                                var t = this;
                                if (r("sdk.Runtime").getIsVersioned()) {
                                    o("sdk.PlatformVersioning").assertVersionIsSet();
                                    var n = new(r("sdk.URI"))(this.iframeOptions.url);
                                    this.iframeOptions.url = n.setPath("/" + r("sdk.Runtime").getVersion() + n.getPath()).toString()
                                }
                                var a = babelHelpers.extends({}, this.params);
                                delete a.channel;
                                var i = r("QueryString").encode(a);
                                if (this.element.getAttribute("fb-iframe-plugin-query") == i) {
                                    o("Log").info("Skipping render: %s:%s %s", this.ns, this.tag, i), this.inform("render");
                                    return
                                }
                                for (this.element.setAttribute("fb-iframe-plugin-query", i), this.subscribe("render", function() {
                                        o("sdk.Event").fire("iframeplugin:onload"), o("sdk.Event").fire("iframeplugin:onload:" + t.iframeOptions.name), t.iframe.style.visibility = "visible", t.$IframePluginClass$p_2 || o("sdk.PluginUtils").collapseIframe(t.iframe)
                                    }); this.element.firstChild;) this.element.removeChild(this.element.firstChild);
                                this.element.appendChild(this.iframeOptions.root);
                                var l = r("sdk.UA").mobile() ? 120 : 45;
                                if (this.$IframePluginClass$p_1 = e(function() {
                                        o("sdk.PluginUtils").collapseIframe(t.iframe), o("Log").warn("%s:%s failed to resize in %ss", t.ns, t.tag, l)
                                    }, l * 1e3), this.iframe = r("sdk.createIframe")(this.iframeOptions, this.postBodyParams, this.deferPostRequest), o("sdk.Event").fire("iframeplugin:create"), (r("sdk.UA").mobile() || a.width === "auto") && (this.useInlineHeightForMobile() && o("sdk.DOM").addCss(this.element, "fbiframe_widget_fluid"), !this.iframeOptions.width)) {
                                    ES("Object", "assign", !1, this.element.style, {
                                        display: "block",
                                        width: "100%",
                                        height: "auto"
                                    }), ES("Object", "assign", !1, this.iframeOptions.root.style, {
                                        width: "100%",
                                        height: "auto"
                                    });
                                    var s = {
                                        height: "auto",
                                        position: "static",
                                        width: "100%"
                                    };
                                    (r("sdk.UA").iphone() || r("sdk.UA").ipad()) && ES("Object", "assign", !1, s, {
                                        width: "220px",
                                        minWidth: "100%"
                                    }), ES("Object", "assign", !1, this.iframe.style, s)
                                }
                            }, a.getParams = function() {
                                return this.params
                            }, a.updateLift = function() {
                                var e = this.iframe.style.width === this.iframeOptions.root.style.width && this.iframe.style.height === this.iframeOptions.root.style.height;
                                (e ? o("sdk.DOM").removeCss : o("sdk.DOM").addCss)(this.iframe, "fbiframe_widget_lift")
                            }, n
                        })(o("sdk.Observable").Observable);
                    l.default = u
                }, 98);
                __d("sdk.XFBML.MessengerCheckbox", ["FB", "IframePluginClass", "Log", "PluginAttrTypes", "sdk.XD"], function(t, n, r, o, a, i, l) {
                    "use strict";

                    function e(e) {
                        var t = e.app_id,
                            n = e.page_id,
                            r = e.user_ref,
                            o = '[page_id="' + n + '"][messenger_app_id="' + t + '"][user_ref="' + r + '"] iframe',
                            a = document.querySelector(o);
                        return (a == null ? void 0 : a.getAttribute("name")) || null
                    }
                    r("FB").provide("CheckboxPlugin", {
                        confirm: function(n) {
                            var t = n.app_id,
                                r = n.page_id,
                                a = n.user_ref,
                                i = e(n);
                            if (t == null) {
                                o("Log").warn("app_id is a required parameter.");
                                return
                            }
                            if (r == null) {
                                o("Log").warn("page_id is a required parameter.");
                                return
                            }
                            if (a == null) {
                                o("Log").warn("user_ref is a required parameter.");
                                return
                            }
                            if (i == null) {
                                o("Log").warn("No matching checkbox for the app_id, page_id, and user_ref given.");
                                return
                            }
                            o("sdk.XD").sendToFacebook(i, {
                                method: "confirmCheckboxSubmission",
                                params: n
                            })
                        }
                    });
                    var s = (function(e) {
                        function t(t, n, r, o) {
                            return e.call(this, t, n, r, o, {
                                fluid: !0,
                                full_width: !0,
                                mobile_fullsize: !1
                            }) || this
                        }
                        babelHelpers.inheritsLoose(t, e);
                        var n = t.prototype;
                        return n.getParams = function() {
                            var e;
                            return {
                                messenger_app_id: (e = o("PluginAttrTypes")).string,
                                page_id: e.string,
                                pixel_id: e.string,
                                prechecked: e.bool,
                                allow_login: e.bool,
                                size: e.string,
                                origin: e.string,
                                user_ref: e.string,
                                identity_match: e.string,
                                center_align: e.bool,
                                opt_in_type: e.string,
                                promotional_frequency: e.string,
                                promotional_topic: e.string
                            }
                        }, t
                    })(r("IframePluginClass"));
                    l.default = s
                }, 98);
                __d("sdk.XFBML.MessengerCheckboxWrapper", ["sdk.Observable", "sdk.XFBML.MessengerCheckbox"], function(t, n, r, o, a, i, l) {
                    var e = function(t, n, r, o) {
                            return new s(t, n, r, o)
                        },
                        s = (function(e) {
                            function t(t, n, r, o) {
                                var a;
                                return a = e.call(this) || this, a.$MessengerCheckboxWrapper$p_2 = t, a.$MessengerCheckboxWrapper$p_3 = n, a.$MessengerCheckboxWrapper$p_4 = r, a.$MessengerCheckboxWrapper$p_5 = o, a
                            }
                            babelHelpers.inheritsLoose(t, e);
                            var n = t.prototype;
                            return n.process = function() {
                                var e = this;
                                this.$MessengerCheckboxWrapper$p_5.should_use_new_domain = !0, this.$MessengerCheckboxWrapper$p_1 = new(r("sdk.XFBML.MessengerCheckbox"))(this.$MessengerCheckboxWrapper$p_2, this.$MessengerCheckboxWrapper$p_3, this.$MessengerCheckboxWrapper$p_4, this.$MessengerCheckboxWrapper$p_5), this.$MessengerCheckboxWrapper$p_1.subscribe("render", function() {
                                    e.inform("render")
                                }), this.$MessengerCheckboxWrapper$p_1.process()
                            }, t
                        })(o("sdk.Observable").Observable),
                        u = e;
                    l.default = u
                }, 98);
                __d("sdk.XFBML.Save", ["IframePlugin", "UrlMap", "sdk.Content", "sdk.DOM", "sdk.DialogUtils", "sdk.Event", "sdk.Runtime", "sdk.UA", "sdk.XD", "sdk.createIframe"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e, s = r("IframePlugin").extend({
                            constructor: function(n, a, i, l) {
                                var t = this;
                                this.parent(n, a, i, l);
                                var s = r("sdk.UA").mobile();
                                this.subscribe("xd.savePluginGetBlankIframe", function(n) {
                                    var r, a = function(t) {
                                            t && o("sdk.DOM").removeCss(t, "fb_invisible")
                                        },
                                        i = function(t) {
                                            t && o("sdk.DOM").addCss(t, "fb_invisible")
                                        };
                                    s && (r = o("sdk.DialogUtils").setupNewDarkOverlay(), i(r), o("sdk.Content").append(r), o("sdk.DialogUtils").addDoubleClickAction(r, function() {
                                        return u.forEach(i)
                                    }, 5e3));
                                    var l = t.setupNewIframeDialog(ES("JSON", "parse", !1, n.data), n.fromIframe);
                                    i(l), o("sdk.Content").append(l);
                                    var u = [l, r],
                                        c = function() {
                                            u.forEach(i), o("sdk.DialogUtils").onDialogHideCleanup(s), window.clearInterval(e)
                                        },
                                        d;
                                    t.subscribe("xd.savePluginShowIframe", function() {
                                        o("sdk.Event").fire("savePlugin:hideDialog"), u.forEach(a), t.positionOnScreen(l, r), !s && !d && (d = o("sdk.DialogUtils").addIdleDesktopAction(l, c, 7e3))
                                    }), t.subscribe("xd.savePluginHideIframe", function() {
                                        return c()
                                    }), o("sdk.Event").subscribe("savePlugin:hideDialog", function() {
                                        return c()
                                    });
                                    var m = window.setInterval(function() {
                                        var e = document.getElementsByName(n.fromIframe);
                                        e.length === 0 && (window.clearInterval(m), c(), u.forEach(function(e) {
                                            var t;
                                            e == null || (t = e.parentNode) == null || t.removeChild(e)
                                        }))
                                    }, 500)
                                })
                            },
                            positionOnScreen: function(n, a) {
                                var t = r("sdk.UA").mobile();
                                if (t) {
                                    var i = function(n, r) {
                                        r != null && o("sdk.DialogUtils").setDialogPositionToCenter(r, t), o("sdk.DialogUtils").setDialogPositionToCenter(n, t)
                                    };
                                    i(n, a), o("sdk.DialogUtils").addMobileOrientationChangeAction(function(e) {
                                        i(n, a)
                                    }), e = window.setInterval(function() {
                                        return i(n, a)
                                    }, 100)
                                } else o("sdk.DOM").setStyle(n, "position", "fixed"), o("sdk.DOM").setStyle(n, "top", "20px"), o("sdk.DOM").setStyle(n, "right", "20px")
                            },
                            getOverlayIFrameURL: function() {
                                return o("UrlMap").resolve("www") + (r("sdk.Runtime").getIsVersioned() ? "/" + r("sdk.Runtime").getVersion() : "") + "/plugins/save/overlay?app_id=" + r("sdk.Runtime").getClientID()
                            },
                            setupNewIframeDialog: function(t, n) {
                                var e = this,
                                    a = o("sdk.DialogUtils").setupNewDialog(),
                                    i = function() {
                                        o("sdk.XD").sendToFacebook(n, {
                                            method: "saveOverlayIFrameAck",
                                            params: ES("JSON", "stringify", !1, {
                                                name: "overlay_" + e._iframeOptions.name
                                            })
                                        })
                                    };
                                return r("sdk.createIframe")({
                                    url: this.getOverlayIFrameURL(),
                                    name: "overlay_" + this._iframeOptions.name,
                                    root: a.contentRoot,
                                    tabindex: -1,
                                    onload: ES(i, "bind", !0, this)
                                }), o("sdk.DOM").addCss(a.contentRoot, "fb_dialog_iframe"), ES("Object", "assign", !1, a.dialogElement.style, t.style || {}), o("sdk.DOM").setStyle(a.dialogElement, "width", t.width + "px"), o("sdk.DOM").setStyle(a.dialogElement, "height", t.height + "px"), t.classList.forEach(function(e) {
                                    return o("sdk.DOM").addCss(a.dialogElement, e)
                                }), o("sdk.DOM").removeCss(a.dialogElement, "fb_dialog_advanced"), a.dialogElement
                            },
                            getParams: function() {
                                return {
                                    uri: "url",
                                    url_category: "string",
                                    size: "string"
                                }
                            }
                        }),
                        u = s;
                    l.default = u
                }, 98);
                __d("sdk.XFBML.ShareButton", ["IframePlugin"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = r("IframePlugin").extend({
                            constructor: function(t, n, r, o) {
                                this.parent(t, n, r, o)
                            },
                            getParams: function() {
                                return {
                                    href: "url",
                                    layout: "string",
                                    mobile_iframe: "bool",
                                    type: "string",
                                    size: "string"
                                }
                            }
                        }),
                        s = e;
                    l.default = s
                }, 98);
                __d("sdk.XFBML.Video", ["Assert", "IframePlugin", "ObservableMixin", "sdk.Event", "sdk.XD"], function(t, n, r, o, a, i, l) {
                    var e = (function() {
                            function e(e) {
                                this.$1 = e.isMuted, this.$2 = e.volume, this.$3 = e.timePosition, this.$4 = e.duration
                            }
                            var t = e.prototype;
                            return t.update = function(t) {
                                t.isMuted !== void 0 && (this.$1 = t.isMuted), t.volume !== void 0 && (this.$2 = t.volume), t.timePosition !== void 0 && (this.$3 = t.timePosition), t.duration !== void 0 && (this.$4 = t.duration)
                            }, t.isMuted = function() {
                                return this.$1
                            }, t.getVolume = function() {
                                return this.$1 ? 0 : this.$2
                            }, t.getCurrentPosition = function() {
                                return this.$3
                            }, t.getDuration = function() {
                                return this.$4
                            }, e
                        })(),
                        s = (function() {
                            function e(e, t, n) {
                                this.$1 = e, this.$2 = t, this.$3 = n
                            }
                            var t = e.prototype;
                            return t.play = function() {
                                o("sdk.XD").sendToFacebook(this.$1, {
                                    method: "play",
                                    params: ES("JSON", "stringify", !1, {})
                                })
                            }, t.pause = function() {
                                o("sdk.XD").sendToFacebook(this.$1, {
                                    method: "pause",
                                    params: ES("JSON", "stringify", !1, {})
                                })
                            }, t.seek = function(t) {
                                r("Assert").isNumber(t, "Invalid argument"), o("sdk.XD").sendToFacebook(this.$1, {
                                    method: "seek",
                                    params: ES("JSON", "stringify", !1, {
                                        target: t
                                    })
                                })
                            }, t.mute = function() {
                                o("sdk.XD").sendToFacebook(this.$1, {
                                    method: "mute",
                                    params: ES("JSON", "stringify", !1, {})
                                })
                            }, t.unmute = function() {
                                o("sdk.XD").sendToFacebook(this.$1, {
                                    method: "unmute",
                                    params: ES("JSON", "stringify", !1, {})
                                })
                            }, t.setVolume = function(t) {
                                r("Assert").isNumber(t, "Invalid argument"), o("sdk.XD").sendToFacebook(this.$1, {
                                    method: "setVolume",
                                    params: ES("JSON", "stringify", !1, {
                                        volume: t
                                    })
                                })
                            }, t.isMuted = function() {
                                return this.$3.isMuted()
                            }, t.getVolume = function() {
                                return this.$3.getVolume()
                            }, t.getCurrentPosition = function() {
                                return this.$3.getCurrentPosition()
                            }, t.getDuration = function() {
                                return this.$3.getDuration()
                            }, t.subscribe = function(t, n) {
                                var e = this;
                                return r("Assert").isString(t, "Invalid argument"), r("Assert").isFunction(n, "Invalid argument"), this.$2.subscribe(t, n), {
                                    release: function() {
                                        e.$2.unsubscribe(t, n)
                                    }
                                }
                            }, e
                        })(),
                        u = r("IframePlugin").extend({
                            constructor: function(n, a, i, l) {
                                this.parent(n, a, i, l), this._videoController = null, this._sharedObservable = null, this._sharedVideoCache = null, this.subscribe("xd.onVideoAPIReady", function(t) {
                                    this._sharedObservable = new(r("ObservableMixin")), this._sharedVideoCache = new e(ES("JSON", "parse", !1, t.data)), this._videoController = new s(this._iframeOptions.name, this._sharedObservable, this._sharedVideoCache), o("sdk.Event").fire("xfbml.ready", {
                                        type: "video",
                                        id: l.id,
                                        instance: this._videoController
                                    })
                                }), this.subscribe("xd.stateChange", function(e) {
                                    this._sharedObservable.inform(e.state)
                                }), this.subscribe("xd.cachedStateUpdateRequest", function(e) {
                                    this._sharedVideoCache.update(ES("JSON", "parse", !1, e.data))
                                })
                            },
                            getParams: function() {
                                return {
                                    allowfullscreen: "bool",
                                    autoplay: "bool",
                                    controls: "bool",
                                    href: "url",
                                    show_captions: "bool",
                                    show_text: "bool"
                                }
                            },
                            getConfig: function() {
                                return {
                                    fluid: !0,
                                    full_width: !0
                                }
                            }
                        }),
                        c = u;
                    l.default = c
                }, 98);
                __d("sdk.CustomTags", ["sdk.XFBML.Comments", "sdk.XFBML.CommentsCount", "sdk.XFBML.LWIAdsCreation", "sdk.XFBML.LWIAdsInsights", "sdk.XFBML.LoginButton", "sdk.XFBML.MessengerCheckboxWrapper", "sdk.XFBML.Save", "sdk.XFBML.ShareButton", "sdk.XFBML.Video"], (function(t, n, r, o, a, i) {
                    "use strict";
                    var e = {
                            comments: n("sdk.XFBML.Comments"),
                            comments_count: n("sdk.XFBML.CommentsCount"),
                            login_button: n("sdk.XFBML.LoginButton"),
                            lwi_ads_creation: n("sdk.XFBML.LWIAdsCreation"),
                            lwi_ads_insights: n("sdk.XFBML.LWIAdsInsights"),
                            messenger_checkbox: n("sdk.XFBML.MessengerCheckboxWrapper"),
                            save: n("sdk.XFBML.Save"),
                            share_button: n("sdk.XFBML.ShareButton"),
                            video: n("sdk.XFBML.Video")
                        },
                        l = e;
                    i.default = l
                }), 66);
                __d("sdk.XFBML-public", ["AssertionError", "FB", "IframePlugin", "PluginConfig", "PluginTags", "XFBML", "sdk.CustomTags", "sdk.Event", "sdk.domReady", "sdk.feature", "wrapFunction"], function(t, n, r, o, a, i) {
                    function e() {
                        n("FB").provide("XFBML", {
                            parse: function(t) {
                                if (t != null && !((t.nodeType === 1 || t.nodeType === 9) && typeof t.nodeName == "string")) throw new(n("AssertionError"))("Invalid argument");
                                return t && t.nodeType === 9 && (t = t.body), n("XFBML").parse.apply(null, arguments)
                            }
                        }), n("XFBML").subscribe("parse", function(e) {
                            return n("sdk.Event").fire("xfbml.parse", e[0], e[1])
                        }), n("XFBML").subscribe("render", function(e) {
                            return n("sdk.Event").fire("xfbml.render", e[0], e[1])
                        }), n("sdk.Event").subscribe("init:post", function(e) {
                            e.xfbml && window.setTimeout(n("wrapFunction")(ES(n("sdk.domReady"), "bind", !0, null, n("XFBML").parse), "entry", "init:post:xfbml.parse"), 0)
                        });
                        try {
                            document.namespaces && !document.namespaces.item.fb && document.namespaces.add("fb")
                        } catch (e) {}
                    }

                    function l() {
                        var e = n("sdk.feature")("plugin_tags_blocklist", []);
                        Object.keys(n("PluginTags")).forEach(function(t) {
                            e.indexOf(t) === -1 && n("XFBML").registerTag({
                                xmlns: "fb",
                                localName: t.replace(/_/g, "-"),
                                ctor: n("IframePlugin").withParams(n("PluginTags")[t], n("PluginConfig")[t])
                            })
                        }), Object.keys(n("sdk.CustomTags")).forEach(function(t) {
                            e.indexOf(t) === -1 && n("XFBML").registerTag({
                                xmlns: "fb",
                                localName: t.replace(/_/g, "-"),
                                ctor: n("sdk.CustomTags")[t]
                            })
                        })
                    }
                    var s = {
                            init: e,
                            initXFBMLBasedSocialPlugin: l
                        },
                        u = s;
                    i.default = u
                }, 66);
                __d("sdk.api-public", ["ApiClient", "FB", "sdk.Runtime", "sdk.Scribe", "sdk.api", "sdk.feature"], function(t, n, r, o, a, i, l) {
                    var e = r("sdk.feature")("should_log_response_error", !1),
                        s;

                    function u() {
                        var t;
                        r("sdk.Runtime").subscribe("ClientID.change", function(e) {
                            return r("ApiClient").setClientID(e)
                        }), r("sdk.Runtime").subscribe("AccessToken.change", function(e) {
                            s = e, r("ApiClient").setAccessToken(e)
                        }), (t = r("ApiClient")).setDefaultParams({
                            sdk: "joey"
                        }), t.subscribe("request.complete", function(e, t, n, o) {
                            var a = !1;
                            o && typeof o == "object" && (o.error ? (o.error == "invalid_token" || o.error.type == "OAuthException" && o.error.code == 190) && (a = !0) : o.error_code && o.error_code == "190" && (a = !0)), a && s === r("sdk.Runtime").getAccessToken() && r("sdk.Runtime").setAccessToken(null)
                        }), t.subscribe("request.complete", function(e, t, n, o) {
                            (e == "/me/permissions" && t === "delete" || e == "/restserver.php" && n.method == "Auth.revokeAuthorization") && o === !0 && r("sdk.Runtime").setAccessToken(null)
                        }), t.subscribe("request.error", function(t, n, a, i) {
                            e && i.error.type === "http" && o("sdk.Scribe").log("jssdk_error", {
                                appId: r("sdk.Runtime").getClientID(),
                                error: "transport",
                                extra: {
                                    name: "transport",
                                    message: ES("JSON", "stringify", !1, i.error) + " from " + t + " , " + n
                                }
                            })
                        }), r("FB").provide("", {
                            api: r("sdk.api")
                        })
                    }
                    var c = {
                            init: u
                        },
                        d = c;
                    l.default = d
                }, 98);
                __d("sdk.MBasicInitializer", ["UrlMap", "sdk.DOM", "sdk.Runtime", "sdk.UA", "sdk.URI", "sdk.fbt"], function(t, n, r, o, a, i, l) {
                    var e = function() {
                        function e(e) {
                            if (e) {
                                var t = e.parentNode;
                                if (t) {
                                    var n = o("sdk.DOM").getAttr(e, "href") || window.location.href,
                                        a = new(r("sdk.URI"))(o("UrlMap").resolve("m"));
                                    a.setPath("/dialog/share"), a.addQueryData("href", encodeURI(n)), a.addQueryData("app_id", r("sdk.Runtime").getClientID()), a.addQueryData("mbasic_link", 1);
                                    var i = document.createElement("a");
                                    i.style.cssText = "display:inline-block; zoom:1;", i.textContent = r("sdk.fbt")._( /*BTDS*/ "Share to Facebook"), i.setAttribute("href", a.toString()), i.setAttribute("target", "_blank"), t.insertBefore(i, e), t.removeChild(e)
                                }
                            }
                        }
                        ES("Array", "from", !1, document.getElementsByTagName("fb:share-button")).forEach(function(t) {
                            return e(t)
                        }), ES("Array", "from", !1, document.getElementsByClassName("fb-share-button")).forEach(function(t) {
                            return e(t)
                        })
                    };

                    function s() {
                        r("sdk.UA").mBasic() && e()
                    }
                    l.init = s
                }, 226);
                __d("sdk.init", ["Log", "ManagedError", "sdk.Cookie", "sdk.Event", "sdk.MBasicInitializer", "sdk.PlatformVersioning", "sdk.Runtime", "sdk.UA", "sdk.URI"], function(t, n, r, o, a, i, l) {
                    function e(e) {
                        if (e == null || typeof e != "object") return !1;
                        var t = Object.getPrototypeOf({}),
                            n = Object.getPrototypeOf(e);
                        return n === t || n == null
                    }

                    function s(e) {
                        var t = typeof e == "number" && e > 0 || typeof e == "string" && /^[0-9a-f]{21,}$|^[0-9]{1,21}$/.test(e);
                        return t ? e.toString() : (o("Log").warn("Invalid App Id: Must be a number or numeric string representing the application id."), null)
                    }

                    function u(t) {
                        if (r("sdk.Runtime").getInitialized() && o("Log").warn("FB.init has already been called - this could indicate a problem"), r("sdk.Runtime").getIsVersioned()) {
                            if (!e(t)) throw new(r("ManagedError"))("Invalid argument");
                            if (t.authResponse) throw new(r("ManagedError"))("Setting authResponse is not supported");
                            t.version || (t.version = new(r("sdk.URI"))(location.href).getQueryData().sdk_version), o("sdk.PlatformVersioning").assertValidVersion(t.version), r("sdk.Runtime").setVersion(t.version)
                        } else /number|string/.test(typeof t) && (o("Log").warn("FB.init called with invalid parameters"), t = {
                            apiKey: t
                        }), t.status == null && (t.legacyStatusInit = !0), t = babelHelpers.extends({
                            status: !0
                        }, t || {});
                        var n = s(t.appId || t.apiKey);
                        n !== null && r("sdk.Runtime").setClientID(n), "scope" in t && r("sdk.Runtime").setScope(t.scope), t.cookie && (r("sdk.Runtime").setUseCookie(!0), typeof t.cookie == "string" && o("sdk.Cookie").setDomain(t.cookie)), (t.localStorage === !1 || t.localStorage === "false") && r("sdk.Runtime").setUseLocalStorage(!1), t.kidDirectedSite && r("sdk.Runtime").setKidDirectedSite(!0), t.useFamilyLogin && r("sdk.Runtime").setShouldLoadFamilyLogin(!0), (t.autoLogAppEvents === "1" || t.autoLogAppEvents === "true") && (t.autoLogAppEvents = !0), t.ab && r("sdk.Runtime").setSDKAB(t.ab), r("sdk.Runtime").setInitialized(!0), r("sdk.UA").mBasic() && o("sdk.MBasicInitializer").init(), o("sdk.Event").fire("init:post", t)
                    }
                    l.default = u
                }, 98);
                __d("sdk.init-public", ["FB", "QueryString", "sdk.AppEvents", "sdk.ErrorHandling", "sdk.Event", "sdk.Frictionless", "sdk.XD", "sdk.init"], function(t, n, r, o, a, i, l) {
                    "use strict";

                    function e() {
                        n("sdk.XD"), n("sdk.AppEvents"), n("sdk.Frictionless"), window.setTimeout(function() {
                            var e = /(connect\.facebook\.net|\.facebook\.com\/assets.php|\.facebook\.net\/assets.php).*?#(.*)/;
                            ES("Array", "from", !1, window.document.getElementsByTagName("script")).forEach(function(t) {
                                if (t.src) {
                                    var n = e.exec(t.src);
                                    if (n) {
                                        var o = {},
                                            a = r("QueryString").decode(n[2]);
                                        for (var i in a)
                                            if (Object.prototype.hasOwnProperty.call(a, i)) {
                                                var l = a[i];
                                                l === "0" ? o[i] = 0 : o[i] = l
                                            }
                                        r("sdk.init")(o)
                                    }
                                }
                            }), window.fbAsyncInit && !window.fbAsyncInit.hasRun && (o("sdk.Event").fire("init:asyncstart"), window.fbAsyncInit.hasRun = !0, r("sdk.ErrorHandling").unguard(window.fbAsyncInit)())
                        }, 0), r("FB").provide("", {
                            init: r("sdk.init")
                        }), o("sdk.Event").subscribe("init:post", function() {
                            window.__buffer !== void 0 && window.__buffer.replay()
                        }), window.setTimeout(function() {
                            window.__buffer && window.__buffer.opts && r("sdk.init")(window.__buffer.opts)
                        }, 0)
                    }
                    var s = {
                            initialize: e
                        },
                        u = s;
                    l.default = u
                }, 98);
                __d("sdk.Time", ["Log", "getErrorSafe", "sdk.Impressions", "sdk.Runtime", "sdk.URI", "sdk.feature"], function(t, n, r, o, a, i, l) {
                    "use strict";
                    var e = window.performance,
                        s = e && "now" in e && "getEntriesByName" in e,
                        u, c = {};

                    function d() {
                        function t(e, t) {
                            var n = !1;
                            try {
                                var a = new(r("sdk.URI"))(e.name),
                                    i = a.getDomain(),
                                    l = a.getPath();
                                n = i === t.getDomain() && ES(l, "includes", !0, "/rsrc.php/")
                            } catch (e) {
                                var s = r("getErrorSafe")(e);
                                o("Log").error("Malformed URL was passed to the URL constructor: Error %s occured", s.message)
                            }
                            return n
                        }

                        function n(n) {
                            try {
                                var a = e.getEntriesByType("resource").filter(function(e) {
                                        return t(e, new(r("sdk.URI"))(n))
                                    }),
                                    i = a.length >= 1;
                                return i || (a = e.getEntriesByType("resource").filter(function(e) {
                                    return ES(e.name, "startsWith", !0, n)
                                })), a
                            } catch (e) {
                                var l = r("getErrorSafe")(e);
                                o("Log").error("Malformed URL was passed to the URL constructor: Error %s occured", l.message)
                            }
                        }
                        if (s) {
                            var a = r("sdk.Runtime").getSDKUrl(),
                                i = null,
                                l = n(a);
                            if (l && l.length > 1)
                                if (l > 2) l = null;
                                else {
                                    var d = ES(l, "findIndex", !0, function(e) {
                                        return ES(e.name, "startsWith", !0, a + "?hash=")
                                    });
                                    d ? (i = l.splice(d)[0], l = l[0]) : l = null
                                }
                            else if (l && l.length === 1) {
                                var m = document.getElementById("facebook-jssdk-iframe");
                                m && m instanceof HTMLIFrameElement && (i = m.contentWindow.performance.getEntriesByType("resource").find(function(e) {
                                    return ES(e.name, "startsWith", !0, a)
                                })), l = l[0]
                            } else l = null;
                            l && (c.fetchTime = Math.round(l.duration), i && (c.fetchTime += Math.round(i.duration)), "transferSize" in l && (c.transferSize = l.transferSize, i && (c.transferSize += i.transferSize)), o("Log").debug("sdkperf: it took %s ms and %s bytes to load %s", c.fetchTime, c.transferSize, a), u = l.startTime, c.ns = r("sdk.Runtime").getSDKNS(), u && window.setTimeout(function() {
                                var e = r("sdk.feature")("log_perf", !1),
                                    t = r("sdk.Runtime").getSDKAB();
                                t && (c.ab = t, e = !0), e && o("sdk.Impressions").log(116, c)
                            }, 1e4))
                        }
                    }

                    function m(t) {
                        !s || !u || (c[t] = Math.round(e.now() - u), o("Log").debug("sdkperf: %s logged after %s ms", t, c[t]))
                    }
                    l.recordBootload = d, l.log = m
                }, 98);
                __d("sdk.time-public", ["runOnce", "sdk.Event", "sdk.Time"], (function(t, n, r, o, a, i, l) {
                    "use strict";

                    function e() {
                        var e;
                        o("sdk.Time").recordBootload(), (e = o("sdk.Event")).subscribe("init:post", function() {
                            o("sdk.Time").log("init")
                        }), e.subscribe("init:asyncstart", function() {
                            o("sdk.Time").log("asyncstart")
                        }), e.subscribe("iframeplugin:create", r("runOnce")(function() {
                            return o("sdk.Time").log("pluginframe")
                        })), e.subscribe("iframeplugin:onload", r("runOnce")(function() {
                            return o("sdk.Time").log("ttfp")
                        }))
                    }
                    var s = {
                            init: e
                        },
                        u = s;
                    l.default = u
                }), 98);
                __d("legacy:fb.sdk.index", ["FB", "sdk.AppEvents-public", "sdk.Auth-public", "sdk.Canvas-public", "sdk.Event-public", "sdk.Frictionless-public", "sdk.GamingServices-public", "sdk.Runtime", "sdk.XFBML-public", "sdk.api-public", "sdk.init-public", "sdk.time-public", "sdk.ui"], (function(t, n, r, o, a, i, l) {
                    var e;
                    r("sdk.api-public").init(), r("sdk.AppEvents-public").init(), r("sdk.Auth-public").init(), (e = r("sdk.Canvas-public")).init(), e.initCanvasPlugin(), e.initCanvasPrefetcher(), e.initCanvasPresence(), r("sdk.Event-public").init(), r("sdk.Frictionless-public").init(), r("sdk.GamingServices-public").init(), r("sdk.init-public").initialize(), r("sdk.time-public").init(), r("FB").provide("", {
                        ui: r("sdk.ui")
                    }), r("sdk.XFBML-public").init(), r("sdk.XFBML-public").initXFBMLBasedSocialPlugin(), r("sdk.Runtime").setIsVersioned(!0)
                }), 35);
                window.FB && window.FB.__buffer && (window.__buffer = babelHelpers.extends({}, window.FB.__buffer));
            }
        }).call(global);
    })();
} catch (__fb_err) {
    var __fb_i = new Image();
    __fb_i.crossOrigin = 'anonymous';
    __fb_i.dataset.testid = 'fbSDKErrorReport';
    __fb_i.src = 'https://www.facebook.com/platform/scribe_endpoint.php/?c=jssdk_error&m=' + encodeURIComponent('{"error":"LOAD", "extra": {"name":"' + __fb_err.name + '","line":"' + (__fb_err.lineNumber || __fb_err.line) + '","script":"' + (__fb_err.fileName || __fb_err.sourceURL || __fb_err.script || "sdk.js") + '","stack":"' + (__fb_err.stackTrace || __fb_err.stack) + '","revision":"1033555463","namespace":"FB","message":"' + __fb_err.message + '"}}');
    document.body.appendChild(__fb_i);
}