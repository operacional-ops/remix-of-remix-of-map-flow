import {
    s as x,
    n as u,
    d as m,
    a as h,
    i as _,
    b as d,
    c as v,
    e as g,
    f as b,
    g as S,
    h as E,
    t as $,
    j,
    k
} from "../chunks/DDNnt9XD.js";
import {
    S as q,
    i as y
} from "../chunks/qWASNxYk.js";
import {
    p as C
} from "../chunks/-FoHBm-c.js";

function H(i) {
    var f;
    let a, s = i[0].status + "",
        r, o, n, p = ((f = i[0].error) == null ? void 0 : f.message) + "",
        c;
    return {
        c() {
            a = E("h1"), r = $(s), o = j(), n = E("p"), c = $(p)
        },
        l(e) {
            a = v(e, "H1", {});
            var t = g(a);
            r = b(t, s), t.forEach(m), o = S(e), n = v(e, "P", {});
            var l = g(n);
            c = b(l, p), l.forEach(m)
        },
        m(e, t) {
            _(e, a, t), d(a, r), _(e, o, t), _(e, n, t), d(n, c)
        },
        p(e, [t]) {
            var l;
            t & 1 && s !== (s = e[0].status + "") && h(r, s), t & 1 && p !== (p = ((l = e[0].error) == null ? void 0 : l.message) + "") && h(c, p)
        },
        i: u,
        o: u,
        d(e) {
            e && (m(a), m(o), m(n))
        }
    }
}

function P(i, a, s) {
    let r;
    return k(i, C, o => s(0, r = o)), [r]
}
class B extends q {
    constructor(a) {
        super(), y(this, a, P, H, x, {})
    }
}
export {
    B as component
};