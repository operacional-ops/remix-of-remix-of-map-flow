var es = Object.defineProperty;
var ts = (D, L, O) => L in D ? es(D, L, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: O
}) : D[L] = O;
var pr = (D, L, O) => ts(D, typeof L != "symbol" ? L + "" : L, O);
import {
    n as $n,
    O as vr,
    B as ns,
    P as Fi,
    s as yr,
    d as Ct,
    r as Ur,
    af as Wi,
    i as gn,
    b as yi,
    q as Gi,
    m as Nt,
    c as jn,
    e as Nn,
    g as Vi,
    h as In,
    j as Yi,
    k as fn,
    v as Fr,
    M as is,
    E as Dr,
    F as Ki,
    ab as rs,
    ac as ss,
    T as os,
    V as Or,
    H as as,
    I as ls,
    J as cs,
    K as us,
    w as Ui
} from "../chunks/DDNnt9XD.js";
import {
    n as Gr,
    l as Vr,
    k as ds,
    o as hs,
    S as br,
    i as _r,
    t as mn,
    a as vn,
    g as wr,
    f as xr,
    d as Xi,
    b as Qi,
    m as Zi,
    c as Er,
    h as ps,
    j as fs
} from "../chunks/qWASNxYk.js"; /* empty css                */
import {
    E as Kt,
    U as Yr,
    u as vi,
    T as gs,
    I as ms
} from "../chunks/B5WePDbK.js";
import {
    e as Lr,
    u as vs,
    f as ys
} from "../chunks/D4UMIlhj.js";
import {
    b as bs,
    a as _s,
    f as ws
} from "../chunks/DVT0mszN.js";
import {
    t as fr,
    T as xs
} from "../chunks/BioHA4eS.js";
import {
    w as Es
} from "../chunks/BKn_unzl.js";
import {
    G as As
} from "../chunks/DdHafqv8.js";
import {
    i as $r
} from "../chunks/ykSDymOf.js";
import {
    C as Ts
} from "../chunks/CNJOnEY2.js";
import {
    t as Cs
} from "../chunks/BszCcFfc.js";
import {
    M as Ss
} from "../chunks/DE6I7gIp.js";
import {
    s as jr
} from "../chunks/BhzxD5oF.js";
import {
    G as ks
} from "../chunks/D123erTg.js";
import {
    s as Ds,
    l as Os
} from "../chunks/DbZnSQSX.js";
import {
    p as Nr
} from "../chunks/-FoHBm-c.js";

function Ls(D, L, O, P) {
    if (!L) return $n;
    const H = D.getBoundingClientRect();
    if (L.left === H.left && L.right === H.right && L.top === H.top && L.bottom === H.bottom) return $n;
    const {
        delay: U = 0,
        duration: J = 300,
        easing: B = vr,
        start: V = Gr() + U,
        end: ue = V + J,
        tick: qe = $n,
        css: be
    } = O(D, {
        from: L,
        to: H
    }, P);
    let de = !0,
        oe = !1,
        Y;

    function fe() {
        be && (Y = hs(D, 0, 1, J, U, B, be)), U || (oe = !0)
    }

    function se() {
        be && ds(D, Y), de = !1
    }
    return Vr(Ve => {
        if (!oe && Ve >= V && (oe = !0), oe && Ve >= ue && (qe(1, 0), se()), !de) return !1;
        if (oe) {
            const gt = Ve - V,
                at = 0 + 1 * B(gt / J);
            qe(at, 1 - at)
        }
        return !0
    }), fe(), qe(0, 1), se
}

function $s(D) {
    const L = getComputedStyle(D);
    if (L.position !== "absolute" && L.position !== "fixed") {
        const {
            width: O,
            height: P
        } = L, H = D.getBoundingClientRect();
        D.style.position = "absolute", D.style.width = O, D.style.height = P, Kr(D, H)
    }
}

function Kr(D, L) {
    const O = D.getBoundingClientRect();
    if (L.left !== O.left || L.top !== O.top) {
        const P = getComputedStyle(D),
            H = P.transform === "none" ? "" : P.transform;
        D.style.transform = `${H} translate(${L.left-O.left}px, ${L.top-O.top}px)`
    }
}

function Ir(D, L) {
    const O = {},
        P = {},
        H = {
            $$scope: 1
        };
    let U = D.length;
    for (; U--;) {
        const J = D[U],
            B = L[U];
        if (B) {
            for (const V in J) V in B || (P[V] = 1);
            for (const V in B) H[V] || (O[V] = B[V], H[V] = 1);
            D[U] = B
        } else
            for (const V in J) H[V] = 1
    }
    for (const J in P) J in O || (O[J] = void 0);
    return O
}

function Pr(D) {
    return typeof D == "object" && D !== null ? D : {}
}
const js = !1,
    Ns = "always",
    Is = !1,
    bo = Object.freeze(Object.defineProperty({
        __proto__: null,
        prerender: js,
        ssr: Is,
        trailingSlash: Ns
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Xr = ["/", "/login", "/register", "/404", "/sessao-expirada", "/verify-email-sent", "/completar-registro", "/completar-registro/invalid-token", "/completar-registro/expired-token", "/completar-registro/already-confirmed", "/redefinir-senha", "/redefinir-senha/invalid-token", "/redefinir-senha/expired-token", "/redefinir-senha/already-used", "/redefinir-senha/confirmar", "/redefinir-senha/redefinida", "/precos", "/integracoes", "/security", "/politica-de-privacidade", "/termos-e-condicoes", "/politica-de-cookies", "/google/callback", "/kwai/callback", "/tiktok/callback", "/nuvem-shop/callback", "/whatsapp-qrcode", "/verify-two-factor", "/connect-meta-profile/[token]", "/connect-google-profile/[token]", "/connect-kwai-profile/[token]", "/manage-kwai-profile/[token]", "/connect-tiktok-profile/[token]", "/parceiros", "/parceiros/[slug]", "/blog", "/blog/artigos/[slug]", "/blog/newsletter/[slug]"]; /*! jQuery v3.6.4 | (c) OpenJS Foundation and other contributors | jquery.org/license */
(function(D, L) {
    typeof module == "object" && typeof module.exports == "object" ? module.exports = D.document ? L(D, !0) : function(O) {
        if (!O.document) throw new Error("jQuery requires a window with a document");
        return L(O)
    } : L(D)
})(typeof window < "u" ? window : void 0, function(D, L) {
    var O = [],
        P = Object.getPrototypeOf,
        H = O.slice,
        U = O.flat ? function(e) {
            return O.flat.call(e)
        } : function(e) {
            return O.concat.apply([], e)
        },
        J = O.push,
        B = O.indexOf,
        V = {},
        ue = V.toString,
        qe = V.hasOwnProperty,
        be = qe.toString,
        de = be.call(Object),
        oe = {},
        Y = function(e) {
            return typeof e == "function" && typeof e.nodeType != "number" && typeof e.item != "function"
        },
        fe = function(e) {
            return e != null && e === e.window
        },
        se = D.document,
        Ve = {
            type: !0,
            src: !0,
            nonce: !0,
            noModule: !0
        };

    function gt(e, n, r) {
        var s, p, g = (r = r || se).createElement("script");
        if (g.text = e, n)
            for (s in Ve)(p = n[s] || n.getAttribute && n.getAttribute(s)) && g.setAttribute(s, p);
        r.head.appendChild(g).parentNode.removeChild(g)
    }

    function at(e) {
        return e == null ? e + "" : typeof e == "object" || typeof e == "function" ? V[ue.call(e)] || "object" : typeof e
    }
    var Pe = "3.6.4",
        a = function(e, n) {
            return new a.fn.init(e, n)
        };

    function xt(e) {
        var n = !!e && "length" in e && e.length,
            r = at(e);
        return !Y(e) && !fe(e) && (r === "array" || n === 0 || typeof n == "number" && 0 < n && n - 1 in e)
    }
    a.fn = a.prototype = {
        jquery: Pe,
        constructor: a,
        length: 0,
        toArray: function() {
            return H.call(this)
        },
        get: function(e) {
            return e == null ? H.call(this) : e < 0 ? this[e + this.length] : this[e]
        },
        pushStack: function(e) {
            var n = a.merge(this.constructor(), e);
            return n.prevObject = this, n
        },
        each: function(e) {
            return a.each(this, e)
        },
        map: function(e) {
            return this.pushStack(a.map(this, function(n, r) {
                return e.call(n, r, n)
            }))
        },
        slice: function() {
            return this.pushStack(H.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq(-1)
        },
        even: function() {
            return this.pushStack(a.grep(this, function(e, n) {
                return (n + 1) % 2
            }))
        },
        odd: function() {
            return this.pushStack(a.grep(this, function(e, n) {
                return n % 2
            }))
        },
        eq: function(e) {
            var n = this.length,
                r = +e + (e < 0 ? n : 0);
            return this.pushStack(0 <= r && r < n ? [this[r]] : [])
        },
        end: function() {
            return this.prevObject || this.constructor()
        },
        push: J,
        sort: O.sort,
        splice: O.splice
    }, a.extend = a.fn.extend = function() {
        var e, n, r, s, p, g, m = arguments[0] || {},
            S = 1,
            T = arguments.length,
            N = !1;
        for (typeof m == "boolean" && (N = m, m = arguments[S] || {}, S++), typeof m == "object" || Y(m) || (m = {}), S === T && (m = this, S--); S < T; S++)
            if ((e = arguments[S]) != null)
                for (n in e) s = e[n], n !== "__proto__" && m !== s && (N && s && (a.isPlainObject(s) || (p = Array.isArray(s))) ? (r = m[n], g = p && !Array.isArray(r) ? [] : p || a.isPlainObject(r) ? r : {}, p = !1, m[n] = a.extend(N, g, s)) : s !== void 0 && (m[n] = s));
        return m
    }, a.extend({
        expando: "jQuery" + (Pe + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function(e) {
            throw new Error(e)
        },
        noop: function() {},
        isPlainObject: function(e) {
            var n, r;
            return !(!e || ue.call(e) !== "[object Object]") && (!(n = P(e)) || typeof(r = qe.call(n, "constructor") && n.constructor) == "function" && be.call(r) === de)
        },
        isEmptyObject: function(e) {
            var n;
            for (n in e) return !1;
            return !0
        },
        globalEval: function(e, n, r) {
            gt(e, {
                nonce: n && n.nonce
            }, r)
        },
        each: function(e, n) {
            var r, s = 0;
            if (xt(e))
                for (r = e.length; s < r && n.call(e[s], s, e[s]) !== !1; s++);
            else
                for (s in e)
                    if (n.call(e[s], s, e[s]) === !1) break;
            return e
        },
        makeArray: function(e, n) {
            var r = n || [];
            return e != null && (xt(Object(e)) ? a.merge(r, typeof e == "string" ? [e] : e) : J.call(r, e)), r
        },
        inArray: function(e, n, r) {
            return n == null ? -1 : B.call(n, e, r)
        },
        merge: function(e, n) {
            for (var r = +n.length, s = 0, p = e.length; s < r; s++) e[p++] = n[s];
            return e.length = p, e
        },
        grep: function(e, n, r) {
            for (var s = [], p = 0, g = e.length, m = !r; p < g; p++) !n(e[p], p) !== m && s.push(e[p]);
            return s
        },
        map: function(e, n, r) {
            var s, p, g = 0,
                m = [];
            if (xt(e))
                for (s = e.length; g < s; g++)(p = n(e[g], g, r)) != null && m.push(p);
            else
                for (g in e)(p = n(e[g], g, r)) != null && m.push(p);
            return U(m)
        },
        guid: 1,
        support: oe
    }), typeof Symbol == "function" && (a.fn[Symbol.iterator] = O[Symbol.iterator]), a.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function(e, n) {
        V["[object " + n + "]"] = n.toLowerCase()
    });
    var St = function(e) {
        var n, r, s, p, g, m, S, T, N, l, t, i, c, v, E, k, W, G, Z, X = "sizzle" + 1 * new Date,
            z = e.document,
            pe = 0,
            ee = 0,
            re = sn(),
            Ce = sn(),
            Ee = sn(),
            Oe = sn(),
            je = function(_, A) {
                return _ === A && (t = !0), 0
            },
            $e = {}.hasOwnProperty,
            ce = [],
            Re = ce.pop,
            xe = ce.push,
            _e = ce.push,
            Ae = ce.slice,
            Ne = function(_, A) {
                for (var j = 0, F = _.length; j < F; j++)
                    if (_[j] === A) return j;
                return -1
            },
            Ue = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
            me = "[\\x20\\t\\r\\n\\f]",
            ve = "(?:\\\\[\\da-fA-F]{1,6}" + me + "?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+",
            Ie = "\\[" + me + "*(" + ve + ")(?:" + me + "*([*^$|!~]?=)" + me + `*(?:'((?:\\\\.|[^\\\\'])*)'|"((?:\\\\.|[^\\\\"])*)"|(` + ve + "))|)" + me + "*\\]",
            Ke = ":(" + ve + `)(?:\\((('((?:\\\\.|[^\\\\'])*)'|"((?:\\\\.|[^\\\\"])*)")|((?:\\\\.|[^\\\\()[\\]]|` + Ie + ")*)|.*)\\)|)",
            Fe = new RegExp(me + "+", "g"),
            Je = new RegExp("^" + me + "+|((?:^|[^\\\\])(?:\\\\.)*)" + me + "+$", "g"),
            jt = new RegExp("^" + me + "*," + me + "*"),
            et = new RegExp("^" + me + "*([>+~]|" + me + ")" + me + "*"),
            it = new RegExp(me + "|>"),
            qt = new RegExp(Ke),
            rt = new RegExp("^" + ve + "$"),
            st = {
                ID: new RegExp("^#(" + ve + ")"),
                CLASS: new RegExp("^\\.(" + ve + ")"),
                TAG: new RegExp("^(" + ve + "|[*])"),
                ATTR: new RegExp("^" + Ie),
                PSEUDO: new RegExp("^" + Ke),
                CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + me + "*(even|odd|(([+-]|)(\\d*)n|)" + me + "*(?:([+-]|)" + me + "*(\\d+)|))" + me + "*\\)|)", "i"),
                bool: new RegExp("^(?:" + Ue + ")$", "i"),
                needsContext: new RegExp("^" + me + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + me + "*((?:-\\d)?\\d*)" + me + "*\\)|)(?=[^-]|$)", "i")
            },
            Gn = /HTML$/i,
            kn = /^(?:input|select|textarea|button)$/i,
            pn = /^h\d$/i,
            Dn = /^[^{]+\{\s*\[native \w/,
            ar = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            On = /[+~]/,
            Bt = new RegExp("\\\\[\\da-fA-F]{1,6}" + me + "?|\\\\([^\\r\\n\\f])", "g"),
            Mt = function(_, A) {
                var j = "0x" + _.slice(1) - 65536;
                return A || (j < 0 ? String.fromCharCode(j + 65536) : String.fromCharCode(j >> 10 | 55296, 1023 & j | 56320))
            },
            fi = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
            gi = function(_, A) {
                return A ? _ === "\0" ? "�" : _.slice(0, -1) + "\\" + _.charCodeAt(_.length - 1).toString(16) + " " : "\\" + _
            },
            mi = function() {
                i()
            },
            lr = Ri(function(_) {
                return _.disabled === !0 && _.nodeName.toLowerCase() === "fieldset"
            }, {
                dir: "parentNode",
                next: "legend"
            });
        try {
            _e.apply(ce = Ae.call(z.childNodes), z.childNodes), ce[z.childNodes.length].nodeType
        } catch {
            _e = {
                apply: ce.length ? function(A, j) {
                    xe.apply(A, Ae.call(j))
                } : function(A, j) {
                    for (var F = A.length, I = 0; A[F++] = j[I++];);
                    A.length = F - 1
                }
            }
        }

        function Ge(_, A, j, F) {
            var I, K, Q, te, le, ke, we, Te = A && A.ownerDocument,
                Be = A ? A.nodeType : 9;
            if (j = j || [], typeof _ != "string" || !_ || Be !== 1 && Be !== 9 && Be !== 11) return j;
            if (!F && (i(A), A = A || c, E)) {
                if (Be !== 11 && (le = ar.exec(_)))
                    if (I = le[1]) {
                        if (Be === 9) {
                            if (!(Q = A.getElementById(I))) return j;
                            if (Q.id === I) return j.push(Q), j
                        } else if (Te && (Q = Te.getElementById(I)) && Z(A, Q) && Q.id === I) return j.push(Q), j
                    } else {
                        if (le[2]) return _e.apply(j, A.getElementsByTagName(_)), j;
                        if ((I = le[3]) && r.getElementsByClassName && A.getElementsByClassName) return _e.apply(j, A.getElementsByClassName(I)), j
                    }
                if (r.qsa && !Oe[_ + " "] && (!k || !k.test(_)) && (Be !== 1 || A.nodeName.toLowerCase() !== "object")) {
                    if (we = _, Te = A, Be === 1 && (it.test(_) || et.test(_))) {
                        for ((Te = On.test(_) && cr(A.parentNode) || A) === A && r.scope || ((te = A.getAttribute("id")) ? te = te.replace(fi, gi) : A.setAttribute("id", te = X)), K = (ke = m(_)).length; K--;) ke[K] = (te ? "#" + te : ":scope") + " " + Hi(ke[K]);
                        we = ke.join(",")
                    }
                    try {
                        return _e.apply(j, Te.querySelectorAll(we)), j
                    } catch {
                        Oe(_, !0)
                    } finally {
                        te === X && A.removeAttribute("id")
                    }
                }
            }
            return T(_.replace(Je, "$1"), A, j, F)
        }

        function sn() {
            var _ = [];
            return function A(j, F) {
                return _.push(j + " ") > s.cacheLength && delete A[_.shift()], A[j + " "] = F
            }
        }

        function Lt(_) {
            return _[X] = !0, _
        }

        function At(_) {
            var A = c.createElement("fieldset");
            try {
                return !!_(A)
            } catch {
                return !1
            } finally {
                A.parentNode && A.parentNode.removeChild(A), A = null
            }
        }

        function Vn(_, A) {
            for (var j = _.split("|"), F = j.length; F--;) s.attrHandle[j[F]] = A
        }

        function Ar(_, A) {
            var j = A && _,
                F = j && _.nodeType === 1 && A.nodeType === 1 && _.sourceIndex - A.sourceIndex;
            if (F) return F;
            if (j) {
                for (; j = j.nextSibling;)
                    if (j === A) return -1
            }
            return _ ? 1 : -1
        }

        function Qr(_) {
            return function(A) {
                return A.nodeName.toLowerCase() === "input" && A.type === _
            }
        }

        function Zr(_) {
            return function(A) {
                var j = A.nodeName.toLowerCase();
                return (j === "input" || j === "button") && A.type === _
            }
        }

        function Tr(_) {
            return function(A) {
                return "form" in A ? A.parentNode && A.disabled === !1 ? "label" in A ? "label" in A.parentNode ? A.parentNode.disabled === _ : A.disabled === _ : A.isDisabled === _ || A.isDisabled !== !_ && lr(A) === _ : A.disabled === _ : "label" in A && A.disabled === _
            }
        }

        function Ln(_) {
            return Lt(function(A) {
                return A = +A, Lt(function(j, F) {
                    for (var I, K = _([], j.length, A), Q = K.length; Q--;) j[I = K[Q]] && (j[I] = !(F[I] = j[I]))
                })
            })
        }

        function cr(_) {
            return _ && typeof _.getElementsByTagName < "u" && _
        }
        for (n in r = Ge.support = {}, g = Ge.isXML = function(_) {
                var A = _ && _.namespaceURI,
                    j = _ && (_.ownerDocument || _).documentElement;
                return !Gn.test(A || j && j.nodeName || "HTML")
            }, i = Ge.setDocument = function(_) {
                var A, j, F = _ ? _.ownerDocument || _ : z;
                return F != c && F.nodeType === 9 && F.documentElement && (v = (c = F).documentElement, E = !g(c), z != c && (j = c.defaultView) && j.top !== j && (j.addEventListener ? j.addEventListener("unload", mi, !1) : j.attachEvent && j.attachEvent("onunload", mi)), r.scope = At(function(I) {
                    return v.appendChild(I).appendChild(c.createElement("div")), typeof I.querySelectorAll < "u" && !I.querySelectorAll(":scope fieldset div").length
                }), r.cssHas = At(function() {
                    try {
                        return c.querySelector(":has(*,:jqfake)"), !1
                    } catch {
                        return !0
                    }
                }), r.attributes = At(function(I) {
                    return I.className = "i", !I.getAttribute("className")
                }), r.getElementsByTagName = At(function(I) {
                    return I.appendChild(c.createComment("")), !I.getElementsByTagName("*").length
                }), r.getElementsByClassName = Dn.test(c.getElementsByClassName), r.getById = At(function(I) {
                    return v.appendChild(I).id = X, !c.getElementsByName || !c.getElementsByName(X).length
                }), r.getById ? (s.filter.ID = function(I) {
                    var K = I.replace(Bt, Mt);
                    return function(Q) {
                        return Q.getAttribute("id") === K
                    }
                }, s.find.ID = function(I, K) {
                    if (typeof K.getElementById < "u" && E) {
                        var Q = K.getElementById(I);
                        return Q ? [Q] : []
                    }
                }) : (s.filter.ID = function(I) {
                    var K = I.replace(Bt, Mt);
                    return function(Q) {
                        var te = typeof Q.getAttributeNode < "u" && Q.getAttributeNode("id");
                        return te && te.value === K
                    }
                }, s.find.ID = function(I, K) {
                    if (typeof K.getElementById < "u" && E) {
                        var Q, te, le, ke = K.getElementById(I);
                        if (ke) {
                            if ((Q = ke.getAttributeNode("id")) && Q.value === I) return [ke];
                            for (le = K.getElementsByName(I), te = 0; ke = le[te++];)
                                if ((Q = ke.getAttributeNode("id")) && Q.value === I) return [ke]
                        }
                        return []
                    }
                }), s.find.TAG = r.getElementsByTagName ? function(I, K) {
                    return typeof K.getElementsByTagName < "u" ? K.getElementsByTagName(I) : r.qsa ? K.querySelectorAll(I) : void 0
                } : function(I, K) {
                    var Q, te = [],
                        le = 0,
                        ke = K.getElementsByTagName(I);
                    if (I === "*") {
                        for (; Q = ke[le++];) Q.nodeType === 1 && te.push(Q);
                        return te
                    }
                    return ke
                }, s.find.CLASS = r.getElementsByClassName && function(I, K) {
                    if (typeof K.getElementsByClassName < "u" && E) return K.getElementsByClassName(I)
                }, W = [], k = [], (r.qsa = Dn.test(c.querySelectorAll)) && (At(function(I) {
                    var K;
                    v.appendChild(I).innerHTML = "<a id='" + X + "'></a><select id='" + X + "-\r\\' msallowcapture=''><option selected=''></option></select>", I.querySelectorAll("[msallowcapture^='']").length && k.push("[*^$]=" + me + `*(?:''|"")`), I.querySelectorAll("[selected]").length || k.push("\\[" + me + "*(?:value|" + Ue + ")"), I.querySelectorAll("[id~=" + X + "-]").length || k.push("~="), (K = c.createElement("input")).setAttribute("name", ""), I.appendChild(K), I.querySelectorAll("[name='']").length || k.push("\\[" + me + "*name" + me + "*=" + me + `*(?:''|"")`), I.querySelectorAll(":checked").length || k.push(":checked"), I.querySelectorAll("a#" + X + "+*").length || k.push(".#.+[+~]"), I.querySelectorAll("\\\f"), k.push("[\\r\\n\\f]")
                }), At(function(I) {
                    I.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
                    var K = c.createElement("input");
                    K.setAttribute("type", "hidden"), I.appendChild(K).setAttribute("name", "D"), I.querySelectorAll("[name=d]").length && k.push("name" + me + "*[*^$|!~]?="), I.querySelectorAll(":enabled").length !== 2 && k.push(":enabled", ":disabled"), v.appendChild(I).disabled = !0, I.querySelectorAll(":disabled").length !== 2 && k.push(":enabled", ":disabled"), I.querySelectorAll("*,:x"), k.push(",.*:")
                })), (r.matchesSelector = Dn.test(G = v.matches || v.webkitMatchesSelector || v.mozMatchesSelector || v.oMatchesSelector || v.msMatchesSelector)) && At(function(I) {
                    r.disconnectedMatch = G.call(I, "*"), G.call(I, "[s!='']:x"), W.push("!=", Ke)
                }), r.cssHas || k.push(":has"), k = k.length && new RegExp(k.join("|")), W = W.length && new RegExp(W.join("|")), A = Dn.test(v.compareDocumentPosition), Z = A || Dn.test(v.contains) ? function(I, K) {
                    var Q = I.nodeType === 9 && I.documentElement || I,
                        te = K && K.parentNode;
                    return I === te || !(!te || te.nodeType !== 1 || !(Q.contains ? Q.contains(te) : I.compareDocumentPosition && 16 & I.compareDocumentPosition(te)))
                } : function(I, K) {
                    if (K) {
                        for (; K = K.parentNode;)
                            if (K === I) return !0
                    }
                    return !1
                }, je = A ? function(I, K) {
                    if (I === K) return t = !0, 0;
                    var Q = !I.compareDocumentPosition - !K.compareDocumentPosition;
                    return Q || (1 & (Q = (I.ownerDocument || I) == (K.ownerDocument || K) ? I.compareDocumentPosition(K) : 1) || !r.sortDetached && K.compareDocumentPosition(I) === Q ? I == c || I.ownerDocument == z && Z(z, I) ? -1 : K == c || K.ownerDocument == z && Z(z, K) ? 1 : l ? Ne(l, I) - Ne(l, K) : 0 : 4 & Q ? -1 : 1)
                } : function(I, K) {
                    if (I === K) return t = !0, 0;
                    var Q, te = 0,
                        le = I.parentNode,
                        ke = K.parentNode,
                        we = [I],
                        Te = [K];
                    if (!le || !ke) return I == c ? -1 : K == c ? 1 : le ? -1 : ke ? 1 : l ? Ne(l, I) - Ne(l, K) : 0;
                    if (le === ke) return Ar(I, K);
                    for (Q = I; Q = Q.parentNode;) we.unshift(Q);
                    for (Q = K; Q = Q.parentNode;) Te.unshift(Q);
                    for (; we[te] === Te[te];) te++;
                    return te ? Ar(we[te], Te[te]) : we[te] == z ? -1 : Te[te] == z ? 1 : 0
                }), c
            }, Ge.matches = function(_, A) {
                return Ge(_, null, null, A)
            }, Ge.matchesSelector = function(_, A) {
                if (i(_), r.matchesSelector && E && !Oe[A + " "] && (!W || !W.test(A)) && (!k || !k.test(A))) try {
                    var j = G.call(_, A);
                    if (j || r.disconnectedMatch || _.document && _.document.nodeType !== 11) return j
                } catch {
                    Oe(A, !0)
                }
                return 0 < Ge(A, c, null, [_]).length
            }, Ge.contains = function(_, A) {
                return (_.ownerDocument || _) != c && i(_), Z(_, A)
            }, Ge.attr = function(_, A) {
                (_.ownerDocument || _) != c && i(_);
                var j = s.attrHandle[A.toLowerCase()],
                    F = j && $e.call(s.attrHandle, A.toLowerCase()) ? j(_, A, !E) : void 0;
                return F !== void 0 ? F : r.attributes || !E ? _.getAttribute(A) : (F = _.getAttributeNode(A)) && F.specified ? F.value : null
            }, Ge.escape = function(_) {
                return (_ + "").replace(fi, gi)
            }, Ge.error = function(_) {
                throw new Error("Syntax error, unrecognized expression: " + _)
            }, Ge.uniqueSort = function(_) {
                var A, j = [],
                    F = 0,
                    I = 0;
                if (t = !r.detectDuplicates, l = !r.sortStable && _.slice(0), _.sort(je), t) {
                    for (; A = _[I++];) A === _[I] && (F = j.push(I));
                    for (; F--;) _.splice(j[F], 1)
                }
                return l = null, _
            }, p = Ge.getText = function(_) {
                var A, j = "",
                    F = 0,
                    I = _.nodeType;
                if (I) {
                    if (I === 1 || I === 9 || I === 11) {
                        if (typeof _.textContent == "string") return _.textContent;
                        for (_ = _.firstChild; _; _ = _.nextSibling) j += p(_)
                    } else if (I === 3 || I === 4) return _.nodeValue
                } else
                    for (; A = _[F++];) j += p(A);
                return j
            }, (s = Ge.selectors = {
                cacheLength: 50,
                createPseudo: Lt,
                match: st,
                attrHandle: {},
                find: {},
                relative: {
                    ">": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function(_) {
                        return _[1] = _[1].replace(Bt, Mt), _[3] = (_[3] || _[4] || _[5] || "").replace(Bt, Mt), _[2] === "~=" && (_[3] = " " + _[3] + " "), _.slice(0, 4)
                    },
                    CHILD: function(_) {
                        return _[1] = _[1].toLowerCase(), _[1].slice(0, 3) === "nth" ? (_[3] || Ge.error(_[0]), _[4] = +(_[4] ? _[5] + (_[6] || 1) : 2 * (_[3] === "even" || _[3] === "odd")), _[5] = +(_[7] + _[8] || _[3] === "odd")) : _[3] && Ge.error(_[0]), _
                    },
                    PSEUDO: function(_) {
                        var A, j = !_[6] && _[2];
                        return st.CHILD.test(_[0]) ? null : (_[3] ? _[2] = _[4] || _[5] || "" : j && qt.test(j) && (A = m(j, !0)) && (A = j.indexOf(")", j.length - A) - j.length) && (_[0] = _[0].slice(0, A), _[2] = j.slice(0, A)), _.slice(0, 3))
                    }
                },
                filter: {
                    TAG: function(_) {
                        var A = _.replace(Bt, Mt).toLowerCase();
                        return _ === "*" ? function() {
                            return !0
                        } : function(j) {
                            return j.nodeName && j.nodeName.toLowerCase() === A
                        }
                    },
                    CLASS: function(_) {
                        var A = re[_ + " "];
                        return A || (A = new RegExp("(^|" + me + ")" + _ + "(" + me + "|$)")) && re(_, function(j) {
                            return A.test(typeof j.className == "string" && j.className || typeof j.getAttribute < "u" && j.getAttribute("class") || "")
                        })
                    },
                    ATTR: function(_, A, j) {
                        return function(F) {
                            var I = Ge.attr(F, _);
                            return I == null ? A === "!=" : !A || (I += "", A === "=" ? I === j : A === "!=" ? I !== j : A === "^=" ? j && I.indexOf(j) === 0 : A === "*=" ? j && -1 < I.indexOf(j) : A === "$=" ? j && I.slice(-j.length) === j : A === "~=" ? -1 < (" " + I.replace(Fe, " ") + " ").indexOf(j) : A === "|=" && (I === j || I.slice(0, j.length + 1) === j + "-"))
                        }
                    },
                    CHILD: function(_, A, j, F, I) {
                        var K = _.slice(0, 3) !== "nth",
                            Q = _.slice(-4) !== "last",
                            te = A === "of-type";
                        return F === 1 && I === 0 ? function(le) {
                            return !!le.parentNode
                        } : function(le, ke, we) {
                            var Te, Be, ot, Le, ht, ft, Tt = K !== Q ? "nextSibling" : "previousSibling",
                                Ye = le.parentNode,
                                Yt = te && le.nodeName.toLowerCase(),
                                wt = !we && !te,
                                ct = !1;
                            if (Ye) {
                                if (K) {
                                    for (; Tt;) {
                                        for (Le = le; Le = Le[Tt];)
                                            if (te ? Le.nodeName.toLowerCase() === Yt : Le.nodeType === 1) return !1;
                                        ft = Tt = _ === "only" && !ft && "nextSibling"
                                    }
                                    return !0
                                }
                                if (ft = [Q ? Ye.firstChild : Ye.lastChild], Q && wt) {
                                    for (ct = (ht = (Te = (Be = (ot = (Le = Ye)[X] || (Le[X] = {}))[Le.uniqueID] || (ot[Le.uniqueID] = {}))[_] || [])[0] === pe && Te[1]) && Te[2], Le = ht && Ye.childNodes[ht]; Le = ++ht && Le && Le[Tt] || (ct = ht = 0) || ft.pop();)
                                        if (Le.nodeType === 1 && ++ct && Le === le) {
                                            Be[_] = [pe, ht, ct];
                                            break
                                        }
                                } else if (wt && (ct = ht = (Te = (Be = (ot = (Le = le)[X] || (Le[X] = {}))[Le.uniqueID] || (ot[Le.uniqueID] = {}))[_] || [])[0] === pe && Te[1]), ct === !1)
                                    for (;
                                        (Le = ++ht && Le && Le[Tt] || (ct = ht = 0) || ft.pop()) && !((te ? Le.nodeName.toLowerCase() === Yt : Le.nodeType === 1) && ++ct && (wt && ((Be = (ot = Le[X] || (Le[X] = {}))[Le.uniqueID] || (ot[Le.uniqueID] = {}))[_] = [pe, ct]), Le === le)););
                                return (ct -= I) === F || ct % F == 0 && 0 <= ct / F
                            }
                        }
                    },
                    PSEUDO: function(_, A) {
                        var j, F = s.pseudos[_] || s.setFilters[_.toLowerCase()] || Ge.error("unsupported pseudo: " + _);
                        return F[X] ? F(A) : 1 < F.length ? (j = [_, _, "", A], s.setFilters.hasOwnProperty(_.toLowerCase()) ? Lt(function(I, K) {
                            for (var Q, te = F(I, A), le = te.length; le--;) I[Q = Ne(I, te[le])] = !(K[Q] = te[le])
                        }) : function(I) {
                            return F(I, 0, j)
                        }) : F
                    }
                },
                pseudos: {
                    not: Lt(function(_) {
                        var A = [],
                            j = [],
                            F = S(_.replace(Je, "$1"));
                        return F[X] ? Lt(function(I, K, Q, te) {
                            for (var le, ke = F(I, null, te, []), we = I.length; we--;)(le = ke[we]) && (I[we] = !(K[we] = le))
                        }) : function(I, K, Q) {
                            return A[0] = I, F(A, null, Q, j), A[0] = null, !j.pop()
                        }
                    }),
                    has: Lt(function(_) {
                        return function(A) {
                            return 0 < Ge(_, A).length
                        }
                    }),
                    contains: Lt(function(_) {
                        return _ = _.replace(Bt, Mt),
                            function(A) {
                                return -1 < (A.textContent || p(A)).indexOf(_)
                            }
                    }),
                    lang: Lt(function(_) {
                        return rt.test(_ || "") || Ge.error("unsupported lang: " + _), _ = _.replace(Bt, Mt).toLowerCase(),
                            function(A) {
                                var j;
                                do
                                    if (j = E ? A.lang : A.getAttribute("xml:lang") || A.getAttribute("lang")) return (j = j.toLowerCase()) === _ || j.indexOf(_ + "-") === 0; while ((A = A.parentNode) && A.nodeType === 1);
                                return !1
                            }
                    }),
                    target: function(_) {
                        var A = e.location && e.location.hash;
                        return A && A.slice(1) === _.id
                    },
                    root: function(_) {
                        return _ === v
                    },
                    focus: function(_) {
                        return _ === c.activeElement && (!c.hasFocus || c.hasFocus()) && !!(_.type || _.href || ~_.tabIndex)
                    },
                    enabled: Tr(!1),
                    disabled: Tr(!0),
                    checked: function(_) {
                        var A = _.nodeName.toLowerCase();
                        return A === "input" && !!_.checked || A === "option" && !!_.selected
                    },
                    selected: function(_) {
                        return _.parentNode && _.parentNode.selectedIndex, _.selected === !0
                    },
                    empty: function(_) {
                        for (_ = _.firstChild; _; _ = _.nextSibling)
                            if (_.nodeType < 6) return !1;
                        return !0
                    },
                    parent: function(_) {
                        return !s.pseudos.empty(_)
                    },
                    header: function(_) {
                        return pn.test(_.nodeName)
                    },
                    input: function(_) {
                        return kn.test(_.nodeName)
                    },
                    button: function(_) {
                        var A = _.nodeName.toLowerCase();
                        return A === "input" && _.type === "button" || A === "button"
                    },
                    text: function(_) {
                        var A;
                        return _.nodeName.toLowerCase() === "input" && _.type === "text" && ((A = _.getAttribute("type")) == null || A.toLowerCase() === "text")
                    },
                    first: Ln(function() {
                        return [0]
                    }),
                    last: Ln(function(_, A) {
                        return [A - 1]
                    }),
                    eq: Ln(function(_, A, j) {
                        return [j < 0 ? j + A : j]
                    }),
                    even: Ln(function(_, A) {
                        for (var j = 0; j < A; j += 2) _.push(j);
                        return _
                    }),
                    odd: Ln(function(_, A) {
                        for (var j = 1; j < A; j += 2) _.push(j);
                        return _
                    }),
                    lt: Ln(function(_, A, j) {
                        for (var F = j < 0 ? j + A : A < j ? A : j; 0 <= --F;) _.push(F);
                        return _
                    }),
                    gt: Ln(function(_, A, j) {
                        for (var F = j < 0 ? j + A : j; ++F < A;) _.push(F);
                        return _
                    })
                }
            }).pseudos.nth = s.pseudos.eq, {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            }) s.pseudos[n] = Qr(n);
        for (n in {
                submit: !0,
                reset: !0
            }) s.pseudos[n] = Zr(n);

        function Cr() {}

        function Hi(_) {
            for (var A = 0, j = _.length, F = ""; A < j; A++) F += _[A].value;
            return F
        }

        function Ri(_, A, j) {
            var F = A.dir,
                I = A.next,
                K = I || F,
                Q = j && K === "parentNode",
                te = ee++;
            return A.first ? function(le, ke, we) {
                for (; le = le[F];)
                    if (le.nodeType === 1 || Q) return _(le, ke, we);
                return !1
            } : function(le, ke, we) {
                var Te, Be, ot, Le = [pe, te];
                if (we) {
                    for (; le = le[F];)
                        if ((le.nodeType === 1 || Q) && _(le, ke, we)) return !0
                } else
                    for (; le = le[F];)
                        if (le.nodeType === 1 || Q)
                            if (Be = (ot = le[X] || (le[X] = {}))[le.uniqueID] || (ot[le.uniqueID] = {}), I && I === le.nodeName.toLowerCase()) le = le[F] || le;
                            else {
                                if ((Te = Be[K]) && Te[0] === pe && Te[1] === te) return Le[2] = Te[2];
                                if ((Be[K] = Le)[2] = _(le, ke, we)) return !0
                            } return !1
            }
        }

        function ur(_) {
            return 1 < _.length ? function(A, j, F) {
                for (var I = _.length; I--;)
                    if (!_[I](A, j, F)) return !1;
                return !0
            } : _[0]
        }

        function Bi(_, A, j, F, I) {
            for (var K, Q = [], te = 0, le = _.length, ke = A != null; te < le; te++)(K = _[te]) && (j && !j(K, F, I) || (Q.push(K), ke && A.push(te)));
            return Q
        }

        function dr(_, A, j, F, I, K) {
            return F && !F[X] && (F = dr(F)), I && !I[X] && (I = dr(I, K)), Lt(function(Q, te, le, ke) {
                var we, Te, Be, ot = [],
                    Le = [],
                    ht = te.length,
                    ft = Q || function(Yt, wt, ct) {
                        for (var zt = 0, zi = wt.length; zt < zi; zt++) Ge(Yt, wt[zt], ct);
                        return ct
                    }(A || "*", le.nodeType ? [le] : le, []),
                    Tt = !_ || !Q && A ? ft : Bi(ft, ot, _, le, ke),
                    Ye = j ? I || (Q ? _ : ht || F) ? [] : te : Tt;
                if (j && j(Tt, Ye, le, ke), F)
                    for (we = Bi(Ye, Le), F(we, [], le, ke), Te = we.length; Te--;)(Be = we[Te]) && (Ye[Le[Te]] = !(Tt[Le[Te]] = Be));
                if (Q) {
                    if (I || _) {
                        if (I) {
                            for (we = [], Te = Ye.length; Te--;)(Be = Ye[Te]) && we.push(Tt[Te] = Be);
                            I(null, Ye = [], we, ke)
                        }
                        for (Te = Ye.length; Te--;)(Be = Ye[Te]) && -1 < (we = I ? Ne(Q, Be) : ot[Te]) && (Q[we] = !(te[we] = Be))
                    }
                } else Ye = Bi(Ye === te ? Ye.splice(ht, Ye.length) : Ye), I ? I(null, te, Ye, ke) : _e.apply(te, Ye)
            })
        }

        function hr(_) {
            for (var A, j, F, I = _.length, K = s.relative[_[0].type], Q = K || s.relative[" "], te = K ? 1 : 0, le = Ri(function(Te) {
                    return Te === A
                }, Q, !0), ke = Ri(function(Te) {
                    return -1 < Ne(A, Te)
                }, Q, !0), we = [function(Te, Be, ot) {
                    var Le = !K && (ot || Be !== N) || ((A = Be).nodeType ? le(Te, Be, ot) : ke(Te, Be, ot));
                    return A = null, Le
                }]; te < I; te++)
                if (j = s.relative[_[te].type]) we = [Ri(ur(we), j)];
                else {
                    if ((j = s.filter[_[te].type].apply(null, _[te].matches))[X]) {
                        for (F = ++te; F < I && !s.relative[_[F].type]; F++);
                        return dr(1 < te && ur(we), 1 < te && Hi(_.slice(0, te - 1).concat({
                            value: _[te - 2].type === " " ? "*" : ""
                        })).replace(Je, "$1"), j, te < F && hr(_.slice(te, F)), F < I && hr(_ = _.slice(F)), F < I && Hi(_))
                    }
                    we.push(j)
                }
            return ur(we)
        }
        return Cr.prototype = s.filters = s.pseudos, s.setFilters = new Cr, m = Ge.tokenize = function(_, A) {
            var j, F, I, K, Q, te, le, ke = Ce[_ + " "];
            if (ke) return A ? 0 : ke.slice(0);
            for (Q = _, te = [], le = s.preFilter; Q;) {
                for (K in j && !(F = jt.exec(Q)) || (F && (Q = Q.slice(F[0].length) || Q), te.push(I = [])), j = !1, (F = et.exec(Q)) && (j = F.shift(), I.push({
                        value: j,
                        type: F[0].replace(Je, " ")
                    }), Q = Q.slice(j.length)), s.filter) !(F = st[K].exec(Q)) || le[K] && !(F = le[K](F)) || (j = F.shift(), I.push({
                    value: j,
                    type: K,
                    matches: F
                }), Q = Q.slice(j.length));
                if (!j) break
            }
            return A ? Q.length : Q ? Ge.error(_) : Ce(_, te).slice(0)
        }, S = Ge.compile = function(_, A) {
            var j, F, I, K, Q, te, le = [],
                ke = [],
                we = Ee[_ + " "];
            if (!we) {
                for (A || (A = m(_)), j = A.length; j--;)(we = hr(A[j]))[X] ? le.push(we) : ke.push(we);
                (we = Ee(_, (F = ke, K = 0 < (I = le).length, Q = 0 < F.length, te = function(Te, Be, ot, Le, ht) {
                    var ft, Tt, Ye, Yt = 0,
                        wt = "0",
                        ct = Te && [],
                        zt = [],
                        zi = N,
                        Sr = Te || Q && s.find.TAG("*", ht),
                        kr = pe += zi == null ? 1 : Math.random() || .1,
                        Jr = Sr.length;
                    for (ht && (N = Be == c || Be || ht); wt !== Jr && (ft = Sr[wt]) != null; wt++) {
                        if (Q && ft) {
                            for (Tt = 0, Be || ft.ownerDocument == c || (i(ft), ot = !E); Ye = F[Tt++];)
                                if (Ye(ft, Be || c, ot)) {
                                    Le.push(ft);
                                    break
                                }
                            ht && (pe = kr)
                        }
                        K && ((ft = !Ye && ft) && Yt--, Te && ct.push(ft))
                    }
                    if (Yt += wt, K && wt !== Yt) {
                        for (Tt = 0; Ye = I[Tt++];) Ye(ct, zt, Be, ot);
                        if (Te) {
                            if (0 < Yt)
                                for (; wt--;) ct[wt] || zt[wt] || (zt[wt] = Re.call(Le));
                            zt = Bi(zt)
                        }
                        _e.apply(Le, zt), ht && !Te && 0 < zt.length && 1 < Yt + I.length && Ge.uniqueSort(Le)
                    }
                    return ht && (pe = kr, N = zi), ct
                }, K ? Lt(te) : te))).selector = _
            }
            return we
        }, T = Ge.select = function(_, A, j, F) {
            var I, K, Q, te, le, ke = typeof _ == "function" && _,
                we = !F && m(_ = ke.selector || _);
            if (j = j || [], we.length === 1) {
                if (2 < (K = we[0] = we[0].slice(0)).length && (Q = K[0]).type === "ID" && A.nodeType === 9 && E && s.relative[K[1].type]) {
                    if (!(A = (s.find.ID(Q.matches[0].replace(Bt, Mt), A) || [])[0])) return j;
                    ke && (A = A.parentNode), _ = _.slice(K.shift().value.length)
                }
                for (I = st.needsContext.test(_) ? 0 : K.length; I-- && (Q = K[I], !s.relative[te = Q.type]);)
                    if ((le = s.find[te]) && (F = le(Q.matches[0].replace(Bt, Mt), On.test(K[0].type) && cr(A.parentNode) || A))) {
                        if (K.splice(I, 1), !(_ = F.length && Hi(K))) return _e.apply(j, F), j;
                        break
                    }
            }
            return (ke || S(_, we))(F, A, !E, j, !A || On.test(_) && cr(A.parentNode) || A), j
        }, r.sortStable = X.split("").sort(je).join("") === X, r.detectDuplicates = !!t, i(), r.sortDetached = At(function(_) {
            return 1 & _.compareDocumentPosition(c.createElement("fieldset"))
        }), At(function(_) {
            return _.innerHTML = "<a href='#'></a>", _.firstChild.getAttribute("href") === "#"
        }) || Vn("type|href|height|width", function(_, A, j) {
            if (!j) return _.getAttribute(A, A.toLowerCase() === "type" ? 1 : 2)
        }), r.attributes && At(function(_) {
            return _.innerHTML = "<input/>", _.firstChild.setAttribute("value", ""), _.firstChild.getAttribute("value") === ""
        }) || Vn("value", function(_, A, j) {
            if (!j && _.nodeName.toLowerCase() === "input") return _.defaultValue
        }), At(function(_) {
            return _.getAttribute("disabled") == null
        }) || Vn(Ue, function(_, A, j) {
            var F;
            if (!j) return _[A] === !0 ? A.toLowerCase() : (F = _.getAttributeNode(A)) && F.specified ? F.value : null
        }), Ge
    }(D);
    a.find = St, a.expr = St.selectors, a.expr[":"] = a.expr.pseudos, a.uniqueSort = a.unique = St.uniqueSort, a.text = St.getText, a.isXMLDoc = St.isXML, a.contains = St.contains, a.escapeSelector = St.escape;
    var Et = function(e, n, r) {
            for (var s = [], p = r !== void 0;
                (e = e[n]) && e.nodeType !== 9;)
                if (e.nodeType === 1) {
                    if (p && a(e).is(r)) break;
                    s.push(e)
                }
            return s
        },
        Ut = function(e, n) {
            for (var r = []; e; e = e.nextSibling) e.nodeType === 1 && e !== n && r.push(e);
            return r
        },
        ze = a.expr.match.needsContext;

    function y(e, n) {
        return e.nodeName && e.nodeName.toLowerCase() === n.toLowerCase()
    }
    var x = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;

    function b(e, n, r) {
        return Y(n) ? a.grep(e, function(s, p) {
            return !!n.call(s, p, s) !== r
        }) : n.nodeType ? a.grep(e, function(s) {
            return s === n !== r
        }) : typeof n != "string" ? a.grep(e, function(s) {
            return -1 < B.call(n, s) !== r
        }) : a.filter(n, e, r)
    }
    a.filter = function(e, n, r) {
        var s = n[0];
        return r && (e = ":not(" + e + ")"), n.length === 1 && s.nodeType === 1 ? a.find.matchesSelector(s, e) ? [s] : [] : a.find.matches(e, a.grep(n, function(p) {
            return p.nodeType === 1
        }))
    }, a.fn.extend({
        find: function(e) {
            var n, r, s = this.length,
                p = this;
            if (typeof e != "string") return this.pushStack(a(e).filter(function() {
                for (n = 0; n < s; n++)
                    if (a.contains(p[n], this)) return !0
            }));
            for (r = this.pushStack([]), n = 0; n < s; n++) a.find(e, p[n], r);
            return 1 < s ? a.uniqueSort(r) : r
        },
        filter: function(e) {
            return this.pushStack(b(this, e || [], !1))
        },
        not: function(e) {
            return this.pushStack(b(this, e || [], !0))
        },
        is: function(e) {
            return !!b(this, typeof e == "string" && ze.test(e) ? a(e) : e || [], !1).length
        }
    });
    var f, d = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
    (a.fn.init = function(e, n, r) {
        var s, p;
        if (!e) return this;
        if (r = r || f, typeof e == "string") {
            if (!(s = e[0] === "<" && e[e.length - 1] === ">" && 3 <= e.length ? [null, e, null] : d.exec(e)) || !s[1] && n) return !n || n.jquery ? (n || r).find(e) : this.constructor(n).find(e);
            if (s[1]) {
                if (n = n instanceof a ? n[0] : n, a.merge(this, a.parseHTML(s[1], n && n.nodeType ? n.ownerDocument || n : se, !0)), x.test(s[1]) && a.isPlainObject(n))
                    for (s in n) Y(this[s]) ? this[s](n[s]) : this.attr(s, n[s]);
                return this
            }
            return (p = se.getElementById(s[2])) && (this[0] = p, this.length = 1), this
        }
        return e.nodeType ? (this[0] = e, this.length = 1, this) : Y(e) ? r.ready !== void 0 ? r.ready(e) : e(a) : a.makeArray(e, this)
    }).prototype = a.fn, f = a(se);
    var o = /^(?:parents|prev(?:Until|All))/,
        h = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };

    function u(e, n) {
        for (;
            (e = e[n]) && e.nodeType !== 1;);
        return e
    }
    a.fn.extend({
        has: function(e) {
            var n = a(e, this),
                r = n.length;
            return this.filter(function() {
                for (var s = 0; s < r; s++)
                    if (a.contains(this, n[s])) return !0
            })
        },
        closest: function(e, n) {
            var r, s = 0,
                p = this.length,
                g = [],
                m = typeof e != "string" && a(e);
            if (!ze.test(e)) {
                for (; s < p; s++)
                    for (r = this[s]; r && r !== n; r = r.parentNode)
                        if (r.nodeType < 11 && (m ? -1 < m.index(r) : r.nodeType === 1 && a.find.matchesSelector(r, e))) {
                            g.push(r);
                            break
                        }
            }
            return this.pushStack(1 < g.length ? a.uniqueSort(g) : g)
        },
        index: function(e) {
            return e ? typeof e == "string" ? B.call(a(e), this[0]) : B.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function(e, n) {
            return this.pushStack(a.uniqueSort(a.merge(this.get(), a(e, n))))
        },
        addBack: function(e) {
            return this.add(e == null ? this.prevObject : this.prevObject.filter(e))
        }
    }), a.each({
        parent: function(e) {
            var n = e.parentNode;
            return n && n.nodeType !== 11 ? n : null
        },
        parents: function(e) {
            return Et(e, "parentNode")
        },
        parentsUntil: function(e, n, r) {
            return Et(e, "parentNode", r)
        },
        next: function(e) {
            return u(e, "nextSibling")
        },
        prev: function(e) {
            return u(e, "previousSibling")
        },
        nextAll: function(e) {
            return Et(e, "nextSibling")
        },
        prevAll: function(e) {
            return Et(e, "previousSibling")
        },
        nextUntil: function(e, n, r) {
            return Et(e, "nextSibling", r)
        },
        prevUntil: function(e, n, r) {
            return Et(e, "previousSibling", r)
        },
        siblings: function(e) {
            return Ut((e.parentNode || {}).firstChild, e)
        },
        children: function(e) {
            return Ut(e.firstChild)
        },
        contents: function(e) {
            return e.contentDocument != null && P(e.contentDocument) ? e.contentDocument : (y(e, "template") && (e = e.content || e), a.merge([], e.childNodes))
        }
    }, function(e, n) {
        a.fn[e] = function(r, s) {
            var p = a.map(this, n, r);
            return e.slice(-5) !== "Until" && (s = r), s && typeof s == "string" && (p = a.filter(s, p)), 1 < this.length && (h[e] || a.uniqueSort(p), o.test(e) && p.reverse()), this.pushStack(p)
        }
    });
    var w = /[^\x20\t\r\n\f]+/g;

    function C(e) {
        return e
    }

    function q(e) {
        throw e
    }

    function M(e, n, r, s) {
        var p;
        try {
            e && Y(p = e.promise) ? p.call(e).done(n).fail(r) : e && Y(p = e.then) ? p.call(e, n, r) : n.apply(void 0, [e].slice(s))
        } catch (g) {
            r.apply(void 0, [g])
        }
    }
    a.Callbacks = function(e) {
        var n, r;
        e = typeof e == "string" ? (n = e, r = {}, a.each(n.match(w) || [], function(i, c) {
            r[c] = !0
        }), r) : a.extend({}, e);
        var s, p, g, m, S = [],
            T = [],
            N = -1,
            l = function() {
                for (m = m || e.once, g = s = !0; T.length; N = -1)
                    for (p = T.shift(); ++N < S.length;) S[N].apply(p[0], p[1]) === !1 && e.stopOnFalse && (N = S.length, p = !1);
                e.memory || (p = !1), s = !1, m && (S = p ? [] : "")
            },
            t = {
                add: function() {
                    return S && (p && !s && (N = S.length - 1, T.push(p)), function i(c) {
                        a.each(c, function(v, E) {
                            Y(E) ? e.unique && t.has(E) || S.push(E) : E && E.length && at(E) !== "string" && i(E)
                        })
                    }(arguments), p && !s && l()), this
                },
                remove: function() {
                    return a.each(arguments, function(i, c) {
                        for (var v; - 1 < (v = a.inArray(c, S, v));) S.splice(v, 1), v <= N && N--
                    }), this
                },
                has: function(i) {
                    return i ? -1 < a.inArray(i, S) : 0 < S.length
                },
                empty: function() {
                    return S && (S = []), this
                },
                disable: function() {
                    return m = T = [], S = p = "", this
                },
                disabled: function() {
                    return !S
                },
                lock: function() {
                    return m = T = [], p || s || (S = p = ""), this
                },
                locked: function() {
                    return !!m
                },
                fireWith: function(i, c) {
                    return m || (c = [i, (c = c || []).slice ? c.slice() : c], T.push(c), s || l()), this
                },
                fire: function() {
                    return t.fireWith(this, arguments), this
                },
                fired: function() {
                    return !!g
                }
            };
        return t
    }, a.extend({
        Deferred: function(e) {
            var n = [
                    ["notify", "progress", a.Callbacks("memory"), a.Callbacks("memory"), 2],
                    ["resolve", "done", a.Callbacks("once memory"), a.Callbacks("once memory"), 0, "resolved"],
                    ["reject", "fail", a.Callbacks("once memory"), a.Callbacks("once memory"), 1, "rejected"]
                ],
                r = "pending",
                s = {
                    state: function() {
                        return r
                    },
                    always: function() {
                        return p.done(arguments).fail(arguments), this
                    },
                    catch: function(g) {
                        return s.then(null, g)
                    },
                    pipe: function() {
                        var g = arguments;
                        return a.Deferred(function(m) {
                            a.each(n, function(S, T) {
                                var N = Y(g[T[4]]) && g[T[4]];
                                p[T[1]](function() {
                                    var l = N && N.apply(this, arguments);
                                    l && Y(l.promise) ? l.promise().progress(m.notify).done(m.resolve).fail(m.reject) : m[T[0] + "With"](this, N ? [l] : arguments)
                                })
                            }), g = null
                        }).promise()
                    },
                    then: function(g, m, S) {
                        var T = 0;

                        function N(l, t, i, c) {
                            return function() {
                                var v = this,
                                    E = arguments,
                                    k = function() {
                                        var G, Z;
                                        if (!(l < T)) {
                                            if ((G = i.apply(v, E)) === t.promise()) throw new TypeError("Thenable self-resolution");
                                            Z = G && (typeof G == "object" || typeof G == "function") && G.then, Y(Z) ? c ? Z.call(G, N(T, t, C, c), N(T, t, q, c)) : (T++, Z.call(G, N(T, t, C, c), N(T, t, q, c), N(T, t, C, t.notifyWith))) : (i !== C && (v = void 0, E = [G]), (c || t.resolveWith)(v, E))
                                        }
                                    },
                                    W = c ? k : function() {
                                        try {
                                            k()
                                        } catch (G) {
                                            a.Deferred.exceptionHook && a.Deferred.exceptionHook(G, W.stackTrace), T <= l + 1 && (i !== q && (v = void 0, E = [G]), t.rejectWith(v, E))
                                        }
                                    };
                                l ? W() : (a.Deferred.getStackHook && (W.stackTrace = a.Deferred.getStackHook()), D.setTimeout(W))
                            }
                        }
                        return a.Deferred(function(l) {
                            n[0][3].add(N(0, l, Y(S) ? S : C, l.notifyWith)), n[1][3].add(N(0, l, Y(g) ? g : C)), n[2][3].add(N(0, l, Y(m) ? m : q))
                        }).promise()
                    },
                    promise: function(g) {
                        return g != null ? a.extend(g, s) : s
                    }
                },
                p = {};
            return a.each(n, function(g, m) {
                var S = m[2],
                    T = m[5];
                s[m[1]] = S.add, T && S.add(function() {
                    r = T
                }, n[3 - g][2].disable, n[3 - g][3].disable, n[0][2].lock, n[0][3].lock), S.add(m[3].fire), p[m[0]] = function() {
                    return p[m[0] + "With"](this === p ? void 0 : this, arguments), this
                }, p[m[0] + "With"] = S.fireWith
            }), s.promise(p), e && e.call(p, p), p
        },
        when: function(e) {
            var n = arguments.length,
                r = n,
                s = Array(r),
                p = H.call(arguments),
                g = a.Deferred(),
                m = function(S) {
                    return function(T) {
                        s[S] = this, p[S] = 1 < arguments.length ? H.call(arguments) : T, --n || g.resolveWith(s, p)
                    }
                };
            if (n <= 1 && (M(e, g.done(m(r)).resolve, g.reject, !n), g.state() === "pending" || Y(p[r] && p[r].then))) return g.then();
            for (; r--;) M(p[r], m(r), g.reject);
            return g.promise()
        }
    });
    var ae = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
    a.Deferred.exceptionHook = function(e, n) {
        D.console && D.console.warn && e && ae.test(e.name) && D.console.warn("jQuery.Deferred exception: " + e.message, e.stack, n)
    }, a.readyException = function(e) {
        D.setTimeout(function() {
            throw e
        })
    };
    var ne = a.Deferred();

    function De() {
        se.removeEventListener("DOMContentLoaded", De), D.removeEventListener("load", De), a.ready()
    }
    a.fn.ready = function(e) {
        return ne.then(e).catch(function(n) {
            a.readyException(n)
        }), this
    }, a.extend({
        isReady: !1,
        readyWait: 1,
        ready: function(e) {
            (e === !0 ? --a.readyWait : a.isReady) || (a.isReady = !0) !== e && 0 < --a.readyWait || ne.resolveWith(se, [a])
        }
    }), a.ready.then = ne.then, se.readyState === "complete" || se.readyState !== "loading" && !se.documentElement.doScroll ? D.setTimeout(a.ready) : (se.addEventListener("DOMContentLoaded", De), D.addEventListener("load", De));
    var ge = function(e, n, r, s, p, g, m) {
            var S = 0,
                T = e.length,
                N = r == null;
            if (at(r) === "object")
                for (S in p = !0, r) ge(e, n, S, r[S], !0, g, m);
            else if (s !== void 0 && (p = !0, Y(s) || (m = !0), N && (m ? (n.call(e, s), n = null) : (N = n, n = function(l, t, i) {
                    return N.call(a(l), i)
                })), n))
                for (; S < T; S++) n(e[S], r, m ? s : s.call(e[S], S, n(e[S], r)));
            return p ? e : N ? n.call(e) : T ? n(e[0], r) : g
        },
        ye = /^-ms-/,
        ie = /-([a-z])/g;

    function Ht(e, n) {
        return n.toUpperCase()
    }

    function mt(e) {
        return e.replace(ye, "ms-").replace(ie, Ht)
    }
    var lt = function(e) {
        return e.nodeType === 1 || e.nodeType === 9 || !+e.nodeType
    };

    function ut() {
        this.expando = a.expando + ut.uid++
    }
    ut.uid = 1, ut.prototype = {
        cache: function(e) {
            var n = e[this.expando];
            return n || (n = {}, lt(e) && (e.nodeType ? e[this.expando] = n : Object.defineProperty(e, this.expando, {
                value: n,
                configurable: !0
            }))), n
        },
        set: function(e, n, r) {
            var s, p = this.cache(e);
            if (typeof n == "string") p[mt(n)] = r;
            else
                for (s in n) p[mt(s)] = n[s];
            return p
        },
        get: function(e, n) {
            return n === void 0 ? this.cache(e) : e[this.expando] && e[this.expando][mt(n)]
        },
        access: function(e, n, r) {
            return n === void 0 || n && typeof n == "string" && r === void 0 ? this.get(e, n) : (this.set(e, n, r), r !== void 0 ? r : n)
        },
        remove: function(e, n) {
            var r, s = e[this.expando];
            if (s !== void 0) {
                if (n !== void 0)
                    for (r = (n = Array.isArray(n) ? n.map(mt) : (n = mt(n)) in s ? [n] : n.match(w) || []).length; r--;) delete s[n[r]];
                (n === void 0 || a.isEmptyObject(s)) && (e.nodeType ? e[this.expando] = void 0 : delete e[this.expando])
            }
        },
        hasData: function(e) {
            var n = e[this.expando];
            return n !== void 0 && !a.isEmptyObject(n)
        }
    };
    var he = new ut,
        tt = new ut,
        Yn = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        kt = /[A-Z]/g;

    function yn(e, n, r) {
        var s, p;
        if (r === void 0 && e.nodeType === 1)
            if (s = "data-" + n.replace(kt, "-$&").toLowerCase(), typeof(r = e.getAttribute(s)) == "string") {
                try {
                    r = (p = r) === "true" || p !== "false" && (p === "null" ? null : p === +p + "" ? +p : Yn.test(p) ? JSON.parse(p) : p)
                } catch {}
                tt.set(e, n, r)
            } else r = void 0;
        return r
    }
    a.extend({
        hasData: function(e) {
            return tt.hasData(e) || he.hasData(e)
        },
        data: function(e, n, r) {
            return tt.access(e, n, r)
        },
        removeData: function(e, n) {
            tt.remove(e, n)
        },
        _data: function(e, n, r) {
            return he.access(e, n, r)
        },
        _removeData: function(e, n) {
            he.remove(e, n)
        }
    }), a.fn.extend({
        data: function(e, n) {
            var r, s, p, g = this[0],
                m = g && g.attributes;
            if (e === void 0) {
                if (this.length && (p = tt.get(g), g.nodeType === 1 && !he.get(g, "hasDataAttrs"))) {
                    for (r = m.length; r--;) m[r] && (s = m[r].name).indexOf("data-") === 0 && (s = mt(s.slice(5)), yn(g, s, p[s]));
                    he.set(g, "hasDataAttrs", !0)
                }
                return p
            }
            return typeof e == "object" ? this.each(function() {
                tt.set(this, e)
            }) : ge(this, function(S) {
                var T;
                if (g && S === void 0) return (T = tt.get(g, e)) !== void 0 || (T = yn(g, e)) !== void 0 ? T : void 0;
                this.each(function() {
                    tt.set(this, e, S)
                })
            }, null, n, 1 < arguments.length, null, !0)
        },
        removeData: function(e) {
            return this.each(function() {
                tt.remove(this, e)
            })
        }
    }), a.extend({
        queue: function(e, n, r) {
            var s;
            if (e) return n = (n || "fx") + "queue", s = he.get(e, n), r && (!s || Array.isArray(r) ? s = he.access(e, n, a.makeArray(r)) : s.push(r)), s || []
        },
        dequeue: function(e, n) {
            n = n || "fx";
            var r = a.queue(e, n),
                s = r.length,
                p = r.shift(),
                g = a._queueHooks(e, n);
            p === "inprogress" && (p = r.shift(), s--), p && (n === "fx" && r.unshift("inprogress"), delete g.stop, p.call(e, function() {
                a.dequeue(e, n)
            }, g)), !s && g && g.empty.fire()
        },
        _queueHooks: function(e, n) {
            var r = n + "queueHooks";
            return he.get(e, r) || he.access(e, r, {
                empty: a.Callbacks("once memory").add(function() {
                    he.remove(e, [n + "queue", r])
                })
            })
        }
    }), a.fn.extend({
        queue: function(e, n) {
            var r = 2;
            return typeof e != "string" && (n = e, e = "fx", r--), arguments.length < r ? a.queue(this[0], e) : n === void 0 ? this : this.each(function() {
                var s = a.queue(this, e, n);
                a._queueHooks(this, e), e === "fx" && s[0] !== "inprogress" && a.dequeue(this, e)
            })
        },
        dequeue: function(e) {
            return this.each(function() {
                a.dequeue(this, e)
            })
        },
        clearQueue: function(e) {
            return this.queue(e || "fx", [])
        },
        promise: function(e, n) {
            var r, s = 1,
                p = a.Deferred(),
                g = this,
                m = this.length,
                S = function() {
                    --s || p.resolveWith(g, [g])
                };
            for (typeof e != "string" && (n = e, e = void 0), e = e || "fx"; m--;)(r = he.get(g[m], e + "queueHooks")) && r.empty && (s++, r.empty.add(S));
            return S(), p.promise(n)
        }
    });
    var Pn = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        Dt = new RegExp("^(?:([+-])=|)(" + Pn + ")([a-z%]*)$", "i"),
        We = ["Top", "Right", "Bottom", "Left"],
        R = se.documentElement,
        Se = function(e) {
            return a.contains(e.ownerDocument, e)
        },
        Me = {
            composed: !0
        };
    R.getRootNode && (Se = function(e) {
        return a.contains(e.ownerDocument, e) || e.getRootNode(Me) === e.ownerDocument
    });
    var He = function(e, n) {
        return (e = n || e).style.display === "none" || e.style.display === "" && Se(e) && a.css(e, "display") === "none"
    };

    function nt(e, n, r, s) {
        var p, g, m = 20,
            S = s ? function() {
                return s.cur()
            } : function() {
                return a.css(e, n, "")
            },
            T = S(),
            N = r && r[3] || (a.cssNumber[n] ? "" : "px"),
            l = e.nodeType && (a.cssNumber[n] || N !== "px" && +T) && Dt.exec(a.css(e, n));
        if (l && l[3] !== N) {
            for (T /= 2, N = N || l[3], l = +T || 1; m--;) a.style(e, n, l + N), (1 - g) * (1 - (g = S() / T || .5)) <= 0 && (m = 0), l /= g;
            l *= 2, a.style(e, n, l + N), r = r || []
        }
        return r && (l = +l || +T || 0, p = r[1] ? l + (r[1] + 1) * r[2] : +r[2], s && (s.unit = N, s.start = l, s.end = p)), p
    }
    var Xe = {};

    function pt(e, n) {
        for (var r, s, p, g, m, S, T, N = [], l = 0, t = e.length; l < t; l++)(s = e[l]).style && (r = s.style.display, n ? (r === "none" && (N[l] = he.get(s, "display") || null, N[l] || (s.style.display = "")), s.style.display === "" && He(s) && (N[l] = (T = m = g = void 0, m = (p = s).ownerDocument, S = p.nodeName, (T = Xe[S]) || (g = m.body.appendChild(m.createElement(S)), T = a.css(g, "display"), g.parentNode.removeChild(g), T === "none" && (T = "block"), Xe[S] = T)))) : r !== "none" && (N[l] = "none", he.set(s, "display", r)));
        for (l = 0; l < t; l++) N[l] != null && (e[l].style.display = N[l]);
        return e
    }
    a.fn.extend({
        show: function() {
            return pt(this, !0)
        },
        hide: function() {
            return pt(this)
        },
        toggle: function(e) {
            return typeof e == "boolean" ? e ? this.show() : this.hide() : this.each(function() {
                He(this) ? a(this).show() : a(this).hide()
            })
        }
    });
    var Qe, dt, Rt = /^(?:checkbox|radio)$/i,
        yt = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
        Kn = /^$|^module$|\/(?:java|ecma)script/i;
    Qe = se.createDocumentFragment().appendChild(se.createElement("div")), (dt = se.createElement("input")).setAttribute("type", "radio"), dt.setAttribute("checked", "checked"), dt.setAttribute("name", "t"), Qe.appendChild(dt), oe.checkClone = Qe.cloneNode(!0).cloneNode(!0).lastChild.checked, Qe.innerHTML = "<textarea>x</textarea>", oe.noCloneChecked = !!Qe.cloneNode(!0).lastChild.defaultValue, Qe.innerHTML = "<option></option>", oe.option = !!Qe.lastChild;
    var bt = {
        thead: [1, "<table>", "</table>"],
        col: [2, "<table><colgroup>", "</colgroup></table>"],
        tr: [2, "<table><tbody>", "</tbody></table>"],
        td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
        _default: [0, "", ""]
    };

    function Ze(e, n) {
        var r;
        return r = typeof e.getElementsByTagName < "u" ? e.getElementsByTagName(n || "*") : typeof e.querySelectorAll < "u" ? e.querySelectorAll(n || "*") : [], n === void 0 || n && y(e, n) ? a.merge([e], r) : r
    }

    function It(e, n) {
        for (var r = 0, s = e.length; r < s; r++) he.set(e[r], "globalEval", !n || he.get(n[r], "globalEval"))
    }
    bt.tbody = bt.tfoot = bt.colgroup = bt.caption = bt.thead, bt.th = bt.td, oe.option || (bt.optgroup = bt.option = [1, "<select multiple='multiple'>", "</select>"]);
    var on = /<|&#?\w+;/;

    function qn(e, n, r, s, p) {
        for (var g, m, S, T, N, l, t = n.createDocumentFragment(), i = [], c = 0, v = e.length; c < v; c++)
            if ((g = e[c]) || g === 0)
                if (at(g) === "object") a.merge(i, g.nodeType ? [g] : g);
                else if (on.test(g)) {
            for (m = m || t.appendChild(n.createElement("div")), S = (yt.exec(g) || ["", ""])[1].toLowerCase(), T = bt[S] || bt._default, m.innerHTML = T[1] + a.htmlPrefilter(g) + T[2], l = T[0]; l--;) m = m.lastChild;
            a.merge(i, m.childNodes), (m = t.firstChild).textContent = ""
        } else i.push(n.createTextNode(g));
        for (t.textContent = "", c = 0; g = i[c++];)
            if (s && -1 < a.inArray(g, s)) p && p.push(g);
            else if (N = Se(g), m = Ze(t.appendChild(g), "script"), N && It(m), r)
            for (l = 0; g = m[l++];) Kn.test(g.type || "") && r.push(g);
        return t
    }
    var Xn = /^([^.]*)(?:\.(.+)|)/;

    function _t() {
        return !0
    }

    function an() {
        return !1
    }

    function Ft(e, n) {
        return e === function() {
            try {
                return se.activeElement
            } catch {}
        }() == (n === "focus")
    }

    function ln(e, n, r, s, p, g) {
        var m, S;
        if (typeof n == "object") {
            for (S in typeof r != "string" && (s = s || r, r = void 0), n) ln(e, S, r, s, n[S], g);
            return e
        }
        if (s == null && p == null ? (p = r, s = r = void 0) : p == null && (typeof r == "string" ? (p = s, s = void 0) : (p = s, s = r, r = void 0)), p === !1) p = an;
        else if (!p) return e;
        return g === 1 && (m = p, (p = function(T) {
            return a().off(T), m.apply(this, arguments)
        }).guid = m.guid || (m.guid = a.guid++)), e.each(function() {
            a.event.add(this, n, p, s, r)
        })
    }

    function bn(e, n, r) {
        r ? (he.set(e, n, !1), a.event.add(e, n, {
            namespace: !1,
            handler: function(s) {
                var p, g, m = he.get(this, n);
                if (1 & s.isTrigger && this[n]) {
                    if (m.length)(a.event.special[n] || {}).delegateType && s.stopPropagation();
                    else if (m = H.call(arguments), he.set(this, n, m), p = r(this, n), this[n](), m !== (g = he.get(this, n)) || p ? he.set(this, n, !1) : g = {}, m !== g) return s.stopImmediatePropagation(), s.preventDefault(), g && g.value
                } else m.length && (he.set(this, n, {
                    value: a.event.trigger(a.extend(m[0], a.Event.prototype), m.slice(1), this)
                }), s.stopImmediatePropagation())
            }
        })) : he.get(e, n) === void 0 && a.event.add(e, n, _t)
    }
    a.event = {
        global: {},
        add: function(e, n, r, s, p) {
            var g, m, S, T, N, l, t, i, c, v, E, k = he.get(e);
            if (lt(e))
                for (r.handler && (r = (g = r).handler, p = g.selector), p && a.find.matchesSelector(R, p), r.guid || (r.guid = a.guid++), (T = k.events) || (T = k.events = Object.create(null)), (m = k.handle) || (m = k.handle = function(W) {
                        return typeof a < "u" && a.event.triggered !== W.type ? a.event.dispatch.apply(e, arguments) : void 0
                    }), N = (n = (n || "").match(w) || [""]).length; N--;) c = E = (S = Xn.exec(n[N]) || [])[1], v = (S[2] || "").split(".").sort(), c && (t = a.event.special[c] || {}, c = (p ? t.delegateType : t.bindType) || c, t = a.event.special[c] || {}, l = a.extend({
                    type: c,
                    origType: E,
                    data: s,
                    handler: r,
                    guid: r.guid,
                    selector: p,
                    needsContext: p && a.expr.match.needsContext.test(p),
                    namespace: v.join(".")
                }, g), (i = T[c]) || ((i = T[c] = []).delegateCount = 0, t.setup && t.setup.call(e, s, v, m) !== !1 || e.addEventListener && e.addEventListener(c, m)), t.add && (t.add.call(e, l), l.handler.guid || (l.handler.guid = r.guid)), p ? i.splice(i.delegateCount++, 0, l) : i.push(l), a.event.global[c] = !0)
        },
        remove: function(e, n, r, s, p) {
            var g, m, S, T, N, l, t, i, c, v, E, k = he.hasData(e) && he.get(e);
            if (k && (T = k.events)) {
                for (N = (n = (n || "").match(w) || [""]).length; N--;)
                    if (c = E = (S = Xn.exec(n[N]) || [])[1], v = (S[2] || "").split(".").sort(), c) {
                        for (t = a.event.special[c] || {}, i = T[c = (s ? t.delegateType : t.bindType) || c] || [], S = S[2] && new RegExp("(^|\\.)" + v.join("\\.(?:.*\\.|)") + "(\\.|$)"), m = g = i.length; g--;) l = i[g], !p && E !== l.origType || r && r.guid !== l.guid || S && !S.test(l.namespace) || s && s !== l.selector && (s !== "**" || !l.selector) || (i.splice(g, 1), l.selector && i.delegateCount--, t.remove && t.remove.call(e, l));
                        m && !i.length && (t.teardown && t.teardown.call(e, v, k.handle) !== !1 || a.removeEvent(e, c, k.handle), delete T[c])
                    } else
                        for (c in T) a.event.remove(e, c + n[N], r, s, !0);
                a.isEmptyObject(T) && he.remove(e, "handle events")
            }
        },
        dispatch: function(e) {
            var n, r, s, p, g, m, S = new Array(arguments.length),
                T = a.event.fix(e),
                N = (he.get(this, "events") || Object.create(null))[T.type] || [],
                l = a.event.special[T.type] || {};
            for (S[0] = T, n = 1; n < arguments.length; n++) S[n] = arguments[n];
            if (T.delegateTarget = this, !l.preDispatch || l.preDispatch.call(this, T) !== !1) {
                for (m = a.event.handlers.call(this, T, N), n = 0;
                    (p = m[n++]) && !T.isPropagationStopped();)
                    for (T.currentTarget = p.elem, r = 0;
                        (g = p.handlers[r++]) && !T.isImmediatePropagationStopped();) T.rnamespace && g.namespace !== !1 && !T.rnamespace.test(g.namespace) || (T.handleObj = g, T.data = g.data, (s = ((a.event.special[g.origType] || {}).handle || g.handler).apply(p.elem, S)) !== void 0 && (T.result = s) === !1 && (T.preventDefault(), T.stopPropagation()));
                return l.postDispatch && l.postDispatch.call(this, T), T.result
            }
        },
        handlers: function(e, n) {
            var r, s, p, g, m, S = [],
                T = n.delegateCount,
                N = e.target;
            if (T && N.nodeType && !(e.type === "click" && 1 <= e.button)) {
                for (; N !== this; N = N.parentNode || this)
                    if (N.nodeType === 1 && (e.type !== "click" || N.disabled !== !0)) {
                        for (g = [], m = {}, r = 0; r < T; r++) m[p = (s = n[r]).selector + " "] === void 0 && (m[p] = s.needsContext ? -1 < a(p, this).index(N) : a.find(p, this, null, [N]).length), m[p] && g.push(s);
                        g.length && S.push({
                            elem: N,
                            handlers: g
                        })
                    }
            }
            return N = this, T < n.length && S.push({
                elem: N,
                handlers: n.slice(T)
            }), S
        },
        addProp: function(e, n) {
            Object.defineProperty(a.Event.prototype, e, {
                enumerable: !0,
                configurable: !0,
                get: Y(n) ? function() {
                    if (this.originalEvent) return n(this.originalEvent)
                } : function() {
                    if (this.originalEvent) return this.originalEvent[e]
                },
                set: function(r) {
                    Object.defineProperty(this, e, {
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                        value: r
                    })
                }
            })
        },
        fix: function(e) {
            return e[a.expando] ? e : new a.Event(e)
        },
        special: {
            load: {
                noBubble: !0
            },
            click: {
                setup: function(e) {
                    var n = this || e;
                    return Rt.test(n.type) && n.click && y(n, "input") && bn(n, "click", _t), !1
                },
                trigger: function(e) {
                    var n = this || e;
                    return Rt.test(n.type) && n.click && y(n, "input") && bn(n, "click"), !0
                },
                _default: function(e) {
                    var n = e.target;
                    return Rt.test(n.type) && n.click && y(n, "input") && he.get(n, "click") || y(n, "a")
                }
            },
            beforeunload: {
                postDispatch: function(e) {
                    e.result !== void 0 && e.originalEvent && (e.originalEvent.returnValue = e.result)
                }
            }
        }
    }, a.removeEvent = function(e, n, r) {
        e.removeEventListener && e.removeEventListener(n, r)
    }, a.Event = function(e, n) {
        if (!(this instanceof a.Event)) return new a.Event(e, n);
        e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || e.defaultPrevented === void 0 && e.returnValue === !1 ? _t : an, this.target = e.target && e.target.nodeType === 3 ? e.target.parentNode : e.target, this.currentTarget = e.currentTarget, this.relatedTarget = e.relatedTarget) : this.type = e, n && a.extend(this, n), this.timeStamp = e && e.timeStamp || Date.now(), this[a.expando] = !0
    }, a.Event.prototype = {
        constructor: a.Event,
        isDefaultPrevented: an,
        isPropagationStopped: an,
        isImmediatePropagationStopped: an,
        isSimulated: !1,
        preventDefault: function() {
            var e = this.originalEvent;
            this.isDefaultPrevented = _t, e && !this.isSimulated && e.preventDefault()
        },
        stopPropagation: function() {
            var e = this.originalEvent;
            this.isPropagationStopped = _t, e && !this.isSimulated && e.stopPropagation()
        },
        stopImmediatePropagation: function() {
            var e = this.originalEvent;
            this.isImmediatePropagationStopped = _t, e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation()
        }
    }, a.each({
        altKey: !0,
        bubbles: !0,
        cancelable: !0,
        changedTouches: !0,
        ctrlKey: !0,
        detail: !0,
        eventPhase: !0,
        metaKey: !0,
        pageX: !0,
        pageY: !0,
        shiftKey: !0,
        view: !0,
        char: !0,
        code: !0,
        charCode: !0,
        key: !0,
        keyCode: !0,
        button: !0,
        buttons: !0,
        clientX: !0,
        clientY: !0,
        offsetX: !0,
        offsetY: !0,
        pointerId: !0,
        pointerType: !0,
        screenX: !0,
        screenY: !0,
        targetTouches: !0,
        toElement: !0,
        touches: !0,
        which: !0
    }, a.event.addProp), a.each({
        focus: "focusin",
        blur: "focusout"
    }, function(e, n) {
        a.event.special[e] = {
            setup: function() {
                return bn(this, e, Ft), !1
            },
            trigger: function() {
                return bn(this, e), !0
            },
            _default: function(r) {
                return he.get(r.target, e)
            },
            delegateType: n
        }
    }), a.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout"
    }, function(e, n) {
        a.event.special[e] = {
            delegateType: n,
            bindType: n,
            handle: function(r) {
                var s, p = r.relatedTarget,
                    g = r.handleObj;
                return p && (p === this || a.contains(this, p)) || (r.type = g.origType, s = g.handler.apply(this, arguments), r.type = n), s
            }
        }
    }), a.fn.extend({
        on: function(e, n, r, s) {
            return ln(this, e, n, r, s)
        },
        one: function(e, n, r, s) {
            return ln(this, e, n, r, s, 1)
        },
        off: function(e, n, r) {
            var s, p;
            if (e && e.preventDefault && e.handleObj) return s = e.handleObj, a(e.delegateTarget).off(s.namespace ? s.origType + "." + s.namespace : s.origType, s.selector, s.handler), this;
            if (typeof e == "object") {
                for (p in e) this.off(p, n, e[p]);
                return this
            }
            return n !== !1 && typeof n != "function" || (r = n, n = void 0), r === !1 && (r = an), this.each(function() {
                a.event.remove(this, e, r, n)
            })
        }
    });
    var _n = /<script|<style|<link/i,
        Qn = /checked\s*(?:[^=]|=\s*.checked.)/i,
        Gt = /^\s*<!\[CDATA\[|\]\]>\s*$/g;

    function cn(e, n) {
        return y(e, "table") && y(n.nodeType !== 11 ? n : n.firstChild, "tr") && a(e).children("tbody")[0] || e
    }

    function Mn(e) {
        return e.type = (e.getAttribute("type") !== null) + "/" + e.type, e
    }

    function Hn(e) {
        return (e.type || "").slice(0, 5) === "true/" ? e.type = e.type.slice(5) : e.removeAttribute("type"), e
    }

    function Zn(e, n) {
        var r, s, p, g, m, S;
        if (n.nodeType === 1) {
            if (he.hasData(e) && (S = he.get(e).events))
                for (p in he.remove(n, "handle events"), S)
                    for (r = 0, s = S[p].length; r < s; r++) a.event.add(n, p, S[p][r]);
            tt.hasData(e) && (g = tt.access(e), m = a.extend({}, g), tt.set(n, m))
        }
    }

    function Xt(e, n, r, s) {
        n = U(n);
        var p, g, m, S, T, N, l = 0,
            t = e.length,
            i = t - 1,
            c = n[0],
            v = Y(c);
        if (v || 1 < t && typeof c == "string" && !oe.checkClone && Qn.test(c)) return e.each(function(E) {
            var k = e.eq(E);
            v && (n[0] = c.call(this, E, k.html())), Xt(k, n, r, s)
        });
        if (t && (g = (p = qn(n, e[0].ownerDocument, !1, e, s)).firstChild, p.childNodes.length === 1 && (p = g), g || s)) {
            for (S = (m = a.map(Ze(p, "script"), Mn)).length; l < t; l++) T = p, l !== i && (T = a.clone(T, !0, !0), S && a.merge(m, Ze(T, "script"))), r.call(e[l], T, l);
            if (S)
                for (N = m[m.length - 1].ownerDocument, a.map(m, Hn), l = 0; l < S; l++) T = m[l], Kn.test(T.type || "") && !he.access(T, "globalEval") && a.contains(N, T) && (T.src && (T.type || "").toLowerCase() !== "module" ? a._evalUrl && !T.noModule && a._evalUrl(T.src, {
                    nonce: T.nonce || T.getAttribute("nonce")
                }, N) : gt(T.textContent.replace(Gt, ""), T, N))
        }
        return e
    }

    function Jn(e, n, r) {
        for (var s, p = n ? a.filter(n, e) : e, g = 0;
            (s = p[g]) != null; g++) r || s.nodeType !== 1 || a.cleanData(Ze(s)), s.parentNode && (r && Se(s) && It(Ze(s, "script")), s.parentNode.removeChild(s));
        return e
    }
    a.extend({
        htmlPrefilter: function(e) {
            return e
        },
        clone: function(e, n, r) {
            var s, p, g, m, S, T, N, l = e.cloneNode(!0),
                t = Se(e);
            if (!(oe.noCloneChecked || e.nodeType !== 1 && e.nodeType !== 11 || a.isXMLDoc(e)))
                for (m = Ze(l), s = 0, p = (g = Ze(e)).length; s < p; s++) S = g[s], T = m[s], (N = T.nodeName.toLowerCase()) === "input" && Rt.test(S.type) ? T.checked = S.checked : N !== "input" && N !== "textarea" || (T.defaultValue = S.defaultValue);
            if (n)
                if (r)
                    for (g = g || Ze(e), m = m || Ze(l), s = 0, p = g.length; s < p; s++) Zn(g[s], m[s]);
                else Zn(e, l);
            return 0 < (m = Ze(l, "script")).length && It(m, !t && Ze(e, "script")), l
        },
        cleanData: function(e) {
            for (var n, r, s, p = a.event.special, g = 0;
                (r = e[g]) !== void 0; g++)
                if (lt(r)) {
                    if (n = r[he.expando]) {
                        if (n.events)
                            for (s in n.events) p[s] ? a.event.remove(r, s) : a.removeEvent(r, s, n.handle);
                        r[he.expando] = void 0
                    }
                    r[tt.expando] && (r[tt.expando] = void 0)
                }
        }
    }), a.fn.extend({
        detach: function(e) {
            return Jn(this, e, !0)
        },
        remove: function(e) {
            return Jn(this, e)
        },
        text: function(e) {
            return ge(this, function(n) {
                return n === void 0 ? a.text(this) : this.empty().each(function() {
                    this.nodeType !== 1 && this.nodeType !== 11 && this.nodeType !== 9 || (this.textContent = n)
                })
            }, null, e, arguments.length)
        },
        append: function() {
            return Xt(this, arguments, function(e) {
                this.nodeType !== 1 && this.nodeType !== 11 && this.nodeType !== 9 || cn(this, e).appendChild(e)
            })
        },
        prepend: function() {
            return Xt(this, arguments, function(e) {
                if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
                    var n = cn(this, e);
                    n.insertBefore(e, n.firstChild)
                }
            })
        },
        before: function() {
            return Xt(this, arguments, function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this)
            })
        },
        after: function() {
            return Xt(this, arguments, function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
            })
        },
        empty: function() {
            for (var e, n = 0;
                (e = this[n]) != null; n++) e.nodeType === 1 && (a.cleanData(Ze(e, !1)), e.textContent = "");
            return this
        },
        clone: function(e, n) {
            return e = e != null && e, n = n ? ? e, this.map(function() {
                return a.clone(this, e, n)
            })
        },
        html: function(e) {
            return ge(this, function(n) {
                var r = this[0] || {},
                    s = 0,
                    p = this.length;
                if (n === void 0 && r.nodeType === 1) return r.innerHTML;
                if (typeof n == "string" && !_n.test(n) && !bt[(yt.exec(n) || ["", ""])[1].toLowerCase()]) {
                    n = a.htmlPrefilter(n);
                    try {
                        for (; s < p; s++)(r = this[s] || {}).nodeType === 1 && (a.cleanData(Ze(r, !1)), r.innerHTML = n);
                        r = 0
                    } catch {}
                }
                r && this.empty().append(n)
            }, null, e, arguments.length)
        },
        replaceWith: function() {
            var e = [];
            return Xt(this, arguments, function(n) {
                var r = this.parentNode;
                a.inArray(this, e) < 0 && (a.cleanData(Ze(this)), r && r.replaceChild(n, this))
            }, e)
        }
    }), a.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function(e, n) {
        a.fn[e] = function(r) {
            for (var s, p = [], g = a(r), m = g.length - 1, S = 0; S <= m; S++) s = S === m ? this : this.clone(!0), a(g[S])[n](s), J.apply(p, s.get());
            return this.pushStack(p)
        }
    });
    var ei = new RegExp("^(" + Pn + ")(?!px)[a-z%]+$", "i"),
        Rn = /^--/,
        un = function(e) {
            var n = e.ownerDocument.defaultView;
            return n && n.opener || (n = D), n.getComputedStyle(e)
        },
        wn = function(e, n, r) {
            var s, p, g = {};
            for (p in n) g[p] = e.style[p], e.style[p] = n[p];
            for (p in s = r.call(e), n) e.style[p] = g[p];
            return s
        },
        ti = new RegExp(We.join("|"), "i"),
        bi = "[\\x20\\t\\r\\n\\f]",
        Bn = new RegExp("^" + bi + "+|((?:^|[^\\\\])(?:\\\\.)*)" + bi + "+$", "g");

    function xn(e, n, r) {
        var s, p, g, m, S = Rn.test(n),
            T = e.style;
        return (r = r || un(e)) && (m = r.getPropertyValue(n) || r[n], S && m && (m = m.replace(Bn, "$1") || void 0), m !== "" || Se(e) || (m = a.style(e, n)), !oe.pixelBoxStyles() && ei.test(m) && ti.test(n) && (s = T.width, p = T.minWidth, g = T.maxWidth, T.minWidth = T.maxWidth = T.width = m, m = r.width, T.width = s, T.minWidth = p, T.maxWidth = g)), m !== void 0 ? m + "" : m
    }

    function ni(e, n) {
        return {
            get: function() {
                if (!e()) return (this.get = n).apply(this, arguments);
                delete this.get
            }
        }
    }(function() {
        function e() {
            if (N) {
                T.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0", N.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%", R.appendChild(T).appendChild(N);
                var l = D.getComputedStyle(N);
                r = l.top !== "1%", S = n(l.marginLeft) === 12, N.style.right = "60%", g = n(l.right) === 36, s = n(l.width) === 36, N.style.position = "absolute", p = n(N.offsetWidth / 3) === 12, R.removeChild(T), N = null
            }
        }

        function n(l) {
            return Math.round(parseFloat(l))
        }
        var r, s, p, g, m, S, T = se.createElement("div"),
            N = se.createElement("div");
        N.style && (N.style.backgroundClip = "content-box", N.cloneNode(!0).style.backgroundClip = "", oe.clearCloneStyle = N.style.backgroundClip === "content-box", a.extend(oe, {
            boxSizingReliable: function() {
                return e(), s
            },
            pixelBoxStyles: function() {
                return e(), g
            },
            pixelPosition: function() {
                return e(), r
            },
            reliableMarginLeft: function() {
                return e(), S
            },
            scrollboxSize: function() {
                return e(), p
            },
            reliableTrDimensions: function() {
                var l, t, i, c;
                return m == null && (l = se.createElement("table"), t = se.createElement("tr"), i = se.createElement("div"), l.style.cssText = "position:absolute;left:-11111px;border-collapse:separate", t.style.cssText = "border:1px solid", t.style.height = "1px", i.style.height = "9px", i.style.display = "block", R.appendChild(l).appendChild(t).appendChild(i), c = D.getComputedStyle(t), m = parseInt(c.height, 10) + parseInt(c.borderTopWidth, 10) + parseInt(c.borderBottomWidth, 10) === t.offsetHeight, R.removeChild(l)), m
            }
        }))
    })();
    var zn = ["Webkit", "Moz", "ms"],
        Wn = se.createElement("div").style,
        Un = {};

    function Qt(e) {
        var n = a.cssProps[e] || Un[e];
        return n || (e in Wn ? e : Un[e] = function(r) {
            for (var s = r[0].toUpperCase() + r.slice(1), p = zn.length; p--;)
                if ((r = zn[p] + s) in Wn) return r
        }(e) || e)
    }
    var ii = /^(none|table(?!-c[ea]).+)/,
        _i = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        dn = {
            letterSpacing: "0",
            fontWeight: "400"
        };

    function ri(e, n, r) {
        var s = Dt.exec(n);
        return s ? Math.max(0, s[2] - (r || 0)) + (s[3] || "px") : n
    }

    function Vt(e, n, r, s, p, g) {
        var m = n === "width" ? 1 : 0,
            S = 0,
            T = 0;
        if (r === (s ? "border" : "content")) return 0;
        for (; m < 4; m += 2) r === "margin" && (T += a.css(e, r + We[m], !0, p)), s ? (r === "content" && (T -= a.css(e, "padding" + We[m], !0, p)), r !== "margin" && (T -= a.css(e, "border" + We[m] + "Width", !0, p))) : (T += a.css(e, "padding" + We[m], !0, p), r !== "padding" ? T += a.css(e, "border" + We[m] + "Width", !0, p) : S += a.css(e, "border" + We[m] + "Width", !0, p));
        return !s && 0 <= g && (T += Math.max(0, Math.ceil(e["offset" + n[0].toUpperCase() + n.slice(1)] - g - T - S - .5)) || 0), T
    }

    function wi(e, n, r) {
        var s = un(e),
            p = (!oe.boxSizingReliable() || r) && a.css(e, "boxSizing", !1, s) === "border-box",
            g = p,
            m = xn(e, n, s),
            S = "offset" + n[0].toUpperCase() + n.slice(1);
        if (ei.test(m)) {
            if (!r) return m;
            m = "auto"
        }
        return (!oe.boxSizingReliable() && p || !oe.reliableTrDimensions() && y(e, "tr") || m === "auto" || !parseFloat(m) && a.css(e, "display", !1, s) === "inline") && e.getClientRects().length && (p = a.css(e, "boxSizing", !1, s) === "border-box", (g = S in e) && (m = e[S])), (m = parseFloat(m) || 0) + Vt(e, n, r || (p ? "border" : "content"), g, s, m) + "px"
    }

    function Ot(e, n, r, s, p) {
        return new Ot.prototype.init(e, n, r, s, p)
    }
    a.extend({
        cssHooks: {
            opacity: {
                get: function(e, n) {
                    if (n) {
                        var r = xn(e, "opacity");
                        return r === "" ? "1" : r
                    }
                }
            }
        },
        cssNumber: {
            animationIterationCount: !0,
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            gridArea: !0,
            gridColumn: !0,
            gridColumnEnd: !0,
            gridColumnStart: !0,
            gridRow: !0,
            gridRowEnd: !0,
            gridRowStart: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {},
        style: function(e, n, r, s) {
            if (e && e.nodeType !== 3 && e.nodeType !== 8 && e.style) {
                var p, g, m, S = mt(n),
                    T = Rn.test(n),
                    N = e.style;
                if (T || (n = Qt(S)), m = a.cssHooks[n] || a.cssHooks[S], r === void 0) return m && "get" in m && (p = m.get(e, !1, s)) !== void 0 ? p : N[n];
                (g = typeof r) == "string" && (p = Dt.exec(r)) && p[1] && (r = nt(e, n, p), g = "number"), r != null && r == r && (g !== "number" || T || (r += p && p[3] || (a.cssNumber[S] ? "" : "px")), oe.clearCloneStyle || r !== "" || n.indexOf("background") !== 0 || (N[n] = "inherit"), m && "set" in m && (r = m.set(e, r, s)) === void 0 || (T ? N.setProperty(n, r) : N[n] = r))
            }
        },
        css: function(e, n, r, s) {
            var p, g, m, S = mt(n);
            return Rn.test(n) || (n = Qt(S)), (m = a.cssHooks[n] || a.cssHooks[S]) && "get" in m && (p = m.get(e, !0, r)), p === void 0 && (p = xn(e, n, s)), p === "normal" && n in dn && (p = dn[n]), r === "" || r ? (g = parseFloat(p), r === !0 || isFinite(g) ? g || 0 : p) : p
        }
    }), a.each(["height", "width"], function(e, n) {
        a.cssHooks[n] = {
            get: function(r, s, p) {
                if (s) return !ii.test(a.css(r, "display")) || r.getClientRects().length && r.getBoundingClientRect().width ? wi(r, n, p) : wn(r, _i, function() {
                    return wi(r, n, p)
                })
            },
            set: function(r, s, p) {
                var g, m = un(r),
                    S = !oe.scrollboxSize() && m.position === "absolute",
                    T = (S || p) && a.css(r, "boxSizing", !1, m) === "border-box",
                    N = p ? Vt(r, n, p, T, m) : 0;
                return T && S && (N -= Math.ceil(r["offset" + n[0].toUpperCase() + n.slice(1)] - parseFloat(m[n]) - Vt(r, n, "border", !1, m) - .5)), N && (g = Dt.exec(s)) && (g[3] || "px") !== "px" && (r.style[n] = s, s = a.css(r, n)), ri(0, s, N)
            }
        }
    }), a.cssHooks.marginLeft = ni(oe.reliableMarginLeft, function(e, n) {
        if (n) return (parseFloat(xn(e, "marginLeft")) || e.getBoundingClientRect().left - wn(e, {
            marginLeft: 0
        }, function() {
            return e.getBoundingClientRect().left
        })) + "px"
    }), a.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function(e, n) {
        a.cssHooks[e + n] = {
            expand: function(r) {
                for (var s = 0, p = {}, g = typeof r == "string" ? r.split(" ") : [r]; s < 4; s++) p[e + We[s] + n] = g[s] || g[s - 2] || g[0];
                return p
            }
        }, e !== "margin" && (a.cssHooks[e + n].set = ri)
    }), a.fn.extend({
        css: function(e, n) {
            return ge(this, function(r, s, p) {
                var g, m, S = {},
                    T = 0;
                if (Array.isArray(s)) {
                    for (g = un(r), m = s.length; T < m; T++) S[s[T]] = a.css(r, s[T], !1, g);
                    return S
                }
                return p !== void 0 ? a.style(r, s, p) : a.css(r, s)
            }, e, n, 1 < arguments.length)
        }
    }), ((a.Tween = Ot).prototype = {
        constructor: Ot,
        init: function(e, n, r, s, p, g) {
            this.elem = e, this.prop = r, this.easing = p || a.easing._default, this.options = n, this.start = this.now = this.cur(), this.end = s, this.unit = g || (a.cssNumber[r] ? "" : "px")
        },
        cur: function() {
            var e = Ot.propHooks[this.prop];
            return e && e.get ? e.get(this) : Ot.propHooks._default.get(this)
        },
        run: function(e) {
            var n, r = Ot.propHooks[this.prop];
            return this.options.duration ? this.pos = n = a.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = n = e, this.now = (this.end - this.start) * n + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), r && r.set ? r.set(this) : Ot.propHooks._default.set(this), this
        }
    }).init.prototype = Ot.prototype, (Ot.propHooks = {
        _default: {
            get: function(e) {
                var n;
                return e.elem.nodeType !== 1 || e.elem[e.prop] != null && e.elem.style[e.prop] == null ? e.elem[e.prop] : (n = a.css(e.elem, e.prop, "")) && n !== "auto" ? n : 0
            },
            set: function(e) {
                a.fx.step[e.prop] ? a.fx.step[e.prop](e) : e.elem.nodeType !== 1 || !a.cssHooks[e.prop] && e.elem.style[Qt(e.prop)] == null ? e.elem[e.prop] = e.now : a.style(e.elem, e.prop, e.now + e.unit)
            }
        }
    }).scrollTop = Ot.propHooks.scrollLeft = {
        set: function(e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    }, a.easing = {
        linear: function(e) {
            return e
        },
        swing: function(e) {
            return .5 - Math.cos(e * Math.PI) / 2
        },
        _default: "swing"
    }, a.fx = Ot.prototype.init, a.fx.step = {};
    var Zt, En, Jt, si, oi = /^(?:toggle|show|hide)$/,
        xi = /queueHooks$/;

    function ai() {
        En && (se.hidden === !1 && D.requestAnimationFrame ? D.requestAnimationFrame(ai) : D.setTimeout(ai, a.fx.interval), a.fx.tick())
    }

    function li() {
        return D.setTimeout(function() {
            Zt = void 0
        }), Zt = Date.now()
    }

    function An(e, n) {
        var r, s = 0,
            p = {
                height: e
            };
        for (n = n ? 1 : 0; s < 4; s += 2 - n) p["margin" + (r = We[s])] = p["padding" + r] = e;
        return n && (p.opacity = p.width = e), p
    }

    function Tn(e, n, r) {
        for (var s, p = ($t.tweeners[n] || []).concat($t.tweeners["*"]), g = 0, m = p.length; g < m; g++)
            if (s = p[g].call(r, n, e)) return s
    }

    function $t(e, n, r) {
        var s, p, g = 0,
            m = $t.prefilters.length,
            S = a.Deferred().always(function() {
                delete T.elem
            }),
            T = function() {
                if (p) return !1;
                for (var t = Zt || li(), i = Math.max(0, N.startTime + N.duration - t), c = 1 - (i / N.duration || 0), v = 0, E = N.tweens.length; v < E; v++) N.tweens[v].run(c);
                return S.notifyWith(e, [N, c, i]), c < 1 && E ? i : (E || S.notifyWith(e, [N, 1, 0]), S.resolveWith(e, [N]), !1)
            },
            N = S.promise({
                elem: e,
                props: a.extend({}, n),
                opts: a.extend(!0, {
                    specialEasing: {},
                    easing: a.easing._default
                }, r),
                originalProperties: n,
                originalOptions: r,
                startTime: Zt || li(),
                duration: r.duration,
                tweens: [],
                createTween: function(t, i) {
                    var c = a.Tween(e, N.opts, t, i, N.opts.specialEasing[t] || N.opts.easing);
                    return N.tweens.push(c), c
                },
                stop: function(t) {
                    var i = 0,
                        c = t ? N.tweens.length : 0;
                    if (p) return this;
                    for (p = !0; i < c; i++) N.tweens[i].run(1);
                    return t ? (S.notifyWith(e, [N, 1, 0]), S.resolveWith(e, [N, t])) : S.rejectWith(e, [N, t]), this
                }
            }),
            l = N.props;
        for (! function(t, i) {
                var c, v, E, k, W;
                for (c in t)
                    if (E = i[v = mt(c)], k = t[c], Array.isArray(k) && (E = k[1], k = t[c] = k[0]), c !== v && (t[v] = k, delete t[c]), (W = a.cssHooks[v]) && "expand" in W)
                        for (c in k = W.expand(k), delete t[v], k) c in t || (t[c] = k[c], i[c] = E);
                    else i[v] = E
            }(l, N.opts.specialEasing); g < m; g++)
            if (s = $t.prefilters[g].call(N, e, l, N.opts)) return Y(s.stop) && (a._queueHooks(N.elem, N.opts.queue).stop = s.stop.bind(s)), s;
        return a.map(l, Tn, N), Y(N.opts.start) && N.opts.start.call(e, N), N.progress(N.opts.progress).done(N.opts.done, N.opts.complete).fail(N.opts.fail).always(N.opts.always), a.fx.timer(a.extend(T, {
            elem: e,
            anim: N,
            queue: N.opts.queue
        })), N
    }
    a.Animation = a.extend($t, {
        tweeners: {
            "*": [function(e, n) {
                var r = this.createTween(e, n);
                return nt(r.elem, e, Dt.exec(n), r), r
            }]
        },
        tweener: function(e, n) {
            Y(e) ? (n = e, e = ["*"]) : e = e.match(w);
            for (var r, s = 0, p = e.length; s < p; s++) r = e[s], $t.tweeners[r] = $t.tweeners[r] || [], $t.tweeners[r].unshift(n)
        },
        prefilters: [function(e, n, r) {
            var s, p, g, m, S, T, N, l, t = "width" in n || "height" in n,
                i = this,
                c = {},
                v = e.style,
                E = e.nodeType && He(e),
                k = he.get(e, "fxshow");
            for (s in r.queue || ((m = a._queueHooks(e, "fx")).unqueued == null && (m.unqueued = 0, S = m.empty.fire, m.empty.fire = function() {
                    m.unqueued || S()
                }), m.unqueued++, i.always(function() {
                    i.always(function() {
                        m.unqueued--, a.queue(e, "fx").length || m.empty.fire()
                    })
                })), n)
                if (p = n[s], oi.test(p)) {
                    if (delete n[s], g = g || p === "toggle", p === (E ? "hide" : "show")) {
                        if (p !== "show" || !k || k[s] === void 0) continue;
                        E = !0
                    }
                    c[s] = k && k[s] || a.style(e, s)
                }
            if ((T = !a.isEmptyObject(n)) || !a.isEmptyObject(c))
                for (s in t && e.nodeType === 1 && (r.overflow = [v.overflow, v.overflowX, v.overflowY], (N = k && k.display) == null && (N = he.get(e, "display")), (l = a.css(e, "display")) === "none" && (N ? l = N : (pt([e], !0), N = e.style.display || N, l = a.css(e, "display"), pt([e]))), (l === "inline" || l === "inline-block" && N != null) && a.css(e, "float") === "none" && (T || (i.done(function() {
                        v.display = N
                    }), N == null && (l = v.display, N = l === "none" ? "" : l)), v.display = "inline-block")), r.overflow && (v.overflow = "hidden", i.always(function() {
                        v.overflow = r.overflow[0], v.overflowX = r.overflow[1], v.overflowY = r.overflow[2]
                    })), T = !1, c) T || (k ? "hidden" in k && (E = k.hidden) : k = he.access(e, "fxshow", {
                    display: N
                }), g && (k.hidden = !E), E && pt([e], !0), i.done(function() {
                    for (s in E || pt([e]), he.remove(e, "fxshow"), c) a.style(e, s, c[s])
                })), T = Tn(E ? k[s] : 0, s, i), s in k || (k[s] = T.start, E && (T.end = T.start, T.start = 0))
        }],
        prefilter: function(e, n) {
            n ? $t.prefilters.unshift(e) : $t.prefilters.push(e)
        }
    }), a.speed = function(e, n, r) {
        var s = e && typeof e == "object" ? a.extend({}, e) : {
            complete: r || !r && n || Y(e) && e,
            duration: e,
            easing: r && n || n && !Y(n) && n
        };
        return a.fx.off ? s.duration = 0 : typeof s.duration != "number" && (s.duration in a.fx.speeds ? s.duration = a.fx.speeds[s.duration] : s.duration = a.fx.speeds._default), s.queue != null && s.queue !== !0 || (s.queue = "fx"), s.old = s.complete, s.complete = function() {
            Y(s.old) && s.old.call(this), s.queue && a.dequeue(this, s.queue)
        }, s
    }, a.fn.extend({
        fadeTo: function(e, n, r, s) {
            return this.filter(He).css("opacity", 0).show().end().animate({
                opacity: n
            }, e, r, s)
        },
        animate: function(e, n, r, s) {
            var p = a.isEmptyObject(e),
                g = a.speed(n, r, s),
                m = function() {
                    var S = $t(this, a.extend({}, e), g);
                    (p || he.get(this, "finish")) && S.stop(!0)
                };
            return m.finish = m, p || g.queue === !1 ? this.each(m) : this.queue(g.queue, m)
        },
        stop: function(e, n, r) {
            var s = function(p) {
                var g = p.stop;
                delete p.stop, g(r)
            };
            return typeof e != "string" && (r = n, n = e, e = void 0), n && this.queue(e || "fx", []), this.each(function() {
                var p = !0,
                    g = e != null && e + "queueHooks",
                    m = a.timers,
                    S = he.get(this);
                if (g) S[g] && S[g].stop && s(S[g]);
                else
                    for (g in S) S[g] && S[g].stop && xi.test(g) && s(S[g]);
                for (g = m.length; g--;) m[g].elem !== this || e != null && m[g].queue !== e || (m[g].anim.stop(r), p = !1, m.splice(g, 1));
                !p && r || a.dequeue(this, e)
            })
        },
        finish: function(e) {
            return e !== !1 && (e = e || "fx"), this.each(function() {
                var n, r = he.get(this),
                    s = r[e + "queue"],
                    p = r[e + "queueHooks"],
                    g = a.timers,
                    m = s ? s.length : 0;
                for (r.finish = !0, a.queue(this, e, []), p && p.stop && p.stop.call(this, !0), n = g.length; n--;) g[n].elem === this && g[n].queue === e && (g[n].anim.stop(!0), g.splice(n, 1));
                for (n = 0; n < m; n++) s[n] && s[n].finish && s[n].finish.call(this);
                delete r.finish
            })
        }
    }), a.each(["toggle", "show", "hide"], function(e, n) {
        var r = a.fn[n];
        a.fn[n] = function(s, p, g) {
            return s == null || typeof s == "boolean" ? r.apply(this, arguments) : this.animate(An(n, !0), s, p, g)
        }
    }), a.each({
        slideDown: An("show"),
        slideUp: An("hide"),
        slideToggle: An("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    }, function(e, n) {
        a.fn[e] = function(r, s, p) {
            return this.animate(n, r, s, p)
        }
    }), a.timers = [], a.fx.tick = function() {
        var e, n = 0,
            r = a.timers;
        for (Zt = Date.now(); n < r.length; n++)(e = r[n])() || r[n] !== e || r.splice(n--, 1);
        r.length || a.fx.stop(), Zt = void 0
    }, a.fx.timer = function(e) {
        a.timers.push(e), a.fx.start()
    }, a.fx.interval = 13, a.fx.start = function() {
        En || (En = !0, ai())
    }, a.fx.stop = function() {
        En = null
    }, a.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    }, a.fn.delay = function(e, n) {
        return e = a.fx && a.fx.speeds[e] || e, n = n || "fx", this.queue(n, function(r, s) {
            var p = D.setTimeout(r, e);
            s.stop = function() {
                D.clearTimeout(p)
            }
        })
    }, Jt = se.createElement("input"), si = se.createElement("select").appendChild(se.createElement("option")), Jt.type = "checkbox", oe.checkOn = Jt.value !== "", oe.optSelected = si.selected, (Jt = se.createElement("input")).value = "t", Jt.type = "radio", oe.radioValue = Jt.value === "t";
    var Ei, en = a.expr.attrHandle;
    a.fn.extend({
        attr: function(e, n) {
            return ge(this, a.attr, e, n, 1 < arguments.length)
        },
        removeAttr: function(e) {
            return this.each(function() {
                a.removeAttr(this, e)
            })
        }
    }), a.extend({
        attr: function(e, n, r) {
            var s, p, g = e.nodeType;
            if (g !== 3 && g !== 8 && g !== 2) return typeof e.getAttribute > "u" ? a.prop(e, n, r) : (g === 1 && a.isXMLDoc(e) || (p = a.attrHooks[n.toLowerCase()] || (a.expr.match.bool.test(n) ? Ei : void 0)), r !== void 0 ? r === null ? void a.removeAttr(e, n) : p && "set" in p && (s = p.set(e, r, n)) !== void 0 ? s : (e.setAttribute(n, r + ""), r) : p && "get" in p && (s = p.get(e, n)) !== null ? s : (s = a.find.attr(e, n)) == null ? void 0 : s)
        },
        attrHooks: {
            type: {
                set: function(e, n) {
                    if (!oe.radioValue && n === "radio" && y(e, "input")) {
                        var r = e.value;
                        return e.setAttribute("type", n), r && (e.value = r), n
                    }
                }
            }
        },
        removeAttr: function(e, n) {
            var r, s = 0,
                p = n && n.match(w);
            if (p && e.nodeType === 1)
                for (; r = p[s++];) e.removeAttribute(r)
        }
    }), Ei = {
        set: function(e, n, r) {
            return n === !1 ? a.removeAttr(e, r) : e.setAttribute(r, r), r
        }
    }, a.each(a.expr.match.bool.source.match(/\w+/g), function(e, n) {
        var r = en[n] || a.find.attr;
        en[n] = function(s, p, g) {
            var m, S, T = p.toLowerCase();
            return g || (S = en[T], en[T] = m, m = r(s, p, g) != null ? T : null, en[T] = S), m
        }
    });
    var Ai = /^(?:input|select|textarea|button)$/i,
        Ji = /^(?:a|area)$/i;

    function tn(e) {
        return (e.match(w) || []).join(" ")
    }

    function nn(e) {
        return e.getAttribute && e.getAttribute("class") || ""
    }

    function ci(e) {
        return Array.isArray(e) ? e : typeof e == "string" && e.match(w) || []
    }
    a.fn.extend({
        prop: function(e, n) {
            return ge(this, a.prop, e, n, 1 < arguments.length)
        },
        removeProp: function(e) {
            return this.each(function() {
                delete this[a.propFix[e] || e]
            })
        }
    }), a.extend({
        prop: function(e, n, r) {
            var s, p, g = e.nodeType;
            if (g !== 3 && g !== 8 && g !== 2) return g === 1 && a.isXMLDoc(e) || (n = a.propFix[n] || n, p = a.propHooks[n]), r !== void 0 ? p && "set" in p && (s = p.set(e, r, n)) !== void 0 ? s : e[n] = r : p && "get" in p && (s = p.get(e, n)) !== null ? s : e[n]
        },
        propHooks: {
            tabIndex: {
                get: function(e) {
                    var n = a.find.attr(e, "tabindex");
                    return n ? parseInt(n, 10) : Ai.test(e.nodeName) || Ji.test(e.nodeName) && e.href ? 0 : -1
                }
            }
        },
        propFix: {
            for: "htmlFor",
            class: "className"
        }
    }), oe.optSelected || (a.propHooks.selected = {
        get: function(e) {
            var n = e.parentNode;
            return n && n.parentNode && n.parentNode.selectedIndex, null
        },
        set: function(e) {
            var n = e.parentNode;
            n && (n.selectedIndex, n.parentNode && n.parentNode.selectedIndex)
        }
    }), a.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
        a.propFix[this.toLowerCase()] = this
    }), a.fn.extend({
        addClass: function(e) {
            var n, r, s, p, g, m;
            return Y(e) ? this.each(function(S) {
                a(this).addClass(e.call(this, S, nn(this)))
            }) : (n = ci(e)).length ? this.each(function() {
                if (s = nn(this), r = this.nodeType === 1 && " " + tn(s) + " ") {
                    for (g = 0; g < n.length; g++) p = n[g], r.indexOf(" " + p + " ") < 0 && (r += p + " ");
                    m = tn(r), s !== m && this.setAttribute("class", m)
                }
            }) : this
        },
        removeClass: function(e) {
            var n, r, s, p, g, m;
            return Y(e) ? this.each(function(S) {
                a(this).removeClass(e.call(this, S, nn(this)))
            }) : arguments.length ? (n = ci(e)).length ? this.each(function() {
                if (s = nn(this), r = this.nodeType === 1 && " " + tn(s) + " ") {
                    for (g = 0; g < n.length; g++)
                        for (p = n[g]; - 1 < r.indexOf(" " + p + " ");) r = r.replace(" " + p + " ", " ");
                    m = tn(r), s !== m && this.setAttribute("class", m)
                }
            }) : this : this.attr("class", "")
        },
        toggleClass: function(e, n) {
            var r, s, p, g, m = typeof e,
                S = m === "string" || Array.isArray(e);
            return Y(e) ? this.each(function(T) {
                a(this).toggleClass(e.call(this, T, nn(this), n), n)
            }) : typeof n == "boolean" && S ? n ? this.addClass(e) : this.removeClass(e) : (r = ci(e), this.each(function() {
                if (S)
                    for (g = a(this), p = 0; p < r.length; p++) s = r[p], g.hasClass(s) ? g.removeClass(s) : g.addClass(s);
                else e !== void 0 && m !== "boolean" || ((s = nn(this)) && he.set(this, "__className__", s), this.setAttribute && this.setAttribute("class", s || e === !1 ? "" : he.get(this, "__className__") || ""))
            }))
        },
        hasClass: function(e) {
            var n, r, s = 0;
            for (n = " " + e + " "; r = this[s++];)
                if (r.nodeType === 1 && -1 < (" " + tn(nn(r)) + " ").indexOf(n)) return !0;
            return !1
        }
    });
    var er = /\r/g;
    a.fn.extend({
        val: function(e) {
            var n, r, s, p = this[0];
            return arguments.length ? (s = Y(e), this.each(function(g) {
                var m;
                this.nodeType === 1 && ((m = s ? e.call(this, g, a(this).val()) : e) == null ? m = "" : typeof m == "number" ? m += "" : Array.isArray(m) && (m = a.map(m, function(S) {
                    return S == null ? "" : S + ""
                })), (n = a.valHooks[this.type] || a.valHooks[this.nodeName.toLowerCase()]) && "set" in n && n.set(this, m, "value") !== void 0 || (this.value = m))
            })) : p ? (n = a.valHooks[p.type] || a.valHooks[p.nodeName.toLowerCase()]) && "get" in n && (r = n.get(p, "value")) !== void 0 ? r : typeof(r = p.value) == "string" ? r.replace(er, "") : r ? ? "" : void 0
        }
    }), a.extend({
        valHooks: {
            option: {
                get: function(e) {
                    var n = a.find.attr(e, "value");
                    return n ? ? tn(a.text(e))
                }
            },
            select: {
                get: function(e) {
                    var n, r, s, p = e.options,
                        g = e.selectedIndex,
                        m = e.type === "select-one",
                        S = m ? null : [],
                        T = m ? g + 1 : p.length;
                    for (s = g < 0 ? T : m ? g : 0; s < T; s++)
                        if (((r = p[s]).selected || s === g) && !r.disabled && (!r.parentNode.disabled || !y(r.parentNode, "optgroup"))) {
                            if (n = a(r).val(), m) return n;
                            S.push(n)
                        }
                    return S
                },
                set: function(e, n) {
                    for (var r, s, p = e.options, g = a.makeArray(n), m = p.length; m--;)((s = p[m]).selected = -1 < a.inArray(a.valHooks.option.get(s), g)) && (r = !0);
                    return r || (e.selectedIndex = -1), g
                }
            }
        }
    }), a.each(["radio", "checkbox"], function() {
        a.valHooks[this] = {
            set: function(e, n) {
                if (Array.isArray(n)) return e.checked = -1 < a.inArray(a(e).val(), n)
            }
        }, oe.checkOn || (a.valHooks[this].get = function(e) {
            return e.getAttribute("value") === null ? "on" : e.value
        })
    }), oe.focusin = "onfocusin" in D;
    var Ti = /^(?:focusinfocus|focusoutblur)$/,
        Ci = function(e) {
            e.stopPropagation()
        };
    a.extend(a.event, {
        trigger: function(e, n, r, s) {
            var p, g, m, S, T, N, l, t, i = [r || se],
                c = qe.call(e, "type") ? e.type : e,
                v = qe.call(e, "namespace") ? e.namespace.split(".") : [];
            if (g = t = m = r = r || se, r.nodeType !== 3 && r.nodeType !== 8 && !Ti.test(c + a.event.triggered) && (-1 < c.indexOf(".") && (c = (v = c.split(".")).shift(), v.sort()), T = c.indexOf(":") < 0 && "on" + c, (e = e[a.expando] ? e : new a.Event(c, typeof e == "object" && e)).isTrigger = s ? 2 : 3, e.namespace = v.join("."), e.rnamespace = e.namespace ? new RegExp("(^|\\.)" + v.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = void 0, e.target || (e.target = r), n = n == null ? [e] : a.makeArray(n, [e]), l = a.event.special[c] || {}, s || !l.trigger || l.trigger.apply(r, n) !== !1)) {
                if (!s && !l.noBubble && !fe(r)) {
                    for (S = l.delegateType || c, Ti.test(S + c) || (g = g.parentNode); g; g = g.parentNode) i.push(g), m = g;
                    m === (r.ownerDocument || se) && i.push(m.defaultView || m.parentWindow || D)
                }
                for (p = 0;
                    (g = i[p++]) && !e.isPropagationStopped();) t = g, e.type = 1 < p ? S : l.bindType || c, (N = (he.get(g, "events") || Object.create(null))[e.type] && he.get(g, "handle")) && N.apply(g, n), (N = T && g[T]) && N.apply && lt(g) && (e.result = N.apply(g, n), e.result === !1 && e.preventDefault());
                return e.type = c, s || e.isDefaultPrevented() || l._default && l._default.apply(i.pop(), n) !== !1 || !lt(r) || T && Y(r[c]) && !fe(r) && ((m = r[T]) && (r[T] = null), a.event.triggered = c, e.isPropagationStopped() && t.addEventListener(c, Ci), r[c](), e.isPropagationStopped() && t.removeEventListener(c, Ci), a.event.triggered = void 0, m && (r[T] = m)), e.result
            }
        },
        simulate: function(e, n, r) {
            var s = a.extend(new a.Event, r, {
                type: e,
                isSimulated: !0
            });
            a.event.trigger(s, null, n)
        }
    }), a.fn.extend({
        trigger: function(e, n) {
            return this.each(function() {
                a.event.trigger(e, n, this)
            })
        },
        triggerHandler: function(e, n) {
            var r = this[0];
            if (r) return a.event.trigger(e, n, r, !0)
        }
    }), oe.focusin || a.each({
        focus: "focusin",
        blur: "focusout"
    }, function(e, n) {
        var r = function(s) {
            a.event.simulate(n, s.target, a.event.fix(s))
        };
        a.event.special[n] = {
            setup: function() {
                var s = this.ownerDocument || this.document || this,
                    p = he.access(s, n);
                p || s.addEventListener(e, r, !0), he.access(s, n, (p || 0) + 1)
            },
            teardown: function() {
                var s = this.ownerDocument || this.document || this,
                    p = he.access(s, n) - 1;
                p ? he.access(s, n, p) : (s.removeEventListener(e, r, !0), he.remove(s, n))
            }
        }
    });
    var Cn = D.location,
        Si = {
            guid: Date.now()
        },
        vt = /\?/;
    a.parseXML = function(e) {
        var n, r;
        if (!e || typeof e != "string") return null;
        try {
            n = new D.DOMParser().parseFromString(e, "text/xml")
        } catch {}
        return r = n && n.getElementsByTagName("parsererror")[0], n && !r || a.error("Invalid XML: " + (r ? a.map(r.childNodes, function(s) {
            return s.textContent
        }).join(`
`) : e)), n
    };
    var ui = /\[\]$/,
        ki = /\r?\n/g,
        tr = /^(?:submit|button|image|reset|file)$/i,
        Di = /^(?:input|select|textarea|keygen)/i;

    function di(e, n, r, s) {
        var p;
        if (Array.isArray(n)) a.each(n, function(g, m) {
            r || ui.test(e) ? s(e, m) : di(e + "[" + (typeof m == "object" && m != null ? g : "") + "]", m, r, s)
        });
        else if (r || at(n) !== "object") s(e, n);
        else
            for (p in n) di(e + "[" + p + "]", n[p], r, s)
    }
    a.param = function(e, n) {
        var r, s = [],
            p = function(g, m) {
                var S = Y(m) ? m() : m;
                s[s.length] = encodeURIComponent(g) + "=" + encodeURIComponent(S ? ? "")
            };
        if (e == null) return "";
        if (Array.isArray(e) || e.jquery && !a.isPlainObject(e)) a.each(e, function() {
            p(this.name, this.value)
        });
        else
            for (r in e) di(r, e[r], n, p);
        return s.join("&")
    }, a.fn.extend({
        serialize: function() {
            return a.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map(function() {
                var e = a.prop(this, "elements");
                return e ? a.makeArray(e) : this
            }).filter(function() {
                var e = this.type;
                return this.name && !a(this).is(":disabled") && Di.test(this.nodeName) && !tr.test(e) && (this.checked || !Rt.test(e))
            }).map(function(e, n) {
                var r = a(this).val();
                return r == null ? null : Array.isArray(r) ? a.map(r, function(s) {
                    return {
                        name: n.name,
                        value: s.replace(ki, `\r
`)
                    }
                }) : {
                    name: n.name,
                    value: r.replace(ki, `\r
`)
                }
            }).get()
        }
    });
    var nr = /%20/g,
        Oi = /#.*$/,
        Li = /([?&])_=[^&]*/,
        ir = /^(.*?):[ \t]*([^\r\n]*)$/gm,
        hn = /^(?:GET|HEAD)$/,
        $i = /^\/\//,
        ji = {},
        Pt = {},
        Ni = "*/".concat("*"),
        hi = se.createElement("a");

    function Ii(e) {
        return function(n, r) {
            typeof n != "string" && (r = n, n = "*");
            var s, p = 0,
                g = n.toLowerCase().match(w) || [];
            if (Y(r))
                for (; s = g[p++];) s[0] === "+" ? (s = s.slice(1) || "*", (e[s] = e[s] || []).unshift(r)) : (e[s] = e[s] || []).push(r)
        }
    }

    function Pi(e, n, r, s) {
        var p = {},
            g = e === Pt;

        function m(S) {
            var T;
            return p[S] = !0, a.each(e[S] || [], function(N, l) {
                var t = l(n, r, s);
                return typeof t != "string" || g || p[t] ? g ? !(T = t) : void 0 : (n.dataTypes.unshift(t), m(t), !1)
            }), T
        }
        return m(n.dataTypes[0]) || !p["*"] && m("*")
    }

    function Fn(e, n) {
        var r, s, p = a.ajaxSettings.flatOptions || {};
        for (r in n) n[r] !== void 0 && ((p[r] ? e : s || (s = {}))[r] = n[r]);
        return s && a.extend(!0, e, s), e
    }
    hi.href = Cn.href, a.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: Cn.href,
            type: "GET",
            isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(Cn.protocol),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": Ni,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /\bxml\b/,
                html: /\bhtml/,
                json: /\bjson\b/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": JSON.parse,
                "text xml": a.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(e, n) {
            return n ? Fn(Fn(e, a.ajaxSettings), n) : Fn(a.ajaxSettings, e)
        },
        ajaxPrefilter: Ii(ji),
        ajaxTransport: Ii(Pt),
        ajax: function(e, n) {
            typeof e == "object" && (n = e, e = void 0), n = n || {};
            var r, s, p, g, m, S, T, N, l, t, i = a.ajaxSetup({}, n),
                c = i.context || i,
                v = i.context && (c.nodeType || c.jquery) ? a(c) : a.event,
                E = a.Deferred(),
                k = a.Callbacks("once memory"),
                W = i.statusCode || {},
                G = {},
                Z = {},
                X = "canceled",
                z = {
                    readyState: 0,
                    getResponseHeader: function(ee) {
                        var re;
                        if (T) {
                            if (!g)
                                for (g = {}; re = ir.exec(p);) g[re[1].toLowerCase() + " "] = (g[re[1].toLowerCase() + " "] || []).concat(re[2]);
                            re = g[ee.toLowerCase() + " "]
                        }
                        return re == null ? null : re.join(", ")
                    },
                    getAllResponseHeaders: function() {
                        return T ? p : null
                    },
                    setRequestHeader: function(ee, re) {
                        return T == null && (ee = Z[ee.toLowerCase()] = Z[ee.toLowerCase()] || ee, G[ee] = re), this
                    },
                    overrideMimeType: function(ee) {
                        return T == null && (i.mimeType = ee), this
                    },
                    statusCode: function(ee) {
                        var re;
                        if (ee)
                            if (T) z.always(ee[z.status]);
                            else
                                for (re in ee) W[re] = [W[re], ee[re]];
                        return this
                    },
                    abort: function(ee) {
                        var re = ee || X;
                        return r && r.abort(re), pe(0, re), this
                    }
                };
            if (E.promise(z), i.url = ((e || i.url || Cn.href) + "").replace($i, Cn.protocol + "//"), i.type = n.method || n.type || i.method || i.type, i.dataTypes = (i.dataType || "*").toLowerCase().match(w) || [""], i.crossDomain == null) {
                S = se.createElement("a");
                try {
                    S.href = i.url, S.href = S.href, i.crossDomain = hi.protocol + "//" + hi.host != S.protocol + "//" + S.host
                } catch {
                    i.crossDomain = !0
                }
            }
            if (i.data && i.processData && typeof i.data != "string" && (i.data = a.param(i.data, i.traditional)), Pi(ji, i, n, z), T) return z;
            for (l in (N = a.event && i.global) && a.active++ == 0 && a.event.trigger("ajaxStart"), i.type = i.type.toUpperCase(), i.hasContent = !hn.test(i.type), s = i.url.replace(Oi, ""), i.hasContent ? i.data && i.processData && (i.contentType || "").indexOf("application/x-www-form-urlencoded") === 0 && (i.data = i.data.replace(nr, "+")) : (t = i.url.slice(s.length), i.data && (i.processData || typeof i.data == "string") && (s += (vt.test(s) ? "&" : "?") + i.data, delete i.data), i.cache === !1 && (s = s.replace(Li, "$1"), t = (vt.test(s) ? "&" : "?") + "_=" + Si.guid++ + t), i.url = s + t), i.ifModified && (a.lastModified[s] && z.setRequestHeader("If-Modified-Since", a.lastModified[s]), a.etag[s] && z.setRequestHeader("If-None-Match", a.etag[s])), (i.data && i.hasContent && i.contentType !== !1 || n.contentType) && z.setRequestHeader("Content-Type", i.contentType), z.setRequestHeader("Accept", i.dataTypes[0] && i.accepts[i.dataTypes[0]] ? i.accepts[i.dataTypes[0]] + (i.dataTypes[0] !== "*" ? ", " + Ni + "; q=0.01" : "") : i.accepts["*"]), i.headers) z.setRequestHeader(l, i.headers[l]);
            if (i.beforeSend && (i.beforeSend.call(c, z, i) === !1 || T)) return z.abort();
            if (X = "abort", k.add(i.complete), z.done(i.success), z.fail(i.error), r = Pi(Pt, i, n, z)) {
                if (z.readyState = 1, N && v.trigger("ajaxSend", [z, i]), T) return z;
                i.async && 0 < i.timeout && (m = D.setTimeout(function() {
                    z.abort("timeout")
                }, i.timeout));
                try {
                    T = !1, r.send(G, pe)
                } catch (ee) {
                    if (T) throw ee;
                    pe(-1, ee)
                }
            } else pe(-1, "No Transport");

            function pe(ee, re, Ce, Ee) {
                var Oe, je, $e, ce, Re, xe = re;
                T || (T = !0, m && D.clearTimeout(m), r = void 0, p = Ee || "", z.readyState = 0 < ee ? 4 : 0, Oe = 200 <= ee && ee < 300 || ee === 304, Ce && (ce = function(_e, Ae, Ne) {
                    for (var Ue, me, ve, Ie, Ke = _e.contents, Fe = _e.dataTypes; Fe[0] === "*";) Fe.shift(), Ue === void 0 && (Ue = _e.mimeType || Ae.getResponseHeader("Content-Type"));
                    if (Ue) {
                        for (me in Ke)
                            if (Ke[me] && Ke[me].test(Ue)) {
                                Fe.unshift(me);
                                break
                            }
                    }
                    if (Fe[0] in Ne) ve = Fe[0];
                    else {
                        for (me in Ne) {
                            if (!Fe[0] || _e.converters[me + " " + Fe[0]]) {
                                ve = me;
                                break
                            }
                            Ie || (Ie = me)
                        }
                        ve = ve || Ie
                    }
                    if (ve) return ve !== Fe[0] && Fe.unshift(ve), Ne[ve]
                }(i, z, Ce)), !Oe && -1 < a.inArray("script", i.dataTypes) && a.inArray("json", i.dataTypes) < 0 && (i.converters["text script"] = function() {}), ce = function(_e, Ae, Ne, Ue) {
                    var me, ve, Ie, Ke, Fe, Je = {},
                        jt = _e.dataTypes.slice();
                    if (jt[1])
                        for (Ie in _e.converters) Je[Ie.toLowerCase()] = _e.converters[Ie];
                    for (ve = jt.shift(); ve;)
                        if (_e.responseFields[ve] && (Ne[_e.responseFields[ve]] = Ae), !Fe && Ue && _e.dataFilter && (Ae = _e.dataFilter(Ae, _e.dataType)), Fe = ve, ve = jt.shift()) {
                            if (ve === "*") ve = Fe;
                            else if (Fe !== "*" && Fe !== ve) {
                                if (!(Ie = Je[Fe + " " + ve] || Je["* " + ve])) {
                                    for (me in Je)
                                        if ((Ke = me.split(" "))[1] === ve && (Ie = Je[Fe + " " + Ke[0]] || Je["* " + Ke[0]])) {
                                            Ie === !0 ? Ie = Je[me] : Je[me] !== !0 && (ve = Ke[0], jt.unshift(Ke[1]));
                                            break
                                        }
                                }
                                if (Ie !== !0)
                                    if (Ie && _e.throws) Ae = Ie(Ae);
                                    else try {
                                        Ae = Ie(Ae)
                                    } catch (et) {
                                        return {
                                            state: "parsererror",
                                            error: Ie ? et : "No conversion from " + Fe + " to " + ve
                                        }
                                    }
                            }
                        }
                    return {
                        state: "success",
                        data: Ae
                    }
                }(i, ce, z, Oe), Oe ? (i.ifModified && ((Re = z.getResponseHeader("Last-Modified")) && (a.lastModified[s] = Re), (Re = z.getResponseHeader("etag")) && (a.etag[s] = Re)), ee === 204 || i.type === "HEAD" ? xe = "nocontent" : ee === 304 ? xe = "notmodified" : (xe = ce.state, je = ce.data, Oe = !($e = ce.error))) : ($e = xe, !ee && xe || (xe = "error", ee < 0 && (ee = 0))), z.status = ee, z.statusText = (re || xe) + "", Oe ? E.resolveWith(c, [je, xe, z]) : E.rejectWith(c, [z, xe, $e]), z.statusCode(W), W = void 0, N && v.trigger(Oe ? "ajaxSuccess" : "ajaxError", [z, i, Oe ? je : $e]), k.fireWith(c, [z, xe]), N && (v.trigger("ajaxComplete", [z, i]), --a.active || a.event.trigger("ajaxStop")))
            }
            return z
        },
        getJSON: function(e, n, r) {
            return a.get(e, n, r, "json")
        },
        getScript: function(e, n) {
            return a.get(e, void 0, n, "script")
        }
    }), a.each(["get", "post"], function(e, n) {
        a[n] = function(r, s, p, g) {
            return Y(s) && (g = g || p, p = s, s = void 0), a.ajax(a.extend({
                url: r,
                type: n,
                dataType: g,
                data: s,
                success: p
            }, a.isPlainObject(r) && r))
        }
    }), a.ajaxPrefilter(function(e) {
        var n;
        for (n in e.headers) n.toLowerCase() === "content-type" && (e.contentType = e.headers[n] || "")
    }), a._evalUrl = function(e, n, r) {
        return a.ajax({
            url: e,
            type: "GET",
            dataType: "script",
            cache: !0,
            async: !1,
            global: !1,
            converters: {
                "text script": function() {}
            },
            dataFilter: function(s) {
                a.globalEval(s, n, r)
            }
        })
    }, a.fn.extend({
        wrapAll: function(e) {
            var n;
            return this[0] && (Y(e) && (e = e.call(this[0])), n = a(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && n.insertBefore(this[0]), n.map(function() {
                for (var r = this; r.firstElementChild;) r = r.firstElementChild;
                return r
            }).append(this)), this
        },
        wrapInner: function(e) {
            return Y(e) ? this.each(function(n) {
                a(this).wrapInner(e.call(this, n))
            }) : this.each(function() {
                var n = a(this),
                    r = n.contents();
                r.length ? r.wrapAll(e) : n.append(e)
            })
        },
        wrap: function(e) {
            var n = Y(e);
            return this.each(function(r) {
                a(this).wrapAll(n ? e.call(this, r) : e)
            })
        },
        unwrap: function(e) {
            return this.parent(e).not("body").each(function() {
                a(this).replaceWith(this.childNodes)
            }), this
        }
    }), a.expr.pseudos.hidden = function(e) {
        return !a.expr.pseudos.visible(e)
    }, a.expr.pseudos.visible = function(e) {
        return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
    }, a.ajaxSettings.xhr = function() {
        try {
            return new D.XMLHttpRequest
        } catch {}
    };
    var rr = {
            0: 200,
            1223: 204
        },
        Sn = a.ajaxSettings.xhr();
    oe.cors = !!Sn && "withCredentials" in Sn, oe.ajax = Sn = !!Sn, a.ajaxTransport(function(e) {
        var n, r;
        if (oe.cors || Sn && !e.crossDomain) return {
            send: function(s, p) {
                var g, m = e.xhr();
                if (m.open(e.type, e.url, e.async, e.username, e.password), e.xhrFields)
                    for (g in e.xhrFields) m[g] = e.xhrFields[g];
                for (g in e.mimeType && m.overrideMimeType && m.overrideMimeType(e.mimeType), e.crossDomain || s["X-Requested-With"] || (s["X-Requested-With"] = "XMLHttpRequest"), s) m.setRequestHeader(g, s[g]);
                n = function(S) {
                    return function() {
                        n && (n = r = m.onload = m.onerror = m.onabort = m.ontimeout = m.onreadystatechange = null, S === "abort" ? m.abort() : S === "error" ? typeof m.status != "number" ? p(0, "error") : p(m.status, m.statusText) : p(rr[m.status] || m.status, m.statusText, (m.responseType || "text") !== "text" || typeof m.responseText != "string" ? {
                            binary: m.response
                        } : {
                            text: m.responseText
                        }, m.getAllResponseHeaders()))
                    }
                }, m.onload = n(), r = m.onerror = m.ontimeout = n("error"), m.onabort !== void 0 ? m.onabort = r : m.onreadystatechange = function() {
                    m.readyState === 4 && D.setTimeout(function() {
                        n && r()
                    })
                }, n = n("abort");
                try {
                    m.send(e.hasContent && e.data || null)
                } catch (S) {
                    if (n) throw S
                }
            },
            abort: function() {
                n && n()
            }
        }
    }), a.ajaxPrefilter(function(e) {
        e.crossDomain && (e.contents.script = !1)
    }), a.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /\b(?:java|ecma)script\b/
        },
        converters: {
            "text script": function(e) {
                return a.globalEval(e), e
            }
        }
    }), a.ajaxPrefilter("script", function(e) {
        e.cache === void 0 && (e.cache = !1), e.crossDomain && (e.type = "GET")
    }), a.ajaxTransport("script", function(e) {
        var n, r;
        if (e.crossDomain || e.scriptAttrs) return {
            send: function(s, p) {
                n = a("<script>").attr(e.scriptAttrs || {}).prop({
                    charset: e.scriptCharset,
                    src: e.url
                }).on("load error", r = function(g) {
                    n.remove(), r = null, g && p(g.type === "error" ? 404 : 200, g.type)
                }), se.head.appendChild(n[0])
            },
            abort: function() {
                r && r()
            }
        }
    });
    var qi, Mi = [],
        pi = /(=)\?(?=&|$)|\?\?/;
    a.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var e = Mi.pop() || a.expando + "_" + Si.guid++;
            return this[e] = !0, e
        }
    }), a.ajaxPrefilter("json jsonp", function(e, n, r) {
        var s, p, g, m = e.jsonp !== !1 && (pi.test(e.url) ? "url" : typeof e.data == "string" && (e.contentType || "").indexOf("application/x-www-form-urlencoded") === 0 && pi.test(e.data) && "data");
        if (m || e.dataTypes[0] === "jsonp") return s = e.jsonpCallback = Y(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, m ? e[m] = e[m].replace(pi, "$1" + s) : e.jsonp !== !1 && (e.url += (vt.test(e.url) ? "&" : "?") + e.jsonp + "=" + s), e.converters["script json"] = function() {
            return g || a.error(s + " was not called"), g[0]
        }, e.dataTypes[0] = "json", p = D[s], D[s] = function() {
            g = arguments
        }, r.always(function() {
            p === void 0 ? a(D).removeProp(s) : D[s] = p, e[s] && (e.jsonpCallback = n.jsonpCallback, Mi.push(s)), g && Y(p) && p(g[0]), g = p = void 0
        }), "script"
    }), oe.createHTMLDocument = ((qi = se.implementation.createHTMLDocument("").body).innerHTML = "<form></form><form></form>", qi.childNodes.length === 2), a.parseHTML = function(e, n, r) {
        return typeof e != "string" ? [] : (typeof n == "boolean" && (r = n, n = !1), n || (oe.createHTMLDocument ? ((s = (n = se.implementation.createHTMLDocument("")).createElement("base")).href = se.location.href, n.head.appendChild(s)) : n = se), g = !r && [], (p = x.exec(e)) ? [n.createElement(p[1])] : (p = qn([e], n, g), g && g.length && a(g).remove(), a.merge([], p.childNodes)));
        var s, p, g
    }, a.fn.load = function(e, n, r) {
        var s, p, g, m = this,
            S = e.indexOf(" ");
        return -1 < S && (s = tn(e.slice(S)), e = e.slice(0, S)), Y(n) ? (r = n, n = void 0) : n && typeof n == "object" && (p = "POST"), 0 < m.length && a.ajax({
            url: e,
            type: p || "GET",
            dataType: "html",
            data: n
        }).done(function(T) {
            g = arguments, m.html(s ? a("<div>").append(a.parseHTML(T)).find(s) : T)
        }).always(r && function(T, N) {
            m.each(function() {
                r.apply(this, g || [T.responseText, N, T])
            })
        }), this
    }, a.expr.pseudos.animated = function(e) {
        return a.grep(a.timers, function(n) {
            return e === n.elem
        }).length
    }, a.offset = {
        setOffset: function(e, n, r) {
            var s, p, g, m, S, T, N = a.css(e, "position"),
                l = a(e),
                t = {};
            N === "static" && (e.style.position = "relative"), S = l.offset(), g = a.css(e, "top"), T = a.css(e, "left"), (N === "absolute" || N === "fixed") && -1 < (g + T).indexOf("auto") ? (m = (s = l.position()).top, p = s.left) : (m = parseFloat(g) || 0, p = parseFloat(T) || 0), Y(n) && (n = n.call(e, r, a.extend({}, S))), n.top != null && (t.top = n.top - S.top + m), n.left != null && (t.left = n.left - S.left + p), "using" in n ? n.using.call(e, t) : l.css(t)
        }
    }, a.fn.extend({
        offset: function(e) {
            if (arguments.length) return e === void 0 ? this : this.each(function(p) {
                a.offset.setOffset(this, e, p)
            });
            var n, r, s = this[0];
            return s ? s.getClientRects().length ? (n = s.getBoundingClientRect(), r = s.ownerDocument.defaultView, {
                top: n.top + r.pageYOffset,
                left: n.left + r.pageXOffset
            }) : {
                top: 0,
                left: 0
            } : void 0
        },
        position: function() {
            if (this[0]) {
                var e, n, r, s = this[0],
                    p = {
                        top: 0,
                        left: 0
                    };
                if (a.css(s, "position") === "fixed") n = s.getBoundingClientRect();
                else {
                    for (n = this.offset(), r = s.ownerDocument, e = s.offsetParent || r.documentElement; e && (e === r.body || e === r.documentElement) && a.css(e, "position") === "static";) e = e.parentNode;
                    e && e !== s && e.nodeType === 1 && ((p = a(e).offset()).top += a.css(e, "borderTopWidth", !0), p.left += a.css(e, "borderLeftWidth", !0))
                }
                return {
                    top: n.top - p.top - a.css(s, "marginTop", !0),
                    left: n.left - p.left - a.css(s, "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var e = this.offsetParent; e && a.css(e, "position") === "static";) e = e.offsetParent;
                return e || R
            })
        }
    }), a.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function(e, n) {
        var r = n === "pageYOffset";
        a.fn[e] = function(s) {
            return ge(this, function(p, g, m) {
                var S;
                if (fe(p) ? S = p : p.nodeType === 9 && (S = p.defaultView), m === void 0) return S ? S[n] : p[g];
                S ? S.scrollTo(r ? S.pageXOffset : m, r ? m : S.pageYOffset) : p[g] = m
            }, e, s, arguments.length)
        }
    }), a.each(["top", "left"], function(e, n) {
        a.cssHooks[n] = ni(oe.pixelPosition, function(r, s) {
            if (s) return s = xn(r, n), ei.test(s) ? a(r).position()[n] + "px" : s
        })
    }), a.each({
        Height: "height",
        Width: "width"
    }, function(e, n) {
        a.each({
            padding: "inner" + e,
            content: n,
            "": "outer" + e
        }, function(r, s) {
            a.fn[s] = function(p, g) {
                var m = arguments.length && (r || typeof p != "boolean"),
                    S = r || (p === !0 || g === !0 ? "margin" : "border");
                return ge(this, function(T, N, l) {
                    var t;
                    return fe(T) ? s.indexOf("outer") === 0 ? T["inner" + e] : T.document.documentElement["client" + e] : T.nodeType === 9 ? (t = T.documentElement, Math.max(T.body["scroll" + e], t["scroll" + e], T.body["offset" + e], t["offset" + e], t["client" + e])) : l === void 0 ? a.css(T, N, S) : a.style(T, N, l, S)
                }, n, m ? p : void 0, m)
            }
        })
    }), a.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(e, n) {
        a.fn[n] = function(r) {
            return this.on(n, r)
        }
    }), a.fn.extend({
        bind: function(e, n, r) {
            return this.on(e, null, n, r)
        },
        unbind: function(e, n) {
            return this.off(e, null, n)
        },
        delegate: function(e, n, r, s) {
            return this.on(n, e, r, s)
        },
        undelegate: function(e, n, r) {
            return arguments.length === 1 ? this.off(e, "**") : this.off(n, e || "**", r)
        },
        hover: function(e, n) {
            return this.mouseenter(e).mouseleave(n || e)
        }
    }), a.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function(e, n) {
        a.fn[n] = function(r, s) {
            return 0 < arguments.length ? this.on(n, null, r, s) : this.trigger(n)
        }
    });
    var rn = /^[\s\uFEFF\xA0]+|([^\s\uFEFF\xA0])[\s\uFEFF\xA0]+$/g;
    a.proxy = function(e, n) {
        var r, s, p;
        if (typeof n == "string" && (r = e[n], n = e, e = r), Y(e)) return s = H.call(arguments, 2), (p = function() {
            return e.apply(n || this, s.concat(H.call(arguments)))
        }).guid = e.guid = e.guid || a.guid++, p
    }, a.holdReady = function(e) {
        e ? a.readyWait++ : a.ready(!0)
    }, a.isArray = Array.isArray, a.parseJSON = JSON.parse, a.nodeName = y, a.isFunction = Y, a.isWindow = fe, a.camelCase = mt, a.type = at, a.now = Date.now, a.isNumeric = function(e) {
        var n = a.type(e);
        return (n === "number" || n === "string") && !isNaN(e - parseFloat(e))
    }, a.trim = function(e) {
        return e == null ? "" : (e + "").replace(rn, "$1")
    }, typeof define == "function" && define.amd && define("jquery", [], function() {
        return a
    });
    var sr = D.jQuery,
        or = D.$;
    return a.noConflict = function(e) {
        return D.$ === a && (D.$ = or), e && D.jQuery === a && (D.jQuery = sr), a
    }, typeof L > "u" && (D.jQuery = D.$ = a), a
});
/*!
 * Bootstrap v5.1.0 (https://getbootstrap.com/)
 * Copyright 2011-2021 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
(function(D, L) {
    typeof exports == "object" && typeof module < "u" ? module.exports = L() : typeof define == "function" && define.amd ? define(L) : (D = typeof globalThis < "u" ? globalThis : D || self).bootstrap = L()
})(void 0, function() {
    const D = l => {
            let t = l.getAttribute("data-bs-target");
            if (!t || t === "#") {
                let i = l.getAttribute("href");
                if (!i || !i.includes("#") && !i.startsWith(".")) return null;
                i.includes("#") && !i.startsWith("#") && (i = "#" + i.split("#")[1]), t = i && i !== "#" ? i.trim() : null
            }
            return t
        },
        L = l => {
            const t = D(l);
            return t && document.querySelector(t) ? t : null
        },
        O = l => {
            const t = D(l);
            return t ? document.querySelector(t) : null
        },
        P = l => {
            l.dispatchEvent(new Event("transitionend"))
        },
        H = l => !(!l || typeof l != "object") && (l.jquery !== void 0 && (l = l[0]), l.nodeType !== void 0),
        U = l => H(l) ? l.jquery ? l[0] : l : typeof l == "string" && l.length > 0 ? document.querySelector(l) : null,
        J = (l, t, i) => {
            Object.keys(i).forEach(c => {
                const v = i[c],
                    E = t[c],
                    k = E && H(E) ? "element" : (W = E) == null ? "" + W : {}.toString.call(W).match(/\s([a-z]+)/i)[1].toLowerCase();
                var W;
                if (!new RegExp(v).test(k)) throw new TypeError(`${l.toUpperCase()}: Option "${c}" provided type "${k}" but expected type "${v}".`)
            })
        },
        B = l => !(!H(l) || l.getClientRects().length === 0) && getComputedStyle(l).getPropertyValue("visibility") === "visible",
        V = l => !l || l.nodeType !== Node.ELEMENT_NODE || !!l.classList.contains("disabled") || (l.disabled !== void 0 ? l.disabled : l.hasAttribute("disabled") && l.getAttribute("disabled") !== "false"),
        ue = l => {
            if (!document.documentElement.attachShadow) return null;
            if (typeof l.getRootNode == "function") {
                const t = l.getRootNode();
                return t instanceof ShadowRoot ? t : null
            }
            return l instanceof ShadowRoot ? l : l.parentNode ? ue(l.parentNode) : null
        },
        qe = () => {},
        be = l => {
            l.offsetHeight
        },
        de = () => {
            const {
                jQuery: l
            } = window;
            return l && !document.body.hasAttribute("data-bs-no-jquery") ? l : null
        },
        oe = [],
        Y = () => document.documentElement.dir === "rtl",
        fe = l => {
            var t;
            t = () => {
                const i = de();
                if (i) {
                    const c = l.NAME,
                        v = i.fn[c];
                    i.fn[c] = l.jQueryInterface, i.fn[c].Constructor = l, i.fn[c].noConflict = () => (i.fn[c] = v, l.jQueryInterface)
                }
            }, document.readyState === "loading" ? (oe.length || document.addEventListener("DOMContentLoaded", () => {
                oe.forEach(i => i())
            }), oe.push(t)) : t()
        },
        se = l => {
            typeof l == "function" && l()
        },
        Ve = (l, t, i = !0) => {
            if (!i) return void se(l);
            const c = (k => {
                if (!k) return 0;
                let {
                    transitionDuration: W,
                    transitionDelay: G
                } = window.getComputedStyle(k);
                const Z = Number.parseFloat(W),
                    X = Number.parseFloat(G);
                return Z || X ? (W = W.split(",")[0], G = G.split(",")[0], 1e3 * (Number.parseFloat(W) + Number.parseFloat(G))) : 0
            })(t) + 5;
            let v = !1;
            const E = ({
                target: k
            }) => {
                k === t && (v = !0, t.removeEventListener("transitionend", E), se(l))
            };
            t.addEventListener("transitionend", E), setTimeout(() => {
                v || P(t)
            }, c)
        },
        gt = (l, t, i, c) => {
            let v = l.indexOf(t);
            if (v === -1) return l[!i && c ? l.length - 1 : 0];
            const E = l.length;
            return v += i ? 1 : -1, c && (v = (v + E) % E), l[Math.max(0, Math.min(v, E - 1))]
        },
        at = /[^.]*(?=\..*)\.|.*/,
        Pe = /\..*/,
        a = /::\d+$/,
        xt = {};
    let St = 1;
    const Et = {
            mouseenter: "mouseover",
            mouseleave: "mouseout"
        },
        Ut = /^(mouseenter|mouseleave)/i,
        ze = new Set(["click", "dblclick", "mouseup", "mousedown", "contextmenu", "mousewheel", "DOMMouseScroll", "mouseover", "mouseout", "mousemove", "selectstart", "selectend", "keydown", "keypress", "keyup", "orientationchange", "touchstart", "touchmove", "touchend", "touchcancel", "pointerdown", "pointermove", "pointerup", "pointerleave", "pointercancel", "gesturestart", "gesturechange", "gestureend", "focus", "blur", "change", "reset", "select", "submit", "focusin", "focusout", "load", "unload", "beforeunload", "resize", "move", "DOMContentLoaded", "readystatechange", "error", "abort", "scroll"]);

    function y(l, t) {
        return t && `${t}::${St++}` || l.uidEvent || St++
    }

    function x(l) {
        const t = y(l);
        return l.uidEvent = t, xt[t] = xt[t] || {}, xt[t]
    }

    function b(l, t, i = null) {
        const c = Object.keys(l);
        for (let v = 0, E = c.length; v < E; v++) {
            const k = l[c[v]];
            if (k.originalHandler === t && k.delegationSelector === i) return k
        }
        return null
    }

    function f(l, t, i) {
        const c = typeof t == "string",
            v = c ? i : t;
        let E = h(l);
        return ze.has(E) || (E = l), [c, v, E]
    }

    function d(l, t, i, c, v) {
        if (typeof t != "string" || !l) return;
        if (i || (i = c, c = null), Ut.test(t)) {
            const ee = re => function(Ce) {
                if (!Ce.relatedTarget || Ce.relatedTarget !== Ce.delegateTarget && !Ce.delegateTarget.contains(Ce.relatedTarget)) return re.call(this, Ce)
            };
            c ? c = ee(c) : i = ee(i)
        }
        const [E, k, W] = f(t, i, c), G = x(l), Z = G[W] || (G[W] = {}), X = b(Z, k, E ? i : null);
        if (X) return void(X.oneOff = X.oneOff && v);
        const z = y(k, t.replace(at, "")),
            pe = E ? function(ee, re, Ce) {
                return function Ee(Oe) {
                    const je = ee.querySelectorAll(re);
                    for (let {
                            target: $e
                        } = Oe; $e && $e !== this; $e = $e.parentNode)
                        for (let ce = je.length; ce--;)
                            if (je[ce] === $e) return Oe.delegateTarget = $e, Ee.oneOff && u.off(ee, Oe.type, re, Ce), Ce.apply($e, [Oe]);
                    return null
                }
            }(l, i, c) : function(ee, re) {
                return function Ce(Ee) {
                    return Ee.delegateTarget = ee, Ce.oneOff && u.off(ee, Ee.type, re), re.apply(ee, [Ee])
                }
            }(l, i);
        pe.delegationSelector = E ? i : null, pe.originalHandler = k, pe.oneOff = v, pe.uidEvent = z, Z[z] = pe, l.addEventListener(W, pe, E)
    }

    function o(l, t, i, c, v) {
        const E = b(t[i], c, v);
        E && (l.removeEventListener(i, E, !!v), delete t[i][E.uidEvent])
    }

    function h(l) {
        return l = l.replace(Pe, ""), Et[l] || l
    }
    const u = {
            on(l, t, i, c) {
                d(l, t, i, c, !1)
            },
            one(l, t, i, c) {
                d(l, t, i, c, !0)
            },
            off(l, t, i, c) {
                if (typeof t != "string" || !l) return;
                const [v, E, k] = f(t, i, c), W = k !== t, G = x(l), Z = t.startsWith(".");
                if (E !== void 0) return !G || !G[k] ? void 0 : void o(l, G, k, E, v ? i : null);
                Z && Object.keys(G).forEach(z => {
                    (function(pe, ee, re, Ce) {
                        const Ee = ee[re] || {};
                        Object.keys(Ee).forEach(Oe => {
                            if (Oe.includes(Ce)) {
                                const je = Ee[Oe];
                                o(pe, ee, re, je.originalHandler, je.delegationSelector)
                            }
                        })
                    })(l, G, z, t.slice(1))
                });
                const X = G[k] || {};
                Object.keys(X).forEach(z => {
                    const pe = z.replace(a, "");
                    if (!W || t.includes(pe)) {
                        const ee = X[z];
                        o(l, G, k, ee.originalHandler, ee.delegationSelector)
                    }
                })
            },
            trigger(l, t, i) {
                if (typeof t != "string" || !l) return null;
                const c = de(),
                    v = h(t),
                    E = t !== v,
                    k = ze.has(v);
                let W, G = !0,
                    Z = !0,
                    X = !1,
                    z = null;
                return E && c && (W = c.Event(t, i), c(l).trigger(W), G = !W.isPropagationStopped(), Z = !W.isImmediatePropagationStopped(), X = W.isDefaultPrevented()), k ? (z = document.createEvent("HTMLEvents"), z.initEvent(v, G, !0)) : z = new CustomEvent(t, {
                    bubbles: G,
                    cancelable: !0
                }), i !== void 0 && Object.keys(i).forEach(pe => {
                    Object.defineProperty(z, pe, {
                        get: () => i[pe]
                    })
                }), X && z.preventDefault(), Z && l.dispatchEvent(z), z.defaultPrevented && W !== void 0 && W.preventDefault(), z
            }
        },
        w = new Map;
    var C = {
        set(l, t, i) {
            w.has(l) || w.set(l, new Map);
            const c = w.get(l);
            c.has(t) || c.size === 0 ? c.set(t, i) : console.error(`Bootstrap doesn't allow more than one instance per element. Bound instance: ${Array.from(c.keys())[0]}.`)
        },
        get: (l, t) => w.has(l) && w.get(l).get(t) || null,
        remove(l, t) {
            if (!w.has(l)) return;
            const i = w.get(l);
            i.delete(t), i.size === 0 && w.delete(l)
        }
    };
    class q {
        constructor(t) {
            (t = U(t)) && (this._element = t, C.set(this._element, this.constructor.DATA_KEY, this))
        }
        dispose() {
            C.remove(this._element, this.constructor.DATA_KEY), u.off(this._element, this.constructor.EVENT_KEY), Object.getOwnPropertyNames(this).forEach(t => {
                this[t] = null
            })
        }
        _queueCallback(t, i, c = !0) {
            Ve(t, i, c)
        }
        static getInstance(t) {
            return C.get(U(t), this.DATA_KEY)
        }
        static getOrCreateInstance(t, i = {}) {
            return this.getInstance(t) || new this(t, typeof i == "object" ? i : null)
        }
        static get VERSION() {
            return "5.1.0"
        }
        static get NAME() {
            throw new Error('You have to implement the static method "NAME", for each component!')
        }
        static get DATA_KEY() {
            return "bs." + this.NAME
        }
        static get EVENT_KEY() {
            return "." + this.DATA_KEY
        }
    }
    const M = (l, t = "hide") => {
        const i = "click.dismiss" + l.EVENT_KEY,
            c = l.NAME;
        u.on(document, i, `[data-bs-dismiss="${c}"]`, function(v) {
            if (["A", "AREA"].includes(this.tagName) && v.preventDefault(), V(this)) return;
            const E = O(this) || this.closest("." + c);
            l.getOrCreateInstance(E)[t]()
        })
    };
    class ae extends q {
        static get NAME() {
            return "alert"
        }
        close() {
            if (u.trigger(this._element, "close.bs.alert").defaultPrevented) return;
            this._element.classList.remove("show");
            const t = this._element.classList.contains("fade");
            this._queueCallback(() => this._destroyElement(), this._element, t)
        }
        _destroyElement() {
            this._element.remove(), u.trigger(this._element, "closed.bs.alert"), this.dispose()
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const i = ae.getOrCreateInstance(this);
                if (typeof t == "string") {
                    if (i[t] === void 0 || t.startsWith("_") || t === "constructor") throw new TypeError(`No method named "${t}"`);
                    i[t](this)
                }
            })
        }
    }
    M(ae, "close"), fe(ae);
    class ne extends q {
        static get NAME() {
            return "button"
        }
        toggle() {
            this._element.setAttribute("aria-pressed", this._element.classList.toggle("active"))
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const i = ne.getOrCreateInstance(this);
                t === "toggle" && i[t]()
            })
        }
    }

    function De(l) {
        return l === "true" || l !== "false" && (l === Number(l).toString() ? Number(l) : l === "" || l === "null" ? null : l)
    }

    function ge(l) {
        return l.replace(/[A-Z]/g, t => "-" + t.toLowerCase())
    }
    u.on(document, "click.bs.button.data-api", '[data-bs-toggle="button"]', l => {
        l.preventDefault();
        const t = l.target.closest('[data-bs-toggle="button"]');
        ne.getOrCreateInstance(t).toggle()
    }), fe(ne);
    const ye = {
            setDataAttribute(l, t, i) {
                l.setAttribute("data-bs-" + ge(t), i)
            },
            removeDataAttribute(l, t) {
                l.removeAttribute("data-bs-" + ge(t))
            },
            getDataAttributes(l) {
                if (!l) return {};
                const t = {};
                return Object.keys(l.dataset).filter(i => i.startsWith("bs")).forEach(i => {
                    let c = i.replace(/^bs/, "");
                    c = c.charAt(0).toLowerCase() + c.slice(1, c.length), t[c] = De(l.dataset[i])
                }), t
            },
            getDataAttribute: (l, t) => De(l.getAttribute("data-bs-" + ge(t))),
            offset(l) {
                const t = l.getBoundingClientRect();
                return {
                    top: t.top + window.pageYOffset,
                    left: t.left + window.pageXOffset
                }
            },
            position: l => ({
                top: l.offsetTop,
                left: l.offsetLeft
            })
        },
        ie = {
            find: (l, t = document.documentElement) => [].concat(...Element.prototype.querySelectorAll.call(t, l)),
            findOne: (l, t = document.documentElement) => Element.prototype.querySelector.call(t, l),
            children: (l, t) => [].concat(...l.children).filter(i => i.matches(t)),
            parents(l, t) {
                const i = [];
                let c = l.parentNode;
                for (; c && c.nodeType === Node.ELEMENT_NODE && c.nodeType !== 3;) c.matches(t) && i.push(c), c = c.parentNode;
                return i
            },
            prev(l, t) {
                let i = l.previousElementSibling;
                for (; i;) {
                    if (i.matches(t)) return [i];
                    i = i.previousElementSibling
                }
                return []
            },
            next(l, t) {
                let i = l.nextElementSibling;
                for (; i;) {
                    if (i.matches(t)) return [i];
                    i = i.nextElementSibling
                }
                return []
            },
            focusableChildren(l) {
                const t = ["a", "button", "input", "textarea", "select", "details", "[tabindex]", '[contenteditable="true"]'].map(i => i + ':not([tabindex^="-"])').join(", ");
                return this.find(t, l).filter(i => !V(i) && B(i))
            }
        },
        Ht = {
            interval: 5e3,
            keyboard: !0,
            slide: !1,
            pause: "hover",
            wrap: !0,
            touch: !0
        },
        mt = {
            interval: "(number|boolean)",
            keyboard: "boolean",
            slide: "(boolean|string)",
            pause: "(string|boolean)",
            wrap: "boolean",
            touch: "boolean"
        },
        lt = "next",
        ut = "prev",
        he = "left",
        tt = "right",
        Yn = {
            ArrowLeft: tt,
            ArrowRight: he
        };
    class kt extends q {
        constructor(t, i) {
            super(t), this._items = null, this._interval = null, this._activeElement = null, this._isPaused = !1, this._isSliding = !1, this.touchTimeout = null, this.touchStartX = 0, this.touchDeltaX = 0, this._config = this._getConfig(i), this._indicatorsElement = ie.findOne(".carousel-indicators", this._element), this._touchSupported = "ontouchstart" in document.documentElement || navigator.maxTouchPoints > 0, this._pointerEvent = !!window.PointerEvent, this._addEventListeners()
        }
        static get Default() {
            return Ht
        }
        static get NAME() {
            return "carousel"
        }
        next() {
            this._slide(lt)
        }
        nextWhenVisible() {
            !document.hidden && B(this._element) && this.next()
        }
        prev() {
            this._slide(ut)
        }
        pause(t) {
            t || (this._isPaused = !0), ie.findOne(".carousel-item-next, .carousel-item-prev", this._element) && (P(this._element), this.cycle(!0)), clearInterval(this._interval), this._interval = null
        }
        cycle(t) {
            t || (this._isPaused = !1), this._interval && (clearInterval(this._interval), this._interval = null), this._config && this._config.interval && !this._isPaused && (this._updateInterval(), this._interval = setInterval((document.visibilityState ? this.nextWhenVisible : this.next).bind(this), this._config.interval))
        }
        to(t) {
            this._activeElement = ie.findOne(".active.carousel-item", this._element);
            const i = this._getItemIndex(this._activeElement);
            if (t > this._items.length - 1 || t < 0) return;
            if (this._isSliding) return void u.one(this._element, "slid.bs.carousel", () => this.to(t));
            if (i === t) return this.pause(), void this.cycle();
            const c = t > i ? lt : ut;
            this._slide(c, this._items[t])
        }
        _getConfig(t) {
            return t = { ...Ht,
                ...ye.getDataAttributes(this._element),
                ...typeof t == "object" ? t : {}
            }, J("carousel", t, mt), t
        }
        _handleSwipe() {
            const t = Math.abs(this.touchDeltaX);
            if (t <= 40) return;
            const i = t / this.touchDeltaX;
            this.touchDeltaX = 0, i && this._slide(i > 0 ? tt : he)
        }
        _addEventListeners() {
            this._config.keyboard && u.on(this._element, "keydown.bs.carousel", t => this._keydown(t)), this._config.pause === "hover" && (u.on(this._element, "mouseenter.bs.carousel", t => this.pause(t)), u.on(this._element, "mouseleave.bs.carousel", t => this.cycle(t))), this._config.touch && this._touchSupported && this._addTouchEventListeners()
        }
        _addTouchEventListeners() {
            const t = v => {
                    !this._pointerEvent || v.pointerType !== "pen" && v.pointerType !== "touch" ? this._pointerEvent || (this.touchStartX = v.touches[0].clientX) : this.touchStartX = v.clientX
                },
                i = v => {
                    this.touchDeltaX = v.touches && v.touches.length > 1 ? 0 : v.touches[0].clientX - this.touchStartX
                },
                c = v => {
                    !this._pointerEvent || v.pointerType !== "pen" && v.pointerType !== "touch" || (this.touchDeltaX = v.clientX - this.touchStartX), this._handleSwipe(), this._config.pause === "hover" && (this.pause(), this.touchTimeout && clearTimeout(this.touchTimeout), this.touchTimeout = setTimeout(E => this.cycle(E), 500 + this._config.interval))
                };
            ie.find(".carousel-item img", this._element).forEach(v => {
                u.on(v, "dragstart.bs.carousel", E => E.preventDefault())
            }), this._pointerEvent ? (u.on(this._element, "pointerdown.bs.carousel", v => t(v)), u.on(this._element, "pointerup.bs.carousel", v => c(v)), this._element.classList.add("pointer-event")) : (u.on(this._element, "touchstart.bs.carousel", v => t(v)), u.on(this._element, "touchmove.bs.carousel", v => i(v)), u.on(this._element, "touchend.bs.carousel", v => c(v)))
        }
        _keydown(t) {
            if (/input|textarea/i.test(t.target.tagName)) return;
            const i = Yn[t.key];
            i && (t.preventDefault(), this._slide(i))
        }
        _getItemIndex(t) {
            return this._items = t && t.parentNode ? ie.find(".carousel-item", t.parentNode) : [], this._items.indexOf(t)
        }
        _getItemByOrder(t, i) {
            const c = t === lt;
            return gt(this._items, i, c, this._config.wrap)
        }
        _triggerSlideEvent(t, i) {
            const c = this._getItemIndex(t),
                v = this._getItemIndex(ie.findOne(".active.carousel-item", this._element));
            return u.trigger(this._element, "slide.bs.carousel", {
                relatedTarget: t,
                direction: i,
                from: v,
                to: c
            })
        }
        _setActiveIndicatorElement(t) {
            if (this._indicatorsElement) {
                const i = ie.findOne(".active", this._indicatorsElement);
                i.classList.remove("active"), i.removeAttribute("aria-current");
                const c = ie.find("[data-bs-target]", this._indicatorsElement);
                for (let v = 0; v < c.length; v++)
                    if (Number.parseInt(c[v].getAttribute("data-bs-slide-to"), 10) === this._getItemIndex(t)) {
                        c[v].classList.add("active"), c[v].setAttribute("aria-current", "true");
                        break
                    }
            }
        }
        _updateInterval() {
            const t = this._activeElement || ie.findOne(".active.carousel-item", this._element);
            if (!t) return;
            const i = Number.parseInt(t.getAttribute("data-bs-interval"), 10);
            i ? (this._config.defaultInterval = this._config.defaultInterval || this._config.interval, this._config.interval = i) : this._config.interval = this._config.defaultInterval || this._config.interval
        }
        _slide(t, i) {
            const c = this._directionToOrder(t),
                v = ie.findOne(".active.carousel-item", this._element),
                E = this._getItemIndex(v),
                k = i || this._getItemByOrder(c, v),
                W = this._getItemIndex(k),
                G = !!this._interval,
                Z = c === lt,
                X = Z ? "carousel-item-start" : "carousel-item-end",
                z = Z ? "carousel-item-next" : "carousel-item-prev",
                pe = this._orderToDirection(c);
            if (k && k.classList.contains("active")) return void(this._isSliding = !1);
            if (this._isSliding || this._triggerSlideEvent(k, pe).defaultPrevented || !v || !k) return;
            this._isSliding = !0, G && this.pause(), this._setActiveIndicatorElement(k), this._activeElement = k;
            const ee = () => {
                u.trigger(this._element, "slid.bs.carousel", {
                    relatedTarget: k,
                    direction: pe,
                    from: E,
                    to: W
                })
            };
            if (this._element.classList.contains("slide")) {
                k.classList.add(z), be(k), v.classList.add(X), k.classList.add(X);
                const re = () => {
                    k.classList.remove(X, z), k.classList.add("active"), v.classList.remove("active", z, X), this._isSliding = !1, setTimeout(ee, 0)
                };
                this._queueCallback(re, v, !0)
            } else v.classList.remove("active"), k.classList.add("active"), this._isSliding = !1, ee();
            G && this.cycle()
        }
        _directionToOrder(t) {
            return [tt, he].includes(t) ? Y() ? t === he ? ut : lt : t === he ? lt : ut : t
        }
        _orderToDirection(t) {
            return [lt, ut].includes(t) ? Y() ? t === ut ? he : tt : t === ut ? tt : he : t
        }
        static carouselInterface(t, i) {
            const c = kt.getOrCreateInstance(t, i);
            let {
                _config: v
            } = c;
            typeof i == "object" && (v = { ...v,
                ...i
            });
            const E = typeof i == "string" ? i : v.slide;
            if (typeof i == "number") c.to(i);
            else if (typeof E == "string") {
                if (c[E] === void 0) throw new TypeError(`No method named "${E}"`);
                c[E]()
            } else v.interval && v.ride && (c.pause(), c.cycle())
        }
        static jQueryInterface(t) {
            return this.each(function() {
                kt.carouselInterface(this, t)
            })
        }
        static dataApiClickHandler(t) {
            const i = O(this);
            if (!i || !i.classList.contains("carousel")) return;
            const c = { ...ye.getDataAttributes(i),
                    ...ye.getDataAttributes(this)
                },
                v = this.getAttribute("data-bs-slide-to");
            v && (c.interval = !1), kt.carouselInterface(i, c), v && kt.getInstance(i).to(v), t.preventDefault()
        }
    }
    u.on(document, "click.bs.carousel.data-api", "[data-bs-slide], [data-bs-slide-to]", kt.dataApiClickHandler), u.on(window, "load.bs.carousel.data-api", () => {
        const l = ie.find('[data-bs-ride="carousel"]');
        for (let t = 0, i = l.length; t < i; t++) kt.carouselInterface(l[t], kt.getInstance(l[t]))
    }), fe(kt);
    const yn = {
            toggle: !0,
            parent: null
        },
        Pn = {
            toggle: "boolean",
            parent: "(null|element)"
        };
    class Dt extends q {
        constructor(t, i) {
            super(t), this._isTransitioning = !1, this._config = this._getConfig(i), this._triggerArray = [];
            const c = ie.find('[data-bs-toggle="collapse"]');
            for (let v = 0, E = c.length; v < E; v++) {
                const k = c[v],
                    W = L(k),
                    G = ie.find(W).filter(Z => Z === this._element);
                W !== null && G.length && (this._selector = W, this._triggerArray.push(k))
            }
            this._initializeChildren(), this._config.parent || this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()), this._config.toggle && this.toggle()
        }
        static get Default() {
            return yn
        }
        static get NAME() {
            return "collapse"
        }
        toggle() {
            this._isShown() ? this.hide() : this.show()
        }
        show() {
            if (this._isTransitioning || this._isShown()) return;
            let t, i = [];
            if (this._config.parent) {
                const k = ie.find(".collapse .collapse", this._config.parent);
                i = ie.find(".show, .collapsing", this._config.parent).filter(W => !k.includes(W))
            }
            const c = ie.findOne(this._selector);
            if (i.length) {
                const k = i.find(W => c !== W);
                if (t = k ? Dt.getInstance(k) : null, t && t._isTransitioning) return
            }
            if (u.trigger(this._element, "show.bs.collapse").defaultPrevented) return;
            i.forEach(k => {
                c !== k && Dt.getOrCreateInstance(k, {
                    toggle: !1
                }).hide(), t || C.set(k, "bs.collapse", null)
            });
            const v = this._getDimension();
            this._element.classList.remove("collapse"), this._element.classList.add("collapsing"), this._element.style[v] = 0, this._addAriaAndCollapsedClass(this._triggerArray, !0), this._isTransitioning = !0;
            const E = "scroll" + (v[0].toUpperCase() + v.slice(1));
            this._queueCallback(() => {
                this._isTransitioning = !1, this._element.classList.remove("collapsing"), this._element.classList.add("collapse", "show"), this._element.style[v] = "", u.trigger(this._element, "shown.bs.collapse")
            }, this._element, !0), this._element.style[v] = this._element[E] + "px"
        }
        hide() {
            if (this._isTransitioning || !this._isShown() || u.trigger(this._element, "hide.bs.collapse").defaultPrevented) return;
            const t = this._getDimension();
            this._element.style[t] = this._element.getBoundingClientRect()[t] + "px", be(this._element), this._element.classList.add("collapsing"), this._element.classList.remove("collapse", "show");
            const i = this._triggerArray.length;
            for (let c = 0; c < i; c++) {
                const v = this._triggerArray[c],
                    E = O(v);
                E && !this._isShown(E) && this._addAriaAndCollapsedClass([v], !1)
            }
            this._isTransitioning = !0, this._element.style[t] = "", this._queueCallback(() => {
                this._isTransitioning = !1, this._element.classList.remove("collapsing"), this._element.classList.add("collapse"), u.trigger(this._element, "hidden.bs.collapse")
            }, this._element, !0)
        }
        _isShown(t = this._element) {
            return t.classList.contains("show")
        }
        _getConfig(t) {
            return (t = { ...yn,
                ...ye.getDataAttributes(this._element),
                ...t
            }).toggle = !!t.toggle, t.parent = U(t.parent), J("collapse", t, Pn), t
        }
        _getDimension() {
            return this._element.classList.contains("collapse-horizontal") ? "width" : "height"
        }
        _initializeChildren() {
            if (!this._config.parent) return;
            const t = ie.find(".collapse .collapse", this._config.parent);
            ie.find('[data-bs-toggle="collapse"]', this._config.parent).filter(i => !t.includes(i)).forEach(i => {
                const c = O(i);
                c && this._addAriaAndCollapsedClass([i], this._isShown(c))
            })
        }
        _addAriaAndCollapsedClass(t, i) {
            t.length && t.forEach(c => {
                i ? c.classList.remove("collapsed") : c.classList.add("collapsed"), c.setAttribute("aria-expanded", i)
            })
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const i = {};
                typeof t == "string" && /show|hide/.test(t) && (i.toggle = !1);
                const c = Dt.getOrCreateInstance(this, i);
                if (typeof t == "string") {
                    if (c[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    c[t]()
                }
            })
        }
    }
    u.on(document, "click.bs.collapse.data-api", '[data-bs-toggle="collapse"]', function(l) {
        (l.target.tagName === "A" || l.delegateTarget && l.delegateTarget.tagName === "A") && l.preventDefault();
        const t = L(this);
        ie.find(t).forEach(i => {
            Dt.getOrCreateInstance(i, {
                toggle: !1
            }).toggle()
        })
    }), fe(Dt);
    var We = "top",
        R = "bottom",
        Se = "right",
        Me = "left",
        He = [We, R, Se, Me],
        nt = He.reduce(function(l, t) {
            return l.concat([t + "-start", t + "-end"])
        }, []),
        Xe = [].concat(He, ["auto"]).reduce(function(l, t) {
            return l.concat([t, t + "-start", t + "-end"])
        }, []),
        pt = ["beforeRead", "read", "afterRead", "beforeMain", "main", "afterMain", "beforeWrite", "write", "afterWrite"];

    function Qe(l) {
        return l ? (l.nodeName || "").toLowerCase() : null
    }

    function dt(l) {
        if (l == null) return window;
        if (l.toString() !== "[object Window]") {
            var t = l.ownerDocument;
            return t && t.defaultView || window
        }
        return l
    }

    function Rt(l) {
        return l instanceof dt(l).Element || l instanceof Element
    }

    function yt(l) {
        return l instanceof dt(l).HTMLElement || l instanceof HTMLElement
    }

    function Kn(l) {
        return typeof ShadowRoot < "u" && (l instanceof dt(l).ShadowRoot || l instanceof ShadowRoot)
    }
    var bt = {
        name: "applyStyles",
        enabled: !0,
        phase: "write",
        fn: function(l) {
            var t = l.state;
            Object.keys(t.elements).forEach(function(i) {
                var c = t.styles[i] || {},
                    v = t.attributes[i] || {},
                    E = t.elements[i];
                yt(E) && Qe(E) && (Object.assign(E.style, c), Object.keys(v).forEach(function(k) {
                    var W = v[k];
                    W === !1 ? E.removeAttribute(k) : E.setAttribute(k, W === !0 ? "" : W)
                }))
            })
        },
        effect: function(l) {
            var t = l.state,
                i = {
                    popper: {
                        position: t.options.strategy,
                        left: "0",
                        top: "0",
                        margin: "0"
                    },
                    arrow: {
                        position: "absolute"
                    },
                    reference: {}
                };
            return Object.assign(t.elements.popper.style, i.popper), t.styles = i, t.elements.arrow && Object.assign(t.elements.arrow.style, i.arrow),
                function() {
                    Object.keys(t.elements).forEach(function(c) {
                        var v = t.elements[c],
                            E = t.attributes[c] || {},
                            k = Object.keys(t.styles.hasOwnProperty(c) ? t.styles[c] : i[c]).reduce(function(W, G) {
                                return W[G] = "", W
                            }, {});
                        yt(v) && Qe(v) && (Object.assign(v.style, k), Object.keys(E).forEach(function(W) {
                            v.removeAttribute(W)
                        }))
                    })
                }
        },
        requires: ["computeStyles"]
    };

    function Ze(l) {
        return l.split("-")[0]
    }
    var It = Math.round;

    function on(l, t) {
        t === void 0 && (t = !1);
        var i = l.getBoundingClientRect(),
            c = 1,
            v = 1;
        return yt(l) && t && (c = i.width / l.offsetWidth || 1, v = i.height / l.offsetHeight || 1), {
            width: It(i.width / c),
            height: It(i.height / v),
            top: It(i.top / v),
            right: It(i.right / c),
            bottom: It(i.bottom / v),
            left: It(i.left / c),
            x: It(i.left / c),
            y: It(i.top / v)
        }
    }

    function qn(l) {
        var t = on(l),
            i = l.offsetWidth,
            c = l.offsetHeight;
        return Math.abs(t.width - i) <= 1 && (i = t.width), Math.abs(t.height - c) <= 1 && (c = t.height), {
            x: l.offsetLeft,
            y: l.offsetTop,
            width: i,
            height: c
        }
    }

    function Xn(l, t) {
        var i = t.getRootNode && t.getRootNode();
        if (l.contains(t)) return !0;
        if (i && Kn(i)) {
            var c = t;
            do {
                if (c && l.isSameNode(c)) return !0;
                c = c.parentNode || c.host
            } while (c)
        }
        return !1
    }

    function _t(l) {
        return dt(l).getComputedStyle(l)
    }

    function an(l) {
        return ["table", "td", "th"].indexOf(Qe(l)) >= 0
    }

    function Ft(l) {
        return ((Rt(l) ? l.ownerDocument : l.document) || window.document).documentElement
    }

    function ln(l) {
        return Qe(l) === "html" ? l : l.assignedSlot || l.parentNode || (Kn(l) ? l.host : null) || Ft(l)
    }

    function bn(l) {
        return yt(l) && _t(l).position !== "fixed" ? l.offsetParent : null
    }

    function _n(l) {
        for (var t = dt(l), i = bn(l); i && an(i) && _t(i).position === "static";) i = bn(i);
        return i && (Qe(i) === "html" || Qe(i) === "body" && _t(i).position === "static") ? t : i || function(c) {
            var v = navigator.userAgent.toLowerCase().indexOf("firefox") !== -1;
            if (navigator.userAgent.indexOf("Trident") !== -1 && yt(c) && _t(c).position === "fixed") return null;
            for (var E = ln(c); yt(E) && ["html", "body"].indexOf(Qe(E)) < 0;) {
                var k = _t(E);
                if (k.transform !== "none" || k.perspective !== "none" || k.contain === "paint" || ["transform", "perspective"].indexOf(k.willChange) !== -1 || v && k.willChange === "filter" || v && k.filter && k.filter !== "none") return E;
                E = E.parentNode
            }
            return null
        }(l) || t
    }

    function Qn(l) {
        return ["top", "bottom"].indexOf(l) >= 0 ? "x" : "y"
    }
    var Gt = Math.max,
        cn = Math.min,
        Mn = Math.round;

    function Hn(l, t, i) {
        return Gt(l, cn(t, i))
    }

    function Zn(l) {
        return Object.assign({}, {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        }, l)
    }

    function Xt(l, t) {
        return t.reduce(function(i, c) {
            return i[c] = l, i
        }, {})
    }
    var Jn = {
            name: "arrow",
            enabled: !0,
            phase: "main",
            fn: function(l) {
                var t, i = l.state,
                    c = l.name,
                    v = l.options,
                    E = i.elements.arrow,
                    k = i.modifiersData.popperOffsets,
                    W = Ze(i.placement),
                    G = Qn(W),
                    Z = [Me, Se].indexOf(W) >= 0 ? "height" : "width";
                if (E && k) {
                    var X = function(Ae, Ne) {
                            return Zn(typeof(Ae = typeof Ae == "function" ? Ae(Object.assign({}, Ne.rects, {
                                placement: Ne.placement
                            })) : Ae) != "number" ? Ae : Xt(Ae, He))
                        }(v.padding, i),
                        z = qn(E),
                        pe = G === "y" ? We : Me,
                        ee = G === "y" ? R : Se,
                        re = i.rects.reference[Z] + i.rects.reference[G] - k[G] - i.rects.popper[Z],
                        Ce = k[G] - i.rects.reference[G],
                        Ee = _n(E),
                        Oe = Ee ? G === "y" ? Ee.clientHeight || 0 : Ee.clientWidth || 0 : 0,
                        je = re / 2 - Ce / 2,
                        $e = X[pe],
                        ce = Oe - z[Z] - X[ee],
                        Re = Oe / 2 - z[Z] / 2 + je,
                        xe = Hn($e, Re, ce),
                        _e = G;
                    i.modifiersData[c] = ((t = {})[_e] = xe, t.centerOffset = xe - Re, t)
                }
            },
            effect: function(l) {
                var t = l.state,
                    i = l.options.element,
                    c = i === void 0 ? "[data-popper-arrow]" : i;
                c != null && (typeof c != "string" || (c = t.elements.popper.querySelector(c))) && Xn(t.elements.popper, c) && (t.elements.arrow = c)
            },
            requires: ["popperOffsets"],
            requiresIfExists: ["preventOverflow"]
        },
        ei = {
            top: "auto",
            right: "auto",
            bottom: "auto",
            left: "auto"
        };

    function Rn(l) {
        var t, i = l.popper,
            c = l.popperRect,
            v = l.placement,
            E = l.offsets,
            k = l.position,
            W = l.gpuAcceleration,
            G = l.adaptive,
            Z = l.roundOffsets,
            X = Z === !0 ? function(Ne) {
                var Ue = Ne.x,
                    me = Ne.y,
                    ve = window.devicePixelRatio || 1;
                return {
                    x: Mn(Mn(Ue * ve) / ve) || 0,
                    y: Mn(Mn(me * ve) / ve) || 0
                }
            }(E) : typeof Z == "function" ? Z(E) : E,
            z = X.x,
            pe = z === void 0 ? 0 : z,
            ee = X.y,
            re = ee === void 0 ? 0 : ee,
            Ce = E.hasOwnProperty("x"),
            Ee = E.hasOwnProperty("y"),
            Oe = Me,
            je = We,
            $e = window;
        if (G) {
            var ce = _n(i),
                Re = "clientHeight",
                xe = "clientWidth";
            ce === dt(i) && _t(ce = Ft(i)).position !== "static" && (Re = "scrollHeight", xe = "scrollWidth"), ce = ce, v === We && (je = R, re -= ce[Re] - c.height, re *= W ? 1 : -1), v === Me && (Oe = Se, pe -= ce[xe] - c.width, pe *= W ? 1 : -1)
        }
        var _e, Ae = Object.assign({
            position: k
        }, G && ei);
        return W ? Object.assign({}, Ae, ((_e = {})[je] = Ee ? "0" : "", _e[Oe] = Ce ? "0" : "", _e.transform = ($e.devicePixelRatio || 1) < 2 ? "translate(" + pe + "px, " + re + "px)" : "translate3d(" + pe + "px, " + re + "px, 0)", _e)) : Object.assign({}, Ae, ((t = {})[je] = Ee ? re + "px" : "", t[Oe] = Ce ? pe + "px" : "", t.transform = "", t))
    }
    var un = {
            name: "computeStyles",
            enabled: !0,
            phase: "beforeWrite",
            fn: function(l) {
                var t = l.state,
                    i = l.options,
                    c = i.gpuAcceleration,
                    v = c === void 0 || c,
                    E = i.adaptive,
                    k = E === void 0 || E,
                    W = i.roundOffsets,
                    G = W === void 0 || W,
                    Z = {
                        placement: Ze(t.placement),
                        popper: t.elements.popper,
                        popperRect: t.rects.popper,
                        gpuAcceleration: v
                    };
                t.modifiersData.popperOffsets != null && (t.styles.popper = Object.assign({}, t.styles.popper, Rn(Object.assign({}, Z, {
                    offsets: t.modifiersData.popperOffsets,
                    position: t.options.strategy,
                    adaptive: k,
                    roundOffsets: G
                })))), t.modifiersData.arrow != null && (t.styles.arrow = Object.assign({}, t.styles.arrow, Rn(Object.assign({}, Z, {
                    offsets: t.modifiersData.arrow,
                    position: "absolute",
                    adaptive: !1,
                    roundOffsets: G
                })))), t.attributes.popper = Object.assign({}, t.attributes.popper, {
                    "data-popper-placement": t.placement
                })
            },
            data: {}
        },
        wn = {
            passive: !0
        },
        ti = {
            name: "eventListeners",
            enabled: !0,
            phase: "write",
            fn: function() {},
            effect: function(l) {
                var t = l.state,
                    i = l.instance,
                    c = l.options,
                    v = c.scroll,
                    E = v === void 0 || v,
                    k = c.resize,
                    W = k === void 0 || k,
                    G = dt(t.elements.popper),
                    Z = [].concat(t.scrollParents.reference, t.scrollParents.popper);
                return E && Z.forEach(function(X) {
                        X.addEventListener("scroll", i.update, wn)
                    }), W && G.addEventListener("resize", i.update, wn),
                    function() {
                        E && Z.forEach(function(X) {
                            X.removeEventListener("scroll", i.update, wn)
                        }), W && G.removeEventListener("resize", i.update, wn)
                    }
            },
            data: {}
        },
        bi = {
            left: "right",
            right: "left",
            bottom: "top",
            top: "bottom"
        };

    function Bn(l) {
        return l.replace(/left|right|bottom|top/g, function(t) {
            return bi[t]
        })
    }
    var xn = {
        start: "end",
        end: "start"
    };

    function ni(l) {
        return l.replace(/start|end/g, function(t) {
            return xn[t]
        })
    }

    function zn(l) {
        var t = dt(l);
        return {
            scrollLeft: t.pageXOffset,
            scrollTop: t.pageYOffset
        }
    }

    function Wn(l) {
        return on(Ft(l)).left + zn(l).scrollLeft
    }

    function Un(l) {
        var t = _t(l),
            i = t.overflow,
            c = t.overflowX,
            v = t.overflowY;
        return /auto|scroll|overlay|hidden/.test(i + v + c)
    }

    function Qt(l, t) {
        var i;
        t === void 0 && (t = []);
        var c = function G(Z) {
                return ["html", "body", "#document"].indexOf(Qe(Z)) >= 0 ? Z.ownerDocument.body : yt(Z) && Un(Z) ? Z : G(ln(Z))
            }(l),
            v = c === ((i = l.ownerDocument) == null ? void 0 : i.body),
            E = dt(c),
            k = v ? [E].concat(E.visualViewport || [], Un(c) ? c : []) : c,
            W = t.concat(k);
        return v ? W : W.concat(Qt(ln(k)))
    }

    function ii(l) {
        return Object.assign({}, l, {
            left: l.x,
            top: l.y,
            right: l.x + l.width,
            bottom: l.y + l.height
        })
    }

    function _i(l, t) {
        return t === "viewport" ? ii(function(i) {
            var c = dt(i),
                v = Ft(i),
                E = c.visualViewport,
                k = v.clientWidth,
                W = v.clientHeight,
                G = 0,
                Z = 0;
            return E && (k = E.width, W = E.height, /^((?!chrome|android).)*safari/i.test(navigator.userAgent) || (G = E.offsetLeft, Z = E.offsetTop)), {
                width: k,
                height: W,
                x: G + Wn(i),
                y: Z
            }
        }(l)) : yt(t) ? function(i) {
            var c = on(i);
            return c.top = c.top + i.clientTop, c.left = c.left + i.clientLeft, c.bottom = c.top + i.clientHeight, c.right = c.left + i.clientWidth, c.width = i.clientWidth, c.height = i.clientHeight, c.x = c.left, c.y = c.top, c
        }(t) : ii(function(i) {
            var c, v = Ft(i),
                E = zn(i),
                k = (c = i.ownerDocument) == null ? void 0 : c.body,
                W = Gt(v.scrollWidth, v.clientWidth, k ? k.scrollWidth : 0, k ? k.clientWidth : 0),
                G = Gt(v.scrollHeight, v.clientHeight, k ? k.scrollHeight : 0, k ? k.clientHeight : 0),
                Z = -E.scrollLeft + Wn(i),
                X = -E.scrollTop;
            return _t(k || v).direction === "rtl" && (Z += Gt(v.clientWidth, k ? k.clientWidth : 0) - W), {
                width: W,
                height: G,
                x: Z,
                y: X
            }
        }(Ft(l)))
    }

    function dn(l) {
        return l.split("-")[1]
    }

    function ri(l) {
        var t, i = l.reference,
            c = l.element,
            v = l.placement,
            E = v ? Ze(v) : null,
            k = v ? dn(v) : null,
            W = i.x + i.width / 2 - c.width / 2,
            G = i.y + i.height / 2 - c.height / 2;
        switch (E) {
            case We:
                t = {
                    x: W,
                    y: i.y - c.height
                };
                break;
            case R:
                t = {
                    x: W,
                    y: i.y + i.height
                };
                break;
            case Se:
                t = {
                    x: i.x + i.width,
                    y: G
                };
                break;
            case Me:
                t = {
                    x: i.x - c.width,
                    y: G
                };
                break;
            default:
                t = {
                    x: i.x,
                    y: i.y
                }
        }
        var Z = E ? Qn(E) : null;
        if (Z != null) {
            var X = Z === "y" ? "height" : "width";
            switch (k) {
                case "start":
                    t[Z] = t[Z] - (i[X] / 2 - c[X] / 2);
                    break;
                case "end":
                    t[Z] = t[Z] + (i[X] / 2 - c[X] / 2)
            }
        }
        return t
    }

    function Vt(l, t) {
        t === void 0 && (t = {});
        var i = t,
            c = i.placement,
            v = c === void 0 ? l.placement : c,
            E = i.boundary,
            k = E === void 0 ? "clippingParents" : E,
            W = i.rootBoundary,
            G = W === void 0 ? "viewport" : W,
            Z = i.elementContext,
            X = Z === void 0 ? "popper" : Z,
            z = i.altBoundary,
            pe = z !== void 0 && z,
            ee = i.padding,
            re = ee === void 0 ? 0 : ee,
            Ce = Zn(typeof re != "number" ? re : Xt(re, He)),
            Ee = X === "popper" ? "reference" : "popper",
            Oe = l.elements.reference,
            je = l.rects.popper,
            $e = l.elements[pe ? Ee : X],
            ce = function(ve, Ie, Ke) {
                var Fe = Ie === "clippingParents" ? function(it) {
                        var qt = Qt(ln(it)),
                            rt = ["absolute", "fixed"].indexOf(_t(it).position) >= 0 && yt(it) ? _n(it) : it;
                        return Rt(rt) ? qt.filter(function(st) {
                            return Rt(st) && Xn(st, rt) && Qe(st) !== "body"
                        }) : []
                    }(ve) : [].concat(Ie),
                    Je = [].concat(Fe, [Ke]),
                    jt = Je[0],
                    et = Je.reduce(function(it, qt) {
                        var rt = _i(ve, qt);
                        return it.top = Gt(rt.top, it.top), it.right = cn(rt.right, it.right), it.bottom = cn(rt.bottom, it.bottom), it.left = Gt(rt.left, it.left), it
                    }, _i(ve, jt));
                return et.width = et.right - et.left, et.height = et.bottom - et.top, et.x = et.left, et.y = et.top, et
            }(Rt($e) ? $e : $e.contextElement || Ft(l.elements.popper), k, G),
            Re = on(Oe),
            xe = ri({
                reference: Re,
                element: je,
                placement: v
            }),
            _e = ii(Object.assign({}, je, xe)),
            Ae = X === "popper" ? _e : Re,
            Ne = {
                top: ce.top - Ae.top + Ce.top,
                bottom: Ae.bottom - ce.bottom + Ce.bottom,
                left: ce.left - Ae.left + Ce.left,
                right: Ae.right - ce.right + Ce.right
            },
            Ue = l.modifiersData.offset;
        if (X === "popper" && Ue) {
            var me = Ue[v];
            Object.keys(Ne).forEach(function(ve) {
                var Ie = [Se, R].indexOf(ve) >= 0 ? 1 : -1,
                    Ke = [We, R].indexOf(ve) >= 0 ? "y" : "x";
                Ne[ve] += me[Ke] * Ie
            })
        }
        return Ne
    }

    function wi(l, t) {
        t === void 0 && (t = {});
        var i = t,
            c = i.placement,
            v = i.boundary,
            E = i.rootBoundary,
            k = i.padding,
            W = i.flipVariations,
            G = i.allowedAutoPlacements,
            Z = G === void 0 ? Xe : G,
            X = dn(c),
            z = X ? W ? nt : nt.filter(function(re) {
                return dn(re) === X
            }) : He,
            pe = z.filter(function(re) {
                return Z.indexOf(re) >= 0
            });
        pe.length === 0 && (pe = z);
        var ee = pe.reduce(function(re, Ce) {
            return re[Ce] = Vt(l, {
                placement: Ce,
                boundary: v,
                rootBoundary: E,
                padding: k
            })[Ze(Ce)], re
        }, {});
        return Object.keys(ee).sort(function(re, Ce) {
            return ee[re] - ee[Ce]
        })
    }
    var Ot = {
        name: "flip",
        enabled: !0,
        phase: "main",
        fn: function(l) {
            var t = l.state,
                i = l.options,
                c = l.name;
            if (!t.modifiersData[c]._skip) {
                for (var v = i.mainAxis, E = v === void 0 || v, k = i.altAxis, W = k === void 0 || k, G = i.fallbackPlacements, Z = i.padding, X = i.boundary, z = i.rootBoundary, pe = i.altBoundary, ee = i.flipVariations, re = ee === void 0 || ee, Ce = i.allowedAutoPlacements, Ee = t.options.placement, Oe = Ze(Ee), je = G || (Oe !== Ee && re ? function(rt) {
                        if (Ze(rt) === "auto") return [];
                        var st = Bn(rt);
                        return [ni(rt), st, ni(st)]
                    }(Ee) : [Bn(Ee)]), $e = [Ee].concat(je).reduce(function(rt, st) {
                        return rt.concat(Ze(st) === "auto" ? wi(t, {
                            placement: st,
                            boundary: X,
                            rootBoundary: z,
                            padding: Z,
                            flipVariations: re,
                            allowedAutoPlacements: Ce
                        }) : st)
                    }, []), ce = t.rects.reference, Re = t.rects.popper, xe = new Map, _e = !0, Ae = $e[0], Ne = 0; Ne < $e.length; Ne++) {
                    var Ue = $e[Ne],
                        me = Ze(Ue),
                        ve = dn(Ue) === "start",
                        Ie = [We, R].indexOf(me) >= 0,
                        Ke = Ie ? "width" : "height",
                        Fe = Vt(t, {
                            placement: Ue,
                            boundary: X,
                            rootBoundary: z,
                            altBoundary: pe,
                            padding: Z
                        }),
                        Je = Ie ? ve ? Se : Me : ve ? R : We;
                    ce[Ke] > Re[Ke] && (Je = Bn(Je));
                    var jt = Bn(Je),
                        et = [];
                    if (E && et.push(Fe[me] <= 0), W && et.push(Fe[Je] <= 0, Fe[jt] <= 0), et.every(function(rt) {
                            return rt
                        })) {
                        Ae = Ue, _e = !1;
                        break
                    }
                    xe.set(Ue, et)
                }
                if (_e)
                    for (var it = function(rt) {
                            var st = $e.find(function(Gn) {
                                var kn = xe.get(Gn);
                                if (kn) return kn.slice(0, rt).every(function(pn) {
                                    return pn
                                })
                            });
                            if (st) return Ae = st, "break"
                        }, qt = re ? 3 : 1; qt > 0 && it(qt) !== "break"; qt--);
                t.placement !== Ae && (t.modifiersData[c]._skip = !0, t.placement = Ae, t.reset = !0)
            }
        },
        requiresIfExists: ["offset"],
        data: {
            _skip: !1
        }
    };

    function Zt(l, t, i) {
        return i === void 0 && (i = {
            x: 0,
            y: 0
        }), {
            top: l.top - t.height - i.y,
            right: l.right - t.width + i.x,
            bottom: l.bottom - t.height + i.y,
            left: l.left - t.width - i.x
        }
    }

    function En(l) {
        return [We, Se, R, Me].some(function(t) {
            return l[t] >= 0
        })
    }
    var Jt = {
            name: "hide",
            enabled: !0,
            phase: "main",
            requiresIfExists: ["preventOverflow"],
            fn: function(l) {
                var t = l.state,
                    i = l.name,
                    c = t.rects.reference,
                    v = t.rects.popper,
                    E = t.modifiersData.preventOverflow,
                    k = Vt(t, {
                        elementContext: "reference"
                    }),
                    W = Vt(t, {
                        altBoundary: !0
                    }),
                    G = Zt(k, c),
                    Z = Zt(W, v, E),
                    X = En(G),
                    z = En(Z);
                t.modifiersData[i] = {
                    referenceClippingOffsets: G,
                    popperEscapeOffsets: Z,
                    isReferenceHidden: X,
                    hasPopperEscaped: z
                }, t.attributes.popper = Object.assign({}, t.attributes.popper, {
                    "data-popper-reference-hidden": X,
                    "data-popper-escaped": z
                })
            }
        },
        si = {
            name: "offset",
            enabled: !0,
            phase: "main",
            requires: ["popperOffsets"],
            fn: function(l) {
                var t = l.state,
                    i = l.options,
                    c = l.name,
                    v = i.offset,
                    E = v === void 0 ? [0, 0] : v,
                    k = Xe.reduce(function(X, z) {
                        return X[z] = function(pe, ee, re) {
                            var Ce = Ze(pe),
                                Ee = [Me, We].indexOf(Ce) >= 0 ? -1 : 1,
                                Oe = typeof re == "function" ? re(Object.assign({}, ee, {
                                    placement: pe
                                })) : re,
                                je = Oe[0],
                                $e = Oe[1];
                            return je = je || 0, $e = ($e || 0) * Ee, [Me, Se].indexOf(Ce) >= 0 ? {
                                x: $e,
                                y: je
                            } : {
                                x: je,
                                y: $e
                            }
                        }(z, t.rects, E), X
                    }, {}),
                    W = k[t.placement],
                    G = W.x,
                    Z = W.y;
                t.modifiersData.popperOffsets != null && (t.modifiersData.popperOffsets.x += G, t.modifiersData.popperOffsets.y += Z), t.modifiersData[c] = k
            }
        },
        oi = {
            name: "popperOffsets",
            enabled: !0,
            phase: "read",
            fn: function(l) {
                var t = l.state,
                    i = l.name;
                t.modifiersData[i] = ri({
                    reference: t.rects.reference,
                    element: t.rects.popper,
                    placement: t.placement
                })
            },
            data: {}
        },
        xi = {
            name: "preventOverflow",
            enabled: !0,
            phase: "main",
            fn: function(l) {
                var t = l.state,
                    i = l.options,
                    c = l.name,
                    v = i.mainAxis,
                    E = v === void 0 || v,
                    k = i.altAxis,
                    W = k !== void 0 && k,
                    G = i.boundary,
                    Z = i.rootBoundary,
                    X = i.altBoundary,
                    z = i.padding,
                    pe = i.tether,
                    ee = pe === void 0 || pe,
                    re = i.tetherOffset,
                    Ce = re === void 0 ? 0 : re,
                    Ee = Vt(t, {
                        boundary: G,
                        rootBoundary: Z,
                        padding: z,
                        altBoundary: X
                    }),
                    Oe = Ze(t.placement),
                    je = dn(t.placement),
                    $e = !je,
                    ce = Qn(Oe),
                    Re = ce === "x" ? "y" : "x",
                    xe = t.modifiersData.popperOffsets,
                    _e = t.rects.reference,
                    Ae = t.rects.popper,
                    Ne = typeof Ce == "function" ? Ce(Object.assign({}, t.rects, {
                        placement: t.placement
                    })) : Ce,
                    Ue = {
                        x: 0,
                        y: 0
                    };
                if (xe) {
                    if (E || W) {
                        var me = ce === "y" ? We : Me,
                            ve = ce === "y" ? R : Se,
                            Ie = ce === "y" ? "height" : "width",
                            Ke = xe[ce],
                            Fe = xe[ce] + Ee[me],
                            Je = xe[ce] - Ee[ve],
                            jt = ee ? -Ae[Ie] / 2 : 0,
                            et = je === "start" ? _e[Ie] : Ae[Ie],
                            it = je === "start" ? -Ae[Ie] : -_e[Ie],
                            qt = t.elements.arrow,
                            rt = ee && qt ? qn(qt) : {
                                width: 0,
                                height: 0
                            },
                            st = t.modifiersData["arrow#persistent"] ? t.modifiersData["arrow#persistent"].padding : {
                                top: 0,
                                right: 0,
                                bottom: 0,
                                left: 0
                            },
                            Gn = st[me],
                            kn = st[ve],
                            pn = Hn(0, _e[Ie], rt[Ie]),
                            Dn = $e ? _e[Ie] / 2 - jt - pn - Gn - Ne : et - pn - Gn - Ne,
                            ar = $e ? -_e[Ie] / 2 + jt + pn + kn + Ne : it + pn + kn + Ne,
                            On = t.elements.arrow && _n(t.elements.arrow),
                            Bt = On ? ce === "y" ? On.clientTop || 0 : On.clientLeft || 0 : 0,
                            Mt = t.modifiersData.offset ? t.modifiersData.offset[t.placement][ce] : 0,
                            fi = xe[ce] + Dn - Mt - Bt,
                            gi = xe[ce] + ar - Mt;
                        if (E) {
                            var mi = Hn(ee ? cn(Fe, fi) : Fe, Ke, ee ? Gt(Je, gi) : Je);
                            xe[ce] = mi, Ue[ce] = mi - Ke
                        }
                        if (W) {
                            var lr = ce === "x" ? We : Me,
                                Ge = ce === "x" ? R : Se,
                                sn = xe[Re],
                                Lt = sn + Ee[lr],
                                At = sn - Ee[Ge],
                                Vn = Hn(ee ? cn(Lt, fi) : Lt, sn, ee ? Gt(At, gi) : At);
                            xe[Re] = Vn, Ue[Re] = Vn - sn
                        }
                    }
                    t.modifiersData[c] = Ue
                }
            },
            requiresIfExists: ["offset"]
        };

    function ai(l, t, i) {
        i === void 0 && (i = !1);
        var c, v, E = yt(t),
            k = yt(t) && function(z) {
                var pe = z.getBoundingClientRect(),
                    ee = pe.width / z.offsetWidth || 1,
                    re = pe.height / z.offsetHeight || 1;
                return ee !== 1 || re !== 1
            }(t),
            W = Ft(t),
            G = on(l, k),
            Z = {
                scrollLeft: 0,
                scrollTop: 0
            },
            X = {
                x: 0,
                y: 0
            };
        return (E || !E && !i) && ((Qe(t) !== "body" || Un(W)) && (Z = (c = t) !== dt(c) && yt(c) ? {
            scrollLeft: (v = c).scrollLeft,
            scrollTop: v.scrollTop
        } : zn(c)), yt(t) ? ((X = on(t, !0)).x += t.clientLeft, X.y += t.clientTop) : W && (X.x = Wn(W))), {
            x: G.left + Z.scrollLeft - X.x,
            y: G.top + Z.scrollTop - X.y,
            width: G.width,
            height: G.height
        }
    }
    var li = {
        placement: "bottom",
        modifiers: [],
        strategy: "absolute"
    };

    function An() {
        for (var l = arguments.length, t = new Array(l), i = 0; i < l; i++) t[i] = arguments[i];
        return !t.some(function(c) {
            return !(c && typeof c.getBoundingClientRect == "function")
        })
    }

    function Tn(l) {
        l === void 0 && (l = {});
        var t = l,
            i = t.defaultModifiers,
            c = i === void 0 ? [] : i,
            v = t.defaultOptions,
            E = v === void 0 ? li : v;
        return function(k, W, G) {
            G === void 0 && (G = E);
            var Z, X, z = {
                    placement: "bottom",
                    orderedModifiers: [],
                    options: Object.assign({}, li, E),
                    modifiersData: {},
                    elements: {
                        reference: k,
                        popper: W
                    },
                    attributes: {},
                    styles: {}
                },
                pe = [],
                ee = !1,
                re = {
                    state: z,
                    setOptions: function(Ee) {
                        Ce(), z.options = Object.assign({}, E, z.options, Ee), z.scrollParents = {
                            reference: Rt(k) ? Qt(k) : k.contextElement ? Qt(k.contextElement) : [],
                            popper: Qt(W)
                        };
                        var Oe, je, $e = function(ce) {
                            var Re = function(xe) {
                                var _e = new Map,
                                    Ae = new Set,
                                    Ne = [];
                                return xe.forEach(function(Ue) {
                                    _e.set(Ue.name, Ue)
                                }), xe.forEach(function(Ue) {
                                    Ae.has(Ue.name) || function me(ve) {
                                        Ae.add(ve.name), [].concat(ve.requires || [], ve.requiresIfExists || []).forEach(function(Ie) {
                                            if (!Ae.has(Ie)) {
                                                var Ke = _e.get(Ie);
                                                Ke && me(Ke)
                                            }
                                        }), Ne.push(ve)
                                    }(Ue)
                                }), Ne
                            }(ce);
                            return pt.reduce(function(xe, _e) {
                                return xe.concat(Re.filter(function(Ae) {
                                    return Ae.phase === _e
                                }))
                            }, [])
                        }((Oe = [].concat(c, z.options.modifiers), je = Oe.reduce(function(ce, Re) {
                            var xe = ce[Re.name];
                            return ce[Re.name] = xe ? Object.assign({}, xe, Re, {
                                options: Object.assign({}, xe.options, Re.options),
                                data: Object.assign({}, xe.data, Re.data)
                            }) : Re, ce
                        }, {}), Object.keys(je).map(function(ce) {
                            return je[ce]
                        })));
                        return z.orderedModifiers = $e.filter(function(ce) {
                            return ce.enabled
                        }), z.orderedModifiers.forEach(function(ce) {
                            var Re = ce.name,
                                xe = ce.options,
                                _e = xe === void 0 ? {} : xe,
                                Ae = ce.effect;
                            if (typeof Ae == "function") {
                                var Ne = Ae({
                                    state: z,
                                    name: Re,
                                    instance: re,
                                    options: _e
                                });
                                pe.push(Ne || function() {})
                            }
                        }), re.update()
                    },
                    forceUpdate: function() {
                        if (!ee) {
                            var Ee = z.elements,
                                Oe = Ee.reference,
                                je = Ee.popper;
                            if (An(Oe, je)) {
                                z.rects = {
                                    reference: ai(Oe, _n(je), z.options.strategy === "fixed"),
                                    popper: qn(je)
                                }, z.reset = !1, z.placement = z.options.placement, z.orderedModifiers.forEach(function(Ne) {
                                    return z.modifiersData[Ne.name] = Object.assign({}, Ne.data)
                                });
                                for (var $e = 0; $e < z.orderedModifiers.length; $e++)
                                    if (z.reset !== !0) {
                                        var ce = z.orderedModifiers[$e],
                                            Re = ce.fn,
                                            xe = ce.options,
                                            _e = xe === void 0 ? {} : xe,
                                            Ae = ce.name;
                                        typeof Re == "function" && (z = Re({
                                            state: z,
                                            options: _e,
                                            name: Ae,
                                            instance: re
                                        }) || z)
                                    } else z.reset = !1, $e = -1
                            }
                        }
                    },
                    update: (Z = function() {
                        return new Promise(function(Ee) {
                            re.forceUpdate(), Ee(z)
                        })
                    }, function() {
                        return X || (X = new Promise(function(Ee) {
                            Promise.resolve().then(function() {
                                X = void 0, Ee(Z())
                            })
                        })), X
                    }),
                    destroy: function() {
                        Ce(), ee = !0
                    }
                };
            if (!An(k, W)) return re;

            function Ce() {
                pe.forEach(function(Ee) {
                    return Ee()
                }), pe = []
            }
            return re.setOptions(G).then(function(Ee) {
                !ee && G.onFirstUpdate && G.onFirstUpdate(Ee)
            }), re
        }
    }
    var $t = Tn(),
        Ei = Tn({
            defaultModifiers: [ti, oi, un, bt]
        }),
        en = Tn({
            defaultModifiers: [ti, oi, un, bt, si, Ot, xi, Jn, Jt]
        }),
        Ai = Object.freeze({
            __proto__: null,
            popperGenerator: Tn,
            detectOverflow: Vt,
            createPopperBase: $t,
            createPopper: en,
            createPopperLite: Ei,
            top: We,
            bottom: R,
            right: Se,
            left: Me,
            auto: "auto",
            basePlacements: He,
            start: "start",
            end: "end",
            clippingParents: "clippingParents",
            viewport: "viewport",
            popper: "popper",
            reference: "reference",
            variationPlacements: nt,
            placements: Xe,
            beforeRead: "beforeRead",
            read: "read",
            afterRead: "afterRead",
            beforeMain: "beforeMain",
            main: "main",
            afterMain: "afterMain",
            beforeWrite: "beforeWrite",
            write: "write",
            afterWrite: "afterWrite",
            modifierPhases: pt,
            applyStyles: bt,
            arrow: Jn,
            computeStyles: un,
            eventListeners: ti,
            flip: Ot,
            hide: Jt,
            offset: si,
            popperOffsets: oi,
            preventOverflow: xi
        });
    const Ji = new RegExp("ArrowUp|ArrowDown|Escape"),
        tn = Y() ? "top-end" : "top-start",
        nn = Y() ? "top-start" : "top-end",
        ci = Y() ? "bottom-end" : "bottom-start",
        er = Y() ? "bottom-start" : "bottom-end",
        Ti = Y() ? "left-start" : "right-start",
        Ci = Y() ? "right-start" : "left-start",
        Cn = {
            offset: [0, 2],
            boundary: "clippingParents",
            reference: "toggle",
            display: "dynamic",
            popperConfig: null,
            autoClose: !0
        },
        Si = {
            offset: "(array|string|function)",
            boundary: "(string|element)",
            reference: "(string|element|object)",
            display: "string",
            popperConfig: "(null|object|function)",
            autoClose: "(boolean|string)"
        };
    class vt extends q {
        constructor(t, i) {
            super(t), this._popper = null, this._config = this._getConfig(i), this._menu = this._getMenuElement(), this._inNavbar = this._detectNavbar()
        }
        static get Default() {
            return Cn
        }
        static get DefaultType() {
            return Si
        }
        static get NAME() {
            return "dropdown"
        }
        toggle() {
            return this._isShown() ? this.hide() : this.show()
        }
        show() {
            if (V(this._element) || this._isShown(this._menu)) return;
            const t = {
                relatedTarget: this._element
            };
            if (u.trigger(this._element, "show.bs.dropdown", t).defaultPrevented) return;
            const i = vt.getParentFromElement(this._element);
            this._inNavbar ? ye.setDataAttribute(this._menu, "popper", "none") : this._createPopper(i), "ontouchstart" in document.documentElement && !i.closest(".navbar-nav") && [].concat(...document.body.children).forEach(c => u.on(c, "mouseover", qe)), this._element.focus(), this._element.setAttribute("aria-expanded", !0), this._menu.classList.add("show"), this._element.classList.add("show"), u.trigger(this._element, "shown.bs.dropdown", t)
        }
        hide() {
            if (V(this._element) || !this._isShown(this._menu)) return;
            const t = {
                relatedTarget: this._element
            };
            this._completeHide(t)
        }
        dispose() {
            this._popper && this._popper.destroy(), super.dispose()
        }
        update() {
            this._inNavbar = this._detectNavbar(), this._popper && this._popper.update()
        }
        _completeHide(t) {
            u.trigger(this._element, "hide.bs.dropdown", t).defaultPrevented || ("ontouchstart" in document.documentElement && [].concat(...document.body.children).forEach(i => u.off(i, "mouseover", qe)), this._popper && this._popper.destroy(), this._menu.classList.remove("show"), this._element.classList.remove("show"), this._element.setAttribute("aria-expanded", "false"), ye.removeDataAttribute(this._menu, "popper"), u.trigger(this._element, "hidden.bs.dropdown", t))
        }
        _getConfig(t) {
            if (t = { ...this.constructor.Default,
                    ...ye.getDataAttributes(this._element),
                    ...t
                }, J("dropdown", t, this.constructor.DefaultType), typeof t.reference == "object" && !H(t.reference) && typeof t.reference.getBoundingClientRect != "function") throw new TypeError("dropdown".toUpperCase() + ': Option "reference" provided type "object" without a required "getBoundingClientRect" method.');
            return t
        }
        _createPopper(t) {
            if (Ai === void 0) throw new TypeError("Bootstrap's dropdowns require Popper (https://popper.js.org)");
            let i = this._element;
            this._config.reference === "parent" ? i = t : H(this._config.reference) ? i = U(this._config.reference) : typeof this._config.reference == "object" && (i = this._config.reference);
            const c = this._getPopperConfig(),
                v = c.modifiers.find(E => E.name === "applyStyles" && E.enabled === !1);
            this._popper = en(i, this._menu, c), v && ye.setDataAttribute(this._menu, "popper", "static")
        }
        _isShown(t = this._element) {
            return t.classList.contains("show")
        }
        _getMenuElement() {
            return ie.next(this._element, ".dropdown-menu")[0]
        }
        _getPlacement() {
            const t = this._element.parentNode;
            if (t.classList.contains("dropend")) return Ti;
            if (t.classList.contains("dropstart")) return Ci;
            const i = getComputedStyle(this._menu).getPropertyValue("--bs-position").trim() === "end";
            return t.classList.contains("dropup") ? i ? nn : tn : i ? er : ci
        }
        _detectNavbar() {
            return this._element.closest(".navbar") !== null
        }
        _getOffset() {
            const {
                offset: t
            } = this._config;
            return typeof t == "string" ? t.split(",").map(i => Number.parseInt(i, 10)) : typeof t == "function" ? i => t(i, this._element) : t
        }
        _getPopperConfig() {
            const t = {
                placement: this._getPlacement(),
                modifiers: [{
                    name: "preventOverflow",
                    options: {
                        boundary: this._config.boundary
                    }
                }, {
                    name: "offset",
                    options: {
                        offset: this._getOffset()
                    }
                }]
            };
            return this._config.display === "static" && (t.modifiers = [{
                name: "applyStyles",
                enabled: !1
            }]), { ...t,
                ...typeof this._config.popperConfig == "function" ? this._config.popperConfig(t) : this._config.popperConfig
            }
        }
        _selectMenuItem({
            key: t,
            target: i
        }) {
            const c = ie.find(".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)", this._menu).filter(B);
            c.length && gt(c, i, t === "ArrowDown", !c.includes(i)).focus()
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const i = vt.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (i[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    i[t]()
                }
            })
        }
        static clearMenus(t) {
            if (t && (t.button === 2 || t.type === "keyup" && t.key !== "Tab")) return;
            const i = ie.find('[data-bs-toggle="dropdown"]');
            for (let c = 0, v = i.length; c < v; c++) {
                const E = vt.getInstance(i[c]);
                if (!E || E._config.autoClose === !1 || !E._isShown()) continue;
                const k = {
                    relatedTarget: E._element
                };
                if (t) {
                    const W = t.composedPath(),
                        G = W.includes(E._menu);
                    if (W.includes(E._element) || E._config.autoClose === "inside" && !G || E._config.autoClose === "outside" && G || E._menu.contains(t.target) && (t.type === "keyup" && t.key === "Tab" || /input|select|option|textarea|form/i.test(t.target.tagName))) continue;
                    t.type === "click" && (k.clickEvent = t)
                }
                E._completeHide(k)
            }
        }
        static getParentFromElement(t) {
            return O(t) || t.parentNode
        }
        static dataApiKeydownHandler(t) {
            if (/input|textarea/i.test(t.target.tagName) ? t.key === "Space" || t.key !== "Escape" && (t.key !== "ArrowDown" && t.key !== "ArrowUp" || t.target.closest(".dropdown-menu")) : !Ji.test(t.key)) return;
            const i = this.classList.contains("show");
            if (!i && t.key === "Escape" || (t.preventDefault(), t.stopPropagation(), V(this))) return;
            const c = this.matches('[data-bs-toggle="dropdown"]') ? this : ie.prev(this, '[data-bs-toggle="dropdown"]')[0],
                v = vt.getOrCreateInstance(c);
            if (t.key !== "Escape") return t.key === "ArrowUp" || t.key === "ArrowDown" ? (i || v.show(), void v._selectMenuItem(t)) : void(i && t.key !== "Space" || vt.clearMenus());
            v.hide()
        }
    }
    u.on(document, "keydown.bs.dropdown.data-api", '[data-bs-toggle="dropdown"]', vt.dataApiKeydownHandler), u.on(document, "keydown.bs.dropdown.data-api", ".dropdown-menu", vt.dataApiKeydownHandler), u.on(document, "click.bs.dropdown.data-api", vt.clearMenus), u.on(document, "keyup.bs.dropdown.data-api", vt.clearMenus), u.on(document, "click.bs.dropdown.data-api", '[data-bs-toggle="dropdown"]', function(l) {
        l.preventDefault(), vt.getOrCreateInstance(this).toggle()
    }), fe(vt);
    class ui {
        constructor() {
            this._element = document.body
        }
        getWidth() {
            const t = document.documentElement.clientWidth;
            return Math.abs(window.innerWidth - t)
        }
        hide() {
            const t = this.getWidth();
            this._disableOverFlow(), this._setElementAttributes(this._element, "paddingRight", i => i + t), this._setElementAttributes(".fixed-top, .fixed-bottom, .is-fixed, .sticky-top", "paddingRight", i => i + t), this._setElementAttributes(".sticky-top", "marginRight", i => i - t)
        }
        _disableOverFlow() {
            this._saveInitialAttribute(this._element, "overflow"), this._element.style.overflow = "hidden"
        }
        _setElementAttributes(t, i, c) {
            const v = this.getWidth();
            this._applyManipulationCallback(t, E => {
                if (E !== this._element && window.innerWidth > E.clientWidth + v) return;
                this._saveInitialAttribute(E, i);
                const k = window.getComputedStyle(E)[i];
                E.style[i] = c(Number.parseFloat(k)) + "px"
            })
        }
        reset() {
            this._resetElementAttributes(this._element, "overflow"), this._resetElementAttributes(this._element, "paddingRight"), this._resetElementAttributes(".fixed-top, .fixed-bottom, .is-fixed, .sticky-top", "paddingRight"), this._resetElementAttributes(".sticky-top", "marginRight")
        }
        _saveInitialAttribute(t, i) {
            const c = t.style[i];
            c && ye.setDataAttribute(t, i, c)
        }
        _resetElementAttributes(t, i) {
            this._applyManipulationCallback(t, c => {
                const v = ye.getDataAttribute(c, i);
                v === void 0 ? c.style.removeProperty(i) : (ye.removeDataAttribute(c, i), c.style[i] = v)
            })
        }
        _applyManipulationCallback(t, i) {
            H(t) ? i(t) : ie.find(t, this._element).forEach(i)
        }
        isOverflowing() {
            return this.getWidth() > 0
        }
    }
    const ki = {
            className: "modal-backdrop",
            isVisible: !0,
            isAnimated: !1,
            rootElement: "body",
            clickCallback: null
        },
        tr = {
            className: "string",
            isVisible: "boolean",
            isAnimated: "boolean",
            rootElement: "(element|string)",
            clickCallback: "(function|null)"
        };
    class Di {
        constructor(t) {
            this._config = this._getConfig(t), this._isAppended = !1, this._element = null
        }
        show(t) {
            this._config.isVisible ? (this._append(), this._config.isAnimated && be(this._getElement()), this._getElement().classList.add("show"), this._emulateAnimation(() => {
                se(t)
            })) : se(t)
        }
        hide(t) {
            this._config.isVisible ? (this._getElement().classList.remove("show"), this._emulateAnimation(() => {
                this.dispose(), se(t)
            })) : se(t)
        }
        _getElement() {
            if (!this._element) {
                const t = document.createElement("div");
                t.className = this._config.className, this._config.isAnimated && t.classList.add("fade"), this._element = t
            }
            return this._element
        }
        _getConfig(t) {
            return (t = { ...ki,
                ...typeof t == "object" ? t : {}
            }).rootElement = U(t.rootElement), J("backdrop", t, tr), t
        }
        _append() {
            this._isAppended || (this._config.rootElement.append(this._getElement()), u.on(this._getElement(), "mousedown.bs.backdrop", () => {
                se(this._config.clickCallback)
            }), this._isAppended = !0)
        }
        dispose() {
            this._isAppended && (u.off(this._element, "mousedown.bs.backdrop"), this._element.remove(), this._isAppended = !1)
        }
        _emulateAnimation(t) {
            Ve(t, this._getElement(), this._config.isAnimated)
        }
    }
    const di = {
            trapElement: null,
            autofocus: !0
        },
        nr = {
            trapElement: "element",
            autofocus: "boolean"
        };
    class Oi {
        constructor(t) {
            this._config = this._getConfig(t), this._isActive = !1, this._lastTabNavDirection = null
        }
        activate() {
            const {
                trapElement: t,
                autofocus: i
            } = this._config;
            this._isActive || (i && t.focus(), u.off(document, ".bs.focustrap"), u.on(document, "focusin.bs.focustrap", c => this._handleFocusin(c)), u.on(document, "keydown.tab.bs.focustrap", c => this._handleKeydown(c)), this._isActive = !0)
        }
        deactivate() {
            this._isActive && (this._isActive = !1, u.off(document, ".bs.focustrap"))
        }
        _handleFocusin(t) {
            const {
                target: i
            } = t, {
                trapElement: c
            } = this._config;
            if (i === document || i === c || c.contains(i)) return;
            const v = ie.focusableChildren(c);
            v.length === 0 ? c.focus() : this._lastTabNavDirection === "backward" ? v[v.length - 1].focus() : v[0].focus()
        }
        _handleKeydown(t) {
            t.key === "Tab" && (this._lastTabNavDirection = t.shiftKey ? "backward" : "forward")
        }
        _getConfig(t) {
            return t = { ...di,
                ...typeof t == "object" ? t : {}
            }, J("focustrap", t, nr), t
        }
    }
    const Li = {
            backdrop: !0,
            keyboard: !0,
            focus: !0
        },
        ir = {
            backdrop: "(boolean|string)",
            keyboard: "boolean",
            focus: "boolean"
        };
    class hn extends q {
        constructor(t, i) {
            super(t), this._config = this._getConfig(i), this._dialog = ie.findOne(".modal-dialog", this._element), this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._isShown = !1, this._ignoreBackdropClick = !1, this._isTransitioning = !1, this._scrollBar = new ui
        }
        static get Default() {
            return Li
        }
        static get NAME() {
            return "modal"
        }
        toggle(t) {
            return this._isShown ? this.hide() : this.show(t)
        }
        show(t) {
            this._isShown || this._isTransitioning || u.trigger(this._element, "show.bs.modal", {
                relatedTarget: t
            }).defaultPrevented || (this._isShown = !0, this._isAnimated() && (this._isTransitioning = !0), this._scrollBar.hide(), document.body.classList.add("modal-open"), this._adjustDialog(), this._setEscapeEvent(), this._setResizeEvent(), u.on(this._dialog, "mousedown.dismiss.bs.modal", () => {
                u.one(this._element, "mouseup.dismiss.bs.modal", i => {
                    i.target === this._element && (this._ignoreBackdropClick = !0)
                })
            }), this._showBackdrop(() => this._showElement(t)))
        }
        hide() {
            if (!this._isShown || this._isTransitioning || u.trigger(this._element, "hide.bs.modal").defaultPrevented) return;
            this._isShown = !1;
            const t = this._isAnimated();
            t && (this._isTransitioning = !0), this._setEscapeEvent(), this._setResizeEvent(), this._focustrap.deactivate(), this._element.classList.remove("show"), u.off(this._element, "click.dismiss.bs.modal"), u.off(this._dialog, "mousedown.dismiss.bs.modal"), this._queueCallback(() => this._hideModal(), this._element, t)
        }
        dispose() {
            [window, this._dialog].forEach(t => u.off(t, ".bs.modal")), this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose()
        }
        handleUpdate() {
            this._adjustDialog()
        }
        _initializeBackDrop() {
            return new Di({
                isVisible: !!this._config.backdrop,
                isAnimated: this._isAnimated()
            })
        }
        _initializeFocusTrap() {
            return new Oi({
                trapElement: this._element
            })
        }
        _getConfig(t) {
            return t = { ...Li,
                ...ye.getDataAttributes(this._element),
                ...typeof t == "object" ? t : {}
            }, J("modal", t, ir), t
        }
        _showElement(t) {
            const i = this._isAnimated(),
                c = ie.findOne(".modal-body", this._dialog);
            this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE || document.body.append(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.scrollTop = 0, c && (c.scrollTop = 0), i && be(this._element), this._element.classList.add("show"), this._queueCallback(() => {
                this._config.focus && this._focustrap.activate(), this._isTransitioning = !1, u.trigger(this._element, "shown.bs.modal", {
                    relatedTarget: t
                })
            }, this._dialog, i)
        }
        _setEscapeEvent() {
            this._isShown ? u.on(this._element, "keydown.dismiss.bs.modal", t => {
                this._config.keyboard && t.key === "Escape" ? (t.preventDefault(), this.hide()) : this._config.keyboard || t.key !== "Escape" || this._triggerBackdropTransition()
            }) : u.off(this._element, "keydown.dismiss.bs.modal")
        }
        _setResizeEvent() {
            this._isShown ? u.on(window, "resize.bs.modal", () => this._adjustDialog()) : u.off(window, "resize.bs.modal")
        }
        _hideModal() {
            this._element.style.display = "none", this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._isTransitioning = !1, this._backdrop.hide(() => {
                document.body.classList.remove("modal-open"), this._resetAdjustments(), this._scrollBar.reset(), u.trigger(this._element, "hidden.bs.modal")
            })
        }
        _showBackdrop(t) {
            u.on(this._element, "click.dismiss.bs.modal", i => {
                this._ignoreBackdropClick ? this._ignoreBackdropClick = !1 : i.target === i.currentTarget && (this._config.backdrop === !0 ? this.hide() : this._config.backdrop === "static" && this._triggerBackdropTransition())
            }), this._backdrop.show(t)
        }
        _isAnimated() {
            return this._element.classList.contains("fade")
        }
        _triggerBackdropTransition() {
            if (u.trigger(this._element, "hidePrevented.bs.modal").defaultPrevented) return;
            const {
                classList: t,
                scrollHeight: i,
                style: c
            } = this._element, v = i > document.documentElement.clientHeight;
            !v && c.overflowY === "hidden" || t.contains("modal-static") || (v || (c.overflowY = "hidden"), t.add("modal-static"), this._queueCallback(() => {
                t.remove("modal-static"), v || this._queueCallback(() => {
                    c.overflowY = ""
                }, this._dialog)
            }, this._dialog), this._element.focus())
        }
        _adjustDialog() {
            const t = this._element.scrollHeight > document.documentElement.clientHeight,
                i = this._scrollBar.getWidth(),
                c = i > 0;
            (!c && t && !Y() || c && !t && Y()) && (this._element.style.paddingLeft = i + "px"), (c && !t && !Y() || !c && t && Y()) && (this._element.style.paddingRight = i + "px")
        }
        _resetAdjustments() {
            this._element.style.paddingLeft = "", this._element.style.paddingRight = ""
        }
        static jQueryInterface(t, i) {
            return this.each(function() {
                const c = hn.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (c[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    c[t](i)
                }
            })
        }
    }
    u.on(document, "click.bs.modal.data-api", '[data-bs-toggle="modal"]', function(l) {
        const t = O(this);
        ["A", "AREA"].includes(this.tagName) && l.preventDefault(), u.one(t, "show.bs.modal", i => {
            i.defaultPrevented || u.one(t, "hidden.bs.modal", () => {
                B(this) && this.focus()
            })
        }), hn.getOrCreateInstance(t).toggle(this)
    }), M(hn), fe(hn);
    const $i = {
            backdrop: !0,
            keyboard: !0,
            scroll: !1
        },
        ji = {
            backdrop: "boolean",
            keyboard: "boolean",
            scroll: "boolean"
        };
    class Pt extends q {
        constructor(t, i) {
            super(t), this._config = this._getConfig(i), this._isShown = !1, this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._addEventListeners()
        }
        static get NAME() {
            return "offcanvas"
        }
        static get Default() {
            return $i
        }
        toggle(t) {
            return this._isShown ? this.hide() : this.show(t)
        }
        show(t) {
            this._isShown || u.trigger(this._element, "show.bs.offcanvas", {
                relatedTarget: t
            }).defaultPrevented || (this._isShown = !0, this._element.style.visibility = "visible", this._backdrop.show(), this._config.scroll || new ui().hide(), this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.classList.add("show"), this._queueCallback(() => {
                this._config.scroll || this._focustrap.activate(), u.trigger(this._element, "shown.bs.offcanvas", {
                    relatedTarget: t
                })
            }, this._element, !0))
        }
        hide() {
            this._isShown && (u.trigger(this._element, "hide.bs.offcanvas").defaultPrevented || (this._focustrap.deactivate(), this._element.blur(), this._isShown = !1, this._element.classList.remove("show"), this._backdrop.hide(), this._queueCallback(() => {
                this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._element.style.visibility = "hidden", this._config.scroll || new ui().reset(), u.trigger(this._element, "hidden.bs.offcanvas")
            }, this._element, !0)))
        }
        dispose() {
            this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose()
        }
        _getConfig(t) {
            return t = { ...$i,
                ...ye.getDataAttributes(this._element),
                ...typeof t == "object" ? t : {}
            }, J("offcanvas", t, ji), t
        }
        _initializeBackDrop() {
            return new Di({
                className: "offcanvas-backdrop",
                isVisible: this._config.backdrop,
                isAnimated: !0,
                rootElement: this._element.parentNode,
                clickCallback: () => this.hide()
            })
        }
        _initializeFocusTrap() {
            return new Oi({
                trapElement: this._element
            })
        }
        _addEventListeners() {
            u.on(this._element, "keydown.dismiss.bs.offcanvas", t => {
                this._config.keyboard && t.key === "Escape" && this.hide()
            })
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const i = Pt.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (i[t] === void 0 || t.startsWith("_") || t === "constructor") throw new TypeError(`No method named "${t}"`);
                    i[t](this)
                }
            })
        }
    }
    u.on(document, "click.bs.offcanvas.data-api", '[data-bs-toggle="offcanvas"]', function(l) {
        const t = O(this);
        if (["A", "AREA"].includes(this.tagName) && l.preventDefault(), V(this)) return;
        u.one(t, "hidden.bs.offcanvas", () => {
            B(this) && this.focus()
        });
        const i = ie.findOne(".offcanvas.show");
        i && i !== t && Pt.getInstance(i).hide(), Pt.getOrCreateInstance(t).toggle(this)
    }), u.on(window, "load.bs.offcanvas.data-api", () => ie.find(".offcanvas.show").forEach(l => Pt.getOrCreateInstance(l).show())), M(Pt), fe(Pt);
    const Ni = new Set(["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"]),
        hi = /^(?:(?:https?|mailto|ftp|tel|file):|[^#&/:?]*(?:[#/?]|$))/i,
        Ii = /^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[\d+/a-z]+=*$/i,
        Pi = (l, t) => {
            const i = l.nodeName.toLowerCase();
            if (t.includes(i)) return !Ni.has(i) || !!(hi.test(l.nodeValue) || Ii.test(l.nodeValue));
            const c = t.filter(v => v instanceof RegExp);
            for (let v = 0, E = c.length; v < E; v++)
                if (c[v].test(i)) return !0;
            return !1
        };

    function Fn(l, t, i) {
        if (!l.length) return l;
        if (i && typeof i == "function") return i(l);
        const c = new window.DOMParser().parseFromString(l, "text/html"),
            v = Object.keys(t),
            E = [].concat(...c.body.querySelectorAll("*"));
        for (let k = 0, W = E.length; k < W; k++) {
            const G = E[k],
                Z = G.nodeName.toLowerCase();
            if (!v.includes(Z)) {
                G.remove();
                continue
            }
            const X = [].concat(...G.attributes),
                z = [].concat(t["*"] || [], t[Z] || []);
            X.forEach(pe => {
                Pi(pe, z) || G.removeAttribute(pe.nodeName)
            })
        }
        return c.body.innerHTML
    }
    const rr = new Set(["sanitize", "allowList", "sanitizeFn"]),
        Sn = {
            animation: "boolean",
            template: "string",
            title: "(string|element|function)",
            trigger: "string",
            delay: "(number|object)",
            html: "boolean",
            selector: "(string|boolean)",
            placement: "(string|function)",
            offset: "(array|string|function)",
            container: "(string|element|boolean)",
            fallbackPlacements: "array",
            boundary: "(string|element)",
            customClass: "(string|function)",
            sanitize: "boolean",
            sanitizeFn: "(null|function)",
            allowList: "object",
            popperConfig: "(null|object|function)"
        },
        qi = {
            AUTO: "auto",
            TOP: "top",
            RIGHT: Y() ? "left" : "right",
            BOTTOM: "bottom",
            LEFT: Y() ? "right" : "left"
        },
        Mi = {
            animation: !0,
            template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
            trigger: "hover focus",
            title: "",
            delay: 0,
            html: !1,
            selector: !1,
            placement: "top",
            offset: [0, 0],
            container: !1,
            fallbackPlacements: ["top", "right", "bottom", "left"],
            boundary: "clippingParents",
            customClass: "",
            sanitize: !0,
            sanitizeFn: null,
            allowList: {
                "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i],
                a: ["target", "href", "title", "rel"],
                area: [],
                b: [],
                br: [],
                col: [],
                code: [],
                div: [],
                em: [],
                hr: [],
                h1: [],
                h2: [],
                h3: [],
                h4: [],
                h5: [],
                h6: [],
                i: [],
                img: ["src", "srcset", "alt", "title", "width", "height"],
                li: [],
                ol: [],
                p: [],
                pre: [],
                s: [],
                small: [],
                span: [],
                sub: [],
                sup: [],
                strong: [],
                u: [],
                ul: []
            },
            popperConfig: null
        },
        pi = {
            HIDE: "hide.bs.tooltip",
            HIDDEN: "hidden.bs.tooltip",
            SHOW: "show.bs.tooltip",
            SHOWN: "shown.bs.tooltip",
            INSERTED: "inserted.bs.tooltip",
            CLICK: "click.bs.tooltip",
            FOCUSIN: "focusin.bs.tooltip",
            FOCUSOUT: "focusout.bs.tooltip",
            MOUSEENTER: "mouseenter.bs.tooltip",
            MOUSELEAVE: "mouseleave.bs.tooltip"
        };
    class rn extends q {
        constructor(t, i) {
            if (Ai === void 0) throw new TypeError("Bootstrap's tooltips require Popper (https://popper.js.org)");
            super(t), this._isEnabled = !0, this._timeout = 0, this._hoverState = "", this._activeTrigger = {}, this._popper = null, this._config = this._getConfig(i), this.tip = null, this._setListeners()
        }
        static get Default() {
            return Mi
        }
        static get NAME() {
            return "tooltip"
        }
        static get Event() {
            return pi
        }
        static get DefaultType() {
            return Sn
        }
        enable() {
            this._isEnabled = !0
        }
        disable() {
            this._isEnabled = !1
        }
        toggleEnabled() {
            this._isEnabled = !this._isEnabled
        }
        toggle(t) {
            if (this._isEnabled)
                if (t) {
                    const i = this._initializeOnDelegatedTarget(t);
                    i._activeTrigger.click = !i._activeTrigger.click, i._isWithActiveTrigger() ? i._enter(null, i) : i._leave(null, i)
                } else {
                    if (this.getTipElement().classList.contains("show")) return void this._leave(null, this);
                    this._enter(null, this)
                }
        }
        dispose() {
            clearTimeout(this._timeout), u.off(this._element.closest(".modal"), "hide.bs.modal", this._hideModalHandler), this.tip && this.tip.remove(), this._popper && this._popper.destroy(), super.dispose()
        }
        show() {
            if (this._element.style.display === "none") throw new Error("Please use show on visible elements");
            if (!this.isWithContent() || !this._isEnabled) return;
            const t = u.trigger(this._element, this.constructor.Event.SHOW),
                i = ue(this._element),
                c = i === null ? this._element.ownerDocument.documentElement.contains(this._element) : i.contains(this._element);
            if (t.defaultPrevented || !c) return;
            const v = this.getTipElement(),
                E = (z => {
                    do z += Math.floor(1e6 * Math.random()); while (document.getElementById(z));
                    return z
                })(this.constructor.NAME);
            v.setAttribute("id", E), this._element.setAttribute("aria-describedby", E), this._config.animation && v.classList.add("fade");
            const k = typeof this._config.placement == "function" ? this._config.placement.call(this, v, this._element) : this._config.placement,
                W = this._getAttachment(k);
            this._addAttachmentClass(W);
            const {
                container: G
            } = this._config;
            C.set(v, this.constructor.DATA_KEY, this), this._element.ownerDocument.documentElement.contains(this.tip) || (G.append(v), u.trigger(this._element, this.constructor.Event.INSERTED)), this._popper ? this._popper.update() : this._popper = en(this._element, v, this._getPopperConfig(W)), v.classList.add("show");
            const Z = this._resolvePossibleFunction(this._config.customClass);
            Z && v.classList.add(...Z.split(" ")), "ontouchstart" in document.documentElement && [].concat(...document.body.children).forEach(z => {
                u.on(z, "mouseover", qe)
            });
            const X = this.tip.classList.contains("fade");
            this._queueCallback(() => {
                const z = this._hoverState;
                this._hoverState = null, u.trigger(this._element, this.constructor.Event.SHOWN), z === "out" && this._leave(null, this)
            }, this.tip, X)
        }
        hide() {
            if (!this._popper) return;
            const t = this.getTipElement();
            if (u.trigger(this._element, this.constructor.Event.HIDE).defaultPrevented) return;
            t.classList.remove("show"), "ontouchstart" in document.documentElement && [].concat(...document.body.children).forEach(c => u.off(c, "mouseover", qe)), this._activeTrigger.click = !1, this._activeTrigger.focus = !1, this._activeTrigger.hover = !1;
            const i = this.tip.classList.contains("fade");
            this._queueCallback(() => {
                this._isWithActiveTrigger() || (this._hoverState !== "show" && t.remove(), this._cleanTipClass(), this._element.removeAttribute("aria-describedby"), u.trigger(this._element, this.constructor.Event.HIDDEN), this._popper && (this._popper.destroy(), this._popper = null))
            }, this.tip, i), this._hoverState = ""
        }
        update() {
            this._popper !== null && this._popper.update()
        }
        isWithContent() {
            return !!this.getTitle()
        }
        getTipElement() {
            if (this.tip) return this.tip;
            const t = document.createElement("div");
            t.innerHTML = this._config.template;
            const i = t.children[0];
            return this.setContent(i), i.classList.remove("fade", "show"), this.tip = i, this.tip
        }
        setContent(t) {
            this._sanitizeAndSetContent(t, this.getTitle(), ".tooltip-inner")
        }
        _sanitizeAndSetContent(t, i, c) {
            const v = ie.findOne(c, t);
            i || !v ? this.setElementContent(v, i) : v.remove()
        }
        setElementContent(t, i) {
            if (t !== null) return H(i) ? (i = U(i), void(this._config.html ? i.parentNode !== t && (t.innerHTML = "", t.append(i)) : t.textContent = i.textContent)) : void(this._config.html ? (this._config.sanitize && (i = Fn(i, this._config.allowList, this._config.sanitizeFn)), t.innerHTML = i) : t.textContent = i)
        }
        getTitle() {
            const t = this._element.getAttribute("data-bs-original-title") || this._config.title;
            return this._resolvePossibleFunction(t)
        }
        updateAttachment(t) {
            return t === "right" ? "end" : t === "left" ? "start" : t
        }
        _initializeOnDelegatedTarget(t, i) {
            return i || this.constructor.getOrCreateInstance(t.delegateTarget, this._getDelegateConfig())
        }
        _getOffset() {
            const {
                offset: t
            } = this._config;
            return typeof t == "string" ? t.split(",").map(i => Number.parseInt(i, 10)) : typeof t == "function" ? i => t(i, this._element) : t
        }
        _resolvePossibleFunction(t) {
            return typeof t == "function" ? t.call(this._element) : t
        }
        _getPopperConfig(t) {
            const i = {
                placement: t,
                modifiers: [{
                    name: "flip",
                    options: {
                        fallbackPlacements: this._config.fallbackPlacements
                    }
                }, {
                    name: "offset",
                    options: {
                        offset: this._getOffset()
                    }
                }, {
                    name: "preventOverflow",
                    options: {
                        boundary: this._config.boundary
                    }
                }, {
                    name: "arrow",
                    options: {
                        element: `.${this.constructor.NAME}-arrow`
                    }
                }, {
                    name: "onChange",
                    enabled: !0,
                    phase: "afterWrite",
                    fn: c => this._handlePopperPlacementChange(c)
                }],
                onFirstUpdate: c => {
                    c.options.placement !== c.placement && this._handlePopperPlacementChange(c)
                }
            };
            return { ...i,
                ...typeof this._config.popperConfig == "function" ? this._config.popperConfig(i) : this._config.popperConfig
            }
        }
        _addAttachmentClass(t) {
            this.getTipElement().classList.add(`${this._getBasicClassPrefix()}-${this.updateAttachment(t)}`)
        }
        _getAttachment(t) {
            return qi[t.toUpperCase()]
        }
        _setListeners() {
            this._config.trigger.split(" ").forEach(t => {
                if (t === "click") u.on(this._element, this.constructor.Event.CLICK, this._config.selector, i => this.toggle(i));
                else if (t !== "manual") {
                    const i = t === "hover" ? this.constructor.Event.MOUSEENTER : this.constructor.Event.FOCUSIN,
                        c = t === "hover" ? this.constructor.Event.MOUSELEAVE : this.constructor.Event.FOCUSOUT;
                    u.on(this._element, i, this._config.selector, v => this._enter(v)), u.on(this._element, c, this._config.selector, v => this._leave(v))
                }
            }), this._hideModalHandler = () => {
                this._element && this.hide()
            }, u.on(this._element.closest(".modal"), "hide.bs.modal", this._hideModalHandler), this._config.selector ? this._config = { ...this._config,
                trigger: "manual",
                selector: ""
            } : this._fixTitle()
        }
        _fixTitle() {
            const t = this._element.getAttribute("title"),
                i = typeof this._element.getAttribute("data-bs-original-title");
            (t || i !== "string") && (this._element.setAttribute("data-bs-original-title", t || ""), !t || this._element.getAttribute("aria-label") || this._element.textContent || this._element.setAttribute("aria-label", t), this._element.setAttribute("title", ""))
        }
        _enter(t, i) {
            i = this._initializeOnDelegatedTarget(t, i), t && (i._activeTrigger[t.type === "focusin" ? "focus" : "hover"] = !0), i.getTipElement().classList.contains("show") || i._hoverState === "show" ? i._hoverState = "show" : (clearTimeout(i._timeout), i._hoverState = "show", i._config.delay && i._config.delay.show ? i._timeout = setTimeout(() => {
                i._hoverState === "show" && i.show()
            }, i._config.delay.show) : i.show())
        }
        _leave(t, i) {
            i = this._initializeOnDelegatedTarget(t, i), t && (i._activeTrigger[t.type === "focusout" ? "focus" : "hover"] = i._element.contains(t.relatedTarget)), i._isWithActiveTrigger() || (clearTimeout(i._timeout), i._hoverState = "out", i._config.delay && i._config.delay.hide ? i._timeout = setTimeout(() => {
                i._hoverState === "out" && i.hide()
            }, i._config.delay.hide) : i.hide())
        }
        _isWithActiveTrigger() {
            for (const t in this._activeTrigger)
                if (this._activeTrigger[t]) return !0;
            return !1
        }
        _getConfig(t) {
            const i = ye.getDataAttributes(this._element);
            return Object.keys(i).forEach(c => {
                rr.has(c) && delete i[c]
            }), (t = { ...this.constructor.Default,
                ...i,
                ...typeof t == "object" && t ? t : {}
            }).container = t.container === !1 ? document.body : U(t.container), typeof t.delay == "number" && (t.delay = {
                show: t.delay,
                hide: t.delay
            }), typeof t.title == "number" && (t.title = t.title.toString()), typeof t.content == "number" && (t.content = t.content.toString()), J("tooltip", t, this.constructor.DefaultType), t.sanitize && (t.template = Fn(t.template, t.allowList, t.sanitizeFn)), t
        }
        _getDelegateConfig() {
            const t = {};
            for (const i in this._config) this.constructor.Default[i] !== this._config[i] && (t[i] = this._config[i]);
            return t
        }
        _cleanTipClass() {
            const t = this.getTipElement(),
                i = new RegExp(`(^|\\s)${this._getBasicClassPrefix()}\\S+`, "g"),
                c = t.getAttribute("class").match(i);
            c !== null && c.length > 0 && c.map(v => v.trim()).forEach(v => t.classList.remove(v))
        }
        _getBasicClassPrefix() {
            return "bs-tooltip"
        }
        _handlePopperPlacementChange(t) {
            const {
                state: i
            } = t;
            i && (this.tip = i.elements.popper, this._cleanTipClass(), this._addAttachmentClass(this._getAttachment(i.placement)))
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const i = rn.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (i[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    i[t]()
                }
            })
        }
    }
    fe(rn);
    const sr = { ...rn.Default,
            placement: "right",
            offset: [0, 8],
            trigger: "click",
            content: "",
            template: '<div class="popover" role="tooltip"><div class="popover-arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>'
        },
        or = { ...rn.DefaultType,
            content: "(string|element|function)"
        },
        e = {
            HIDE: "hide.bs.popover",
            HIDDEN: "hidden.bs.popover",
            SHOW: "show.bs.popover",
            SHOWN: "shown.bs.popover",
            INSERTED: "inserted.bs.popover",
            CLICK: "click.bs.popover",
            FOCUSIN: "focusin.bs.popover",
            FOCUSOUT: "focusout.bs.popover",
            MOUSEENTER: "mouseenter.bs.popover",
            MOUSELEAVE: "mouseleave.bs.popover"
        };
    class n extends rn {
        static get Default() {
            return sr
        }
        static get NAME() {
            return "popover"
        }
        static get Event() {
            return e
        }
        static get DefaultType() {
            return or
        }
        isWithContent() {
            return this.getTitle() || this._getContent()
        }
        setContent(t) {
            this._sanitizeAndSetContent(t, this.getTitle(), ".popover-header"), this._sanitizeAndSetContent(t, this._getContent(), ".popover-body")
        }
        _getContent() {
            return this._resolvePossibleFunction(this._config.content)
        }
        _getBasicClassPrefix() {
            return "bs-popover"
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const i = n.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (i[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    i[t]()
                }
            })
        }
    }
    fe(n);
    const r = {
            offset: 10,
            method: "auto",
            target: ""
        },
        s = {
            offset: "number",
            method: "string",
            target: "(string|element)"
        },
        p = ".nav-link, .list-group-item, .dropdown-item";
    class g extends q {
        constructor(t, i) {
            super(t), this._scrollElement = this._element.tagName === "BODY" ? window : this._element, this._config = this._getConfig(i), this._offsets = [], this._targets = [], this._activeTarget = null, this._scrollHeight = 0, u.on(this._scrollElement, "scroll.bs.scrollspy", () => this._process()), this.refresh(), this._process()
        }
        static get Default() {
            return r
        }
        static get NAME() {
            return "scrollspy"
        }
        refresh() {
            const t = this._scrollElement === this._scrollElement.window ? "offset" : "position",
                i = this._config.method === "auto" ? t : this._config.method,
                c = i === "position" ? this._getScrollTop() : 0;
            this._offsets = [], this._targets = [], this._scrollHeight = this._getScrollHeight(), ie.find(p, this._config.target).map(v => {
                const E = L(v),
                    k = E ? ie.findOne(E) : null;
                if (k) {
                    const W = k.getBoundingClientRect();
                    if (W.width || W.height) return [ye[i](k).top + c, E]
                }
                return null
            }).filter(v => v).sort((v, E) => v[0] - E[0]).forEach(v => {
                this._offsets.push(v[0]), this._targets.push(v[1])
            })
        }
        dispose() {
            u.off(this._scrollElement, ".bs.scrollspy"), super.dispose()
        }
        _getConfig(t) {
            return (t = { ...r,
                ...ye.getDataAttributes(this._element),
                ...typeof t == "object" && t ? t : {}
            }).target = U(t.target) || document.documentElement, J("scrollspy", t, s), t
        }
        _getScrollTop() {
            return this._scrollElement === window ? this._scrollElement.pageYOffset : this._scrollElement.scrollTop
        }
        _getScrollHeight() {
            return this._scrollElement.scrollHeight || Math.max(document.body.scrollHeight, document.documentElement.scrollHeight)
        }
        _getOffsetHeight() {
            return this._scrollElement === window ? window.innerHeight : this._scrollElement.getBoundingClientRect().height
        }
        _process() {
            const t = this._getScrollTop() + this._config.offset,
                i = this._getScrollHeight(),
                c = this._config.offset + i - this._getOffsetHeight();
            if (this._scrollHeight !== i && this.refresh(), t >= c) {
                const v = this._targets[this._targets.length - 1];
                this._activeTarget !== v && this._activate(v)
            } else {
                if (this._activeTarget && t < this._offsets[0] && this._offsets[0] > 0) return this._activeTarget = null, void this._clear();
                for (let v = this._offsets.length; v--;) this._activeTarget !== this._targets[v] && t >= this._offsets[v] && (this._offsets[v + 1] === void 0 || t < this._offsets[v + 1]) && this._activate(this._targets[v])
            }
        }
        _activate(t) {
            this._activeTarget = t, this._clear();
            const i = p.split(",").map(v => `${v}[data-bs-target="${t}"],${v}[href="${t}"]`),
                c = ie.findOne(i.join(","), this._config.target);
            c.classList.add("active"), c.classList.contains("dropdown-item") ? ie.findOne(".dropdown-toggle", c.closest(".dropdown")).classList.add("active") : ie.parents(c, ".nav, .list-group").forEach(v => {
                ie.prev(v, ".nav-link, .list-group-item").forEach(E => E.classList.add("active")), ie.prev(v, ".nav-item").forEach(E => {
                    ie.children(E, ".nav-link").forEach(k => k.classList.add("active"))
                })
            }), u.trigger(this._scrollElement, "activate.bs.scrollspy", {
                relatedTarget: t
            })
        }
        _clear() {
            ie.find(p, this._config.target).filter(t => t.classList.contains("active")).forEach(t => t.classList.remove("active"))
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const i = g.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (i[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    i[t]()
                }
            })
        }
    }
    u.on(window, "load.bs.scrollspy.data-api", () => {
        ie.find('[data-bs-spy="scroll"]').forEach(l => new g(l))
    }), fe(g);
    class m extends q {
        static get NAME() {
            return "tab"
        }
        show() {
            if (this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE && this._element.classList.contains("active")) return;
            let t;
            const i = O(this._element),
                c = this._element.closest(".nav, .list-group");
            if (c) {
                const k = c.nodeName === "UL" || c.nodeName === "OL" ? ":scope > li > .active" : ".active";
                t = ie.find(k, c), t = t[t.length - 1]
            }
            const v = t ? u.trigger(t, "hide.bs.tab", {
                relatedTarget: this._element
            }) : null;
            if (u.trigger(this._element, "show.bs.tab", {
                    relatedTarget: t
                }).defaultPrevented || v !== null && v.defaultPrevented) return;
            this._activate(this._element, c);
            const E = () => {
                u.trigger(t, "hidden.bs.tab", {
                    relatedTarget: this._element
                }), u.trigger(this._element, "shown.bs.tab", {
                    relatedTarget: t
                })
            };
            i ? this._activate(i, i.parentNode, E) : E()
        }
        _activate(t, i, c) {
            const v = (!i || i.nodeName !== "UL" && i.nodeName !== "OL" ? ie.children(i, ".active") : ie.find(":scope > li > .active", i))[0],
                E = c && v && v.classList.contains("fade"),
                k = () => this._transitionComplete(t, v, c);
            v && E ? (v.classList.remove("show"), this._queueCallback(k, t, !0)) : k()
        }
        _transitionComplete(t, i, c) {
            if (i) {
                i.classList.remove("active");
                const E = ie.findOne(":scope > .dropdown-menu .active", i.parentNode);
                E && E.classList.remove("active"), i.getAttribute("role") === "tab" && i.setAttribute("aria-selected", !1)
            }
            t.classList.add("active"), t.getAttribute("role") === "tab" && t.setAttribute("aria-selected", !0), be(t), t.classList.contains("fade") && t.classList.add("show");
            let v = t.parentNode;
            if (v && v.nodeName === "LI" && (v = v.parentNode), v && v.classList.contains("dropdown-menu")) {
                const E = t.closest(".dropdown");
                E && ie.find(".dropdown-toggle", E).forEach(k => k.classList.add("active")), t.setAttribute("aria-expanded", !0)
            }
            c && c()
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const i = m.getOrCreateInstance(this);
                if (typeof t == "string") {
                    if (i[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    i[t]()
                }
            })
        }
    }
    u.on(document, "click.bs.tab.data-api", '[data-bs-toggle="tab"], [data-bs-toggle="pill"], [data-bs-toggle="list"]', function(l) {
        ["A", "AREA"].includes(this.tagName) && l.preventDefault(), V(this) || m.getOrCreateInstance(this).show()
    }), fe(m);
    const S = {
            animation: "boolean",
            autohide: "boolean",
            delay: "number"
        },
        T = {
            animation: !0,
            autohide: !0,
            delay: 5e3
        };
    class N extends q {
        constructor(t, i) {
            super(t), this._config = this._getConfig(i), this._timeout = null, this._hasMouseInteraction = !1, this._hasKeyboardInteraction = !1, this._setListeners()
        }
        static get DefaultType() {
            return S
        }
        static get Default() {
            return T
        }
        static get NAME() {
            return "toast"
        }
        show() {
            u.trigger(this._element, "show.bs.toast").defaultPrevented || (this._clearTimeout(), this._config.animation && this._element.classList.add("fade"), this._element.classList.remove("hide"), be(this._element), this._element.classList.add("show"), this._element.classList.add("showing"), this._queueCallback(() => {
                this._element.classList.remove("showing"), u.trigger(this._element, "shown.bs.toast"), this._maybeScheduleHide()
            }, this._element, this._config.animation))
        }
        hide() {
            this._element.classList.contains("show") && (u.trigger(this._element, "hide.bs.toast").defaultPrevented || (this._element.classList.add("showing"), this._queueCallback(() => {
                this._element.classList.add("hide"), this._element.classList.remove("showing"), this._element.classList.remove("show"), u.trigger(this._element, "hidden.bs.toast")
            }, this._element, this._config.animation)))
        }
        dispose() {
            this._clearTimeout(), this._element.classList.contains("show") && this._element.classList.remove("show"), super.dispose()
        }
        _getConfig(t) {
            return t = { ...T,
                ...ye.getDataAttributes(this._element),
                ...typeof t == "object" && t ? t : {}
            }, J("toast", t, this.constructor.DefaultType), t
        }
        _maybeScheduleHide() {
            this._config.autohide && (this._hasMouseInteraction || this._hasKeyboardInteraction || (this._timeout = setTimeout(() => {
                this.hide()
            }, this._config.delay)))
        }
        _onInteraction(t, i) {
            switch (t.type) {
                case "mouseover":
                case "mouseout":
                    this._hasMouseInteraction = i;
                    break;
                case "focusin":
                case "focusout":
                    this._hasKeyboardInteraction = i
            }
            if (i) return void this._clearTimeout();
            const c = t.relatedTarget;
            this._element === c || this._element.contains(c) || this._maybeScheduleHide()
        }
        _setListeners() {
            u.on(this._element, "mouseover.bs.toast", t => this._onInteraction(t, !0)), u.on(this._element, "mouseout.bs.toast", t => this._onInteraction(t, !1)), u.on(this._element, "focusin.bs.toast", t => this._onInteraction(t, !0)), u.on(this._element, "focusout.bs.toast", t => this._onInteraction(t, !1))
        }
        _clearTimeout() {
            clearTimeout(this._timeout), this._timeout = null
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const i = N.getOrCreateInstance(this, t);
                if (typeof t == "string") {
                    if (i[t] === void 0) throw new TypeError(`No method named "${t}"`);
                    i[t](this)
                }
            })
        }
    }
    return M(N), fe(N), {
        Alert: ae,
        Button: ne,
        Carousel: kt,
        Collapse: Dt,
        Dropdown: vt,
        Modal: hn,
        Offcanvas: Pt,
        Popover: n,
        ScrollSpy: g,
        Tab: m,
        Toast: N,
        Tooltip: rn
    }
}); /*! Select2 4.0.13 | https://github.com/select2/select2/blob/master/LICENSE.md */
(function(D) {
    typeof define == "function" && define.amd ? define(["jquery"], D) : typeof module == "object" && module.exports ? module.exports = function(L, O) {
        return O === void 0 && (O = typeof window < "u" ? require("jquery") : require("jquery")(L)), D(O), O
    } : D(jQuery)
})(function(D) {
    var L = function() {
            if (D && D.fn && D.fn.select2 && D.fn.select2.amd) var P = D.fn.select2.amd;
            var H, U, J, B, V, ue, qe, be, de, oe, Y, fe, se, Ve, gt, at;

            function Pe(y, x) {
                return se.call(y, x)
            }

            function a(y, x) {
                var b, f, d, o, h, u, w, C, q, M, ae, ne = x && x.split("/"),
                    De = Y.map,
                    ge = De && De["*"] || {};
                if (y) {
                    for (h = (y = y.split("/")).length - 1, Y.nodeIdCompat && gt.test(y[h]) && (y[h] = y[h].replace(gt, "")), y[0].charAt(0) === "." && ne && (y = ne.slice(0, ne.length - 1).concat(y)), q = 0; q < y.length; q++)
                        if ((ae = y[q]) === ".") y.splice(q, 1), --q;
                        else if (ae === "..") {
                        if (q === 0 || q === 1 && y[2] === ".." || y[q - 1] === "..") continue;
                        0 < q && (y.splice(q - 1, 2), q -= 2)
                    }
                    y = y.join("/")
                }
                if ((ne || ge) && De) {
                    for (q = (b = y.split("/")).length; 0 < q; --q) {
                        if (f = b.slice(0, q).join("/"), ne) {
                            for (M = ne.length; 0 < M; --M)
                                if (d = (d = De[ne.slice(0, M).join("/")]) && d[f]) {
                                    o = d, u = q;
                                    break
                                }
                        }
                        if (o) break;
                        !w && ge && ge[f] && (w = ge[f], C = q)
                    }!o && w && (o = w, u = C), o && (b.splice(0, u, o), y = b.join("/"))
                }
                return y
            }

            function xt(y, x) {
                return function() {
                    var b = Ve.call(arguments, 0);
                    return typeof b[0] != "string" && b.length === 1 && b.push(null), ue.apply(B, b.concat([y, x]))
                }
            }

            function St(y) {
                return function(x) {
                    de[y] = x
                }
            }

            function Et(y) {
                if (Pe(oe, y)) {
                    var x = oe[y];
                    delete oe[y], fe[y] = !0, V.apply(B, x)
                }
                if (!Pe(de, y) && !Pe(fe, y)) throw new Error("No " + y);
                return de[y]
            }

            function Ut(y) {
                var x, b = y ? y.indexOf("!") : -1;
                return -1 < b && (x = y.substring(0, b), y = y.substring(b + 1, y.length)), [x, y]
            }

            function ze(y) {
                return y ? Ut(y) : []
            }
            return P && P.requirejs || (P ? U = P : P = {}, de = {}, oe = {}, Y = {}, fe = {}, se = Object.prototype.hasOwnProperty, Ve = [].slice, gt = /\.js$/, qe = function(y, x) {
                var b, f, d = Ut(y),
                    o = d[0],
                    h = x[1];
                return y = d[1], o && (b = Et(o = a(o, h))), o ? y = b && b.normalize ? b.normalize(y, (f = h, function(u) {
                    return a(u, f)
                })) : a(y, h) : (o = (d = Ut(y = a(y, h)))[0], y = d[1], o && (b = Et(o))), {
                    f: o ? o + "!" + y : y,
                    n: y,
                    pr: o,
                    p: b
                }
            }, be = {
                require: function(y) {
                    return xt(y)
                },
                exports: function(y) {
                    var x = de[y];
                    return x !== void 0 ? x : de[y] = {}
                },
                module: function(y) {
                    return {
                        id: y,
                        uri: "",
                        exports: de[y],
                        config: (x = y, function() {
                            return Y && Y.config && Y.config[x] || {}
                        })
                    };
                    var x
                }
            }, V = function(y, x, b, f) {
                var d, o, h, u, w, C, q, M = [],
                    ae = typeof b;
                if (C = ze(f = f || y), ae == "undefined" || ae == "function") {
                    for (x = !x.length && b.length ? ["require", "exports", "module"] : x, w = 0; w < x.length; w += 1)
                        if ((o = (u = qe(x[w], C)).f) === "require") M[w] = be.require(y);
                        else if (o === "exports") M[w] = be.exports(y), q = !0;
                    else if (o === "module") d = M[w] = be.module(y);
                    else if (Pe(de, o) || Pe(oe, o) || Pe(fe, o)) M[w] = Et(o);
                    else {
                        if (!u.p) throw new Error(y + " missing " + o);
                        u.p.load(u.n, xt(f, !0), St(o), {}), M[w] = de[o]
                    }
                    h = b ? b.apply(de[y], M) : void 0, y && (d && d.exports !== B && d.exports !== de[y] ? de[y] = d.exports : h === B && q || (de[y] = h))
                } else y && (de[y] = b)
            }, H = U = ue = function(y, x, b, f, d) {
                if (typeof y == "string") return be[y] ? be[y](x) : Et(qe(y, ze(x)).f);
                if (!y.splice) {
                    if ((Y = y).deps && ue(Y.deps, Y.callback), !x) return;
                    x.splice ? (y = x, x = b, b = null) : y = B
                }
                return x = x || function() {}, typeof b == "function" && (b = f, f = d), f ? V(B, y, x, b) : setTimeout(function() {
                    V(B, y, x, b)
                }, 4), ue
            }, ue.config = function(y) {
                return ue(y)
            }, H._defined = de, (J = function(y, x, b) {
                if (typeof y != "string") throw new Error("See almond README: incorrect module build, no module name");
                x.splice || (b = x, x = []), Pe(de, y) || Pe(oe, y) || (oe[y] = [y, x, b])
            }).amd = {
                jQuery: !0
            }, P.requirejs = H, P.require = U, P.define = J), P.define("almond", function() {}), P.define("jquery", [], function() {
                var y = D || $;
                return y == null && console && console.error && console.error("Select2: An instance of jQuery or a jQuery-compatible library was not found. Make sure that you are including jQuery before Select2 on your web page."), y
            }), P.define("select2/utils", ["jquery"], function(y) {
                var x = {};

                function b(o) {
                    var h = o.prototype,
                        u = [];
                    for (var w in h) typeof h[w] == "function" && w !== "constructor" && u.push(w);
                    return u
                }
                x.Extend = function(o, h) {
                    var u = {}.hasOwnProperty;

                    function w() {
                        this.constructor = o
                    }
                    for (var C in h) u.call(h, C) && (o[C] = h[C]);
                    return w.prototype = h.prototype, o.prototype = new w, o.__super__ = h.prototype, o
                }, x.Decorate = function(o, h) {
                    var u = b(h),
                        w = b(o);

                    function C() {
                        var ge = Array.prototype.unshift,
                            ye = h.prototype.constructor.length,
                            ie = o.prototype.constructor;
                        0 < ye && (ge.call(arguments, o.prototype.constructor), ie = h.prototype.constructor), ie.apply(this, arguments)
                    }
                    h.displayName = o.displayName, C.prototype = new function() {
                        this.constructor = C
                    };
                    for (var q = 0; q < w.length; q++) {
                        var M = w[q];
                        C.prototype[M] = o.prototype[M]
                    }

                    function ae(ge) {
                        var ye = function() {};
                        ge in C.prototype && (ye = C.prototype[ge]);
                        var ie = h.prototype[ge];
                        return function() {
                            return Array.prototype.unshift.call(arguments, ye), ie.apply(this, arguments)
                        }
                    }
                    for (var ne = 0; ne < u.length; ne++) {
                        var De = u[ne];
                        C.prototype[De] = ae(De)
                    }
                    return C
                };

                function f() {
                    this.listeners = {}
                }
                f.prototype.on = function(o, h) {
                    this.listeners = this.listeners || {}, o in this.listeners ? this.listeners[o].push(h) : this.listeners[o] = [h]
                }, f.prototype.trigger = function(o) {
                    var h = Array.prototype.slice,
                        u = h.call(arguments, 1);
                    this.listeners = this.listeners || {}, u == null && (u = []), u.length === 0 && u.push({}), (u[0]._type = o) in this.listeners && this.invoke(this.listeners[o], h.call(arguments, 1)), "*" in this.listeners && this.invoke(this.listeners["*"], arguments)
                }, f.prototype.invoke = function(o, h) {
                    for (var u = 0, w = o.length; u < w; u++) o[u].apply(this, h)
                }, x.Observable = f, x.generateChars = function(o) {
                    for (var h = "", u = 0; u < o; u++) h += Math.floor(36 * Math.random()).toString(36);
                    return h
                }, x.bind = function(o, h) {
                    return function() {
                        o.apply(h, arguments)
                    }
                }, x._convertData = function(o) {
                    for (var h in o) {
                        var u = h.split("-"),
                            w = o;
                        if (u.length !== 1) {
                            for (var C = 0; C < u.length; C++) {
                                var q = u[C];
                                (q = q.substring(0, 1).toLowerCase() + q.substring(1)) in w || (w[q] = {}), C == u.length - 1 && (w[q] = o[h]), w = w[q]
                            }
                            delete o[h]
                        }
                    }
                    return o
                }, x.hasScroll = function(o, h) {
                    var u = y(h),
                        w = h.style.overflowX,
                        C = h.style.overflowY;
                    return (w !== C || C !== "hidden" && C !== "visible") && (w === "scroll" || C === "scroll" || u.innerHeight() < h.scrollHeight || u.innerWidth() < h.scrollWidth)
                }, x.escapeMarkup = function(o) {
                    var h = {
                        "\\": "&#92;",
                        "&": "&amp;",
                        "<": "&lt;",
                        ">": "&gt;",
                        '"': "&quot;",
                        "'": "&#39;",
                        "/": "&#47;"
                    };
                    return typeof o != "string" ? o : String(o).replace(/[&<>"'\/\\]/g, function(u) {
                        return h[u]
                    })
                }, x.appendMany = function(o, h) {
                    if (y.fn.jquery.substr(0, 3) === "1.7") {
                        var u = y();
                        y.map(h, function(w) {
                            u = u.add(w)
                        }), h = u
                    }
                    o.append(h)
                }, x.__cache = {};
                var d = 0;
                return x.GetUniqueElementId = function(o) {
                    var h = o.getAttribute("data-select2-id");
                    return h == null && (o.id ? (h = o.id, o.setAttribute("data-select2-id", h)) : (o.setAttribute("data-select2-id", ++d), h = d.toString())), h
                }, x.StoreData = function(o, h, u) {
                    var w = x.GetUniqueElementId(o);
                    x.__cache[w] || (x.__cache[w] = {}), x.__cache[w][h] = u
                }, x.GetData = function(o, h) {
                    var u = x.GetUniqueElementId(o);
                    return h ? x.__cache[u] && x.__cache[u][h] != null ? x.__cache[u][h] : y(o).data(h) : x.__cache[u]
                }, x.RemoveData = function(o) {
                    var h = x.GetUniqueElementId(o);
                    x.__cache[h] != null && delete x.__cache[h], o.removeAttribute("data-select2-id")
                }, x
            }), P.define("select2/results", ["jquery", "./utils"], function(y, x) {
                function b(f, d, o) {
                    this.$element = f, this.data = o, this.options = d, b.__super__.constructor.call(this)
                }
                return x.Extend(b, x.Observable), b.prototype.render = function() {
                    var f = y('<ul class="select2-results__options" role="listbox"></ul>');
                    return this.options.get("multiple") && f.attr("aria-multiselectable", "true"), this.$results = f
                }, b.prototype.clear = function() {
                    this.$results.empty()
                }, b.prototype.displayMessage = function(f) {
                    var d = this.options.get("escapeMarkup");
                    this.clear(), this.hideLoading();
                    var o = y('<li role="alert" aria-live="assertive" class="select2-results__option"></li>'),
                        h = this.options.get("translations").get(f.message);
                    o.append(d(h(f.args))), o[0].className += " select2-results__message", this.$results.append(o)
                }, b.prototype.hideMessages = function() {
                    this.$results.find(".select2-results__message").remove()
                }, b.prototype.append = function(f) {
                    this.hideLoading();
                    var d = [];
                    if (f.results != null && f.results.length !== 0) {
                        f.results = this.sort(f.results);
                        for (var o = 0; o < f.results.length; o++) {
                            var h = f.results[o],
                                u = this.option(h);
                            d.push(u)
                        }
                        this.$results.append(d)
                    } else this.$results.children().length === 0 && this.trigger("results:message", {
                        message: "noResults"
                    })
                }, b.prototype.position = function(f, d) {
                    d.find(".select2-results").append(f)
                }, b.prototype.sort = function(f) {
                    return this.options.get("sorter")(f)
                }, b.prototype.highlightFirstItem = function() {
                    var f = this.$results.find(".select2-results__option[aria-selected]"),
                        d = f.filter("[aria-selected=true]");
                    0 < d.length ? d.first().trigger("mouseenter") : f.first().trigger("mouseenter"), this.ensureHighlightVisible()
                }, b.prototype.setClasses = function() {
                    var f = this;
                    this.data.current(function(d) {
                        var o = y.map(d, function(h) {
                            return h.id.toString()
                        });
                        f.$results.find(".select2-results__option[aria-selected]").each(function() {
                            var h = y(this),
                                u = x.GetData(this, "data"),
                                w = "" + u.id;
                            u.element != null && u.element.selected || u.element == null && -1 < y.inArray(w, o) ? h.attr("aria-selected", "true") : h.attr("aria-selected", "false")
                        })
                    })
                }, b.prototype.showLoading = function(f) {
                    this.hideLoading();
                    var d = {
                            disabled: !0,
                            loading: !0,
                            text: this.options.get("translations").get("searching")(f)
                        },
                        o = this.option(d);
                    o.className += " loading-results", this.$results.prepend(o)
                }, b.prototype.hideLoading = function() {
                    this.$results.find(".loading-results").remove()
                }, b.prototype.option = function(f) {
                    var d = document.createElement("li");
                    d.className = "select2-results__option";
                    var o = {
                            role: "option",
                            "aria-selected": "false"
                        },
                        h = window.Element.prototype.matches || window.Element.prototype.msMatchesSelector || window.Element.prototype.webkitMatchesSelector;
                    for (var u in (f.element != null && h.call(f.element, ":disabled") || f.element == null && f.disabled) && (delete o["aria-selected"], o["aria-disabled"] = "true"), f.id == null && delete o["aria-selected"], f._resultId != null && (d.id = f._resultId), f.title && (d.title = f.title), f.children && (o.role = "group", o["aria-label"] = f.text, delete o["aria-selected"]), o) {
                        var w = o[u];
                        d.setAttribute(u, w)
                    }
                    if (f.children) {
                        var C = y(d),
                            q = document.createElement("strong");
                        q.className = "select2-results__group", y(q), this.template(f, q);
                        for (var M = [], ae = 0; ae < f.children.length; ae++) {
                            var ne = f.children[ae],
                                De = this.option(ne);
                            M.push(De)
                        }
                        var ge = y("<ul></ul>", {
                            class: "select2-results__options select2-results__options--nested"
                        });
                        ge.append(M), C.append(q), C.append(ge)
                    } else this.template(f, d);
                    return x.StoreData(d, "data", f), d
                }, b.prototype.bind = function(f, d) {
                    var o = this,
                        h = f.id + "-results";
                    this.$results.attr("id", h), f.on("results:all", function(u) {
                        o.clear(), o.append(u.data), f.isOpen() && (o.setClasses(), o.highlightFirstItem())
                    }), f.on("results:append", function(u) {
                        o.append(u.data), f.isOpen() && o.setClasses()
                    }), f.on("query", function(u) {
                        o.hideMessages(), o.showLoading(u)
                    }), f.on("select", function() {
                        f.isOpen() && (o.setClasses(), o.options.get("scrollAfterSelect") && o.highlightFirstItem())
                    }), f.on("unselect", function() {
                        f.isOpen() && (o.setClasses(), o.options.get("scrollAfterSelect") && o.highlightFirstItem())
                    }), f.on("open", function() {
                        o.$results.attr("aria-expanded", "true"), o.$results.attr("aria-hidden", "false"), o.setClasses(), o.ensureHighlightVisible()
                    }), f.on("close", function() {
                        o.$results.attr("aria-expanded", "false"), o.$results.attr("aria-hidden", "true"), o.$results.removeAttr("aria-activedescendant")
                    }), f.on("results:toggle", function() {
                        var u = o.getHighlightedResults();
                        u.length !== 0 && u.trigger("mouseup")
                    }), f.on("results:select", function() {
                        var u = o.getHighlightedResults();
                        if (u.length !== 0) {
                            var w = x.GetData(u[0], "data");
                            u.attr("aria-selected") == "true" ? o.trigger("close", {}) : o.trigger("select", {
                                data: w
                            })
                        }
                    }), f.on("results:previous", function() {
                        var u = o.getHighlightedResults(),
                            w = o.$results.find("[aria-selected]"),
                            C = w.index(u);
                        if (!(C <= 0)) {
                            var q = C - 1;
                            u.length === 0 && (q = 0);
                            var M = w.eq(q);
                            M.trigger("mouseenter");
                            var ae = o.$results.offset().top,
                                ne = M.offset().top,
                                De = o.$results.scrollTop() + (ne - ae);
                            q === 0 ? o.$results.scrollTop(0) : ne - ae < 0 && o.$results.scrollTop(De)
                        }
                    }), f.on("results:next", function() {
                        var u = o.getHighlightedResults(),
                            w = o.$results.find("[aria-selected]"),
                            C = w.index(u) + 1;
                        if (!(C >= w.length)) {
                            var q = w.eq(C);
                            q.trigger("mouseenter");
                            var M = o.$results.offset().top + o.$results.outerHeight(!1),
                                ae = q.offset().top + q.outerHeight(!1),
                                ne = o.$results.scrollTop() + ae - M;
                            C === 0 ? o.$results.scrollTop(0) : M < ae && o.$results.scrollTop(ne)
                        }
                    }), f.on("results:focus", function(u) {
                        u.element.addClass("select2-results__option--highlighted")
                    }), f.on("results:message", function(u) {
                        o.displayMessage(u)
                    }), y.fn.mousewheel && this.$results.on("mousewheel", function(u) {
                        var w = o.$results.scrollTop(),
                            C = o.$results.get(0).scrollHeight - w + u.deltaY,
                            q = 0 < u.deltaY && w - u.deltaY <= 0,
                            M = u.deltaY < 0 && C <= o.$results.height();
                        q ? (o.$results.scrollTop(0), u.preventDefault(), u.stopPropagation()) : M && (o.$results.scrollTop(o.$results.get(0).scrollHeight - o.$results.height()), u.preventDefault(), u.stopPropagation())
                    }), this.$results.on("mouseup", ".select2-results__option[aria-selected]", function(u) {
                        var w = y(this),
                            C = x.GetData(this, "data");
                        w.attr("aria-selected") !== "true" ? o.trigger("select", {
                            originalEvent: u,
                            data: C
                        }) : o.options.get("multiple") ? o.trigger("unselect", {
                            originalEvent: u,
                            data: C
                        }) : o.trigger("close", {})
                    }), this.$results.on("mouseenter", ".select2-results__option[aria-selected]", function(u) {
                        var w = x.GetData(this, "data");
                        o.getHighlightedResults().removeClass("select2-results__option--highlighted"), o.trigger("results:focus", {
                            data: w,
                            element: y(this)
                        })
                    })
                }, b.prototype.getHighlightedResults = function() {
                    return this.$results.find(".select2-results__option--highlighted")
                }, b.prototype.destroy = function() {
                    this.$results.remove()
                }, b.prototype.ensureHighlightVisible = function() {
                    var f = this.getHighlightedResults();
                    if (f.length !== 0) {
                        var d = this.$results.find("[aria-selected]").index(f),
                            o = this.$results.offset().top,
                            h = f.offset().top,
                            u = this.$results.scrollTop() + (h - o),
                            w = h - o;
                        u -= 2 * f.outerHeight(!1), d <= 2 ? this.$results.scrollTop(0) : (w > this.$results.outerHeight() || w < 0) && this.$results.scrollTop(u)
                    }
                }, b.prototype.template = function(f, d) {
                    var o = this.options.get("templateResult"),
                        h = this.options.get("escapeMarkup"),
                        u = o(f, d);
                    u == null ? d.style.display = "none" : typeof u == "string" ? d.innerHTML = h(u) : y(d).append(u)
                }, b
            }), P.define("select2/keys", [], function() {
                return {
                    BACKSPACE: 8,
                    TAB: 9,
                    ENTER: 13,
                    SHIFT: 16,
                    CTRL: 17,
                    ALT: 18,
                    ESC: 27,
                    SPACE: 32,
                    PAGE_UP: 33,
                    PAGE_DOWN: 34,
                    END: 35,
                    HOME: 36,
                    LEFT: 37,
                    UP: 38,
                    RIGHT: 39,
                    DOWN: 40,
                    DELETE: 46
                }
            }), P.define("select2/selection/base", ["jquery", "../utils", "../keys"], function(y, x, b) {
                function f(d, o) {
                    this.$element = d, this.options = o, f.__super__.constructor.call(this)
                }
                return x.Extend(f, x.Observable), f.prototype.render = function() {
                    var d = y('<span class="select2-selection" role="combobox"  aria-haspopup="true" aria-expanded="false"></span>');
                    return this._tabindex = 0, x.GetData(this.$element[0], "old-tabindex") != null ? this._tabindex = x.GetData(this.$element[0], "old-tabindex") : this.$element.attr("tabindex") != null && (this._tabindex = this.$element.attr("tabindex")), d.attr("title", this.$element.attr("title")), d.attr("tabindex", this._tabindex), d.attr("aria-disabled", "false"), this.$selection = d
                }, f.prototype.bind = function(d, o) {
                    var h = this,
                        u = d.id + "-results";
                    this.container = d, this.$selection.on("focus", function(w) {
                        h.trigger("focus", w)
                    }), this.$selection.on("blur", function(w) {
                        h._handleBlur(w)
                    }), this.$selection.on("keydown", function(w) {
                        h.trigger("keypress", w), w.which === b.SPACE && w.preventDefault()
                    }), d.on("results:focus", function(w) {
                        h.$selection.attr("aria-activedescendant", w.data._resultId)
                    }), d.on("selection:update", function(w) {
                        h.update(w.data)
                    }), d.on("open", function() {
                        h.$selection.attr("aria-expanded", "true"), h.$selection.attr("aria-owns", u), h._attachCloseHandler(d)
                    }), d.on("close", function() {
                        h.$selection.attr("aria-expanded", "false"), h.$selection.removeAttr("aria-activedescendant"), h.$selection.removeAttr("aria-owns"), h.$selection.trigger("focus"), h._detachCloseHandler(d)
                    }), d.on("enable", function() {
                        h.$selection.attr("tabindex", h._tabindex), h.$selection.attr("aria-disabled", "false")
                    }), d.on("disable", function() {
                        h.$selection.attr("tabindex", "-1"), h.$selection.attr("aria-disabled", "true")
                    })
                }, f.prototype._handleBlur = function(d) {
                    var o = this;
                    window.setTimeout(function() {
                        document.activeElement == o.$selection[0] || y.contains(o.$selection[0], document.activeElement) || o.trigger("blur", d)
                    }, 1)
                }, f.prototype._attachCloseHandler = function(d) {
                    y(document.body).on("mousedown.select2." + d.id, function(o) {
                        var h = y(o.target).closest(".select2");
                        y(".select2.select2-container--open").each(function() {
                            this != h[0] && x.GetData(this, "element").select2("close")
                        })
                    })
                }, f.prototype._detachCloseHandler = function(d) {
                    y(document.body).off("mousedown.select2." + d.id)
                }, f.prototype.position = function(d, o) {
                    o.find(".selection").append(d)
                }, f.prototype.destroy = function() {
                    this._detachCloseHandler(this.container)
                }, f.prototype.update = function(d) {
                    throw new Error("The `update` method must be defined in child classes.")
                }, f.prototype.isEnabled = function() {
                    return !this.isDisabled()
                }, f.prototype.isDisabled = function() {
                    return this.options.get("disabled")
                }, f
            }), P.define("select2/selection/single", ["jquery", "./base", "../utils", "../keys"], function(y, x, b, f) {
                function d() {
                    d.__super__.constructor.apply(this, arguments)
                }
                return b.Extend(d, x), d.prototype.render = function() {
                    var o = d.__super__.render.call(this);
                    return o.addClass("select2-selection--single"), o.html('<span class="select2-selection__rendered"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span>'), o
                }, d.prototype.bind = function(o, h) {
                    var u = this;
                    d.__super__.bind.apply(this, arguments);
                    var w = o.id + "-container";
                    this.$selection.find(".select2-selection__rendered").attr("id", w).attr("role", "textbox").attr("aria-readonly", "true"), this.$selection.attr("aria-labelledby", w), this.$selection.on("mousedown", function(C) {
                        C.which === 1 && u.trigger("toggle", {
                            originalEvent: C
                        })
                    }), this.$selection.on("focus", function(C) {}), this.$selection.on("blur", function(C) {}), o.on("focus", function(C) {
                        o.isOpen() || u.$selection.trigger("focus")
                    })
                }, d.prototype.clear = function() {
                    var o = this.$selection.find(".select2-selection__rendered");
                    o.empty(), o.removeAttr("title")
                }, d.prototype.display = function(o, h) {
                    var u = this.options.get("templateSelection");
                    return this.options.get("escapeMarkup")(u(o, h))
                }, d.prototype.selectionContainer = function() {
                    return y("<span></span>")
                }, d.prototype.update = function(o) {
                    if (o.length !== 0) {
                        var h = o[0],
                            u = this.$selection.find(".select2-selection__rendered"),
                            w = this.display(h, u);
                        u.empty().append(w);
                        var C = h.title || h.text;
                        C ? u.attr("title", C) : u.removeAttr("title")
                    } else this.clear()
                }, d
            }), P.define("select2/selection/multiple", ["jquery", "./base", "../utils"], function(y, x, b) {
                function f(d, o) {
                    f.__super__.constructor.apply(this, arguments)
                }
                return b.Extend(f, x), f.prototype.render = function() {
                    var d = f.__super__.render.call(this);
                    return d.addClass("select2-selection--multiple"), d.html('<ul class="select2-selection__rendered"></ul>'), d
                }, f.prototype.bind = function(d, o) {
                    var h = this;
                    f.__super__.bind.apply(this, arguments), this.$selection.on("click", function(u) {
                        h.trigger("toggle", {
                            originalEvent: u
                        })
                    }), this.$selection.on("click", ".select2-selection__choice__remove", function(u) {
                        if (!h.isDisabled()) {
                            var w = y(this).parent(),
                                C = b.GetData(w[0], "data");
                            h.trigger("unselect", {
                                originalEvent: u,
                                data: C
                            })
                        }
                    })
                }, f.prototype.clear = function() {
                    var d = this.$selection.find(".select2-selection__rendered");
                    d.empty(), d.removeAttr("title")
                }, f.prototype.display = function(d, o) {
                    var h = this.options.get("templateSelection");
                    return this.options.get("escapeMarkup")(h(d, o))
                }, f.prototype.selectionContainer = function() {
                    return y('<li class="select2-selection__choice"><span class="select2-selection__choice__remove" role="presentation">&times;</span></li>')
                }, f.prototype.update = function(d) {
                    if (this.clear(), d.length !== 0) {
                        for (var o = [], h = 0; h < d.length; h++) {
                            var u = d[h],
                                w = this.selectionContainer(),
                                C = this.display(u, w);
                            w.append(C);
                            var q = u.title || u.text;
                            q && w.attr("title", q), b.StoreData(w[0], "data", u), o.push(w)
                        }
                        var M = this.$selection.find(".select2-selection__rendered");
                        b.appendMany(M, o)
                    }
                }, f
            }), P.define("select2/selection/placeholder", ["../utils"], function(y) {
                function x(b, f, d) {
                    this.placeholder = this.normalizePlaceholder(d.get("placeholder")), b.call(this, f, d)
                }
                return x.prototype.normalizePlaceholder = function(b, f) {
                    return typeof f == "string" && (f = {
                        id: "",
                        text: f
                    }), f
                }, x.prototype.createPlaceholder = function(b, f) {
                    var d = this.selectionContainer();
                    return d.html(this.display(f)), d.addClass("select2-selection__placeholder").removeClass("select2-selection__choice"), d
                }, x.prototype.update = function(b, f) {
                    var d = f.length == 1 && f[0].id != this.placeholder.id;
                    if (1 < f.length || d) return b.call(this, f);
                    this.clear();
                    var o = this.createPlaceholder(this.placeholder);
                    this.$selection.find(".select2-selection__rendered").append(o)
                }, x
            }), P.define("select2/selection/allowClear", ["jquery", "../keys", "../utils"], function(y, x, b) {
                function f() {}
                return f.prototype.bind = function(d, o, h) {
                    var u = this;
                    d.call(this, o, h), this.placeholder == null && this.options.get("debug") && window.console && console.error && console.error("Select2: The `allowClear` option should be used in combination with the `placeholder` option."), this.$selection.on("mousedown", ".select2-selection__clear", function(w) {
                        u._handleClear(w)
                    }), o.on("keypress", function(w) {
                        u._handleKeyboardClear(w, o)
                    })
                }, f.prototype._handleClear = function(d, o) {
                    if (!this.isDisabled()) {
                        var h = this.$selection.find(".select2-selection__clear");
                        if (h.length !== 0) {
                            o.stopPropagation();
                            var u = b.GetData(h[0], "data"),
                                w = this.$element.val();
                            this.$element.val(this.placeholder.id);
                            var C = {
                                data: u
                            };
                            if (this.trigger("clear", C), C.prevented) this.$element.val(w);
                            else {
                                for (var q = 0; q < u.length; q++)
                                    if (C = {
                                            data: u[q]
                                        }, this.trigger("unselect", C), C.prevented) return void this.$element.val(w);
                                this.$element.trigger("input").trigger("change"), this.trigger("toggle", {})
                            }
                        }
                    }
                }, f.prototype._handleKeyboardClear = function(d, o, h) {
                    h.isOpen() || o.which != x.DELETE && o.which != x.BACKSPACE || this._handleClear(o)
                }, f.prototype.update = function(d, o) {
                    if (d.call(this, o), !(0 < this.$selection.find(".select2-selection__placeholder").length || o.length === 0)) {
                        var h = this.options.get("translations").get("removeAllItems"),
                            u = y('<span class="select2-selection__clear" title="' + h() + '">&times;</span>');
                        b.StoreData(u[0], "data", o), this.$selection.find(".select2-selection__rendered").prepend(u)
                    }
                }, f
            }), P.define("select2/selection/search", ["jquery", "../utils", "../keys"], function(y, x, b) {
                function f(d, o, h) {
                    d.call(this, o, h)
                }
                return f.prototype.render = function(d) {
                    var o = y('<li class="select2-search select2-search--inline"><input class="select2-search__field" type="search" tabindex="-1" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" role="searchbox" aria-autocomplete="list" /></li>');
                    this.$searchContainer = o, this.$search = o.find("input");
                    var h = d.call(this);
                    return this._transferTabIndex(), h
                }, f.prototype.bind = function(d, o, h) {
                    var u = this,
                        w = o.id + "-results";
                    d.call(this, o, h), o.on("open", function() {
                        u.$search.attr("aria-controls", w), u.$search.trigger("focus")
                    }), o.on("close", function() {
                        u.$search.val(""), u.$search.removeAttr("aria-controls"), u.$search.removeAttr("aria-activedescendant"), u.$search.trigger("focus")
                    }), o.on("enable", function() {
                        u.$search.prop("disabled", !1), u._transferTabIndex()
                    }), o.on("disable", function() {
                        u.$search.prop("disabled", !0)
                    }), o.on("focus", function(M) {
                        u.$search.trigger("focus")
                    }), o.on("results:focus", function(M) {
                        M.data._resultId ? u.$search.attr("aria-activedescendant", M.data._resultId) : u.$search.removeAttr("aria-activedescendant")
                    }), this.$selection.on("focusin", ".select2-search--inline", function(M) {
                        u.trigger("focus", M)
                    }), this.$selection.on("focusout", ".select2-search--inline", function(M) {
                        u._handleBlur(M)
                    }), this.$selection.on("keydown", ".select2-search--inline", function(M) {
                        if (M.stopPropagation(), u.trigger("keypress", M), u._keyUpPrevented = M.isDefaultPrevented(), M.which === b.BACKSPACE && u.$search.val() === "") {
                            var ae = u.$searchContainer.prev(".select2-selection__choice");
                            if (0 < ae.length) {
                                var ne = x.GetData(ae[0], "data");
                                u.searchRemoveChoice(ne), M.preventDefault()
                            }
                        }
                    }), this.$selection.on("click", ".select2-search--inline", function(M) {
                        u.$search.val() && M.stopPropagation()
                    });
                    var C = document.documentMode,
                        q = C && C <= 11;
                    this.$selection.on("input.searchcheck", ".select2-search--inline", function(M) {
                        q ? u.$selection.off("input.search input.searchcheck") : u.$selection.off("keyup.search")
                    }), this.$selection.on("keyup.search input.search", ".select2-search--inline", function(M) {
                        if (q && M.type === "input") u.$selection.off("input.search input.searchcheck");
                        else {
                            var ae = M.which;
                            ae != b.SHIFT && ae != b.CTRL && ae != b.ALT && ae != b.TAB && u.handleSearch(M)
                        }
                    })
                }, f.prototype._transferTabIndex = function(d) {
                    this.$search.attr("tabindex", this.$selection.attr("tabindex")), this.$selection.attr("tabindex", "-1")
                }, f.prototype.createPlaceholder = function(d, o) {
                    this.$search.attr("placeholder", o.text)
                }, f.prototype.update = function(d, o) {
                    var h = this.$search[0] == document.activeElement;
                    this.$search.attr("placeholder", ""), d.call(this, o), this.$selection.find(".select2-selection__rendered").append(this.$searchContainer), this.resizeSearch(), h && this.$search.trigger("focus")
                }, f.prototype.handleSearch = function() {
                    if (this.resizeSearch(), !this._keyUpPrevented) {
                        var d = this.$search.val();
                        this.trigger("query", {
                            term: d
                        })
                    }
                    this._keyUpPrevented = !1
                }, f.prototype.searchRemoveChoice = function(d, o) {
                    this.trigger("unselect", {
                        data: o
                    }), this.$search.val(o.text), this.handleSearch()
                }, f.prototype.resizeSearch = function() {
                    this.$search.css("width", "25px");
                    var d = "";
                    this.$search.attr("placeholder") !== "" ? d = this.$selection.find(".select2-selection__rendered").width() : d = .75 * (this.$search.val().length + 1) + "em", this.$search.css("width", d)
                }, f
            }), P.define("select2/selection/eventRelay", ["jquery"], function(y) {
                function x() {}
                return x.prototype.bind = function(b, f, d) {
                    var o = this,
                        h = ["open", "opening", "close", "closing", "select", "selecting", "unselect", "unselecting", "clear", "clearing"],
                        u = ["opening", "closing", "selecting", "unselecting", "clearing"];
                    b.call(this, f, d), f.on("*", function(w, C) {
                        if (y.inArray(w, h) !== -1) {
                            C = C || {};
                            var q = y.Event("select2:" + w, {
                                params: C
                            });
                            o.$element.trigger(q), y.inArray(w, u) !== -1 && (C.prevented = q.isDefaultPrevented())
                        }
                    })
                }, x
            }), P.define("select2/translation", ["jquery", "require"], function(y, x) {
                function b(f) {
                    this.dict = f || {}
                }
                return b.prototype.all = function() {
                    return this.dict
                }, b.prototype.get = function(f) {
                    return this.dict[f]
                }, b.prototype.extend = function(f) {
                    this.dict = y.extend({}, f.all(), this.dict)
                }, b._cache = {}, b.loadPath = function(f) {
                    if (!(f in b._cache)) {
                        var d = x(f);
                        b._cache[f] = d
                    }
                    return new b(b._cache[f])
                }, b
            }), P.define("select2/diacritics", [], function() {
                return {
                    "Ⓐ": "A",
                    Ａ: "A",
                    À: "A",
                    Á: "A",
                    Â: "A",
                    Ầ: "A",
                    Ấ: "A",
                    Ẫ: "A",
                    Ẩ: "A",
                    Ã: "A",
                    Ā: "A",
                    Ă: "A",
                    Ằ: "A",
                    Ắ: "A",
                    Ẵ: "A",
                    Ẳ: "A",
                    Ȧ: "A",
                    Ǡ: "A",
                    Ä: "A",
                    Ǟ: "A",
                    Ả: "A",
                    Å: "A",
                    Ǻ: "A",
                    Ǎ: "A",
                    Ȁ: "A",
                    Ȃ: "A",
                    Ạ: "A",
                    Ậ: "A",
                    Ặ: "A",
                    Ḁ: "A",
                    Ą: "A",
                    "Ⱥ": "A",
                    "Ɐ": "A",
                    "Ꜳ": "AA",
                    Æ: "AE",
                    Ǽ: "AE",
                    Ǣ: "AE",
                    "Ꜵ": "AO",
                    "Ꜷ": "AU",
                    "Ꜹ": "AV",
                    "Ꜻ": "AV",
                    "Ꜽ": "AY",
                    "Ⓑ": "B",
                    Ｂ: "B",
                    Ḃ: "B",
                    Ḅ: "B",
                    Ḇ: "B",
                    "Ƀ": "B",
                    Ƃ: "B",
                    Ɓ: "B",
                    "Ⓒ": "C",
                    Ｃ: "C",
                    Ć: "C",
                    Ĉ: "C",
                    Ċ: "C",
                    Č: "C",
                    Ç: "C",
                    Ḉ: "C",
                    Ƈ: "C",
                    "Ȼ": "C",
                    "Ꜿ": "C",
                    "Ⓓ": "D",
                    Ｄ: "D",
                    Ḋ: "D",
                    Ď: "D",
                    Ḍ: "D",
                    Ḑ: "D",
                    Ḓ: "D",
                    Ḏ: "D",
                    Đ: "D",
                    Ƌ: "D",
                    Ɗ: "D",
                    Ɖ: "D",
                    "Ꝺ": "D",
                    Ǳ: "DZ",
                    Ǆ: "DZ",
                    ǲ: "Dz",
                    ǅ: "Dz",
                    "Ⓔ": "E",
                    Ｅ: "E",
                    È: "E",
                    É: "E",
                    Ê: "E",
                    Ề: "E",
                    Ế: "E",
                    Ễ: "E",
                    Ể: "E",
                    Ẽ: "E",
                    Ē: "E",
                    Ḕ: "E",
                    Ḗ: "E",
                    Ĕ: "E",
                    Ė: "E",
                    Ë: "E",
                    Ẻ: "E",
                    Ě: "E",
                    Ȅ: "E",
                    Ȇ: "E",
                    Ẹ: "E",
                    Ệ: "E",
                    Ȩ: "E",
                    Ḝ: "E",
                    Ę: "E",
                    Ḙ: "E",
                    Ḛ: "E",
                    Ɛ: "E",
                    Ǝ: "E",
                    "Ⓕ": "F",
                    Ｆ: "F",
                    Ḟ: "F",
                    Ƒ: "F",
                    "Ꝼ": "F",
                    "Ⓖ": "G",
                    Ｇ: "G",
                    Ǵ: "G",
                    Ĝ: "G",
                    Ḡ: "G",
                    Ğ: "G",
                    Ġ: "G",
                    Ǧ: "G",
                    Ģ: "G",
                    Ǥ: "G",
                    Ɠ: "G",
                    "Ꞡ": "G",
                    "Ᵹ": "G",
                    "Ꝿ": "G",
                    "Ⓗ": "H",
                    Ｈ: "H",
                    Ĥ: "H",
                    Ḣ: "H",
                    Ḧ: "H",
                    Ȟ: "H",
                    Ḥ: "H",
                    Ḩ: "H",
                    Ḫ: "H",
                    Ħ: "H",
                    "Ⱨ": "H",
                    "Ⱶ": "H",
                    "Ɥ": "H",
                    "Ⓘ": "I",
                    Ｉ: "I",
                    Ì: "I",
                    Í: "I",
                    Î: "I",
                    Ĩ: "I",
                    Ī: "I",
                    Ĭ: "I",
                    İ: "I",
                    Ï: "I",
                    Ḯ: "I",
                    Ỉ: "I",
                    Ǐ: "I",
                    Ȉ: "I",
                    Ȋ: "I",
                    Ị: "I",
                    Į: "I",
                    Ḭ: "I",
                    Ɨ: "I",
                    "Ⓙ": "J",
                    Ｊ: "J",
                    Ĵ: "J",
                    "Ɉ": "J",
                    "Ⓚ": "K",
                    Ｋ: "K",
                    Ḱ: "K",
                    Ǩ: "K",
                    Ḳ: "K",
                    Ķ: "K",
                    Ḵ: "K",
                    Ƙ: "K",
                    "Ⱪ": "K",
                    "Ꝁ": "K",
                    "Ꝃ": "K",
                    "Ꝅ": "K",
                    "Ꞣ": "K",
                    "Ⓛ": "L",
                    Ｌ: "L",
                    Ŀ: "L",
                    Ĺ: "L",
                    Ľ: "L",
                    Ḷ: "L",
                    Ḹ: "L",
                    Ļ: "L",
                    Ḽ: "L",
                    Ḻ: "L",
                    Ł: "L",
                    "Ƚ": "L",
                    "Ɫ": "L",
                    "Ⱡ": "L",
                    "Ꝉ": "L",
                    "Ꝇ": "L",
                    "Ꞁ": "L",
                    Ǉ: "LJ",
                    ǈ: "Lj",
                    "Ⓜ": "M",
                    Ｍ: "M",
                    Ḿ: "M",
                    Ṁ: "M",
                    Ṃ: "M",
                    "Ɱ": "M",
                    Ɯ: "M",
                    "Ⓝ": "N",
                    Ｎ: "N",
                    Ǹ: "N",
                    Ń: "N",
                    Ñ: "N",
                    Ṅ: "N",
                    Ň: "N",
                    Ṇ: "N",
                    Ņ: "N",
                    Ṋ: "N",
                    Ṉ: "N",
                    "Ƞ": "N",
                    Ɲ: "N",
                    "Ꞑ": "N",
                    "Ꞥ": "N",
                    Ǌ: "NJ",
                    ǋ: "Nj",
                    "Ⓞ": "O",
                    Ｏ: "O",
                    Ò: "O",
                    Ó: "O",
                    Ô: "O",
                    Ồ: "O",
                    Ố: "O",
                    Ỗ: "O",
                    Ổ: "O",
                    Õ: "O",
                    Ṍ: "O",
                    Ȭ: "O",
                    Ṏ: "O",
                    Ō: "O",
                    Ṑ: "O",
                    Ṓ: "O",
                    Ŏ: "O",
                    Ȯ: "O",
                    Ȱ: "O",
                    Ö: "O",
                    Ȫ: "O",
                    Ỏ: "O",
                    Ő: "O",
                    Ǒ: "O",
                    Ȍ: "O",
                    Ȏ: "O",
                    Ơ: "O",
                    Ờ: "O",
                    Ớ: "O",
                    Ỡ: "O",
                    Ở: "O",
                    Ợ: "O",
                    Ọ: "O",
                    Ộ: "O",
                    Ǫ: "O",
                    Ǭ: "O",
                    Ø: "O",
                    Ǿ: "O",
                    Ɔ: "O",
                    Ɵ: "O",
                    "Ꝋ": "O",
                    "Ꝍ": "O",
                    Œ: "OE",
                    Ƣ: "OI",
                    "Ꝏ": "OO",
                    Ȣ: "OU",
                    "Ⓟ": "P",
                    Ｐ: "P",
                    Ṕ: "P",
                    Ṗ: "P",
                    Ƥ: "P",
                    "Ᵽ": "P",
                    "Ꝑ": "P",
                    "Ꝓ": "P",
                    "Ꝕ": "P",
                    "Ⓠ": "Q",
                    Ｑ: "Q",
                    "Ꝗ": "Q",
                    "Ꝙ": "Q",
                    "Ɋ": "Q",
                    "Ⓡ": "R",
                    Ｒ: "R",
                    Ŕ: "R",
                    Ṙ: "R",
                    Ř: "R",
                    Ȑ: "R",
                    Ȓ: "R",
                    Ṛ: "R",
                    Ṝ: "R",
                    Ŗ: "R",
                    Ṟ: "R",
                    "Ɍ": "R",
                    "Ɽ": "R",
                    "Ꝛ": "R",
                    "Ꞧ": "R",
                    "Ꞃ": "R",
                    "Ⓢ": "S",
                    Ｓ: "S",
                    "ẞ": "S",
                    Ś: "S",
                    Ṥ: "S",
                    Ŝ: "S",
                    Ṡ: "S",
                    Š: "S",
                    Ṧ: "S",
                    Ṣ: "S",
                    Ṩ: "S",
                    Ș: "S",
                    Ş: "S",
                    "Ȿ": "S",
                    "Ꞩ": "S",
                    "Ꞅ": "S",
                    "Ⓣ": "T",
                    Ｔ: "T",
                    Ṫ: "T",
                    Ť: "T",
                    Ṭ: "T",
                    Ț: "T",
                    Ţ: "T",
                    Ṱ: "T",
                    Ṯ: "T",
                    Ŧ: "T",
                    Ƭ: "T",
                    Ʈ: "T",
                    "Ⱦ": "T",
                    "Ꞇ": "T",
                    "Ꜩ": "TZ",
                    "Ⓤ": "U",
                    Ｕ: "U",
                    Ù: "U",
                    Ú: "U",
                    Û: "U",
                    Ũ: "U",
                    Ṹ: "U",
                    Ū: "U",
                    Ṻ: "U",
                    Ŭ: "U",
                    Ü: "U",
                    Ǜ: "U",
                    Ǘ: "U",
                    Ǖ: "U",
                    Ǚ: "U",
                    Ủ: "U",
                    Ů: "U",
                    Ű: "U",
                    Ǔ: "U",
                    Ȕ: "U",
                    Ȗ: "U",
                    Ư: "U",
                    Ừ: "U",
                    Ứ: "U",
                    Ữ: "U",
                    Ử: "U",
                    Ự: "U",
                    Ụ: "U",
                    Ṳ: "U",
                    Ų: "U",
                    Ṷ: "U",
                    Ṵ: "U",
                    "Ʉ": "U",
                    "Ⓥ": "V",
                    Ｖ: "V",
                    Ṽ: "V",
                    Ṿ: "V",
                    Ʋ: "V",
                    "Ꝟ": "V",
                    "Ʌ": "V",
                    "Ꝡ": "VY",
                    "Ⓦ": "W",
                    Ｗ: "W",
                    Ẁ: "W",
                    Ẃ: "W",
                    Ŵ: "W",
                    Ẇ: "W",
                    Ẅ: "W",
                    Ẉ: "W",
                    "Ⱳ": "W",
                    "Ⓧ": "X",
                    Ｘ: "X",
                    Ẋ: "X",
                    Ẍ: "X",
                    "Ⓨ": "Y",
                    Ｙ: "Y",
                    Ỳ: "Y",
                    Ý: "Y",
                    Ŷ: "Y",
                    Ỹ: "Y",
                    Ȳ: "Y",
                    Ẏ: "Y",
                    Ÿ: "Y",
                    Ỷ: "Y",
                    Ỵ: "Y",
                    Ƴ: "Y",
                    "Ɏ": "Y",
                    "Ỿ": "Y",
                    "Ⓩ": "Z",
                    Ｚ: "Z",
                    Ź: "Z",
                    Ẑ: "Z",
                    Ż: "Z",
                    Ž: "Z",
                    Ẓ: "Z",
                    Ẕ: "Z",
                    Ƶ: "Z",
                    Ȥ: "Z",
                    "Ɀ": "Z",
                    "Ⱬ": "Z",
                    "Ꝣ": "Z",
                    "ⓐ": "a",
                    ａ: "a",
                    ẚ: "a",
                    à: "a",
                    á: "a",
                    â: "a",
                    ầ: "a",
                    ấ: "a",
                    ẫ: "a",
                    ẩ: "a",
                    ã: "a",
                    ā: "a",
                    ă: "a",
                    ằ: "a",
                    ắ: "a",
                    ẵ: "a",
                    ẳ: "a",
                    ȧ: "a",
                    ǡ: "a",
                    ä: "a",
                    ǟ: "a",
                    ả: "a",
                    å: "a",
                    ǻ: "a",
                    ǎ: "a",
                    ȁ: "a",
                    ȃ: "a",
                    ạ: "a",
                    ậ: "a",
                    ặ: "a",
                    ḁ: "a",
                    ą: "a",
                    "ⱥ": "a",
                    ɐ: "a",
                    "ꜳ": "aa",
                    æ: "ae",
                    ǽ: "ae",
                    ǣ: "ae",
                    "ꜵ": "ao",
                    "ꜷ": "au",
                    "ꜹ": "av",
                    "ꜻ": "av",
                    "ꜽ": "ay",
                    "ⓑ": "b",
                    ｂ: "b",
                    ḃ: "b",
                    ḅ: "b",
                    ḇ: "b",
                    ƀ: "b",
                    ƃ: "b",
                    ɓ: "b",
                    "ⓒ": "c",
                    ｃ: "c",
                    ć: "c",
                    ĉ: "c",
                    ċ: "c",
                    č: "c",
                    ç: "c",
                    ḉ: "c",
                    ƈ: "c",
                    "ȼ": "c",
                    "ꜿ": "c",
                    "ↄ": "c",
                    "ⓓ": "d",
                    ｄ: "d",
                    ḋ: "d",
                    ď: "d",
                    ḍ: "d",
                    ḑ: "d",
                    ḓ: "d",
                    ḏ: "d",
                    đ: "d",
                    ƌ: "d",
                    ɖ: "d",
                    ɗ: "d",
                    "ꝺ": "d",
                    ǳ: "dz",
                    ǆ: "dz",
                    "ⓔ": "e",
                    ｅ: "e",
                    è: "e",
                    é: "e",
                    ê: "e",
                    ề: "e",
                    ế: "e",
                    ễ: "e",
                    ể: "e",
                    ẽ: "e",
                    ē: "e",
                    ḕ: "e",
                    ḗ: "e",
                    ĕ: "e",
                    ė: "e",
                    ë: "e",
                    ẻ: "e",
                    ě: "e",
                    ȅ: "e",
                    ȇ: "e",
                    ẹ: "e",
                    ệ: "e",
                    ȩ: "e",
                    ḝ: "e",
                    ę: "e",
                    ḙ: "e",
                    ḛ: "e",
                    "ɇ": "e",
                    ɛ: "e",
                    ǝ: "e",
                    "ⓕ": "f",
                    ｆ: "f",
                    ḟ: "f",
                    ƒ: "f",
                    "ꝼ": "f",
                    "ⓖ": "g",
                    ｇ: "g",
                    ǵ: "g",
                    ĝ: "g",
                    ḡ: "g",
                    ğ: "g",
                    ġ: "g",
                    ǧ: "g",
                    ģ: "g",
                    ǥ: "g",
                    ɠ: "g",
                    "ꞡ": "g",
                    "ᵹ": "g",
                    "ꝿ": "g",
                    "ⓗ": "h",
                    ｈ: "h",
                    ĥ: "h",
                    ḣ: "h",
                    ḧ: "h",
                    ȟ: "h",
                    ḥ: "h",
                    ḩ: "h",
                    ḫ: "h",
                    ẖ: "h",
                    ħ: "h",
                    "ⱨ": "h",
                    "ⱶ": "h",
                    ɥ: "h",
                    ƕ: "hv",
                    "ⓘ": "i",
                    ｉ: "i",
                    ì: "i",
                    í: "i",
                    î: "i",
                    ĩ: "i",
                    ī: "i",
                    ĭ: "i",
                    ï: "i",
                    ḯ: "i",
                    ỉ: "i",
                    ǐ: "i",
                    ȉ: "i",
                    ȋ: "i",
                    ị: "i",
                    į: "i",
                    ḭ: "i",
                    ɨ: "i",
                    ı: "i",
                    "ⓙ": "j",
                    ｊ: "j",
                    ĵ: "j",
                    ǰ: "j",
                    "ɉ": "j",
                    "ⓚ": "k",
                    ｋ: "k",
                    ḱ: "k",
                    ǩ: "k",
                    ḳ: "k",
                    ķ: "k",
                    ḵ: "k",
                    ƙ: "k",
                    "ⱪ": "k",
                    "ꝁ": "k",
                    "ꝃ": "k",
                    "ꝅ": "k",
                    "ꞣ": "k",
                    "ⓛ": "l",
                    ｌ: "l",
                    ŀ: "l",
                    ĺ: "l",
                    ľ: "l",
                    ḷ: "l",
                    ḹ: "l",
                    ļ: "l",
                    ḽ: "l",
                    ḻ: "l",
                    ſ: "l",
                    ł: "l",
                    ƚ: "l",
                    ɫ: "l",
                    "ⱡ": "l",
                    "ꝉ": "l",
                    "ꞁ": "l",
                    "ꝇ": "l",
                    ǉ: "lj",
                    "ⓜ": "m",
                    ｍ: "m",
                    ḿ: "m",
                    ṁ: "m",
                    ṃ: "m",
                    ɱ: "m",
                    ɯ: "m",
                    "ⓝ": "n",
                    ｎ: "n",
                    ǹ: "n",
                    ń: "n",
                    ñ: "n",
                    ṅ: "n",
                    ň: "n",
                    ṇ: "n",
                    ņ: "n",
                    ṋ: "n",
                    ṉ: "n",
                    ƞ: "n",
                    ɲ: "n",
                    ŉ: "n",
                    "ꞑ": "n",
                    "ꞥ": "n",
                    ǌ: "nj",
                    "ⓞ": "o",
                    ｏ: "o",
                    ò: "o",
                    ó: "o",
                    ô: "o",
                    ồ: "o",
                    ố: "o",
                    ỗ: "o",
                    ổ: "o",
                    õ: "o",
                    ṍ: "o",
                    ȭ: "o",
                    ṏ: "o",
                    ō: "o",
                    ṑ: "o",
                    ṓ: "o",
                    ŏ: "o",
                    ȯ: "o",
                    ȱ: "o",
                    ö: "o",
                    ȫ: "o",
                    ỏ: "o",
                    ő: "o",
                    ǒ: "o",
                    ȍ: "o",
                    ȏ: "o",
                    ơ: "o",
                    ờ: "o",
                    ớ: "o",
                    ỡ: "o",
                    ở: "o",
                    ợ: "o",
                    ọ: "o",
                    ộ: "o",
                    ǫ: "o",
                    ǭ: "o",
                    ø: "o",
                    ǿ: "o",
                    ɔ: "o",
                    "ꝋ": "o",
                    "ꝍ": "o",
                    ɵ: "o",
                    œ: "oe",
                    ƣ: "oi",
                    ȣ: "ou",
                    "ꝏ": "oo",
                    "ⓟ": "p",
                    ｐ: "p",
                    ṕ: "p",
                    ṗ: "p",
                    ƥ: "p",
                    "ᵽ": "p",
                    "ꝑ": "p",
                    "ꝓ": "p",
                    "ꝕ": "p",
                    "ⓠ": "q",
                    ｑ: "q",
                    "ɋ": "q",
                    "ꝗ": "q",
                    "ꝙ": "q",
                    "ⓡ": "r",
                    ｒ: "r",
                    ŕ: "r",
                    ṙ: "r",
                    ř: "r",
                    ȑ: "r",
                    ȓ: "r",
                    ṛ: "r",
                    ṝ: "r",
                    ŗ: "r",
                    ṟ: "r",
                    "ɍ": "r",
                    ɽ: "r",
                    "ꝛ": "r",
                    "ꞧ": "r",
                    "ꞃ": "r",
                    "ⓢ": "s",
                    ｓ: "s",
                    ß: "s",
                    ś: "s",
                    ṥ: "s",
                    ŝ: "s",
                    ṡ: "s",
                    š: "s",
                    ṧ: "s",
                    ṣ: "s",
                    ṩ: "s",
                    ș: "s",
                    ş: "s",
                    "ȿ": "s",
                    "ꞩ": "s",
                    "ꞅ": "s",
                    ẛ: "s",
                    "ⓣ": "t",
                    ｔ: "t",
                    ṫ: "t",
                    ẗ: "t",
                    ť: "t",
                    ṭ: "t",
                    ț: "t",
                    ţ: "t",
                    ṱ: "t",
                    ṯ: "t",
                    ŧ: "t",
                    ƭ: "t",
                    ʈ: "t",
                    "ⱦ": "t",
                    "ꞇ": "t",
                    "ꜩ": "tz",
                    "ⓤ": "u",
                    ｕ: "u",
                    ù: "u",
                    ú: "u",
                    û: "u",
                    ũ: "u",
                    ṹ: "u",
                    ū: "u",
                    ṻ: "u",
                    ŭ: "u",
                    ü: "u",
                    ǜ: "u",
                    ǘ: "u",
                    ǖ: "u",
                    ǚ: "u",
                    ủ: "u",
                    ů: "u",
                    ű: "u",
                    ǔ: "u",
                    ȕ: "u",
                    ȗ: "u",
                    ư: "u",
                    ừ: "u",
                    ứ: "u",
                    ữ: "u",
                    ử: "u",
                    ự: "u",
                    ụ: "u",
                    ṳ: "u",
                    ų: "u",
                    ṷ: "u",
                    ṵ: "u",
                    ʉ: "u",
                    "ⓥ": "v",
                    ｖ: "v",
                    ṽ: "v",
                    ṿ: "v",
                    ʋ: "v",
                    "ꝟ": "v",
                    ʌ: "v",
                    "ꝡ": "vy",
                    "ⓦ": "w",
                    ｗ: "w",
                    ẁ: "w",
                    ẃ: "w",
                    ŵ: "w",
                    ẇ: "w",
                    ẅ: "w",
                    ẘ: "w",
                    ẉ: "w",
                    "ⱳ": "w",
                    "ⓧ": "x",
                    ｘ: "x",
                    ẋ: "x",
                    ẍ: "x",
                    "ⓨ": "y",
                    ｙ: "y",
                    ỳ: "y",
                    ý: "y",
                    ŷ: "y",
                    ỹ: "y",
                    ȳ: "y",
                    ẏ: "y",
                    ÿ: "y",
                    ỷ: "y",
                    ẙ: "y",
                    ỵ: "y",
                    ƴ: "y",
                    "ɏ": "y",
                    "ỿ": "y",
                    "ⓩ": "z",
                    ｚ: "z",
                    ź: "z",
                    ẑ: "z",
                    ż: "z",
                    ž: "z",
                    ẓ: "z",
                    ẕ: "z",
                    ƶ: "z",
                    ȥ: "z",
                    "ɀ": "z",
                    "ⱬ": "z",
                    "ꝣ": "z",
                    Ά: "Α",
                    Έ: "Ε",
                    Ή: "Η",
                    Ί: "Ι",
                    Ϊ: "Ι",
                    Ό: "Ο",
                    Ύ: "Υ",
                    Ϋ: "Υ",
                    Ώ: "Ω",
                    ά: "α",
                    έ: "ε",
                    ή: "η",
                    ί: "ι",
                    ϊ: "ι",
                    ΐ: "ι",
                    ό: "ο",
                    ύ: "υ",
                    ϋ: "υ",
                    ΰ: "υ",
                    ώ: "ω",
                    ς: "σ",
                    "’": "'"
                }
            }), P.define("select2/data/base", ["../utils"], function(y) {
                function x(b, f) {
                    x.__super__.constructor.call(this)
                }
                return y.Extend(x, y.Observable), x.prototype.current = function(b) {
                    throw new Error("The `current` method must be defined in child classes.")
                }, x.prototype.query = function(b, f) {
                    throw new Error("The `query` method must be defined in child classes.")
                }, x.prototype.bind = function(b, f) {}, x.prototype.destroy = function() {}, x.prototype.generateResultId = function(b, f) {
                    var d = b.id + "-result-";
                    return d += y.generateChars(4), f.id != null ? d += "-" + f.id.toString() : d += "-" + y.generateChars(4), d
                }, x
            }), P.define("select2/data/select", ["./base", "../utils", "jquery"], function(y, x, b) {
                function f(d, o) {
                    this.$element = d, this.options = o, f.__super__.constructor.call(this)
                }
                return x.Extend(f, y), f.prototype.current = function(d) {
                    var o = [],
                        h = this;
                    this.$element.find(":selected").each(function() {
                        var u = b(this),
                            w = h.item(u);
                        o.push(w)
                    }), d(o)
                }, f.prototype.select = function(d) {
                    var o = this;
                    if (d.selected = !0, b(d.element).is("option")) return d.element.selected = !0, void this.$element.trigger("input").trigger("change");
                    if (this.$element.prop("multiple")) this.current(function(u) {
                        var w = [];
                        (d = [d]).push.apply(d, u);
                        for (var C = 0; C < d.length; C++) {
                            var q = d[C].id;
                            b.inArray(q, w) === -1 && w.push(q)
                        }
                        o.$element.val(w), o.$element.trigger("input").trigger("change")
                    });
                    else {
                        var h = d.id;
                        this.$element.val(h), this.$element.trigger("input").trigger("change")
                    }
                }, f.prototype.unselect = function(d) {
                    var o = this;
                    if (this.$element.prop("multiple")) {
                        if (d.selected = !1, b(d.element).is("option")) return d.element.selected = !1, void this.$element.trigger("input").trigger("change");
                        this.current(function(h) {
                            for (var u = [], w = 0; w < h.length; w++) {
                                var C = h[w].id;
                                C !== d.id && b.inArray(C, u) === -1 && u.push(C)
                            }
                            o.$element.val(u), o.$element.trigger("input").trigger("change")
                        })
                    }
                }, f.prototype.bind = function(d, o) {
                    var h = this;
                    (this.container = d).on("select", function(u) {
                        h.select(u.data)
                    }), d.on("unselect", function(u) {
                        h.unselect(u.data)
                    })
                }, f.prototype.destroy = function() {
                    this.$element.find("*").each(function() {
                        x.RemoveData(this)
                    })
                }, f.prototype.query = function(d, o) {
                    var h = [],
                        u = this;
                    this.$element.children().each(function() {
                        var w = b(this);
                        if (w.is("option") || w.is("optgroup")) {
                            var C = u.item(w),
                                q = u.matches(d, C);
                            q !== null && h.push(q)
                        }
                    }), o({
                        results: h
                    })
                }, f.prototype.addOptions = function(d) {
                    x.appendMany(this.$element, d)
                }, f.prototype.option = function(d) {
                    var o;
                    d.children ? (o = document.createElement("optgroup")).label = d.text : (o = document.createElement("option")).textContent !== void 0 ? o.textContent = d.text : o.innerText = d.text, d.id !== void 0 && (o.value = d.id), d.disabled && (o.disabled = !0), d.selected && (o.selected = !0), d.title && (o.title = d.title);
                    var h = b(o),
                        u = this._normalizeItem(d);
                    return u.element = o, x.StoreData(o, "data", u), h
                }, f.prototype.item = function(d) {
                    var o = {};
                    if ((o = x.GetData(d[0], "data")) != null) return o;
                    if (d.is("option")) o = {
                        id: d.val(),
                        text: d.text(),
                        disabled: d.prop("disabled"),
                        selected: d.prop("selected"),
                        title: d.prop("title")
                    };
                    else if (d.is("optgroup")) {
                        o = {
                            text: d.prop("label"),
                            children: [],
                            title: d.prop("title")
                        };
                        for (var h = d.children("option"), u = [], w = 0; w < h.length; w++) {
                            var C = b(h[w]),
                                q = this.item(C);
                            u.push(q)
                        }
                        o.children = u
                    }
                    return (o = this._normalizeItem(o)).element = d[0], x.StoreData(d[0], "data", o), o
                }, f.prototype._normalizeItem = function(d) {
                    return d !== Object(d) && (d = {
                        id: d,
                        text: d
                    }), (d = b.extend({}, {
                        text: ""
                    }, d)).id != null && (d.id = d.id.toString()), d.text != null && (d.text = d.text.toString()), d._resultId == null && d.id && this.container != null && (d._resultId = this.generateResultId(this.container, d)), b.extend({}, {
                        selected: !1,
                        disabled: !1
                    }, d)
                }, f.prototype.matches = function(d, o) {
                    return this.options.get("matcher")(d, o)
                }, f
            }), P.define("select2/data/array", ["./select", "../utils", "jquery"], function(y, x, b) {
                function f(d, o) {
                    this._dataToConvert = o.get("data") || [], f.__super__.constructor.call(this, d, o)
                }
                return x.Extend(f, y), f.prototype.bind = function(d, o) {
                    f.__super__.bind.call(this, d, o), this.addOptions(this.convertToOptions(this._dataToConvert))
                }, f.prototype.select = function(d) {
                    var o = this.$element.find("option").filter(function(h, u) {
                        return u.value == d.id.toString()
                    });
                    o.length === 0 && (o = this.option(d), this.addOptions(o)), f.__super__.select.call(this, d)
                }, f.prototype.convertToOptions = function(d) {
                    var o = this,
                        h = this.$element.find("option"),
                        u = h.map(function() {
                            return o.item(b(this)).id
                        }).get(),
                        w = [];

                    function C(Ht) {
                        return function() {
                            return b(this).val() == Ht.id
                        }
                    }
                    for (var q = 0; q < d.length; q++) {
                        var M = this._normalizeItem(d[q]);
                        if (0 <= b.inArray(M.id, u)) {
                            var ae = h.filter(C(M)),
                                ne = this.item(ae),
                                De = b.extend(!0, {}, M, ne),
                                ge = this.option(De);
                            ae.replaceWith(ge)
                        } else {
                            var ye = this.option(M);
                            if (M.children) {
                                var ie = this.convertToOptions(M.children);
                                x.appendMany(ye, ie)
                            }
                            w.push(ye)
                        }
                    }
                    return w
                }, f
            }), P.define("select2/data/ajax", ["./array", "../utils", "jquery"], function(y, x, b) {
                function f(d, o) {
                    this.ajaxOptions = this._applyDefaults(o.get("ajax")), this.ajaxOptions.processResults != null && (this.processResults = this.ajaxOptions.processResults), f.__super__.constructor.call(this, d, o)
                }
                return x.Extend(f, y), f.prototype._applyDefaults = function(d) {
                    var o = {
                        data: function(h) {
                            return b.extend({}, h, {
                                q: h.term
                            })
                        },
                        transport: function(h, u, w) {
                            var C = b.ajax(h);
                            return C.then(u), C.fail(w), C
                        }
                    };
                    return b.extend({}, o, d, !0)
                }, f.prototype.processResults = function(d) {
                    return d
                }, f.prototype.query = function(d, o) {
                    var h = this;
                    this._request != null && (b.isFunction(this._request.abort) && this._request.abort(), this._request = null);
                    var u = b.extend({
                        type: "GET"
                    }, this.ajaxOptions);

                    function w() {
                        var C = u.transport(u, function(q) {
                            var M = h.processResults(q, d);
                            h.options.get("debug") && window.console && console.error && (M && M.results && b.isArray(M.results) || console.error("Select2: The AJAX results did not return an array in the `results` key of the response.")), o(M)
                        }, function() {
                            "status" in C && (C.status === 0 || C.status === "0") || h.trigger("results:message", {
                                message: "errorLoading"
                            })
                        });
                        h._request = C
                    }
                    typeof u.url == "function" && (u.url = u.url.call(this.$element, d)), typeof u.data == "function" && (u.data = u.data.call(this.$element, d)), this.ajaxOptions.delay && d.term != null ? (this._queryTimeout && window.clearTimeout(this._queryTimeout), this._queryTimeout = window.setTimeout(w, this.ajaxOptions.delay)) : w()
                }, f
            }), P.define("select2/data/tags", ["jquery"], function(y) {
                function x(b, f, d) {
                    var o = d.get("tags"),
                        h = d.get("createTag");
                    h !== void 0 && (this.createTag = h);
                    var u = d.get("insertTag");
                    if (u !== void 0 && (this.insertTag = u), b.call(this, f, d), y.isArray(o))
                        for (var w = 0; w < o.length; w++) {
                            var C = o[w],
                                q = this._normalizeItem(C),
                                M = this.option(q);
                            this.$element.append(M)
                        }
                }
                return x.prototype.query = function(b, f, d) {
                    var o = this;
                    this._removeOldTags(), f.term != null && f.page == null ? b.call(this, f, function h(u, w) {
                        for (var C = u.results, q = 0; q < C.length; q++) {
                            var M = C[q],
                                ae = M.children != null && !h({
                                    results: M.children
                                }, !0);
                            if ((M.text || "").toUpperCase() === (f.term || "").toUpperCase() || ae) return !w && (u.data = C, void d(u))
                        }
                        if (w) return !0;
                        var ne = o.createTag(f);
                        if (ne != null) {
                            var De = o.option(ne);
                            De.attr("data-select2-tag", !0), o.addOptions([De]), o.insertTag(C, ne)
                        }
                        u.results = C, d(u)
                    }) : b.call(this, f, d)
                }, x.prototype.createTag = function(b, f) {
                    var d = y.trim(f.term);
                    return d === "" ? null : {
                        id: d,
                        text: d
                    }
                }, x.prototype.insertTag = function(b, f, d) {
                    f.unshift(d)
                }, x.prototype._removeOldTags = function(b) {
                    this.$element.find("option[data-select2-tag]").each(function() {
                        this.selected || y(this).remove()
                    })
                }, x
            }), P.define("select2/data/tokenizer", ["jquery"], function(y) {
                function x(b, f, d) {
                    var o = d.get("tokenizer");
                    o !== void 0 && (this.tokenizer = o), b.call(this, f, d)
                }
                return x.prototype.bind = function(b, f, d) {
                    b.call(this, f, d), this.$search = f.dropdown.$search || f.selection.$search || d.find(".select2-search__field")
                }, x.prototype.query = function(b, f, d) {
                    var o = this;
                    f.term = f.term || "";
                    var h = this.tokenizer(f, this.options, function(u) {
                        var w, C = o._normalizeItem(u);
                        if (!o.$element.find("option").filter(function() {
                                return y(this).val() === C.id
                            }).length) {
                            var q = o.option(C);
                            q.attr("data-select2-tag", !0), o._removeOldTags(), o.addOptions([q])
                        }
                        w = C, o.trigger("select", {
                            data: w
                        })
                    });
                    h.term !== f.term && (this.$search.length && (this.$search.val(h.term), this.$search.trigger("focus")), f.term = h.term), b.call(this, f, d)
                }, x.prototype.tokenizer = function(b, f, d, o) {
                    for (var h = d.get("tokenSeparators") || [], u = f.term, w = 0, C = this.createTag || function(ne) {
                            return {
                                id: ne.term,
                                text: ne.term
                            }
                        }; w < u.length;) {
                        var q = u[w];
                        if (y.inArray(q, h) !== -1) {
                            var M = u.substr(0, w),
                                ae = C(y.extend({}, f, {
                                    term: M
                                }));
                            ae != null ? (o(ae), u = u.substr(w + 1) || "", w = 0) : w++
                        } else w++
                    }
                    return {
                        term: u
                    }
                }, x
            }), P.define("select2/data/minimumInputLength", [], function() {
                function y(x, b, f) {
                    this.minimumInputLength = f.get("minimumInputLength"), x.call(this, b, f)
                }
                return y.prototype.query = function(x, b, f) {
                    b.term = b.term || "", b.term.length < this.minimumInputLength ? this.trigger("results:message", {
                        message: "inputTooShort",
                        args: {
                            minimum: this.minimumInputLength,
                            input: b.term,
                            params: b
                        }
                    }) : x.call(this, b, f)
                }, y
            }), P.define("select2/data/maximumInputLength", [], function() {
                function y(x, b, f) {
                    this.maximumInputLength = f.get("maximumInputLength"), x.call(this, b, f)
                }
                return y.prototype.query = function(x, b, f) {
                    b.term = b.term || "", 0 < this.maximumInputLength && b.term.length > this.maximumInputLength ? this.trigger("results:message", {
                        message: "inputTooLong",
                        args: {
                            maximum: this.maximumInputLength,
                            input: b.term,
                            params: b
                        }
                    }) : x.call(this, b, f)
                }, y
            }), P.define("select2/data/maximumSelectionLength", [], function() {
                function y(x, b, f) {
                    this.maximumSelectionLength = f.get("maximumSelectionLength"), x.call(this, b, f)
                }
                return y.prototype.bind = function(x, b, f) {
                    var d = this;
                    x.call(this, b, f), b.on("select", function() {
                        d._checkIfMaximumSelected()
                    })
                }, y.prototype.query = function(x, b, f) {
                    var d = this;
                    this._checkIfMaximumSelected(function() {
                        x.call(d, b, f)
                    })
                }, y.prototype._checkIfMaximumSelected = function(x, b) {
                    var f = this;
                    this.current(function(d) {
                        var o = d != null ? d.length : 0;
                        0 < f.maximumSelectionLength && o >= f.maximumSelectionLength ? f.trigger("results:message", {
                            message: "maximumSelected",
                            args: {
                                maximum: f.maximumSelectionLength
                            }
                        }) : b && b()
                    })
                }, y
            }), P.define("select2/dropdown", ["jquery", "./utils"], function(y, x) {
                function b(f, d) {
                    this.$element = f, this.options = d, b.__super__.constructor.call(this)
                }
                return x.Extend(b, x.Observable), b.prototype.render = function() {
                    var f = y('<span class="select2-dropdown"><span class="select2-results"></span></span>');
                    return f.attr("dir", this.options.get("dir")), this.$dropdown = f
                }, b.prototype.bind = function() {}, b.prototype.position = function(f, d) {}, b.prototype.destroy = function() {
                    this.$dropdown.remove()
                }, b
            }), P.define("select2/dropdown/search", ["jquery", "../utils"], function(y, x) {
                function b() {}
                return b.prototype.render = function(f) {
                    var d = f.call(this),
                        o = y('<span class="select2-search select2-search--dropdown"><input class="select2-search__field" type="search" tabindex="-1" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" role="searchbox" aria-autocomplete="list" /></span>');
                    return this.$searchContainer = o, this.$search = o.find("input"), d.prepend(o), d
                }, b.prototype.bind = function(f, d, o) {
                    var h = this,
                        u = d.id + "-results";
                    f.call(this, d, o), this.$search.on("keydown", function(w) {
                        h.trigger("keypress", w), h._keyUpPrevented = w.isDefaultPrevented()
                    }), this.$search.on("input", function(w) {
                        y(this).off("keyup")
                    }), this.$search.on("keyup input", function(w) {
                        h.handleSearch(w)
                    }), d.on("open", function() {
                        h.$search.attr("tabindex", 0), h.$search.attr("aria-controls", u), h.$search.trigger("focus"), window.setTimeout(function() {
                            h.$search.trigger("focus")
                        }, 0)
                    }), d.on("close", function() {
                        h.$search.attr("tabindex", -1), h.$search.removeAttr("aria-controls"), h.$search.removeAttr("aria-activedescendant"), h.$search.val(""), h.$search.trigger("blur")
                    }), d.on("focus", function() {
                        d.isOpen() || h.$search.trigger("focus")
                    }), d.on("results:all", function(w) {
                        w.query.term != null && w.query.term !== "" || (h.showSearch(w) ? h.$searchContainer.removeClass("select2-search--hide") : h.$searchContainer.addClass("select2-search--hide"))
                    }), d.on("results:focus", function(w) {
                        w.data._resultId ? h.$search.attr("aria-activedescendant", w.data._resultId) : h.$search.removeAttr("aria-activedescendant")
                    })
                }, b.prototype.handleSearch = function(f) {
                    if (!this._keyUpPrevented) {
                        var d = this.$search.val();
                        this.trigger("query", {
                            term: d
                        })
                    }
                    this._keyUpPrevented = !1
                }, b.prototype.showSearch = function(f, d) {
                    return !0
                }, b
            }), P.define("select2/dropdown/hidePlaceholder", [], function() {
                function y(x, b, f, d) {
                    this.placeholder = this.normalizePlaceholder(f.get("placeholder")), x.call(this, b, f, d)
                }
                return y.prototype.append = function(x, b) {
                    b.results = this.removePlaceholder(b.results), x.call(this, b)
                }, y.prototype.normalizePlaceholder = function(x, b) {
                    return typeof b == "string" && (b = {
                        id: "",
                        text: b
                    }), b
                }, y.prototype.removePlaceholder = function(x, b) {
                    for (var f = b.slice(0), d = b.length - 1; 0 <= d; d--) {
                        var o = b[d];
                        this.placeholder.id === o.id && f.splice(d, 1)
                    }
                    return f
                }, y
            }), P.define("select2/dropdown/infiniteScroll", ["jquery"], function(y) {
                function x(b, f, d, o) {
                    this.lastParams = {}, b.call(this, f, d, o), this.$loadingMore = this.createLoadingMore(), this.loading = !1
                }
                return x.prototype.append = function(b, f) {
                    this.$loadingMore.remove(), this.loading = !1, b.call(this, f), this.showLoadingMore(f) && (this.$results.append(this.$loadingMore), this.loadMoreIfNeeded())
                }, x.prototype.bind = function(b, f, d) {
                    var o = this;
                    b.call(this, f, d), f.on("query", function(h) {
                        o.lastParams = h, o.loading = !0
                    }), f.on("query:append", function(h) {
                        o.lastParams = h, o.loading = !0
                    }), this.$results.on("scroll", this.loadMoreIfNeeded.bind(this))
                }, x.prototype.loadMoreIfNeeded = function() {
                    var b = y.contains(document.documentElement, this.$loadingMore[0]);
                    if (!this.loading && b) {
                        var f = this.$results.offset().top + this.$results.outerHeight(!1);
                        this.$loadingMore.offset().top + this.$loadingMore.outerHeight(!1) <= f + 50 && this.loadMore()
                    }
                }, x.prototype.loadMore = function() {
                    this.loading = !0;
                    var b = y.extend({}, {
                        page: 1
                    }, this.lastParams);
                    b.page++, this.trigger("query:append", b)
                }, x.prototype.showLoadingMore = function(b, f) {
                    return f.pagination && f.pagination.more
                }, x.prototype.createLoadingMore = function() {
                    var b = y('<li class="select2-results__option select2-results__option--load-more"role="option" aria-disabled="true"></li>'),
                        f = this.options.get("translations").get("loadingMore");
                    return b.html(f(this.lastParams)), b
                }, x
            }), P.define("select2/dropdown/attachBody", ["jquery", "../utils"], function(y, x) {
                function b(f, d, o) {
                    this.$dropdownParent = y(o.get("dropdownParent") || document.body), f.call(this, d, o)
                }
                return b.prototype.bind = function(f, d, o) {
                    var h = this;
                    f.call(this, d, o), d.on("open", function() {
                        h._showDropdown(), h._attachPositioningHandler(d), h._bindContainerResultHandlers(d)
                    }), d.on("close", function() {
                        h._hideDropdown(), h._detachPositioningHandler(d)
                    }), this.$dropdownContainer.on("mousedown", function(u) {
                        u.stopPropagation()
                    })
                }, b.prototype.destroy = function(f) {
                    f.call(this), this.$dropdownContainer.remove()
                }, b.prototype.position = function(f, d, o) {
                    d.attr("class", o.attr("class")), d.removeClass("select2"), d.addClass("select2-container--open"), d.css({
                        position: "absolute",
                        top: -999999
                    }), this.$container = o
                }, b.prototype.render = function(f) {
                    var d = y("<span></span>"),
                        o = f.call(this);
                    return d.append(o), this.$dropdownContainer = d
                }, b.prototype._hideDropdown = function(f) {
                    this.$dropdownContainer.detach()
                }, b.prototype._bindContainerResultHandlers = function(f, d) {
                    if (!this._containerResultsHandlersBound) {
                        var o = this;
                        d.on("results:all", function() {
                            o._positionDropdown(), o._resizeDropdown()
                        }), d.on("results:append", function() {
                            o._positionDropdown(), o._resizeDropdown()
                        }), d.on("results:message", function() {
                            o._positionDropdown(), o._resizeDropdown()
                        }), d.on("select", function() {
                            o._positionDropdown(), o._resizeDropdown()
                        }), d.on("unselect", function() {
                            o._positionDropdown(), o._resizeDropdown()
                        }), this._containerResultsHandlersBound = !0
                    }
                }, b.prototype._attachPositioningHandler = function(f, d) {
                    var o = this,
                        h = "scroll.select2." + d.id,
                        u = "resize.select2." + d.id,
                        w = "orientationchange.select2." + d.id,
                        C = this.$container.parents().filter(x.hasScroll);
                    C.each(function() {
                        x.StoreData(this, "select2-scroll-position", {
                            x: y(this).scrollLeft(),
                            y: y(this).scrollTop()
                        })
                    }), C.on(h, function(q) {
                        var M = x.GetData(this, "select2-scroll-position");
                        y(this).scrollTop(M.y)
                    }), y(window).on(h + " " + u + " " + w, function(q) {
                        o._positionDropdown(), o._resizeDropdown()
                    })
                }, b.prototype._detachPositioningHandler = function(f, d) {
                    var o = "scroll.select2." + d.id,
                        h = "resize.select2." + d.id,
                        u = "orientationchange.select2." + d.id;
                    this.$container.parents().filter(x.hasScroll).off(o), y(window).off(o + " " + h + " " + u)
                }, b.prototype._positionDropdown = function() {
                    var f = y(window),
                        d = this.$dropdown.hasClass("select2-dropdown--above"),
                        o = this.$dropdown.hasClass("select2-dropdown--below"),
                        h = null,
                        u = this.$container.offset();
                    u.bottom = u.top + this.$container.outerHeight(!1);
                    var w = {
                        height: this.$container.outerHeight(!1)
                    };
                    w.top = u.top, w.bottom = u.top + w.height;
                    var C = this.$dropdown.outerHeight(!1),
                        q = f.scrollTop(),
                        M = f.scrollTop() + f.height(),
                        ae = q < u.top - C,
                        ne = M > u.bottom + C,
                        De = {
                            left: u.left,
                            top: w.bottom
                        },
                        ge = this.$dropdownParent;
                    ge.css("position") === "static" && (ge = ge.offsetParent());
                    var ye = {
                        top: 0,
                        left: 0
                    };
                    (y.contains(document.body, ge[0]) || ge[0].isConnected) && (ye = ge.offset()), De.top -= ye.top, De.left -= ye.left, d || o || (h = "below"), ne || !ae || d ? !ae && ne && d && (h = "below") : h = "above", (h == "above" || d && h !== "below") && (De.top = w.top - ye.top - C), h != null && (this.$dropdown.removeClass("select2-dropdown--below select2-dropdown--above").addClass("select2-dropdown--" + h), this.$container.removeClass("select2-container--below select2-container--above").addClass("select2-container--" + h)), this.$dropdownContainer.css(De)
                }, b.prototype._resizeDropdown = function() {
                    var f = {
                        width: this.$container.outerWidth(!1) + "px"
                    };
                    this.options.get("dropdownAutoWidth") && (f.minWidth = f.width, f.position = "relative", f.width = "auto"), this.$dropdown.css(f)
                }, b.prototype._showDropdown = function(f) {
                    this.$dropdownContainer.appendTo(this.$dropdownParent), this._positionDropdown(), this._resizeDropdown()
                }, b
            }), P.define("select2/dropdown/minimumResultsForSearch", [], function() {
                function y(x, b, f, d) {
                    this.minimumResultsForSearch = f.get("minimumResultsForSearch"), this.minimumResultsForSearch < 0 && (this.minimumResultsForSearch = 1 / 0), x.call(this, b, f, d)
                }
                return y.prototype.showSearch = function(x, b) {
                    return !(function f(d) {
                        for (var o = 0, h = 0; h < d.length; h++) {
                            var u = d[h];
                            u.children ? o += f(u.children) : o++
                        }
                        return o
                    }(b.data.results) < this.minimumResultsForSearch) && x.call(this, b)
                }, y
            }), P.define("select2/dropdown/selectOnClose", ["../utils"], function(y) {
                function x() {}
                return x.prototype.bind = function(b, f, d) {
                    var o = this;
                    b.call(this, f, d), f.on("close", function(h) {
                        o._handleSelectOnClose(h)
                    })
                }, x.prototype._handleSelectOnClose = function(b, f) {
                    if (f && f.originalSelect2Event != null) {
                        var d = f.originalSelect2Event;
                        if (d._type === "select" || d._type === "unselect") return
                    }
                    var o = this.getHighlightedResults();
                    if (!(o.length < 1)) {
                        var h = y.GetData(o[0], "data");
                        h.element != null && h.element.selected || h.element == null && h.selected || this.trigger("select", {
                            data: h
                        })
                    }
                }, x
            }), P.define("select2/dropdown/closeOnSelect", [], function() {
                function y() {}
                return y.prototype.bind = function(x, b, f) {
                    var d = this;
                    x.call(this, b, f), b.on("select", function(o) {
                        d._selectTriggered(o)
                    }), b.on("unselect", function(o) {
                        d._selectTriggered(o)
                    })
                }, y.prototype._selectTriggered = function(x, b) {
                    var f = b.originalEvent;
                    f && (f.ctrlKey || f.metaKey) || this.trigger("close", {
                        originalEvent: f,
                        originalSelect2Event: b
                    })
                }, y
            }), P.define("select2/i18n/en", [], function() {
                return {
                    errorLoading: function() {
                        return "The results could not be loaded."
                    },
                    inputTooLong: function(y) {
                        var x = y.input.length - y.maximum,
                            b = "Please delete " + x + " character";
                        return x != 1 && (b += "s"), b
                    },
                    inputTooShort: function(y) {
                        return "Please enter " + (y.minimum - y.input.length) + " or more characters"
                    },
                    loadingMore: function() {
                        return "Loading more results…"
                    },
                    maximumSelected: function(y) {
                        var x = "You can only select " + y.maximum + " item";
                        return y.maximum != 1 && (x += "s"), x
                    },
                    noResults: function() {
                        return "Sem resultados"
                    },
                    searching: function() {
                        return "Searching…"
                    },
                    removeAllItems: function() {
                        return "Remove all items"
                    }
                }
            }), P.define("select2/defaults", ["jquery", "require", "./results", "./selection/single", "./selection/multiple", "./selection/placeholder", "./selection/allowClear", "./selection/search", "./selection/eventRelay", "./utils", "./translation", "./diacritics", "./data/select", "./data/array", "./data/ajax", "./data/tags", "./data/tokenizer", "./data/minimumInputLength", "./data/maximumInputLength", "./data/maximumSelectionLength", "./dropdown", "./dropdown/search", "./dropdown/hidePlaceholder", "./dropdown/infiniteScroll", "./dropdown/attachBody", "./dropdown/minimumResultsForSearch", "./dropdown/selectOnClose", "./dropdown/closeOnSelect", "./i18n/en"], function(y, x, b, f, d, o, h, u, w, C, q, M, ae, ne, De, ge, ye, ie, Ht, mt, lt, ut, he, tt, Yn, kt, yn, Pn, Dt) {
                function We() {
                    this.reset()
                }
                return We.prototype.apply = function(R) {
                    if ((R = y.extend(!0, {}, this.defaults, R)).dataAdapter == null) {
                        if (R.ajax != null ? R.dataAdapter = De : R.data != null ? R.dataAdapter = ne : R.dataAdapter = ae, 0 < R.minimumInputLength && (R.dataAdapter = C.Decorate(R.dataAdapter, ie)), 0 < R.maximumInputLength && (R.dataAdapter = C.Decorate(R.dataAdapter, Ht)), 0 < R.maximumSelectionLength && (R.dataAdapter = C.Decorate(R.dataAdapter, mt)), R.tags && (R.dataAdapter = C.Decorate(R.dataAdapter, ge)), R.tokenSeparators == null && R.tokenizer == null || (R.dataAdapter = C.Decorate(R.dataAdapter, ye)), R.query != null) {
                            var Se = x(R.amdBase + "compat/query");
                            R.dataAdapter = C.Decorate(R.dataAdapter, Se)
                        }
                        if (R.initSelection != null) {
                            var Me = x(R.amdBase + "compat/initSelection");
                            R.dataAdapter = C.Decorate(R.dataAdapter, Me)
                        }
                    }
                    if (R.resultsAdapter == null && (R.resultsAdapter = b, R.ajax != null && (R.resultsAdapter = C.Decorate(R.resultsAdapter, tt)), R.placeholder != null && (R.resultsAdapter = C.Decorate(R.resultsAdapter, he)), R.selectOnClose && (R.resultsAdapter = C.Decorate(R.resultsAdapter, yn))), R.dropdownAdapter == null) {
                        if (R.multiple) R.dropdownAdapter = lt;
                        else {
                            var He = C.Decorate(lt, ut);
                            R.dropdownAdapter = He
                        }
                        if (R.minimumResultsForSearch !== 0 && (R.dropdownAdapter = C.Decorate(R.dropdownAdapter, kt)), R.closeOnSelect && (R.dropdownAdapter = C.Decorate(R.dropdownAdapter, Pn)), R.dropdownCssClass != null || R.dropdownCss != null || R.adaptDropdownCssClass != null) {
                            var nt = x(R.amdBase + "compat/dropdownCss");
                            R.dropdownAdapter = C.Decorate(R.dropdownAdapter, nt)
                        }
                        R.dropdownAdapter = C.Decorate(R.dropdownAdapter, Yn)
                    }
                    if (R.selectionAdapter == null) {
                        if (R.multiple ? R.selectionAdapter = d : R.selectionAdapter = f, R.placeholder != null && (R.selectionAdapter = C.Decorate(R.selectionAdapter, o)), R.allowClear && (R.selectionAdapter = C.Decorate(R.selectionAdapter, h)), R.multiple && (R.selectionAdapter = C.Decorate(R.selectionAdapter, u)), R.containerCssClass != null || R.containerCss != null || R.adaptContainerCssClass != null) {
                            var Xe = x(R.amdBase + "compat/containerCss");
                            R.selectionAdapter = C.Decorate(R.selectionAdapter, Xe)
                        }
                        R.selectionAdapter = C.Decorate(R.selectionAdapter, w)
                    }
                    R.language = this._resolveLanguage(R.language), R.language.push("en");
                    for (var pt = [], Qe = 0; Qe < R.language.length; Qe++) {
                        var dt = R.language[Qe];
                        pt.indexOf(dt) === -1 && pt.push(dt)
                    }
                    return R.language = pt, R.translations = this._processTranslations(R.language, R.debug), R
                }, We.prototype.reset = function() {
                    function R(Se) {
                        return Se.replace(/[^\u0000-\u007E]/g, function(Me) {
                            return M[Me] || Me
                        })
                    }
                    this.defaults = {
                        amdBase: "./",
                        amdLanguageBase: "./i18n/",
                        closeOnSelect: !0,
                        debug: !1,
                        dropdownAutoWidth: !1,
                        escapeMarkup: C.escapeMarkup,
                        language: {},
                        matcher: function Se(Me, He) {
                            if (y.trim(Me.term) === "") return He;
                            if (He.children && 0 < He.children.length) {
                                for (var nt = y.extend(!0, {}, He), Xe = He.children.length - 1; 0 <= Xe; Xe--) Se(Me, He.children[Xe]) == null && nt.children.splice(Xe, 1);
                                return 0 < nt.children.length ? nt : Se(Me, nt)
                            }
                            var pt = R(He.text).toUpperCase(),
                                Qe = R(Me.term).toUpperCase();
                            return -1 < pt.indexOf(Qe) ? He : null
                        },
                        minimumInputLength: 0,
                        maximumInputLength: 0,
                        maximumSelectionLength: 0,
                        minimumResultsForSearch: 0,
                        selectOnClose: !1,
                        scrollAfterSelect: !1,
                        sorter: function(Se) {
                            return Se
                        },
                        templateResult: function(Se) {
                            return Se.text
                        },
                        templateSelection: function(Se) {
                            return Se.text
                        },
                        theme: "default",
                        width: "resolve"
                    }
                }, We.prototype.applyFromElement = function(R, Se) {
                    var Me = R.language,
                        He = this.defaults.language,
                        nt = Se.prop("lang"),
                        Xe = Se.closest("[lang]").prop("lang"),
                        pt = Array.prototype.concat.call(this._resolveLanguage(nt), this._resolveLanguage(Me), this._resolveLanguage(He), this._resolveLanguage(Xe));
                    return R.language = pt, R
                }, We.prototype._resolveLanguage = function(R) {
                    if (!R) return [];
                    if (y.isEmptyObject(R)) return [];
                    if (y.isPlainObject(R)) return [R];
                    var Se;
                    Se = y.isArray(R) ? R : [R];
                    for (var Me = [], He = 0; He < Se.length; He++)
                        if (Me.push(Se[He]), typeof Se[He] == "string" && 0 < Se[He].indexOf("-")) {
                            var nt = Se[He].split("-")[0];
                            Me.push(nt)
                        }
                    return Me
                }, We.prototype._processTranslations = function(R, Se) {
                    for (var Me = new q, He = 0; He < R.length; He++) {
                        var nt = new q,
                            Xe = R[He];
                        if (typeof Xe == "string") try {
                            nt = q.loadPath(Xe)
                        } catch {
                            try {
                                Xe = this.defaults.amdLanguageBase + Xe, nt = q.loadPath(Xe)
                            } catch {
                                Se && window.console && console.warn && console.warn('Select2: The language file for "' + Xe + '" could not be automatically loaded. A fallback will be used instead.')
                            }
                        } else nt = y.isPlainObject(Xe) ? new q(Xe) : Xe;
                        Me.extend(nt)
                    }
                    return Me
                }, We.prototype.set = function(R, Se) {
                    var Me = {};
                    Me[y.camelCase(R)] = Se;
                    var He = C._convertData(Me);
                    y.extend(!0, this.defaults, He)
                }, new We
            }), P.define("select2/options", ["require", "jquery", "./defaults", "./utils"], function(y, x, b, f) {
                function d(o, h) {
                    if (this.options = o, h != null && this.fromElement(h), h != null && (this.options = b.applyFromElement(this.options, h)), this.options = b.apply(this.options), h && h.is("input")) {
                        var u = y(this.get("amdBase") + "compat/inputData");
                        this.options.dataAdapter = f.Decorate(this.options.dataAdapter, u)
                    }
                }
                return d.prototype.fromElement = function(o) {
                    var h = ["select2"];
                    this.options.multiple == null && (this.options.multiple = o.prop("multiple")), this.options.disabled == null && (this.options.disabled = o.prop("disabled")), this.options.dir == null && (o.prop("dir") ? this.options.dir = o.prop("dir") : o.closest("[dir]").prop("dir") ? this.options.dir = o.closest("[dir]").prop("dir") : this.options.dir = "ltr"), o.prop("disabled", this.options.disabled), o.prop("multiple", this.options.multiple), f.GetData(o[0], "select2Tags") && (this.options.debug && window.console && console.warn && console.warn('Select2: The `data-select2-tags` attribute has been changed to use the `data-data` and `data-tags="true"` attributes and will be removed in future versions of Select2.'), f.StoreData(o[0], "data", f.GetData(o[0], "select2Tags")), f.StoreData(o[0], "tags", !0)), f.GetData(o[0], "ajaxUrl") && (this.options.debug && window.console && console.warn && console.warn("Select2: The `data-ajax-url` attribute has been changed to `data-ajax--url` and support for the old attribute will be removed in future versions of Select2."), o.attr("ajax--url", f.GetData(o[0], "ajaxUrl")), f.StoreData(o[0], "ajax-Url", f.GetData(o[0], "ajaxUrl")));
                    var u = {};

                    function w(ye, ie) {
                        return ie.toUpperCase()
                    }
                    for (var C = 0; C < o[0].attributes.length; C++) {
                        var q = o[0].attributes[C].name,
                            M = "data-";
                        if (q.substr(0, M.length) == M) {
                            var ae = q.substring(M.length),
                                ne = f.GetData(o[0], ae);
                            u[ae.replace(/-([a-z])/g, w)] = ne
                        }
                    }
                    x.fn.jquery && x.fn.jquery.substr(0, 2) == "1." && o[0].dataset && (u = x.extend(!0, {}, o[0].dataset, u));
                    var De = x.extend(!0, {}, f.GetData(o[0]), u);
                    for (var ge in De = f._convertData(De)) - 1 < x.inArray(ge, h) || (x.isPlainObject(this.options[ge]) ? x.extend(this.options[ge], De[ge]) : this.options[ge] = De[ge]);
                    return this
                }, d.prototype.get = function(o) {
                    return this.options[o]
                }, d.prototype.set = function(o, h) {
                    this.options[o] = h
                }, d
            }), P.define("select2/core", ["jquery", "./options", "./utils", "./keys"], function(y, x, b, f) {
                var d = function(o, h) {
                    b.GetData(o[0], "select2") != null && b.GetData(o[0], "select2").destroy(), this.$element = o, this.id = this._generateId(o), h = h || {}, this.options = new x(h, o), d.__super__.constructor.call(this);
                    var u = o.attr("tabindex") || 0;
                    b.StoreData(o[0], "old-tabindex", u), o.attr("tabindex", "-1");
                    var w = this.options.get("dataAdapter");
                    this.dataAdapter = new w(o, this.options);
                    var C = this.render();
                    this._placeContainer(C);
                    var q = this.options.get("selectionAdapter");
                    this.selection = new q(o, this.options), this.$selection = this.selection.render(), this.selection.position(this.$selection, C);
                    var M = this.options.get("dropdownAdapter");
                    this.dropdown = new M(o, this.options), this.$dropdown = this.dropdown.render(), this.dropdown.position(this.$dropdown, C);
                    var ae = this.options.get("resultsAdapter");
                    this.results = new ae(o, this.options, this.dataAdapter), this.$results = this.results.render(), this.results.position(this.$results, this.$dropdown);
                    var ne = this;
                    this._bindAdapters(), this._registerDomEvents(), this._registerDataEvents(), this._registerSelectionEvents(), this._registerDropdownEvents(), this._registerResultsEvents(), this._registerEvents(), this.dataAdapter.current(function(De) {
                        ne.trigger("selection:update", {
                            data: De
                        })
                    }), o.addClass("select2-hidden-accessible"), o.attr("aria-hidden", "true"), this._syncAttributes(), b.StoreData(o[0], "select2", this), o.data("select2", this)
                };
                return b.Extend(d, b.Observable), d.prototype._generateId = function(o) {
                    return "select2-" + (o.attr("id") != null ? o.attr("id") : o.attr("name") != null ? o.attr("name") + "-" + b.generateChars(2) : b.generateChars(4)).replace(/(:|\.|\[|\]|,)/g, "")
                }, d.prototype._placeContainer = function(o) {
                    o.insertAfter(this.$element);
                    var h = this._resolveWidth(this.$element, this.options.get("width"));
                    h != null && o.css("width", h)
                }, d.prototype._resolveWidth = function(o, h) {
                    var u = /^width:(([-+]?([0-9]*\.)?[0-9]+)(px|em|ex|%|in|cm|mm|pt|pc))/i;
                    if (h == "resolve") {
                        var w = this._resolveWidth(o, "style");
                        return w ? ? this._resolveWidth(o, "element")
                    }
                    if (h == "element") {
                        var C = o.outerWidth(!1);
                        return C <= 0 ? "auto" : C + "px"
                    }
                    if (h != "style") return h != "computedstyle" ? h : window.getComputedStyle(o[0]).width;
                    var q = o.attr("style");
                    if (typeof q != "string") return null;
                    for (var M = q.split(";"), ae = 0, ne = M.length; ae < ne; ae += 1) {
                        var De = M[ae].replace(/\s/g, "").match(u);
                        if (De !== null && 1 <= De.length) return De[1]
                    }
                    return null
                }, d.prototype._bindAdapters = function() {
                    this.dataAdapter.bind(this, this.$container), this.selection.bind(this, this.$container), this.dropdown.bind(this, this.$container), this.results.bind(this, this.$container)
                }, d.prototype._registerDomEvents = function() {
                    var o = this;
                    this.$element.on("change.select2", function() {
                        o.dataAdapter.current(function(u) {
                            o.trigger("selection:update", {
                                data: u
                            })
                        })
                    }), this.$element.on("focus.select2", function(u) {
                        o.trigger("focus", u)
                    }), this._syncA = b.bind(this._syncAttributes, this), this._syncS = b.bind(this._syncSubtree, this), this.$element[0].attachEvent && this.$element[0].attachEvent("onpropertychange", this._syncA);
                    var h = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
                    h != null ? (this._observer = new h(function(u) {
                        o._syncA(), o._syncS(null, u)
                    }), this._observer.observe(this.$element[0], {
                        attributes: !0,
                        childList: !0,
                        subtree: !1
                    })) : this.$element[0].addEventListener && (this.$element[0].addEventListener("DOMAttrModified", o._syncA, !1), this.$element[0].addEventListener("DOMNodeInserted", o._syncS, !1), this.$element[0].addEventListener("DOMNodeRemoved", o._syncS, !1))
                }, d.prototype._registerDataEvents = function() {
                    var o = this;
                    this.dataAdapter.on("*", function(h, u) {
                        o.trigger(h, u)
                    })
                }, d.prototype._registerSelectionEvents = function() {
                    var o = this,
                        h = ["toggle", "focus"];
                    this.selection.on("toggle", function() {
                        o.toggleDropdown()
                    }), this.selection.on("focus", function(u) {
                        o.focus(u)
                    }), this.selection.on("*", function(u, w) {
                        y.inArray(u, h) === -1 && o.trigger(u, w)
                    })
                }, d.prototype._registerDropdownEvents = function() {
                    var o = this;
                    this.dropdown.on("*", function(h, u) {
                        o.trigger(h, u)
                    })
                }, d.prototype._registerResultsEvents = function() {
                    var o = this;
                    this.results.on("*", function(h, u) {
                        o.trigger(h, u)
                    })
                }, d.prototype._registerEvents = function() {
                    var o = this;
                    this.on("open", function() {
                        o.$container.addClass("select2-container--open")
                    }), this.on("close", function() {
                        o.$container.removeClass("select2-container--open")
                    }), this.on("enable", function() {
                        o.$container.removeClass("select2-container--disabled")
                    }), this.on("disable", function() {
                        o.$container.addClass("select2-container--disabled")
                    }), this.on("blur", function() {
                        o.$container.removeClass("select2-container--focus")
                    }), this.on("query", function(h) {
                        o.isOpen() || o.trigger("open", {}), this.dataAdapter.query(h, function(u) {
                            o.trigger("results:all", {
                                data: u,
                                query: h
                            })
                        })
                    }), this.on("query:append", function(h) {
                        this.dataAdapter.query(h, function(u) {
                            o.trigger("results:append", {
                                data: u,
                                query: h
                            })
                        })
                    }), this.on("keypress", function(h) {
                        var u = h.which;
                        o.isOpen() ? u === f.ESC || u === f.TAB || u === f.UP && h.altKey ? (o.close(h), h.preventDefault()) : u === f.ENTER ? (o.trigger("results:select", {}), h.preventDefault()) : u === f.SPACE && h.ctrlKey ? (o.trigger("results:toggle", {}), h.preventDefault()) : u === f.UP ? (o.trigger("results:previous", {}), h.preventDefault()) : u === f.DOWN && (o.trigger("results:next", {}), h.preventDefault()) : (u === f.ENTER || u === f.SPACE || u === f.DOWN && h.altKey) && (o.open(), h.preventDefault())
                    })
                }, d.prototype._syncAttributes = function() {
                    this.options.set("disabled", this.$element.prop("disabled")), this.isDisabled() ? (this.isOpen() && this.close(), this.trigger("disable", {})) : this.trigger("enable", {})
                }, d.prototype._isChangeMutation = function(o, h) {
                    var u = !1,
                        w = this;
                    if (!o || !o.target || o.target.nodeName === "OPTION" || o.target.nodeName === "OPTGROUP") {
                        if (h)
                            if (h.addedNodes && 0 < h.addedNodes.length)
                                for (var C = 0; C < h.addedNodes.length; C++) h.addedNodes[C].selected && (u = !0);
                            else h.removedNodes && 0 < h.removedNodes.length ? u = !0 : y.isArray(h) && y.each(h, function(q, M) {
                                if (w._isChangeMutation(q, M)) return !(u = !0)
                            });
                        else u = !0;
                        return u
                    }
                }, d.prototype._syncSubtree = function(o, h) {
                    var u = this._isChangeMutation(o, h),
                        w = this;
                    u && this.dataAdapter.current(function(C) {
                        w.trigger("selection:update", {
                            data: C
                        })
                    })
                }, d.prototype.trigger = function(o, h) {
                    var u = d.__super__.trigger,
                        w = {
                            open: "opening",
                            close: "closing",
                            select: "selecting",
                            unselect: "unselecting",
                            clear: "clearing"
                        };
                    if (h === void 0 && (h = {}), o in w) {
                        var C = w[o],
                            q = {
                                prevented: !1,
                                name: o,
                                args: h
                            };
                        if (u.call(this, C, q), q.prevented) return void(h.prevented = !0)
                    }
                    u.call(this, o, h)
                }, d.prototype.toggleDropdown = function() {
                    this.isDisabled() || (this.isOpen() ? this.close() : this.open())
                }, d.prototype.open = function() {
                    this.isOpen() || this.isDisabled() || this.trigger("query", {})
                }, d.prototype.close = function(o) {
                    this.isOpen() && this.trigger("close", {
                        originalEvent: o
                    })
                }, d.prototype.isEnabled = function() {
                    return !this.isDisabled()
                }, d.prototype.isDisabled = function() {
                    return this.options.get("disabled")
                }, d.prototype.isOpen = function() {
                    return this.$container.hasClass("select2-container--open")
                }, d.prototype.hasFocus = function() {
                    return this.$container.hasClass("select2-container--focus")
                }, d.prototype.focus = function(o) {
                    this.hasFocus() || (this.$container.addClass("select2-container--focus"), this.trigger("focus", {}))
                }, d.prototype.enable = function(o) {
                    this.options.get("debug") && window.console && console.warn && console.warn('Select2: The `select2("enable")` method has been deprecated and will be removed in later Select2 versions. Use $element.prop("disabled") instead.'), o != null && o.length !== 0 || (o = [!0]);
                    var h = !o[0];
                    this.$element.prop("disabled", h)
                }, d.prototype.data = function() {
                    this.options.get("debug") && 0 < arguments.length && window.console && console.warn && console.warn('Select2: Data can no longer be set using `select2("data")`. You should consider setting the value instead using `$element.val()`.');
                    var o = [];
                    return this.dataAdapter.current(function(h) {
                        o = h
                    }), o
                }, d.prototype.val = function(o) {
                    if (this.options.get("debug") && window.console && console.warn && console.warn('Select2: The `select2("val")` method has been deprecated and will be removed in later Select2 versions. Use $element.val() instead.'), o == null || o.length === 0) return this.$element.val();
                    var h = o[0];
                    y.isArray(h) && (h = y.map(h, function(u) {
                        return u.toString()
                    })), this.$element.val(h).trigger("input").trigger("change")
                }, d.prototype.destroy = function() {
                    this.$container.remove(), this.$element[0].detachEvent && this.$element[0].detachEvent("onpropertychange", this._syncA), this._observer != null ? (this._observer.disconnect(), this._observer = null) : this.$element[0].removeEventListener && (this.$element[0].removeEventListener("DOMAttrModified", this._syncA, !1), this.$element[0].removeEventListener("DOMNodeInserted", this._syncS, !1), this.$element[0].removeEventListener("DOMNodeRemoved", this._syncS, !1)), this._syncA = null, this._syncS = null, this.$element.off(".select2"), this.$element.attr("tabindex", b.GetData(this.$element[0], "old-tabindex")), this.$element.removeClass("select2-hidden-accessible"), this.$element.attr("aria-hidden", "false"), b.RemoveData(this.$element[0]), this.$element.removeData("select2"), this.dataAdapter.destroy(), this.selection.destroy(), this.dropdown.destroy(), this.results.destroy(), this.dataAdapter = null, this.selection = null, this.dropdown = null, this.results = null
                }, d.prototype.render = function() {
                    var o = y('<span class="select2 select2-container"><span class="selection"></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>');
                    return o.attr("dir", this.options.get("dir")), this.$container = o, this.$container.addClass("select2-container--" + this.options.get("theme")), b.StoreData(o[0], "element", this.$element), o
                }, d
            }), P.define("select2/compat/utils", ["jquery"], function(y) {
                return {
                    syncCssClasses: function(x, b, f) {
                        var d, o, h = [];
                        (d = y.trim(x.attr("class"))) && y((d = "" + d).split(/\s+/)).each(function() {
                            this.indexOf("select2-") === 0 && h.push(this)
                        }), (d = y.trim(b.attr("class"))) && y((d = "" + d).split(/\s+/)).each(function() {
                            this.indexOf("select2-") !== 0 && (o = f(this)) != null && h.push(o)
                        }), x.attr("class", h.join(" "))
                    }
                }
            }), P.define("select2/compat/containerCss", ["jquery", "./utils"], function(y, x) {
                function b(d) {
                    return null
                }

                function f() {}
                return f.prototype.render = function(d) {
                    var o = d.call(this),
                        h = this.options.get("containerCssClass") || "";
                    y.isFunction(h) && (h = h(this.$element));
                    var u = this.options.get("adaptContainerCssClass");
                    if (u = u || b, h.indexOf(":all:") !== -1) {
                        h = h.replace(":all:", "");
                        var w = u;
                        u = function(q) {
                            var M = w(q);
                            return M != null ? M + " " + q : q
                        }
                    }
                    var C = this.options.get("containerCss") || {};
                    return y.isFunction(C) && (C = C(this.$element)), x.syncCssClasses(o, this.$element, u), o.css(C), o.addClass(h), o
                }, f
            }), P.define("select2/compat/dropdownCss", ["jquery", "./utils"], function(y, x) {
                function b(d) {
                    return null
                }

                function f() {}
                return f.prototype.render = function(d) {
                    var o = d.call(this),
                        h = this.options.get("dropdownCssClass") || "";
                    y.isFunction(h) && (h = h(this.$element));
                    var u = this.options.get("adaptDropdownCssClass");
                    if (u = u || b, h.indexOf(":all:") !== -1) {
                        h = h.replace(":all:", "");
                        var w = u;
                        u = function(q) {
                            var M = w(q);
                            return M != null ? M + " " + q : q
                        }
                    }
                    var C = this.options.get("dropdownCss") || {};
                    return y.isFunction(C) && (C = C(this.$element)), x.syncCssClasses(o, this.$element, u), o.css(C), o.addClass(h), o
                }, f
            }), P.define("select2/compat/initSelection", ["jquery"], function(y) {
                function x(b, f, d) {
                    d.get("debug") && window.console && console.warn && console.warn("Select2: The `initSelection` option has been deprecated in favor of a custom data adapter that overrides the `current` method. This method is now called multiple times instead of a single time when the instance is initialized. Support will be removed for the `initSelection` option in future versions of Select2"), this.initSelection = d.get("initSelection"), this._isInitialized = !1, b.call(this, f, d)
                }
                return x.prototype.current = function(b, f) {
                    var d = this;
                    this._isInitialized ? b.call(this, f) : this.initSelection.call(null, this.$element, function(o) {
                        d._isInitialized = !0, y.isArray(o) || (o = [o]), f(o)
                    })
                }, x
            }), P.define("select2/compat/inputData", ["jquery", "../utils"], function(y, x) {
                function b(f, d, o) {
                    this._currentData = [], this._valueSeparator = o.get("valueSeparator") || ",", d.prop("type") === "hidden" && o.get("debug") && console && console.warn && console.warn("Select2: Using a hidden input with Select2 is no longer supported and may stop working in the future. It is recommended to use a `<select>` element instead."), f.call(this, d, o)
                }
                return b.prototype.current = function(f, d) {
                    function o(C, q) {
                        var M = [];
                        return C.selected || y.inArray(C.id, q) !== -1 ? (C.selected = !0, M.push(C)) : C.selected = !1, C.children && M.push.apply(M, o(C.children, q)), M
                    }
                    for (var h = [], u = 0; u < this._currentData.length; u++) {
                        var w = this._currentData[u];
                        h.push.apply(h, o(w, this.$element.val().split(this._valueSeparator)))
                    }
                    d(h)
                }, b.prototype.select = function(f, d) {
                    if (this.options.get("multiple")) {
                        var o = this.$element.val();
                        o += this._valueSeparator + d.id, this.$element.val(o), this.$element.trigger("input").trigger("change")
                    } else this.current(function(h) {
                        y.map(h, function(u) {
                            u.selected = !1
                        })
                    }), this.$element.val(d.id), this.$element.trigger("input").trigger("change")
                }, b.prototype.unselect = function(f, d) {
                    var o = this;
                    d.selected = !1, this.current(function(h) {
                        for (var u = [], w = 0; w < h.length; w++) {
                            var C = h[w];
                            d.id != C.id && u.push(C.id)
                        }
                        o.$element.val(u.join(o._valueSeparator)), o.$element.trigger("input").trigger("change")
                    })
                }, b.prototype.query = function(f, d, o) {
                    for (var h = [], u = 0; u < this._currentData.length; u++) {
                        var w = this._currentData[u],
                            C = this.matches(d, w);
                        C !== null && h.push(C)
                    }
                    o({
                        results: h
                    })
                }, b.prototype.addOptions = function(f, d) {
                    var o = y.map(d, function(h) {
                        return x.GetData(h[0], "data")
                    });
                    this._currentData.push.apply(this._currentData, o)
                }, b
            }), P.define("select2/compat/matcher", ["jquery"], function(y) {
                return function(x) {
                    return function(b, f) {
                        var d = y.extend(!0, {}, f);
                        if (b.term == null || y.trim(b.term) === "") return d;
                        if (f.children) {
                            for (var o = f.children.length - 1; 0 <= o; o--) {
                                var h = f.children[o];
                                x(b.term, h.text, h) || d.children.splice(o, 1)
                            }
                            if (0 < d.children.length) return d
                        }
                        return x(b.term, f.text, f) ? d : null
                    }
                }
            }), P.define("select2/compat/query", [], function() {
                function y(x, b, f) {
                    f.get("debug") && window.console && console.warn && console.warn("Select2: The `query` option has been deprecated in favor of a custom data adapter that overrides the `query` method. Support will be removed for the `query` option in future versions of Select2."), x.call(this, b, f)
                }
                return y.prototype.query = function(x, b, f) {
                    b.callback = f, this.options.get("query").call(null, b)
                }, y
            }), P.define("select2/dropdown/attachContainer", [], function() {
                function y(x, b, f) {
                    x.call(this, b, f)
                }
                return y.prototype.position = function(x, b, f) {
                    f.find(".dropdown-wrapper").append(b), b.addClass("select2-dropdown--below"), f.addClass("select2-container--below")
                }, y
            }), P.define("select2/dropdown/stopPropagation", [], function() {
                function y() {}
                return y.prototype.bind = function(x, b, f) {
                    x.call(this, b, f), this.$dropdown.on(["blur", "change", "click", "dblclick", "focus", "focusin", "focusout", "input", "keydown", "keyup", "keypress", "mousedown", "mouseenter", "mouseleave", "mousemove", "mouseover", "mouseup", "search", "touchend", "touchstart"].join(" "), function(d) {
                        d.stopPropagation()
                    })
                }, y
            }), P.define("select2/selection/stopPropagation", [], function() {
                function y() {}
                return y.prototype.bind = function(x, b, f) {
                    x.call(this, b, f), this.$selection.on(["blur", "change", "click", "dblclick", "focus", "focusin", "focusout", "input", "keydown", "keyup", "keypress", "mousedown", "mouseenter", "mouseleave", "mousemove", "mouseover", "mouseup", "search", "touchend", "touchstart"].join(" "), function(d) {
                        d.stopPropagation()
                    })
                }, y
            }), at = function(y) {
                var x, b, f = ["wheel", "mousewheel", "DOMMouseScroll", "MozMousePixelScroll"],
                    d = "onwheel" in document || 9 <= document.documentMode ? ["wheel"] : ["mousewheel", "DomMouseScroll", "MozMousePixelScroll"],
                    o = Array.prototype.slice;
                if (y.event.fixHooks)
                    for (var h = f.length; h;) y.event.fixHooks[f[--h]] = y.event.mouseHooks;
                var u = y.event.special.mousewheel = {
                    version: "3.1.12",
                    setup: function() {
                        if (this.addEventListener)
                            for (var M = d.length; M;) this.addEventListener(d[--M], w, !1);
                        else this.onmousewheel = w;
                        y.data(this, "mousewheel-line-height", u.getLineHeight(this)), y.data(this, "mousewheel-page-height", u.getPageHeight(this))
                    },
                    teardown: function() {
                        if (this.removeEventListener)
                            for (var M = d.length; M;) this.removeEventListener(d[--M], w, !1);
                        else this.onmousewheel = null;
                        y.removeData(this, "mousewheel-line-height"), y.removeData(this, "mousewheel-page-height")
                    },
                    getLineHeight: function(M) {
                        var ae = y(M),
                            ne = ae["offsetParent" in y.fn ? "offsetParent" : "parent"]();
                        return ne.length || (ne = y("body")), parseInt(ne.css("fontSize"), 10) || parseInt(ae.css("fontSize"), 10) || 16
                    },
                    getPageHeight: function(M) {
                        return y(M).height()
                    },
                    settings: {
                        adjustOldDeltas: !0,
                        normalizeOffset: !0
                    }
                };

                function w(M) {
                    var ae, ne = M || window.event,
                        De = o.call(arguments, 1),
                        ge = 0,
                        ye = 0,
                        ie = 0,
                        Ht = 0,
                        mt = 0;
                    if ((M = y.event.fix(ne)).type = "mousewheel", "detail" in ne && (ie = -1 * ne.detail), "wheelDelta" in ne && (ie = ne.wheelDelta), "wheelDeltaY" in ne && (ie = ne.wheelDeltaY), "wheelDeltaX" in ne && (ye = -1 * ne.wheelDeltaX), "axis" in ne && ne.axis === ne.HORIZONTAL_AXIS && (ye = -1 * ie, ie = 0), ge = ie === 0 ? ye : ie, "deltaY" in ne && (ge = ie = -1 * ne.deltaY), "deltaX" in ne && (ye = ne.deltaX, ie === 0 && (ge = -1 * ye)), ie !== 0 || ye !== 0) {
                        if (ne.deltaMode === 1) {
                            var lt = y.data(this, "mousewheel-line-height");
                            ge *= lt, ie *= lt, ye *= lt
                        } else if (ne.deltaMode === 2) {
                            var ut = y.data(this, "mousewheel-page-height");
                            ge *= ut, ie *= ut, ye *= ut
                        }
                        if (ae = Math.max(Math.abs(ie), Math.abs(ye)), (!b || ae < b) && q(ne, b = ae) && (b /= 40), q(ne, ae) && (ge /= 40, ye /= 40, ie /= 40), ge = Math[1 <= ge ? "floor" : "ceil"](ge / b), ye = Math[1 <= ye ? "floor" : "ceil"](ye / b), ie = Math[1 <= ie ? "floor" : "ceil"](ie / b), u.settings.normalizeOffset && this.getBoundingClientRect) {
                            var he = this.getBoundingClientRect();
                            Ht = M.clientX - he.left, mt = M.clientY - he.top
                        }
                        return M.deltaX = ye, M.deltaY = ie, M.deltaFactor = b, M.offsetX = Ht, M.offsetY = mt, M.deltaMode = 0, De.unshift(M, ge, ye, ie), x && clearTimeout(x), x = setTimeout(C, 200), (y.event.dispatch || y.event.handle).apply(this, De)
                    }
                }

                function C() {
                    b = null
                }

                function q(M, ae) {
                    return u.settings.adjustOldDeltas && M.type === "mousewheel" && ae % 120 == 0
                }
                y.fn.extend({
                    mousewheel: function(M) {
                        return M ? this.bind("mousewheel", M) : this.trigger("mousewheel")
                    },
                    unmousewheel: function(M) {
                        return this.unbind("mousewheel", M)
                    }
                })
            }, typeof P.define == "function" && P.define.amd ? P.define("jquery-mousewheel", ["jquery"], at) : typeof exports == "object" ? module.exports = at : at(D), P.define("jquery.select2", ["jquery", "jquery-mousewheel", "./select2/core", "./select2/defaults", "./select2/utils"], function(y, x, b, f, d) {
                if (y.fn.select2 == null) {
                    var o = ["open", "close", "destroy"];
                    y.fn.select2 = function(h) {
                        if (typeof(h = h || {}) == "object") return this.each(function() {
                            var C = y.extend(!0, {}, h);
                            new b(y(this), C)
                        }), this;
                        if (typeof h != "string") throw new Error("Invalid arguments for Select2: " + h);
                        var u, w = Array.prototype.slice.call(arguments, 1);
                        return this.each(function() {
                            var C = d.GetData(this, "select2");
                            C == null && window.console && console.error && console.error("The select2('" + h + "') method was called on an element that is not using Select2."), u = C[h].apply(C, w)
                        }), -1 < y.inArray(h, o) ? this : u
                    }
                }
                return y.fn.select2.defaults == null && (y.fn.select2.defaults = f), b
            }), {
                define: P.define,
                require: P.require
            }
        }(),
        O = L.require("jquery.select2");
    return D.fn.select2.amd = L, O
});
async function Ps(D, L) {
    var O;
    if ((O = L.error) != null && O.message.includes("Not Found")) {
        Kt.navigateTo("/404");
        return
    }
    if (!D || Ms(D.authData)) {
        const {
            pathname: P
        } = window.location;
        qs(P) || await Kt.navigateTo("/sessao-expirada")
    }
}

function qs(D) {
    let L = D.replace(/\/+$/, "");
    return L === "" && (L = "/"), Xr.some(O => {
        if (O.includes("[") && O.includes("]")) {
            const P = O.split("/[")[0];
            return L.startsWith(`${P}/`)
        }
        return L === O
    })
}

function Ms(D) {
    const L = new Date,
        O = new Date(D.refreshTokenExpInSecs * 1e3);
    return L > O
}

function Hs(D, {
    from: L,
    to: O
}, P = {}) {
    const H = getComputedStyle(D),
        U = H.transform === "none" ? "" : H.transform,
        [J, B] = H.transformOrigin.split(" ").map(parseFloat),
        V = L.left + L.width * J / O.width - (O.left + J),
        ue = L.top + L.height * B / O.height - (O.top + B),
        {
            delay: qe = 0,
            duration: be = oe => Math.sqrt(oe) * 120,
            easing: de = bs
        } = P;
    return {
        delay: qe,
        duration: ns(be) ? be(Math.sqrt(V * V + ue * ue)) : be,
        easing: de,
        css: (oe, Y) => {
            const fe = Y * V,
                se = Y * ue,
                Ve = oe + Y * L.width / O.width,
                gt = oe + Y * L.height / O.height;
            return `transform: ${U} translate(${fe}px, ${se}px) scale(${Ve}, ${gt});`
        }
    }
}

function qr(D) {
    return Object.prototype.toString.call(D) === "[object Date]"
}

function gr(D, L) {
    if (D === L || D !== D) return () => D;
    const O = typeof D;
    if (O !== typeof L || Array.isArray(D) !== Array.isArray(L)) throw new Error("Cannot interpolate values of different type");
    if (Array.isArray(D)) {
        const P = L.map((H, U) => gr(D[U], H));
        return H => P.map(U => U(H))
    }
    if (O === "object") {
        if (!D || !L) throw new Error("Object cannot be null");
        if (qr(D) && qr(L)) {
            D = D.getTime(), L = L.getTime();
            const U = L - D;
            return J => new Date(D + J * U)
        }
        const P = Object.keys(L),
            H = {};
        return P.forEach(U => {
            H[U] = gr(D[U], L[U])
        }), U => {
            const J = {};
            return P.forEach(B => {
                J[B] = H[B](U)
            }), J
        }
    }
    if (O === "number") {
        const P = L - D;
        return H => D + H * P
    }
    throw new Error(`Cannot interpolate ${O} values`)
}

function Rs(D, L = {}) {
    const O = Es(D);
    let P, H = D;

    function U(J, B) {
        if (D == null) return O.set(D = J), Promise.resolve();
        H = J;
        let V = P,
            ue = !1,
            {
                delay: qe = 0,
                duration: be = 400,
                easing: de = vr,
                interpolate: oe = gr
            } = Fi(Fi({}, L), B);
        if (be === 0) return V && (V.abort(), V = null), O.set(D = H), Promise.resolve();
        const Y = Gr() + qe;
        let fe;
        return P = Vr(se => {
            if (se < Y) return !0;
            ue || (fe = oe(D, J), typeof be == "function" && (be = be(D, J)), ue = !0), V && (V.abort(), V = null);
            const Ve = se - Y;
            return Ve > be ? (O.set(D = J), !1) : (O.set(D = fe(de(Ve / be))), !0)
        }), P.promise
    }
    return {
        set: U,
        update: (J, B) => U(J(H, D), B),
        subscribe: O.subscribe
    }
}

function Bs(D) {
    let L, O = D[0].msg + "",
        P;
    return {
        c() {
            L = new ss(!1), P = Ki(), this.h()
        },
        l(H) {
            L = rs(H, !1), P = Ki(), this.h()
        },
        h() {
            L.a = P
        },
        m(H, U) {
            L.m(O, H, U), gn(H, P, U)
        },
        p(H, U) {
            U & 1 && O !== (O = H[0].msg + "") && L.p(O)
        },
        i: $n,
        o: $n,
        d(H) {
            H && (Ct(P), L.d())
        }
    }
}

function zs(D) {
    let L, O, P;
    const H = [D[2]];
    var U = D[0].component.src;

    function J(B, V) {
        let ue = {};
        for (let qe = 0; qe < H.length; qe += 1) ue = Fi(ue, H[qe]);
        return V !== void 0 && V & 4 && (ue = Fi(ue, Ir(H, [Pr(B[2])]))), {
            props: ue
        }
    }
    return U && (L = Dr(U, J(D))), {
        c() {
            L && Qi(L.$$.fragment), O = Ki()
        },
        l(B) {
            L && Er(L.$$.fragment, B), O = Ki()
        },
        m(B, V) {
            L && Zi(L, B, V), gn(B, O, V), P = !0
        },
        p(B, V) {
            if (V & 1 && U !== (U = B[0].component.src)) {
                if (L) {
                    wr();
                    const ue = L;
                    mn(ue.$$.fragment, 1, 0, () => {
                        Xi(ue, 1)
                    }), xr()
                }
                U ? (L = Dr(U, J(B, V)), Qi(L.$$.fragment), vn(L.$$.fragment, 1), Zi(L, O.parentNode, O)) : L = null
            } else if (U) {
                const ue = V & 4 ? Ir(H, [Pr(B[2])]) : {};
                L.$set(ue)
            }
        },
        i(B) {
            P || (L && vn(L.$$.fragment, B), P = !0)
        },
        o(B) {
            L && mn(L.$$.fragment, B), P = !1
        },
        d(B) {
            B && Ct(O), L && Xi(L, B)
        }
    }
}

function Mr(D) {
    let L, O, P;
    return {
        c() {
            L = In("div"), this.h()
        },
        l(H) {
            L = jn(H, "DIV", {
                class: !0,
                role: !0,
                tabindex: !0
            }), Nn(L).forEach(Ct), this.h()
        },
        h() {
            Nt(L, "class", "_toastBtn pe svelte-l65oht"), Nt(L, "role", "button"), Nt(L, "tabindex", "0")
        },
        m(H, U) {
            gn(H, L, U), O || (P = [Gi(L, "click", D[8]), Gi(L, "keydown", D[9])], O = !0)
        },
        p: $n,
        d(H) {
            H && Ct(L), O = !1, Ur(P)
        }
    }
}

function Ws(D) {
    let L, O, P, H, U, J, B, V, ue, qe;
    const be = [zs, Bs],
        de = [];

    function oe(fe, se) {
        return fe[0].component ? 0 : 1
    }
    P = oe(D), H = de[P] = be[P](D);
    let Y = D[0].dismissable && Mr(D);
    return {
        c() {
            L = In("div"), O = In("div"), H.c(), U = Yi(), Y && Y.c(), J = Yi(), B = In("progress"), this.h()
        },
        l(fe) {
            L = jn(fe, "DIV", {
                role: !0,
                class: !0
            });
            var se = Nn(L);
            O = jn(se, "DIV", {
                class: !0
            });
            var Ve = Nn(O);
            H.l(Ve), Ve.forEach(Ct), U = Vi(se), Y && Y.l(se), J = Vi(se), B = jn(se, "PROGRESS", {
                class: !0
            }), Nn(B).forEach(Ct), se.forEach(Ct), this.h()
        },
        h() {
            Nt(O, "class", "_toastMsg svelte-l65oht"), Wi(O, "pe", D[0].component), Nt(B, "class", "_toastBar svelte-l65oht"), B.value = D[1], Nt(L, "role", "status"), Nt(L, "class", "_toastItem svelte-l65oht"), Wi(L, "pe", D[0].pausable)
        },
        m(fe, se) {
            gn(fe, L, se), yi(L, O), de[P].m(O, null), yi(L, U), Y && Y.m(L, null), yi(L, J), yi(L, B), V = !0, ue || (qe = [Gi(L, "mouseenter", D[10]), Gi(L, "mouseleave", D[6])], ue = !0)
        },
        p(fe, [se]) {
            let Ve = P;
            P = oe(fe), P === Ve ? de[P].p(fe, se) : (wr(), mn(de[Ve], 1, 1, () => {
                de[Ve] = null
            }), xr(), H = de[P], H ? H.p(fe, se) : (H = de[P] = be[P](fe), H.c()), vn(H, 1), H.m(O, null)), (!V || se & 1) && Wi(O, "pe", fe[0].component), fe[0].dismissable ? Y ? Y.p(fe, se) : (Y = Mr(fe), Y.c(), Y.m(L, J)) : Y && (Y.d(1), Y = null), (!V || se & 2) && (B.value = fe[1]), (!V || se & 1) && Wi(L, "pe", fe[0].pausable)
        },
        i(fe) {
            V || (vn(H), V = !0)
        },
        o(fe) {
            mn(H), V = !1
        },
        d(fe) {
            fe && Ct(L), de[P].d(), Y && Y.d(), ue = !1, Ur(qe)
        }
    }
}

function Hr(D, L = "undefined") {
    return typeof D === L
}

function Us(D, L, O) {
    let P, {
            item: H
        } = L,
        U = H.initial,
        J = U,
        B = !1,
        V = {},
        ue, qe;
    const be = Rs(H.initial, {
        duration: H.duration,
        easing: vr
    });
    fn(D, be, Pe => O(1, P = Pe));

    function de(Pe) {
        Pe && (qe = Pe), fr.pop(H.id)
    }

    function oe() {
        (P === 1 || P === 0) && de()
    }

    function Y() {
        !B && P !== U && (be.set(P, {
            duration: 0
        }), B = !0)
    }

    function fe() {
        if (B) {
            const Pe = H.duration,
                a = Pe - Pe * ((P - J) / (U - J));
            be.set(U, {
                duration: a
            }).then(oe), B = !1
        }
    }

    function se(Pe = document) {
        if (Hr(Pe.hidden)) return;
        const a = () => Pe.hidden ? Y() : fe(),
            xt = "visibilitychange";
        Pe.addEventListener(xt, a), ue = () => Pe.removeEventListener(xt, a), a()
    }
    Fr(se), is(() => {
        H.onpop && H.onpop(H.id, {
            event: qe
        }), ue && ue()
    });
    const Ve = Pe => de(Pe),
        gt = Pe => {
            Pe instanceof KeyboardEvent && ["Enter", " "].includes(Pe.key) && de(Pe)
        },
        at = () => {
            H.pausable && Y()
        };
    return D.$$set = Pe => {
        "item" in Pe && O(0, H = Pe.item)
    }, D.$$.update = () => {
        if (D.$$.dirty & 1 && (Hr(H.progress) || O(0, H.next = H.progress, H)), D.$$.dirty & 131 && U !== H.next && (O(7, U = H.next), J = P, B = !1, be.set(U).then(oe)), D.$$.dirty & 1 && H.component) {
            const {
                props: Pe = {},
                sendIdTo: a
            } = H.component;
            O(2, V = { ...Pe,
                ...a && {
                    [a]: H.id
                }
            })
        }
    }, [H, P, V, be, de, Y, fe, U, Ve, gt, at]
}
class Fs extends br {
    constructor(L) {
        super(), _r(this, L, Us, Ws, yr, {
            item: 0
        })
    }
}

function Rr(D, L, O) {
    const P = D.slice();
    return P[4] = L[O], P
}

function Br(D, L) {
    let O, P, H, U, J, B, V, ue, qe = $n,
        be;
    return P = new Fs({
        props: {
            item: L[4]
        }
    }), {
        key: D,
        first: null,
        c() {
            O = In("li"), Qi(P.$$.fragment), H = Yi(), this.h()
        },
        l(de) {
            O = jn(de, "LI", {
                class: !0,
                style: !0
            });
            var oe = Nn(O);
            Er(P.$$.fragment, oe), H = Vi(oe), oe.forEach(Ct), this.h()
        },
        h() {
            var de;
            Nt(O, "class", U = Or((de = L[4].classes) == null ? void 0 : de.join(" ")) + " svelte-yh90az"), Nt(O, "style", J = zr(L[4].theme)), this.first = O
        },
        m(de, oe) {
            gn(de, O, oe), Zi(P, O, null), yi(O, H), be = !0
        },
        p(de, oe) {
            var fe;
            L = de;
            const Y = {};
            oe & 1 && (Y.item = L[4]), P.$set(Y), (!be || oe & 1 && U !== (U = Or((fe = L[4].classes) == null ? void 0 : fe.join(" ")) + " svelte-yh90az")) && Nt(O, "class", U), (!be || oe & 1 && J !== (J = zr(L[4].theme))) && Nt(O, "style", J)
        },
        r() {
            ue = O.getBoundingClientRect()
        },
        f() {
            $s(O), qe(), Kr(O, ue)
        },
        a() {
            qe(), qe = Ls(O, ue, Hs, {
                duration: 200
            })
        },
        i(de) {
            be || (vn(P.$$.fragment, de), de && os(() => {
                be && (V && V.end(1), B = fs(O, _s, L[4].intro), B.start())
            }), be = !0)
        },
        o(de) {
            mn(P.$$.fragment, de), B && B.invalidate(), de && (V = ps(O, ws, {})), be = !1
        },
        d(de) {
            de && Ct(O), Xi(P), de && V && V.end()
        }
    }
}

function Gs(D) {
    let L, O = [],
        P = new Map,
        H, U = Lr(D[0]);
    const J = B => B[4].id;
    for (let B = 0; B < U.length; B += 1) {
        let V = Rr(D, U, B),
            ue = J(V);
        P.set(ue, O[B] = Br(ue, V))
    }
    return {
        c() {
            L = In("ul");
            for (let B = 0; B < O.length; B += 1) O[B].c();
            this.h()
        },
        l(B) {
            L = jn(B, "UL", {
                class: !0
            });
            var V = Nn(L);
            for (let ue = 0; ue < O.length; ue += 1) O[ue].l(V);
            V.forEach(Ct), this.h()
        },
        h() {
            Nt(L, "class", "_toastContainer svelte-yh90az")
        },
        m(B, V) {
            gn(B, L, V);
            for (let ue = 0; ue < O.length; ue += 1) O[ue] && O[ue].m(L, null);
            H = !0
        },
        p(B, [V]) {
            if (V & 1) {
                U = Lr(B[0]), wr();
                for (let ue = 0; ue < O.length; ue += 1) O[ue].r();
                O = vs(O, V, J, 1, B, U, P, L, ys, Br, null, Rr);
                for (let ue = 0; ue < O.length; ue += 1) O[ue].a();
                xr()
            }
        },
        i(B) {
            if (!H) {
                for (let V = 0; V < U.length; V += 1) vn(O[V]);
                H = !0
            }
        },
        o(B) {
            for (let V = 0; V < O.length; V += 1) mn(O[V]);
            H = !1
        },
        d(B) {
            B && Ct(L);
            for (let V = 0; V < O.length; V += 1) O[V].d()
        }
    }
}

function zr(D) {
    return D ? Object.keys(D).reduce((L, O) => `${L}${O}:${D[O]};`, "") : void 0
}

function Vs(D, L, O) {
    let P;
    fn(D, fr, B => O(3, P = B));
    let {
        options: H = {}
    } = L, {
        target: U = "default"
    } = L, J = [];
    return D.$$set = B => {
        "options" in B && O(1, H = B.options), "target" in B && O(2, U = B.target)
    }, D.$$.update = () => {
        D.$$.dirty & 6 && fr._init(U, H), D.$$.dirty & 12 && O(0, J = P.filter(B => B.target === U))
    }, [J, H, U, P]
}
class Ys extends br {
    constructor(L) {
        super(), _r(this, L, Vs, Gs, yr, {
            options: 1,
            target: 2
        })
    }
}
const Wt = class Wt {
    static init(L) {
        document.addEventListener("keydown", O => {
            (O.key === "Shift" || O.shiftKey) && (console.log("shift down"), Wt._isShiftBeingPressed = !0)
        }), document.addEventListener("keyup", O => {
            (O.key === "Shift" || O.shiftKey) && (console.log("shift up"), Wt._isShiftBeingPressed = !1)
        }), L != null && L.removeTextSelectionOnShift && Wt._removeTextSelectionOnShift(), Wt._isInitialized = !0
    }
    static _assertInitialized() {
        if (!Wt._isInitialized) throw new Error("KeyHandler is not initialized")
    }
    static get isShiftBeingPressed() {
        return Wt._assertInitialized(), Wt._isShiftBeingPressed
    }
    static _removeTextSelectionOnShift() {
        ["keyup", "keydown"].forEach(L => {
            window.addEventListener(L, O => {
                document.onselectstart = function() {
                    return !(O.key === "Shift" && O.shiftKey)
                }
            })
        })
    }
};
pr(Wt, "_isInitialized", !1), pr(Wt, "_isShiftBeingPressed", !1);
let mr = Wt;
class Ks {
    static async execute(L) {
        var H;
        const O = await Yr.get("/dashboards/actives", {
            token: ((H = L.authData) == null ? void 0 : H.token) ? ? ""
        });
        return O.statusCode === 200 ? {
            status: "SUCCESS",
            data: O.data
        } : O.statusCode === 401 ? {
            status: "UNAUTHORIZED"
        } : {
            status: "UNKNOWN"
        }
    }
}
class Xs {
    static async execute(L) {
        var P;
        const O = await Yr.get("/users/prize-info", {
            token: ((P = L.authData) == null ? void 0 : P.token) ? ? ""
        });
        return O.statusCode === 401 ? {
            status: "UNAUTHORIZED"
        } : O.statusCode === 200 ? {
            status: "SUCCESS",
            data: O.data.prizeInfo ? ? void 0
        } : {
            status: "UNKNOWN"
        }
    }
}

function Qs(D) {
    let L, O, P, H;
    O = new Ys({
        props: {
            options: D[0]
        }
    });
    const U = D[3].default,
        J = as(U, D, D[2], null);
    return {
        c() {
            L = In("div"), Qi(O.$$.fragment), P = Yi(), J && J.c(), this.h()
        },
        l(B) {
            L = jn(B, "DIV", {
                class: !0
            });
            var V = Nn(L);
            Er(O.$$.fragment, V), V.forEach(Ct), P = Vi(B), J && J.l(B), this.h()
        },
        h() {
            Nt(L, "class", "wrap svelte-1qii328")
        },
        m(B, V) {
            gn(B, L, V), Zi(O, L, null), gn(B, P, V), J && J.m(B, V), H = !0
        },
        p(B, [V]) {
            J && J.p && (!H || V & 4) && ls(J, U, B, B[2], H ? us(U, B[2], V, null) : cs(B[2]), null)
        },
        i(B) {
            H || (vn(O.$$.fragment, B), vn(J, B), H = !0)
        },
        o(B) {
            mn(O.$$.fragment, B), mn(J, B), H = !1
        },
        d(B) {
            B && (Ct(L), Ct(P)), Xi(O), J && J.d(B)
        }
    }
}
const Wr = "/primeira-assinatura/";

function Zs() {
    return (typeof crypto < "u" && crypto.getRandomValues ? crypto.getRandomValues(new Uint32Array(1))[0] / 4294967296 : Math.random()) < .5 ? "pv2_video1" : "pv2_video2"
}

function Js(D, L, O) {
    let P, H, U, J, B, V;
    fn(D, jr, h => O(8, P = h)), fn(D, Cs, h => O(9, H = h)), fn(D, vi, h => O(1, U = h)), fn(D, Nr, h => O(10, J = h)), fn(D, $r, h => O(11, B = h)), fn(D, Os, h => O(12, V = h));
    let {
        $$slots: ue = {},
        $$scope: qe
    } = L;
    const be = Xr.map(h => {
            const u = h === "/" ? "/" : h.replace(/\/+$/, "");
            if (u.includes("[")) {
                const w = u.split("[")[0];
                return {
                    type: "prefix",
                    value: w.endsWith("/") ? w : `${w}/`
                }
            }
            return {
                type: "exact",
                value: u
            }
        }),
        de = h => h === "/" ? "/" : h.replace(/\/+$/, ""),
        oe = h => {
            const u = de(h);
            return be.some(w => w.type === "exact" ? u === w.value : u === w.value.replace(/\/+$/, "") || u.startsWith(w.value))
        },
        Y = h => {
            const u = de(h);
            return !!(u === de(Wr) || oe(u))
        },
        fe = () => {
            var u, w, C;
            return Kt.isLogged(U) ? !((u = U == null ? void 0 : U.user) != null && u.howMetUtmify) && !((w = U == null ? void 0 : U.user) != null && w.mainTrafficSource) && new Date(((C = U == null ? void 0 : U.user) == null ? void 0 : C.createdAt) ? ? 0).getTime() >= new Date("2025-12-25T03:00:00.000Z").getTime() : !1
        };
    let se = "";
    const Ve = () => {
            const {
                pathname: h
            } = J.url;
            if (Y(h) || !fe()) return;
            const u = `${h}${J.url.search}`,
                w = `${Wr}?next=${encodeURIComponent(u)}`;
            se !== w && (se = w, Kt.navigateTo(w))
        },
        gt = {},
        at = ["fbclid", "gclid", "ttclid"];

    function Pe(h) {
        return at.some(u => h.searchParams.has(u))
    }

    function a() {
        const h = new URL(window.location.href),
            u = h.searchParams,
            w = {},
            C = (q, M) => {
                const ae = u.get(M);
                ae && (w[q] = ae)
            };
        C("utmRegion", "utm_region"), C("utmSource", "utm_source"), C("utmAccount", "utm_account"), C("utmCampaign", "utm_campaign"), C("utmMedium", "utm_medium"), C("utmContent", "utm_content"), C("utmId", "utm_id"), C("utmTerm", "utm_term"), !(V != null && V.src) && Pe(h) && (w.src = Zs()), Object.keys(w).length > 0 && Ds(w)
    }
    const xt = async () => {
            var u;
            const h = await Ks.execute({
                authData: U == null ? void 0 : U.authData
            });
            switch (h.status) {
                case "SUCCESS":
                    {
                        const w = ((u = h.data) == null ? void 0 : u.actives) ? ? [],
                            C = ms(w),
                            q = w.reduce((M, ae) => {
                                const ne = ae.dashboard._id ? ? ae.dashboard.id ? ? "";
                                return ne && (M[ne] = ae.access), M
                            }, {});vi.update(M => M && { ...M,
                            user: { ...M.user,
                                dashboards: C
                            },
                            accessMap: q
                        });
                        return
                    }
                case "UNAUTHORIZED":
                    Kt.navigateToSessionExpired();
                    break;
                default:
                    xs.error("Ocorreu um erro ao buscar informações. Tente novamente mais tarde ou chame o suporte.");
                    break
            }
        },
        St = async () => {
            const h = await As.execute({
                authData: U == null ? void 0 : U.authData
            });
            switch (h.status) {
                case "SUCCESS":
                    Ui(vi, U.user.waitingListReason = h.reason ? ? null, U);
                    break;
                case "UNAUTHORIZED":
                    Kt.navigateTo("/sessao-expirada");
                    break
            }
        },
        Et = async () => {
            const h = await Xs.execute({
                authData: U == null ? void 0 : U.authData
            });
            switch (h.status) {
                case "SUCCESS":
                    h.data && Ui(vi, U.user.prizeInfo = h.data, U);
                    break;
                case "UNAUTHORIZED":
                    Kt.navigateToSessionExpired();
                    break
            }
        },
        Ut = () => {
            const h = J.url.searchParams.get(Ts.indicationQueryParamKey);
            h != null && Ui($r, B = {
                coupon: h,
                settedAt: new Date
            }, B)
        };
    let ze = null,
        y = null;

    function x() {
        ze == null || ze.remove(), ze = null, y == null || y.remove(), y = null
    }

    function b() {
        ze || (ze = document.createElement("button"), ze.innerHTML = "&times;", ze.style.position = "fixed", ze.style.bottom = "75px", ze.style.right = "10px", ze.style.zIndex = "9998", ze.style.backgroundColor = "#b0bec5", ze.style.color = "#fff", ze.style.border = "none", ze.style.borderRadius = "50%", ze.style.width = "30px", ze.style.height = "30px", ze.style.cursor = "pointer", ze.style.fontSize = "20px", ze.style.boxShadow = "0px 2px 5px rgba(0, 0, 0, 0.3)", ze.onclick = () => {
            x()
        }, document.body.appendChild(ze))
    }

    function f() {
        if (y) return;
        if (!document.querySelector("#whatsapp-button-style")) {
            const u = document.createElement("style");
            u.id = "whatsapp-button-style", u.innerHTML = `
            .whatsapp-button {
                position: fixed;
                bottom: 15px;
                right: 15px;
                z-index: 9998;
                width: 65px;
                height: 65px;
                border-radius: 50%;
                background-color: #25D366;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
                cursor: pointer;
                opacity: 0.5;
                transition: opacity 0.3s ease;
            }

            .whatsapp-button:hover {
                opacity: 1;
            }
        `, document.head.appendChild(u)
        }
        y = document.createElement("div"), y.className = "whatsapp-button";
        const h = document.createElement("img");
        h.src = "/icons/whatsapp-logo.png", h.alt = "WhatsApp", h.style.width = "30px", h.style.height = "30px", y.appendChild(h), document.body.appendChild(y), y.addEventListener("click", () => {
            var w;
            ks.trackWhatsappSupport();
            const u = (w = U == null ? void 0 : U.user) == null ? void 0 : w.email;
            Kt.openWhatsApp(`Olá, preciso de uma ajuda ${u?`na conta cadastrada com o e-mail: ${u}`:"com "}`)
        }), b()
    }
    let d = !1;
    const o = () => {
        d || (d = !0, queueMicrotask(() => {
            d = !1, Ve()
        }))
    };
    return Fr(() => {
        Ss.init(), mr.init({
            removeTextSelectionOnShift: !0
        }), Ps(U, J), o();
        const h = Nr.subscribe(() => {
                o()
            }),
            u = vi.subscribe(() => {
                o()
            });
        return Kt.isLogged(U) && (xt(), St(), Et()), Ut(), gs.refreshVuexyTheme(H == null ? void 0 : H.theme), Ui(jr, P = {
            top: 0
        }, P), a(), () => {
            h(), u()
        }
    }), D.$$set = h => {
        "$$scope" in h && O(2, qe = h.$$scope)
    }, D.$$.update = () => {
        D.$$.dirty & 2 && (Kt.isLogged(U) ? f() : x())
    }, [gt, U, qe, ue]
}
class _o extends br {
    constructor(L) {
        super(), _r(this, L, Js, Qs, yr, {})
    }
}
export {
    _o as component, bo as universal
};