import {
    l as o,
    a as r
} from "../chunks/B0Dzt1sk.js";
export {
    o as load_css, r as start
};