import {
    s as G,
    n as w,
    d as g,
    i as $,
    F as N,
    k as T,
    b as u,
    m as h,
    c as p,
    e as x,
    o as I,
    g as D,
    f as y,
    h as _,
    j as E,
    t as S,
    r as Y,
    q as M,
    w as ee,
    H as te,
    I as re,
    J as ae,
    K as oe
} from "./DDNnt9XD.js";
import {
    S as W,
    i as R,
    t as O,
    a as V,
    g as ne,
    f as se,
    d as U,
    m as H,
    c as j,
    b as F
} from "./qWASNxYk.js";
import {
    C as X
} from "./CNJOnEY2.js";
import {
    E as q,
    u as P,
    g as J
} from "./B5WePDbK.js";
import {
    p as z
} from "./-FoHBm-c.js";
import {
    O as le
} from "./Bna1muQZ.js";
import {
    C as ie
} from "./hG5l1xEc.js";
import {
    G as Z
} from "./D123erTg.js";
import {
    X as Q
} from "./BtulAGCG.js";

function ce(d) {
    let e, t, o = "Configuração COMPLETA!",
        s, a, c, l, i = " ",
        n, r, f;
    return {
        c() {
            e = _("div"), t = _("h4"), t.textContent = o, s = E(), a = _("div"), c = S(`Deseja reiniciar a configuração?
      `), l = _("span"), l.textContent = i, n = E(), r = _("a"), f = S("Clique aqui para reiniciar"), this.h()
        },
        l(m) {
            e = p(m, "DIV", {
                class: !0,
                role: !0
            });
            var b = x(e);
            t = p(b, "H4", {
                class: !0,
                "data-svelte-h": !0
            }), I(t) !== "svelte-14j1gx1" && (t.textContent = o), s = D(b), a = p(b, "DIV", {
                class: !0
            });
            var v = x(a);
            c = y(v, `Deseja reiniciar a configuração?
      `), l = p(v, "SPAN", {
                "data-svelte-h": !0
            }), I(l) !== "svelte-1ujjwrx" && (l.textContent = i), n = D(v), r = p(v, "A", {
                href: !0,
                class: !0
            });
            var C = x(r);
            f = y(C, "Clique aqui para reiniciar"), C.forEach(g), v.forEach(g), b.forEach(g), this.h()
        },
        h() {
            var m;
            h(t, "class", "alert-heading"), h(r, "href", "/dashboards/" + ((m = d[1]) == null ? void 0 : m.id) + "/onboarding"), h(r, "class", "underline text-dark hover:text-dark hover:underline"), h(a, "class", "alert-body"), h(e, "class", "alert alert-dark"), h(e, "role", "alert")
        },
        m(m, b) {
            $(m, e, b), u(e, t), u(e, s), u(e, a), u(a, c), u(a, l), u(a, n), u(a, r), u(r, f)
        },
        p: w,
        d(m) {
            m && g(e)
        }
    }
}

function ue(d) {
    let e, t, o = "CONFIGURAÇÃO INCOMPLETA!",
        s, a, c, l, i = " ",
        n, r, f;
    return {
        c() {
            e = _("div"), t = _("h4"), t.textContent = o, s = E(), a = _("div"), c = S(`Você ainda não terminou a configuração desse dashboard.
      `), l = _("span"), l.textContent = i, n = E(), r = _("a"), f = S("Por favor, clique aqui para continuar."), this.h()
        },
        l(m) {
            e = p(m, "DIV", {
                class: !0,
                role: !0
            });
            var b = x(e);
            t = p(b, "H4", {
                class: !0,
                "data-svelte-h": !0
            }), I(t) !== "svelte-xgqgxo" && (t.textContent = o), s = D(b), a = p(b, "DIV", {
                class: !0
            });
            var v = x(a);
            c = y(v, `Você ainda não terminou a configuração desse dashboard.
      `), l = p(v, "SPAN", {
                "data-svelte-h": !0
            }), I(l) !== "svelte-1ujjwrx" && (l.textContent = i), n = D(v), r = p(v, "A", {
                href: !0,
                class: !0
            });
            var C = x(r);
            f = y(C, "Por favor, clique aqui para continuar."), C.forEach(g), v.forEach(g), b.forEach(g), this.h()
        },
        h() {
            var m;
            h(t, "class", "alert-heading"), h(r, "href", "/dashboards/" + ((m = d[1]) == null ? void 0 : m.id) + "/onboarding"), h(r, "class", "underline text-error hover:text-error-dark hover:underline"), h(a, "class", "alert-body"), h(e, "class", "alert alert-danger"), h(e, "role", "alert")
        },
        m(m, b) {
            $(m, e, b), u(e, t), u(e, s), u(e, a), u(a, c), u(a, l), u(a, n), u(a, r), u(r, f)
        },
        p: w,
        d(m) {
            m && g(e)
        }
    }
}

function de(d) {
    let e;

    function t(a, c) {
        if (!a[2]) return ue;
        if (a[0]) return ce
    }
    let o = t(d),
        s = o && o(d);
    return {
        c() {
            s && s.c(), e = N()
        },
        l(a) {
            s && s.l(a), e = N()
        },
        m(a, c) {
            s && s.m(a, c), $(a, e, c)
        },
        p(a, [c]) {
            o === (o = t(a)) && s ? s.p(a, c) : (s && s.d(1), s = o && o(a), s && (s.c(), s.m(e.parentNode, e)))
        },
        i: w,
        o: w,
        d(a) {
            a && g(e), s && s.d(a)
        }
    }
}

function fe(d, e, t) {
    let o, s;
    T(d, z, n => t(3, o = n)), T(d, P, n => t(4, s = n));
    let {
        showCompletion: a = !1
    } = e;
    const c = q.getCurrentDashboard(s, o),
        l = le.fromDash(c),
        i = l == null ? void 0 : l.isComplete();
    return d.$$set = n => {
        "showCompletion" in n && t(0, a = n.showCompletion)
    }, [a, c, i]
}
class he extends W {
    constructor(e) {
        super(), R(this, e, fe, de, G, {
            showCompletion: 0
        })
    }
}

function me(d) {
    let e, t, o = "Pixel não configurado!",
        s, a, c = `Você não está aproveitando ao máximo a Utmify porque você ainda não
      configurou nenhum pixel para melhorar seus eventos.  
      <a href="${X.pixelTutorialLink}" target="_blank" class="underline text-[#FF9F43] hover:text-[#FF9F43] hover:underline">Assistir tutorial</a>`,
        l, i, n, r, f, m, b;
    return r = new Q({
        props: {
            class: "!w-[21px] !h-[21px] !cursor-pointer !stroke-[2px]"
        }
    }), {
        c() {
            e = _("div"), t = _("h4"), t.textContent = o, s = E(), a = _("div"), a.innerHTML = c, l = E(), i = _("div"), n = _("div"), F(r.$$.fragment), this.h()
        },
        l(v) {
            e = p(v, "DIV", {
                class: !0,
                role: !0
            });
            var C = x(e);
            t = p(C, "H4", {
                class: !0,
                "data-svelte-h": !0
            }), I(t) !== "svelte-1psyseg" && (t.textContent = o), s = D(C), a = p(C, "DIV", {
                class: !0,
                "data-svelte-h": !0
            }), I(a) !== "svelte-1kzkgxx" && (a.innerHTML = c), l = D(C), i = p(C, "DIV", {
                class: !0
            });
            var k = x(i);
            n = p(k, "DIV", {
                class: !0
            });
            var A = x(n);
            j(r.$$.fragment, A), A.forEach(g), k.forEach(g), C.forEach(g), this.h()
        },
        h() {
            h(t, "class", "alert-heading"), h(a, "class", "alert-body"), h(n, "class", "!w-[38px] !h-[38px] hover:bg-yellow-500 hover:bg-opacity-10 rounded-md flex flex-col justify-center items-center"), h(i, "class", "absolute right-2 top-0"), h(e, "class", "alert alert-warning"), h(e, "role", "alert")
        },
        m(v, C) {
            $(v, e, C), u(e, t), u(e, s), u(e, a), u(e, l), u(e, i), u(i, n), H(r, n, null), f = !0, m || (b = M(n, "click", d[7]), m = !0)
        },
        p: w,
        i(v) {
            f || (V(r.$$.fragment, v), f = !0)
        },
        o(v) {
            O(r.$$.fragment, v), f = !1
        },
        d(v) {
            v && g(e), U(r), m = !1, b()
        }
    }
}

function pe(d) {
    let e, t, o = "UTMs não configuradas!",
        s, a, c, l, i = "Assistir agora",
        n, r, f, m, b, v, C;
    return m = new Q({
        props: {
            class: "!w-[21px] !h-[21px] !cursor-pointer !stroke-[2px]"
        }
    }), {
        c() {
            e = _("div"), t = _("h4"), t.textContent = o, s = E(), a = _("div"), c = S(`Assista ao tutorial para garantir que suas vendas serão
      marcadas com sucesso.  
      
      `), l = _("a"), l.textContent = i, n = E(), r = _("div"), f = _("div"), F(m.$$.fragment), this.h()
        },
        l(k) {
            e = p(k, "DIV", {
                class: !0,
                role: !0
            });
            var A = x(e);
            t = p(A, "H4", {
                class: !0,
                "data-svelte-h": !0
            }), I(t) !== "svelte-1it0fki" && (t.textContent = o), s = D(A), a = p(A, "DIV", {
                class: !0
            });
            var L = x(a);
            c = y(L, `Assista ao tutorial para garantir que suas vendas serão
      marcadas com sucesso.  
      
      `), l = p(L, "A", {
                href: !0,
                class: !0,
                target: !0,
                "data-svelte-h": !0
            }), I(l) !== "svelte-1qe88kg" && (l.textContent = i), L.forEach(g), n = D(A), r = p(A, "DIV", {
                class: !0
            });
            var B = x(r);
            f = p(B, "DIV", {
                class: !0
            });
            var K = x(f);
            j(m.$$.fragment, K), K.forEach(g), B.forEach(g), A.forEach(g), this.h()
        },
        h() {
            h(t, "class", "alert-heading"), h(l, "href", X.tutorialLink), h(l, "class", "underline text-error hover:text-error-dark hover:underline"), h(l, "target", "_blank"), h(a, "class", "alert-body"), h(f, "class", "!w-[38px] !h-[38px] text-error hover:bg-red-500 hover:bg-opacity-10 rounded-md flex flex-col justify-center items-center"), h(r, "class", "absolute right-2 top-0"), h(e, "class", "alert alert-danger"), h(e, "role", "alert")
        },
        m(k, A) {
            $(k, e, A), u(e, t), u(e, s), u(e, a), u(a, c), u(a, l), u(e, n), u(e, r), u(r, f), H(m, f, null), b = !0, v || (C = [M(l, "click", d[5]), M(f, "click", d[4])], v = !0)
        },
        p: w,
        i(k) {
            b || (V(m.$$.fragment, k), b = !0)
        },
        o(k) {
            O(m.$$.fragment, k), b = !1
        },
        d(k) {
            k && g(e), U(m), v = !1, Y(C)
        }
    }
}

function _e(d) {
    let e, t, o = "Webhook não configurado!",
        s, a, c, l, i;
    return {
        c() {
            e = _("div"), t = _("h4"), t.textContent = o, s = E(), a = _("div"), c = S(`Sua página pode estar sem vendas porque você ainda não configurou nenhum
      webhook.  
      `), l = _("a"), i = S("Configurar agora"), this.h()
        },
        l(n) {
            e = p(n, "DIV", {
                class: !0,
                role: !0
            });
            var r = x(e);
            t = p(r, "H4", {
                class: !0,
                "data-svelte-h": !0
            }), I(t) !== "svelte-6z9b9v" && (t.textContent = o), s = D(r), a = p(r, "DIV", {
                class: !0
            });
            var f = x(a);
            c = y(f, `Sua página pode estar sem vendas porque você ainda não configurou nenhum
      webhook.  
      `), l = p(f, "A", {
                href: !0,
                class: !0
            });
            var m = x(l);
            i = y(m, "Configurar agora"), m.forEach(g), f.forEach(g), r.forEach(g), this.h()
        },
        h() {
            var n;
            h(t, "class", "alert-heading"), h(l, "href", "/dashboards/" + ((n = d[2]) == null ? void 0 : n.id) + "/integracoes"), h(l, "class", "underline text-error hover:text-error-dark hover:underline"), h(a, "class", "alert-body"), h(e, "class", "alert alert-danger"), h(e, "role", "alert")
        },
        m(n, r) {
            $(n, e, r), u(e, t), u(e, s), u(e, a), u(a, c), u(a, l), u(l, i)
        },
        p: w,
        i: w,
        o: w,
        d(n) {
            n && g(e)
        }
    }
}

function ve(d) {
    let e, t, o = "Nenhuma conta de anúncio habilitada!",
        s, a, c, l, i;
    return {
        c() {
            e = _("div"), t = _("h4"), t.textContent = o, s = E(), a = _("div"), c = S(`Algumas funcionalidades podem estar sem dados pois você ainda não
      habilitou nenhuma conta de anúncio.  
      `), l = _("a"), i = S("Habilitar agora"), this.h()
        },
        l(n) {
            e = p(n, "DIV", {
                class: !0,
                role: !0
            });
            var r = x(e);
            t = p(r, "H4", {
                class: !0,
                "data-svelte-h": !0
            }), I(t) !== "svelte-68ctju" && (t.textContent = o), s = D(r), a = p(r, "DIV", {
                class: !0
            });
            var f = x(a);
            c = y(f, `Algumas funcionalidades podem estar sem dados pois você ainda não
      habilitou nenhuma conta de anúncio.  
      `), l = p(f, "A", {
                href: !0,
                class: !0
            });
            var m = x(l);
            i = y(m, "Habilitar agora"), m.forEach(g), f.forEach(g), r.forEach(g), this.h()
        },
        h() {
            var n;
            h(t, "class", "alert-heading"), h(l, "href", "/dashboards/" + ((n = d[2]) == null ? void 0 : n.id) + "/integracoes"), h(l, "class", "underline text-error hover:text-error-dark hover:underline"), h(a, "class", "alert-body"), h(e, "class", "alert alert-danger"), h(e, "role", "alert")
        },
        m(n, r) {
            $(n, e, r), u(e, t), u(e, s), u(e, a), u(a, c), u(a, l), u(l, i)
        },
        p: w,
        i: w,
        o: w,
        d(n) {
            n && g(e)
        }
    }
}

function ge(d) {
    let e, t, o, s;
    const a = [ve, _e, pe, me],
        c = [];

    function l(i, n) {
        return i[0] === "NO_ENABLED_AD_ACCOUNTS" ? 0 : i[0] === "NO_WEBHOOKS" ? 1 : i[0] === "NOT_CONFIGURED_UTMS" ? 2 : i[0] === "NO_PIXELS" && i[3] && !("closedPixelAlert" in localStorage) && !i[1] ? 3 : -1
    }
    return ~(e = l(d)) && (t = c[e] = a[e](d)), {
        c() {
            t && t.c(), o = N()
        },
        l(i) {
            t && t.l(i), o = N()
        },
        m(i, n) {
            ~e && c[e].m(i, n), $(i, o, n), s = !0
        },
        p(i, [n]) {
            let r = e;
            e = l(i), e === r ? ~e && c[e].p(i, n) : (t && (ne(), O(c[r], 1, 1, () => {
                c[r] = null
            }), se()), ~e ? (t = c[e], t ? t.p(i, n) : (t = c[e] = a[e](i), t.c()), V(t, 1), t.m(o.parentNode, o)) : t = null)
        },
        i(i) {
            s || (V(t), s = !0)
        },
        o(i) {
            O(t), s = !1
        },
        d(i) {
            i && g(o), ~e && c[e].d(i)
        }
    }
}

function be(d, e, t) {
    let o, s;
    T(d, P, k => t(8, o = k)), T(d, z, k => t(9, s = k));
    const a = q.getCurrentDashboard(o, s),
        c = q.getCurrentDashboardIndex(o, s),
        l = s.url.pathname,
        i = l.includes("resumo"),
        n = l.includes("campanhas") ? "Meta" : l.includes("google") ? "Google" : void 0;
    let r = J(a, o, n);
    const f = async () => {
            if (c == null || c === -1) return;
            switch ((await ie.execute({
                authData: o.authData,
                dashboardId: o.user.dashboards[c].id
            })).status) {
                case "SUCCESS":
                    Z.trackFinishUtmsConfig(), ee(P, o.user.dashboards[c].configuredUtms = !0, o), t(0, r = J(a, o, n));
                    break;
                case "UNAUTHORIZED":
                    q.navigateTo("/sessao-expirada");
                    break
            }
        },
        m = async () => {
            Z.trackWatchTutorial(), f()
        };
    let b = !1;
    const v = () => {
        localStorage.removeItem("closedPixelAlert"), "closedPixelAlert" in localStorage || (t(1, b = !0), localStorage.setItem("closedPixelAlert", "true"))
    };
    return [r, b, a, i, f, m, v, () => {
        v()
    }]
}
class xe extends W {
    constructor(e) {
        super(), R(this, e, be, ge, G, {})
    }
}

function Ce(d) {
    let e, t;
    return e = new he({
        props: {
            showCompletion: d[0]
        }
    }), {
        c() {
            F(e.$$.fragment)
        },
        l(o) {
            j(e.$$.fragment, o)
        },
        m(o, s) {
            H(e, o, s), t = !0
        },
        p(o, s) {
            const a = {};
            s & 1 && (a.showCompletion = o[0]), e.$set(a)
        },
        i(o) {
            t || (V(e.$$.fragment, o), t = !0)
        },
        o(o) {
            O(e.$$.fragment, o), t = !1
        },
        d(o) {
            U(e, o)
        }
    }
}

function ke(d) {
    let e, t;
    return e = new xe({}), {
        c() {
            F(e.$$.fragment)
        },
        l(o) {
            j(e.$$.fragment, o)
        },
        m(o, s) {
            H(e, o, s), t = !0
        },
        p: w,
        i(o) {
            t || (V(e.$$.fragment, o), t = !0)
        },
        o(o) {
            O(e.$$.fragment, o), t = !1
        },
        d(o) {
            U(e, o)
        }
    }
}

function we(d) {
    let e, t, o, s;
    const a = [ke, Ce],
        c = [];

    function l(r, f) {
        return r[1] === "old" ? 0 : 1
    }
    e = l(d), t = c[e] = a[e](d);
    const i = d[3].default,
        n = te(i, d, d[2], null);
    return {
        c() {
            t.c(), o = E(), n && n.c()
        },
        l(r) {
            t.l(r), o = D(r), n && n.l(r)
        },
        m(r, f) {
            c[e].m(r, f), $(r, o, f), n && n.m(r, f), s = !0
        },
        p(r, [f]) {
            t.p(r, f), n && n.p && (!s || f & 4) && re(n, i, r, r[2], s ? oe(i, r[2], f, null) : ae(r[2]), null)
        },
        i(r) {
            s || (V(t), V(n, r), s = !0)
        },
        o(r) {
            O(t), O(n, r), s = !1
        },
        d(r) {
            r && g(o), c[e].d(r), n && n.d(r)
        }
    }
}

function Ae(d, e, t) {
    let o, s;
    T(d, z, r => t(4, o = r)), T(d, P, r => t(5, s = r));
    let {
        $$slots: a = {},
        $$scope: c
    } = e, {
        showCompletion: l = !1
    } = e;
    const i = q.getCurrentDashboard(s, o),
        n = i != null && i.createdAt != null && X.onboardingUpdateDate.getTime() < new Date(i.createdAt).getTime() ? "new" : "old";
    return d.$$set = r => {
        "showCompletion" in r && t(0, l = r.showCompletion), "$$scope" in r && t(2, c = r.$$scope)
    }, [l, n, c, a]
}
class qe extends W {
    constructor(e) {
        super(), R(this, e, Ae, we, G, {
            showCompletion: 0
        })
    }
}
export {
    qe as C
};