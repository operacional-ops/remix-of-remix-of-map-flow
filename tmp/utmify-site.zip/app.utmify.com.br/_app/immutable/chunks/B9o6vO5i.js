import {
    s as Q,
    d as h,
    m as u,
    p as N,
    i as T,
    b as g,
    q as U,
    c as v,
    e as E,
    g as V,
    h as k,
    j as q,
    a as W,
    f as F,
    F as O,
    t as P,
    n as j
} from "./DDNnt9XD.js";
import {
    S as Y,
    i as Z,
    d as R,
    t as p,
    a as I,
    g as X,
    f as G,
    m as H,
    c as J,
    b as K
} from "./qWASNxYk.js";
import {
    I as y
} from "./BtulAGCG.js";
import {
    I as x
} from "./s1mAKLjT.js";

function $(f) {
    let e, l;
    return {
        c() {
            e = k("label"), l = P("‍"), this.h()
        },
        l(a) {
            e = v(a, "LABEL", {
                class: !0,
                for: !0
            });
            var n = E(e);
            l = F(n, "‍"), n.forEach(h), this.h()
        },
        h() {
            u(e, "class", "form-label"), u(e, "for", f[1])
        },
        m(a, n) {
            T(a, e, n), g(e, l)
        },
        p(a, n) {
            n & 2 && u(e, "for", a[1])
        },
        i: j,
        o: j,
        d(a) {
            a && h(e)
        }
    }
}

function ee(f) {
    let e, l, a, n, c, o = f[8] && C(f);
    return {
        c() {
            e = k("label"), l = P(f[7]), a = q(), o && o.c(), n = O(), this.h()
        },
        l(r) {
            e = v(r, "LABEL", {
                class: !0,
                for: !0
            });
            var t = E(e);
            l = F(t, f[7]), t.forEach(h), a = V(r), o && o.l(r), n = O(), this.h()
        },
        h() {
            u(e, "class", "form-label"), u(e, "for", f[1])
        },
        m(r, t) {
            T(r, e, t), g(e, l), T(r, a, t), o && o.m(r, t), T(r, n, t), c = !0
        },
        p(r, t) {
            (!c || t & 128) && W(l, r[7]), (!c || t & 2) && u(e, "for", r[1]), r[8] ? o ? (o.p(r, t), t & 256 && I(o, 1)) : (o = C(r), o.c(), I(o, 1), o.m(n.parentNode, n)) : o && (X(), p(o, 1, 1, () => {
                o = null
            }), G())
        },
        i(r) {
            c || (I(o), c = !0)
        },
        o(r) {
            p(o), c = !1
        },
        d(r) {
            r && (h(e), h(a), h(n)), o && o.d(r)
        }
    }
}

function C(f) {
    let e, l, a;
    return l = new y({
        props: {
            margin: !1,
            text: f[8]
        }
    }), {
        c() {
            e = k("span"), K(l.$$.fragment), this.h()
        },
        l(n) {
            e = v(n, "SPAN", {
                class: !0
            });
            var c = E(e);
            J(l.$$.fragment, c), c.forEach(h), this.h()
        },
        h() {
            u(e, "class", "!ml-1")
        },
        m(n, c) {
            T(n, e, c), H(l, e, null), a = !0
        },
        p(n, c) {
            const o = {};
            c & 256 && (o.text = n[8]), l.$set(o)
        },
        i(n) {
            a || (I(l.$$.fragment, n), a = !0)
        },
        o(n) {
            p(l.$$.fragment, n), a = !1
        },
        d(n) {
            n && h(e), R(l)
        }
    }
}

function le(f) {
    let e, l, a, n, c, o, r, t, L, d, w, _, S, z;
    const D = [ee, $],
        b = [];

    function i(s, m) {
        return s[7] ? 0 : s[9] ? 1 : -1
    }
    return ~(l = i(f)) && (a = b[l] = D[l](f)), d = new x({
        props: {
            error: f[2]
        }
    }), {
        c() {
            e = k("div"), a && a.c(), n = q(), c = k("div"), o = k("div"), r = k("div"), t = k("textarea"), L = q(), K(d.$$.fragment), this.h()
        },
        l(s) {
            e = v(s, "DIV", {
                class: !0
            });
            var m = E(e);
            a && a.l(m), n = V(m), c = v(m, "DIV", {
                class: !0
            });
            var A = E(c);
            o = v(A, "DIV", {
                class: !0
            });
            var M = E(o);
            r = v(M, "DIV", {
                class: !0
            });
            var B = E(r);
            t = v(B, "TEXTAREA", {
                autocomplete: !0,
                class: !0,
                inputmode: !0,
                placeholder: !0,
                name: !0,
                cols: !0,
                rows: !0
            }), E(t).forEach(h), B.forEach(h), M.forEach(h), A.forEach(h), L = V(m), J(d.$$.fragment, m), m.forEach(h), this.h()
        },
        h() {
            t.readOnly = f[10], u(t, "autocomplete", f[11]), u(t, "class", "form-control"), u(t, "inputmode", f[12]), u(t, "placeholder", f[5]), u(t, "name", f[1]), u(t, "cols", f[3]), u(t, "rows", f[4]), u(r, "class", "input-group input-group-merge form-password-toggle"), u(o, "class", "flex-1"), u(c, "class", "flex flex-row items-center w-full space-x-3"), u(e, "class", w = f[6] ? "mb-1" : "")
        },
        m(s, m) {
            T(s, e, m), ~l && b[l].m(e, null), g(e, n), g(e, c), g(c, o), g(o, r), g(r, t), N(t, f[0]), g(e, L), H(d, e, null), _ = !0, S || (z = U(t, "input", f[13]), S = !0)
        },
        p(s, [m]) {
            let A = l;
            l = i(s), l === A ? ~l && b[l].p(s, m) : (a && (X(), p(b[A], 1, 1, () => {
                b[A] = null
            }), G()), ~l ? (a = b[l], a ? a.p(s, m) : (a = b[l] = D[l](s), a.c()), I(a, 1), a.m(e, n)) : a = null), (!_ || m & 1024) && (t.readOnly = s[10]), (!_ || m & 2048) && u(t, "autocomplete", s[11]), (!_ || m & 4096) && u(t, "inputmode", s[12]), (!_ || m & 32) && u(t, "placeholder", s[5]), (!_ || m & 2) && u(t, "name", s[1]), (!_ || m & 8) && u(t, "cols", s[3]), (!_ || m & 16) && u(t, "rows", s[4]), m & 1 && N(t, s[0]);
            const M = {};
            m & 4 && (M.error = s[2]), d.$set(M), (!_ || m & 64 && w !== (w = s[6] ? "mb-1" : "")) && u(e, "class", w)
        },
        i(s) {
            _ || (I(a), I(d.$$.fragment, s), _ = !0)
        },
        o(s) {
            p(a), p(d.$$.fragment, s), _ = !1
        },
        d(s) {
            s && h(e), ~l && b[l].d(), R(d), S = !1, z()
        }
    }
}

function te(f, e, l) {
    let {
        name: a
    } = e, {
        value: n = ""
    } = e, {
        error: c = null
    } = e, {
        cols: o = 30
    } = e, {
        rows: r = 5
    } = e, {
        placeholder: t = null
    } = e, {
        margin: L = !0
    } = e, {
        label: d = null
    } = e, {
        tooltip: w = null
    } = e, {
        useLabelSize: _ = !0
    } = e, {
        readonly: S = !1
    } = e, {
        autocomplete: z = "on"
    } = e, {
        inputMode: D = "text"
    } = e;

    function b() {
        n = this.value, l(0, n)
    }
    return f.$$set = i => {
        "name" in i && l(1, a = i.name), "value" in i && l(0, n = i.value), "error" in i && l(2, c = i.error), "cols" in i && l(3, o = i.cols), "rows" in i && l(4, r = i.rows), "placeholder" in i && l(5, t = i.placeholder), "margin" in i && l(6, L = i.margin), "label" in i && l(7, d = i.label), "tooltip" in i && l(8, w = i.tooltip), "useLabelSize" in i && l(9, _ = i.useLabelSize), "readonly" in i && l(10, S = i.readonly), "autocomplete" in i && l(11, z = i.autocomplete), "inputMode" in i && l(12, D = i.inputMode)
    }, [n, a, c, o, r, t, L, d, w, _, S, z, D, b]
}
class ie extends Y {
    constructor(e) {
        super(), Z(this, e, te, le, Q, {
            name: 1,
            value: 0,
            error: 2,
            cols: 3,
            rows: 4,
            placeholder: 5,
            margin: 6,
            label: 7,
            tooltip: 8,
            useLabelSize: 9,
            readonly: 10,
            autocomplete: 11,
            inputMode: 12
        })
    }
}
export {
    ie as T
};