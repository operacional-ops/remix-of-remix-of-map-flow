var o = Object.defineProperty;
var f = (t, a, r) => a in t ? o(t, a, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: r
}) : t[a] = r;
var T = (t, a, r) => f(t, typeof a != "symbol" ? a + "" : a, r);
import {
    D as u
} from "./Dd0nEcXu.js";
class s {
    constructor(a) {
        T(this, "hoursOffset");
        if (a == null) throw new Error("Timezone offset is required");
        const r = Number(a);
        if (Number.isNaN(r)) throw new Error("Invalid timezone offset");
        if (r < -12 || r > 14) throw new Error("Invalid timezone offset");
        if (!(r === Math.floor(r))) throw new Error("Timezone offset must be an integer");
        this.hoursOffset = r
    }
    static fromTimeZoneOffset() {
        return s.fromInt(u.getTimeZoneOffsetInHours())
    }
    static fromDto(a) {
        return new s((a == null ? void 0 : a.hoursOffset) ? ? -3)
    }
    static fromInt(a) {
        return new s(a)
    }
    static isValidFromInt(a) {
        try {
            return new s(a), !0
        } catch {
            return !1
        }
    }
    asInt() {
        return this.hoursOffset
    }
    static fromTimeZoneString(a) {
        const r = Number(a.split("GMT")[1]);
        return s.fromInt(r)
    }
    asTimeZoneString() {
        const a = this.asInt();
        return `GMT${a>=0?"+":""}${a}`
    }
    asTimeZoneStringValue() {
        var r;
        const a = this.asTimeZoneString();
        return ((r = Object.entries(M).find(([G, n]) => G === a)) == null ? void 0 : r[1]) ? ? ""
    }
}
var M = (t => (t["GMT-12"] = "GMT-12 | Linha Internacional de Data", t["GMT-11"] = "GMT-11 | Midway", t["GMT-10"] = "GMT-10 | Havaí-Aleutas", t["GMT-9"] = "GMT-9 | Alasca", t["GMT-8"] = "GMT-8 | Pacífico", t["GMT-7"] = "GMT-7 | Montanha", t["GMT-6"] = "GMT-6 | Central", t["GMT-5"] = "GMT-5 | Oriental", t["GMT-4"] = "GMT-4 | Atlântico", t["GMT-3"] = "GMT-3 | Brasília", t["GMT-2"] = "GMT-2 | Centro-Atlântico", t["GMT-1"] = "GMT-1 | Azores", t["GMT+0"] = "GMT+0 | Greenwich", t["GMT+1"] = "GMT+1 | Europa Central", t["GMT+2"] = "GMT+2 | Europa Oriental", t["GMT+3"] = "GMT+3 | Moscou", t["GMT+4"] = "GMT+4 | Arábia", t["GMT+5"] = "GMT+5 | Paquistão", t["GMT+6"] = "GMT+6 | Índia", t["GMT+7"] = "GMT+7 | Indochina", t["GMT+8"] = "GMT+8 | China", t["GMT+9"] = "GMT+9 | Japão", t["GMT+10"] = "GMT+10 | Austrália Oriental", t["GMT+11"] = "GMT+11 | Pacífico/Guadalcanal", t["GMT+12"] = "GMT+12 | Nova Zelândia", t["GMT+13"] = "GMT+13 | Tonga", t["GMT+14"] = "GMT+14 | Ilhas Line", t))(M || {});
const l = () => Object.entries(M).map(([t, a]) => ({
    value: t,
    label: a
}));
export {
    s as T, M as a, l as g
};