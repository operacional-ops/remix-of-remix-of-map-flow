import {
    s as q,
    H as B,
    d,
    I as P,
    J as V,
    K,
    i as b,
    g as I,
    j as R,
    k as A,
    a as D,
    b as g,
    m as E,
    c as L,
    e as w,
    f as k,
    h as S,
    t as F,
    n as M,
    o as j
} from "./DDNnt9XD.js";
import {
    S as y,
    i as N,
    t as U,
    a as x
} from "./qWASNxYk.js";
import {
    E as H,
    u as X
} from "./B5WePDbK.js";
import {
    p as z
} from "./-FoHBm-c.js";

function T(o) {
    var i, v;
    let s, n, t = o[1]((i = o[0]) == null ? void 0 : i.user.waitingListReason) + "",
        r, f, e, u = o[2]((v = o[0]) == null ? void 0 : v.user.waitingListReason) + "",
        a, l;

    function _(c, p) {
        return c[4] ? G : J
    }
    let m = _(o)(o);
    return {
        c() {
            s = S("div"), n = S("h4"), r = F(t), f = R(), e = S("div"), a = F(u), l = R(), m.c(), this.h()
        },
        l(c) {
            s = L(c, "DIV", {
                class: !0,
                role: !0
            });
            var p = w(s);
            n = L(p, "H4", {
                class: !0
            });
            var C = w(n);
            r = k(C, t), C.forEach(d), f = I(p), e = L(p, "DIV", {
                class: !0
            });
            var h = w(e);
            a = k(h, u), l = I(h), m.l(h), h.forEach(d), p.forEach(d), this.h()
        },
        h() {
            E(n, "class", "alert-heading"), E(e, "class", "alert-body"), E(s, "class", "alert alert-danger"), E(s, "role", "alert")
        },
        m(c, p) {
            b(c, s, p), g(s, n), g(n, r), g(s, f), g(s, e), g(e, a), g(e, l), m.m(e, null)
        },
        p(c, p) {
            var C, h;
            p & 1 && t !== (t = c[1]((C = c[0]) == null ? void 0 : C.user.waitingListReason) + "") && D(r, t), p & 1 && u !== (u = c[2]((h = c[0]) == null ? void 0 : h.user.waitingListReason) + "") && D(a, u), m.p(c, p)
        },
        d(c) {
            c && d(s), m.d()
        }
    }
}

function G(o) {
    var f;
    let s, n, t = o[3]((f = o[0]) == null ? void 0 : f.user.waitingListReason) + "",
        r;
    return {
        c() {
            s = S("br"), n = R(), r = F(t)
        },
        l(e) {
            s = L(e, "BR", {}), n = I(e), r = k(e, t)
        },
        m(e, u) {
            b(e, s, u), b(e, n, u), b(e, r, u)
        },
        p(e, u) {
            var a;
            u & 1 && t !== (t = e[3]((a = e[0]) == null ? void 0 : a.user.waitingListReason) + "") && D(r, t)
        },
        d(e) {
            e && (d(s), d(n), d(r))
        }
    }
}

function J(o) {
    let s, n = "Gerenciar assinatura";
    return {
        c() {
            s = S("a"), s.textContent = n, this.h()
        },
        l(t) {
            s = L(t, "A", {
                href: !0,
                class: !0,
                "data-svelte-h": !0
            }), j(s) !== "svelte-xppprr" && (s.textContent = n), this.h()
        },
        h() {
            E(s, "href", "/assinatura"), E(s, "class", "underline text-error hover:text-error-dark hover:underline")
        },
        m(t, r) {
            b(t, s, r)
        },
        p: M,
        d(t) {
            t && d(s)
        }
    }
}

function Q(o) {
    var u;
    let s = ((u = o[0]) == null ? void 0 : u.user.waitingListReason) && o[5](),
        n, t, r = s && T(o);
    const f = o[7].default,
        e = B(f, o, o[6], null);
    return {
        c() {
            r && r.c(), n = R(), e && e.c()
        },
        l(a) {
            r && r.l(a), n = I(a), e && e.l(a)
        },
        m(a, l) {
            r && r.m(a, l), b(a, n, l), e && e.m(a, l), t = !0
        },
        p(a, [l]) {
            var _;
            l & 1 && (s = ((_ = a[0]) == null ? void 0 : _.user.waitingListReason) && a[5]()), s ? r ? r.p(a, l) : (r = T(a), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), e && e.p && (!t || l & 64) && P(e, f, a, a[6], t ? K(f, a[6], l, null) : V(a[6]), null)
        },
        i(a) {
            t || (x(e, a), t = !0)
        },
        o(a) {
            U(e, a), t = !1
        },
        d(a) {
            a && d(n), r && r.d(a), e && e.d(a)
        }
    }
}

function Y(o, s, n) {
    let t, r;
    A(o, X, i => n(0, t = i)), A(o, z, i => n(8, r = i));
    let {
        $$slots: f = {},
        $$scope: e
    } = s;
    const u = i => i === "SOFT_BLOCKED" ? "Pagamento pendente!" : "Conta suspensa!",
        a = i => {
            switch (i) {
                case "FREE_QUOTA_EXCEEDED":
                    return "Sua conta foi suspensa por exceder o limite gratuito. Atualize seu plano.";
                case "SUBSCRIPTION_EXPIRED":
                    return "Sua conta foi suspensa pois sua assinatura expirou. Verifique as informações de pagamento ou entre em contato com o suporte.";
                case "SOFT_BLOCKED":
                    return "O pagamento da sua conta falhou. Corrija as informações de pagamento ou sua conta será suspensa em breve.";
                case "PAYMENT_FAILED":
                    return "Sua conta foi suspensa pois o pagamento falhou. Verifique as informações de pagamento ou entre em contato com o suporte.";
                default:
                    return "Sua conta foi suspensa. Verifique as informações de pagamento ou entre em contato com o suporte."
            }
        },
        l = i => i === "SOFT_BLOCKED" ? "Se precisar de ajuda, basta entrar em contato com o suporte." : "Mas fique tranquilo, suas vendas ainda estão sendo salvas. Basta reativar a conta para recuperá-las, sem perder nenhum dado.",
        _ = r.url.pathname,
        O = _ === "assinatura" || _ === "assinatura/" || _ === "/assinatura/",
        m = () => {
            const i = H.getCurrentDashboardIndex(t, r);
            if (i === null) return !0;
            const v = t == null ? void 0 : t.user.dashboards[i];
            return v ? v.userId === (t == null ? void 0 : t.user.id) : !0
        };
    return o.$$set = i => {
        "$$scope" in i && n(6, e = i.$$scope)
    }, [t, u, a, l, O, m, e, f]
}
class te extends y {
    constructor(s) {
        super(), N(this, s, Y, Q, q, {})
    }
}
export {
    te as A
};