var U = (C => (C.UTC_6 = "UTC-6", C.UTC_5 = "UTC-5", C.UTC_4 = "UTC-4", C.UTC_3 = "UTC-3", C.UTC0 = "UTC+0", C.UTC1 = "UTC+1", C.UTC2 = "UTC+2", C.UTC3 = "UTC+3", C.UTC5 = "UTC+5", C.UTC6 = "UTC+6", C.UTC7 = "UTC+7", C.UTC8 = "UTC+8", C))(U || {});
export {
    U as K
};