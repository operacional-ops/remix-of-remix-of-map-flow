import {
    s as an,
    n as Ze,
    d as ne,
    r as Bn,
    m as R,
    p as Xe,
    i as be,
    q as Se,
    B as Jn,
    c as Pe,
    h as Ye,
    k as Kn,
    v as Un,
    x as rn,
    z as Vn,
    u as he,
    e as $e,
    g as qn,
    j as zn
} from "./DDNnt9XD.js";
import {
    S as on,
    i as ln,
    e as Qn,
    d as Gn,
    t as Zn,
    a as Xn,
    m as $n,
    c as et,
    b as nt
} from "./qWASNxYk.js";
import {
    b as tt
} from "./DwsiLpv2.js";
import {
    t as at
} from "./BszCcFfc.js";
import {
    D as it
} from "./Dd0nEcXu.js";
var He = {
    exports: {}
};
(function(a, i) {
    (function(e, u) {
        u(i)
    })(tt, function(e) {
        var u = typeof window < "u" && window.flatpickr !== void 0 ? window.flatpickr : {
                l10ns: {}
            },
            s = {
                weekdays: {
                    shorthand: ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"],
                    longhand: ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"]
                },
                months: {
                    shorthand: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"],
                    longhand: ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]
                },
                rangeSeparator: " até ",
                time_24hr: !0
            };
        u.l10ns.pt = s;
        var m = u.l10ns;
        e.Portuguese = s, e.default = m, Object.defineProperty(e, "__esModule", {
            value: !0
        })
    })
})(He, He.exports);
var en = He.exports,
    Te = ["onChange", "onClose", "onDayCreate", "onDestroy", "onKeyDown", "onMonthChange", "onOpen", "onParseConfig", "onReady", "onValueUpdate", "onYearChange", "onPreCalendarPosition"],
    te = {
        _disable: [],
        allowInput: !1,
        allowInvalidPreload: !1,
        altFormat: "F j, Y",
        altInput: !1,
        altInputClass: "form-control input",
        animate: typeof window == "object" && window.navigator.userAgent.indexOf("MSIE") === -1,
        ariaDateFormat: "F j, Y",
        autoFillDefaultTime: !0,
        clickOpens: !0,
        closeOnSelect: !0,
        conjunction: ", ",
        dateFormat: "Y-m-d",
        defaultHour: 12,
        defaultMinute: 0,
        defaultSeconds: 0,
        disable: [],
        disableMobile: !1,
        enableSeconds: !1,
        enableTime: !1,
        errorHandler: function(a) {
            return typeof console < "u" && console.warn(a)
        },
        getWeek: function(a) {
            var i = new Date(a.getTime());
            i.setHours(0, 0, 0, 0), i.setDate(i.getDate() + 3 - (i.getDay() + 6) % 7);
            var e = new Date(i.getFullYear(), 0, 4);
            return 1 + Math.round(((i.getTime() - e.getTime()) / 864e5 - 3 + (e.getDay() + 6) % 7) / 7)
        },
        hourIncrement: 1,
        ignoredFocusElements: [],
        inline: !1,
        locale: "default",
        minuteIncrement: 5,
        mode: "single",
        monthSelectorType: "dropdown",
        nextArrow: "<svg version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 17 17'><g></g><path d='M13.207 8.472l-7.854 7.854-0.707-0.707 7.146-7.146-7.146-7.148 0.707-0.707 7.854 7.854z' /></svg>",
        noCalendar: !1,
        now: new Date,
        onChange: [],
        onClose: [],
        onDayCreate: [],
        onDestroy: [],
        onKeyDown: [],
        onMonthChange: [],
        onOpen: [],
        onParseConfig: [],
        onReady: [],
        onValueUpdate: [],
        onYearChange: [],
        onPreCalendarPosition: [],
        plugins: [],
        position: "auto",
        positionElement: void 0,
        prevArrow: "<svg version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 17 17'><g></g><path d='M5.207 8.471l7.146 7.147-0.707 0.707-7.853-7.854 7.854-7.853 0.707 0.707-7.147 7.146z' /></svg>",
        shorthandCurrentMonth: !1,
        showMonths: 1,
        static: !1,
        time_24hr: !1,
        weekNumbers: !1,
        wrap: !1
    },
    ue = {
        weekdays: {
            shorthand: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            longhand: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        },
        months: {
            shorthand: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            longhand: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
        },
        daysInMonth: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
        firstDayOfWeek: 0,
        ordinal: function(a) {
            var i = a % 100;
            if (i > 3 && i < 21) return "th";
            switch (i % 10) {
                case 1:
                    return "st";
                case 2:
                    return "nd";
                case 3:
                    return "rd";
                default:
                    return "th"
            }
        },
        rangeSeparator: " to ",
        weekAbbreviation: "Wk",
        scrollTitle: "Scroll to increment",
        toggleTitle: "Click to toggle",
        amPM: ["AM", "PM"],
        yearAriaLabel: "Year",
        monthAriaLabel: "Month",
        hourAriaLabel: "Hour",
        minuteAriaLabel: "Minute",
        time_24hr: !1
    },
    P = function(a, i) {
        return i === void 0 && (i = 2), ("000" + a).slice(i * -1)
    },
    L = function(a) {
        return a === !0 ? 1 : 0
    };

function nn(a, i) {
    var e;
    return function() {
        var u = this,
            s = arguments;
        clearTimeout(e), e = setTimeout(function() {
            return a.apply(u, s)
        }, i)
    }
}
var Ie = function(a) {
    return a instanceof Array ? a : [a]
};

function N(a, i, e) {
    if (e === !0) return a.classList.add(i);
    a.classList.remove(i)
}

function x(a, i, e) {
    var u = window.document.createElement(a);
    return i = i || "", e = e || "", u.className = i, e !== void 0 && (u.textContent = e), u
}

function ve(a) {
    for (; a.firstChild;) a.removeChild(a.firstChild)
}

function un(a, i) {
    if (i(a)) return a;
    if (a.parentNode) return un(a.parentNode, i)
}

function De(a, i) {
    var e = x("div", "numInputWrapper"),
        u = x("input", "numInput " + a),
        s = x("span", "arrowUp"),
        m = x("span", "arrowDown");
    if (navigator.userAgent.indexOf("MSIE 9.0") === -1 ? u.type = "number" : (u.type = "text", u.pattern = "\\d*"), i !== void 0)
        for (var p in i) u.setAttribute(p, i[p]);
    return e.appendChild(u), e.appendChild(s), e.appendChild(m), e
}

function H(a) {
    try {
        if (typeof a.composedPath == "function") {
            var i = a.composedPath();
            return i[0]
        }
        return a.target
    } catch {
        return a.target
    }
}
var Oe = function() {},
    Me = function(a, i, e) {
        return e.months[i ? "shorthand" : "longhand"][a]
    },
    rt = {
        D: Oe,
        F: function(a, i, e) {
            a.setMonth(e.months.longhand.indexOf(i))
        },
        G: function(a, i) {
            a.setHours((a.getHours() >= 12 ? 12 : 0) + parseFloat(i))
        },
        H: function(a, i) {
            a.setHours(parseFloat(i))
        },
        J: function(a, i) {
            a.setDate(parseFloat(i))
        },
        K: function(a, i, e) {
            a.setHours(a.getHours() % 12 + 12 * L(new RegExp(e.amPM[1], "i").test(i)))
        },
        M: function(a, i, e) {
            a.setMonth(e.months.shorthand.indexOf(i))
        },
        S: function(a, i) {
            a.setSeconds(parseFloat(i))
        },
        U: function(a, i) {
            return new Date(parseFloat(i) * 1e3)
        },
        W: function(a, i, e) {
            var u = parseInt(i),
                s = new Date(a.getFullYear(), 0, 2 + (u - 1) * 7, 0, 0, 0, 0);
            return s.setDate(s.getDate() - s.getDay() + e.firstDayOfWeek), s
        },
        Y: function(a, i) {
            a.setFullYear(parseFloat(i))
        },
        Z: function(a, i) {
            return new Date(i)
        },
        d: function(a, i) {
            a.setDate(parseFloat(i))
        },
        h: function(a, i) {
            a.setHours((a.getHours() >= 12 ? 12 : 0) + parseFloat(i))
        },
        i: function(a, i) {
            a.setMinutes(parseFloat(i))
        },
        j: function(a, i) {
            a.setDate(parseFloat(i))
        },
        l: Oe,
        m: function(a, i) {
            a.setMonth(parseFloat(i) - 1)
        },
        n: function(a, i) {
            a.setMonth(parseFloat(i) - 1)
        },
        s: function(a, i) {
            a.setSeconds(parseFloat(i))
        },
        u: function(a, i) {
            return new Date(parseFloat(i))
        },
        w: Oe,
        y: function(a, i) {
            a.setFullYear(2e3 + parseFloat(i))
        }
    },
    X = {
        D: "",
        F: "",
        G: "(\\d\\d|\\d)",
        H: "(\\d\\d|\\d)",
        J: "(\\d\\d|\\d)\\w+",
        K: "",
        M: "",
        S: "(\\d\\d|\\d)",
        U: "(.+)",
        W: "(\\d\\d|\\d)",
        Y: "(\\d{4})",
        Z: "(.+)",
        d: "(\\d\\d|\\d)",
        h: "(\\d\\d|\\d)",
        i: "(\\d\\d|\\d)",
        j: "(\\d\\d|\\d)",
        l: "",
        m: "(\\d\\d|\\d)",
        n: "(\\d\\d|\\d)",
        s: "(\\d\\d|\\d)",
        u: "(.+)",
        w: "(\\d\\d|\\d)",
        y: "(\\d{2})"
    },
    le = {
        Z: function(a) {
            return a.toISOString()
        },
        D: function(a, i, e) {
            return i.weekdays.shorthand[le.w(a, i, e)]
        },
        F: function(a, i, e) {
            return Me(le.n(a, i, e) - 1, !1, i)
        },
        G: function(a, i, e) {
            return P(le.h(a, i, e))
        },
        H: function(a) {
            return P(a.getHours())
        },
        J: function(a, i) {
            return i.ordinal !== void 0 ? a.getDate() + i.ordinal(a.getDate()) : a.getDate()
        },
        K: function(a, i) {
            return i.amPM[L(a.getHours() > 11)]
        },
        M: function(a, i) {
            return Me(a.getMonth(), !0, i)
        },
        S: function(a) {
            return P(a.getSeconds())
        },
        U: function(a) {
            return a.getTime() / 1e3
        },
        W: function(a, i, e) {
            return e.getWeek(a)
        },
        Y: function(a) {
            return P(a.getFullYear(), 4)
        },
        d: function(a) {
            return P(a.getDate())
        },
        h: function(a) {
            return a.getHours() % 12 ? a.getHours() % 12 : 12
        },
        i: function(a) {
            return P(a.getMinutes())
        },
        j: function(a) {
            return a.getDate()
        },
        l: function(a, i) {
            return i.weekdays.longhand[a.getDay()]
        },
        m: function(a) {
            return P(a.getMonth() + 1)
        },
        n: function(a) {
            return a.getMonth() + 1
        },
        s: function(a) {
            return a.getSeconds()
        },
        u: function(a) {
            return a.getTime()
        },
        w: function(a) {
            return a.getDay()
        },
        y: function(a) {
            return String(a.getFullYear()).substring(2)
        }
    },
    fn = function(a) {
        var i = a.config,
            e = i === void 0 ? te : i,
            u = a.l10n,
            s = u === void 0 ? ue : u,
            m = a.isMobile,
            p = m === void 0 ? !1 : m;
        return function(M, E, b) {
            var h = b || s;
            return e.formatDate !== void 0 && !p ? e.formatDate(M, E, h) : E.split("").map(function(k, O, F) {
                return le[k] && F[O - 1] !== "\\" ? le[k](M, h, e) : k !== "\\" ? k : ""
            }).join("")
        }
    },
    je = function(a) {
        var i = a.config,
            e = i === void 0 ? te : i,
            u = a.l10n,
            s = u === void 0 ? ue : u;
        return function(m, p, M, E) {
            if (!(m !== 0 && !m)) {
                var b = E || s,
                    h, k = m;
                if (m instanceof Date) h = new Date(m.getTime());
                else if (typeof m != "string" && m.toFixed !== void 0) h = new Date(m);
                else if (typeof m == "string") {
                    var O = p || (e || te).dateFormat,
                        F = String(m).trim();
                    if (F === "today") h = new Date, M = !0;
                    else if (e && e.parseDate) h = e.parseDate(m, O);
                    else if (/Z$/.test(F) || /GMT$/.test(F)) h = new Date(m);
                    else {
                        for (var U = void 0, w = [], y = 0, V = 0, T = ""; y < O.length; y++) {
                            var J = O[y],
                                q = J === "\\",
                                C = O[y - 1] === "\\" || q;
                            if (X[J] && !C) {
                                T += X[J];
                                var z = new RegExp(T).exec(m);
                                z && (U = !0) && w[J !== "Y" ? "push" : "unshift"]({
                                    fn: rt[J],
                                    val: z[++V]
                                })
                            } else q || (T += ".")
                        }
                        h = !e || !e.noCalendar ? new Date(new Date().getFullYear(), 0, 1, 0, 0, 0, 0) : new Date(new Date().setHours(0, 0, 0, 0)), w.forEach(function(Q) {
                            var W = Q.fn,
                                G = Q.val;
                            return h = W(h, G, b) || h
                        }), h = U ? h : void 0
                    }
                }
                if (!(h instanceof Date && !isNaN(h.getTime()))) {
                    e.errorHandler(new Error("Invalid date provided: " + k));
                    return
                }
                return M === !0 && h.setHours(0, 0, 0, 0), h
            }
        }
    };

function j(a, i, e) {
    return e === void 0 && (e = !0), e !== !1 ? new Date(a.getTime()).setHours(0, 0, 0, 0) - new Date(i.getTime()).setHours(0, 0, 0, 0) : a.getTime() - i.getTime()
}
var ot = function(a, i, e) {
        return a > Math.min(i, e) && a < Math.max(i, e)
    },
    Fe = function(a, i, e) {
        return a * 3600 + i * 60 + e
    },
    lt = function(a) {
        var i = Math.floor(a / 3600),
            e = (a - i * 3600) / 60;
        return [i, e, a - i * 3600 - e * 60]
    },
    ut = {
        DAY: 864e5
    };

function Ae(a) {
    var i = a.defaultHour,
        e = a.defaultMinute,
        u = a.defaultSeconds;
    if (a.minDate !== void 0) {
        var s = a.minDate.getHours(),
            m = a.minDate.getMinutes(),
            p = a.minDate.getSeconds();
        i < s && (i = s), i === s && e < m && (e = m), i === s && e === m && u < p && (u = a.minDate.getSeconds())
    }
    if (a.maxDate !== void 0) {
        var M = a.maxDate.getHours(),
            E = a.maxDate.getMinutes();
        i = Math.min(i, M), i === M && (e = Math.min(E, e)), i === M && e === E && (u = a.maxDate.getSeconds())
    }
    return {
        hours: i,
        minutes: e,
        seconds: u
    }
}
typeof Object.assign != "function" && (Object.assign = function(a) {
    for (var i = [], e = 1; e < arguments.length; e++) i[e - 1] = arguments[e];
    if (!a) throw TypeError("Cannot convert undefined or null to object");
    for (var u = function(M) {
            M && Object.keys(M).forEach(function(E) {
                return a[E] = M[E]
            })
        }, s = 0, m = i; s < m.length; s++) {
        var p = m[s];
        u(p)
    }
    return a
});
var A = function() {
        return A = Object.assign || function(a) {
            for (var i, e = 1, u = arguments.length; e < u; e++) {
                i = arguments[e];
                for (var s in i) Object.prototype.hasOwnProperty.call(i, s) && (a[s] = i[s])
            }
            return a
        }, A.apply(this, arguments)
    },
    tn = function() {
        for (var a = 0, i = 0, e = arguments.length; i < e; i++) a += arguments[i].length;
        for (var u = Array(a), s = 0, i = 0; i < e; i++)
            for (var m = arguments[i], p = 0, M = m.length; p < M; p++, s++) u[s] = m[p];
        return u
    },
    ft = 300;

function st(a, i) {
    var e = {
        config: A(A({}, te), I.defaultConfig),
        l10n: ue
    };
    e.parseDate = je({
        config: e.config,
        l10n: e.l10n
    }), e._handlers = [], e.pluginElements = [], e.loadedPlugins = [], e._bind = w, e._setHoursFromDate = O, e._positionCalendar = me, e.changeMonth = we, e.changeYear = se, e.clear = pn, e.close = hn, e.onMouseOver = ce, e._createElement = x, e.createDay = z, e.destroy = vn, e.isEnabled = Z, e.jumpToDate = T, e.updateValue = K, e.open = Mn, e.redraw = Ve, e.set = xn, e.setDate = En, e.toggle = Tn;

    function u() {
        e.utils = {
            getDaysInMonth: function(n, t) {
                return n === void 0 && (n = e.currentMonth), t === void 0 && (t = e.currentYear), n === 1 && (t % 4 === 0 && t % 100 !== 0 || t % 400 === 0) ? 29 : e.l10n.daysInMonth[n]
            }
        }
    }

    function s() {
        e.element = e.input = a, e.isOpen = !1, wn(), Ue(), _n(), kn(), u(), e.isMobile || C(), V(), (e.selectedDates.length || e.config.noCalendar) && (e.config.enableTime && O(e.config.noCalendar ? e.latestSelectedDateObj : void 0), K(!1)), M();
        var n = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
        !e.isMobile && n && me(), S("onReady")
    }

    function m() {
        var n;
        return ((n = e.calendarContainer) === null || n === void 0 ? void 0 : n.getRootNode()).activeElement || document.activeElement
    }

    function p(n) {
        return n.bind(e)
    }

    function M() {
        var n = e.config;
        n.weekNumbers === !1 && n.showMonths === 1 || n.noCalendar !== !0 && window.requestAnimationFrame(function() {
            if (e.calendarContainer !== void 0 && (e.calendarContainer.style.visibility = "hidden", e.calendarContainer.style.display = "block"), e.daysContainer !== void 0) {
                var t = (e.days.offsetWidth + 1) * n.showMonths;
                e.daysContainer.style.width = t + "px", e.calendarContainer.style.width = t + (e.weekWrapper !== void 0 ? e.weekWrapper.offsetWidth : 0) + "px", e.calendarContainer.style.removeProperty("visibility"), e.calendarContainer.style.removeProperty("display")
            }
        })
    }

    function E(n) {
        if (e.selectedDates.length === 0) {
            var t = e.config.minDate === void 0 || j(new Date, e.config.minDate) >= 0 ? new Date : new Date(e.config.minDate.getTime()),
                r = Ae(e.config);
            t.setHours(r.hours, r.minutes, r.seconds, t.getMilliseconds()), e.selectedDates = [t], e.latestSelectedDateObj = t
        }
        n !== void 0 && n.type !== "blur" && Fn(n);
        var o = e._input.value;
        k(), K(), e._input.value !== o && e._debouncedChange()
    }

    function b(n, t) {
        return n % 12 + 12 * L(t === e.l10n.amPM[1])
    }

    function h(n) {
        switch (n % 24) {
            case 0:
            case 12:
                return 12;
            default:
                return n % 12
        }
    }

    function k() {
        if (!(e.hourElement === void 0 || e.minuteElement === void 0)) {
            var n = (parseInt(e.hourElement.value.slice(-2), 10) || 0) % 24,
                t = (parseInt(e.minuteElement.value, 10) || 0) % 60,
                r = e.secondElement !== void 0 ? (parseInt(e.secondElement.value, 10) || 0) % 60 : 0;
            e.amPM !== void 0 && (n = b(n, e.amPM.textContent));
            var o = e.config.minTime !== void 0 || e.config.minDate && e.minDateHasTime && e.latestSelectedDateObj && j(e.latestSelectedDateObj, e.config.minDate, !0) === 0,
                l = e.config.maxTime !== void 0 || e.config.maxDate && e.maxDateHasTime && e.latestSelectedDateObj && j(e.latestSelectedDateObj, e.config.maxDate, !0) === 0;
            if (e.config.maxTime !== void 0 && e.config.minTime !== void 0 && e.config.minTime > e.config.maxTime) {
                var f = Fe(e.config.minTime.getHours(), e.config.minTime.getMinutes(), e.config.minTime.getSeconds()),
                    v = Fe(e.config.maxTime.getHours(), e.config.maxTime.getMinutes(), e.config.maxTime.getSeconds()),
                    c = Fe(n, t, r);
                if (c > v && c < f) {
                    var D = lt(f);
                    n = D[0], t = D[1], r = D[2]
                }
            } else {
                if (l) {
                    var d = e.config.maxTime !== void 0 ? e.config.maxTime : e.config.maxDate;
                    n = Math.min(n, d.getHours()), n === d.getHours() && (t = Math.min(t, d.getMinutes())), t === d.getMinutes() && (r = Math.min(r, d.getSeconds()))
                }
                if (o) {
                    var g = e.config.minTime !== void 0 ? e.config.minTime : e.config.minDate;
                    n = Math.max(n, g.getHours()), n === g.getHours() && t < g.getMinutes() && (t = g.getMinutes()), t === g.getMinutes() && (r = Math.max(r, g.getSeconds()))
                }
            }
            F(n, t, r)
        }
    }

    function O(n) {
        var t = n || e.latestSelectedDateObj;
        t && t instanceof Date && F(t.getHours(), t.getMinutes(), t.getSeconds())
    }

    function F(n, t, r) {
        e.latestSelectedDateObj !== void 0 && e.latestSelectedDateObj.setHours(n % 24, t, r || 0, 0), !(!e.hourElement || !e.minuteElement || e.isMobile) && (e.hourElement.value = P(e.config.time_24hr ? n : (12 + n) % 12 + 12 * L(n % 12 === 0)), e.minuteElement.value = P(t), e.amPM !== void 0 && (e.amPM.textContent = e.l10n.amPM[L(n >= 12)]), e.secondElement !== void 0 && (e.secondElement.value = P(r)))
    }

    function U(n) {
        var t = H(n),
            r = parseInt(t.value) + (n.delta || 0);
        (r / 1e3 > 1 || n.key === "Enter" && !/[^\d]/.test(r.toString())) && se(r)
    }

    function w(n, t, r, o) {
        if (t instanceof Array) return t.forEach(function(l) {
            return w(n, l, r, o)
        });
        if (n instanceof Array) return n.forEach(function(l) {
            return w(l, t, r, o)
        });
        n.addEventListener(t, r, o), e._handlers.push({
            remove: function() {
                return n.removeEventListener(t, r, o)
            }
        })
    }

    function y() {
        S("onChange")
    }

    function V() {
        if (e.config.wrap && ["open", "close", "toggle", "clear"].forEach(function(r) {
                Array.prototype.forEach.call(e.element.querySelectorAll("[data-" + r + "]"), function(o) {
                    return w(o, "click", e[r])
                })
            }), e.isMobile) {
            Sn();
            return
        }
        var n = nn(bn, 50);
        if (e._debouncedChange = nn(y, ft), e.daysContainer && !/iPhone|iPad|iPod/i.test(navigator.userAgent) && w(e.daysContainer, "mouseover", function(r) {
                e.config.mode === "range" && ce(H(r))
            }), w(e._input, "keydown", Be), e.calendarContainer !== void 0 && w(e.calendarContainer, "keydown", Be), !e.config.inline && !e.config.static && w(window, "resize", n), window.ontouchstart !== void 0 ? w(window.document, "touchstart", ye) : w(window.document, "mousedown", ye), w(window.document, "focus", ye, {
                capture: !0
            }), e.config.clickOpens === !0 && (w(e._input, "focus", e.open), w(e._input, "click", e.open)), e.daysContainer !== void 0 && (w(e.monthNav, "click", On), w(e.monthNav, ["keyup", "increment"], U), w(e.daysContainer, "click", qe)), e.timeContainer !== void 0 && e.minuteElement !== void 0 && e.hourElement !== void 0) {
            var t = function(r) {
                return H(r).select()
            };
            w(e.timeContainer, ["increment"], E), w(e.timeContainer, "blur", E, {
                capture: !0
            }), w(e.timeContainer, "click", J), w([e.hourElement, e.minuteElement], ["focus", "click"], t), e.secondElement !== void 0 && w(e.secondElement, "focus", function() {
                return e.secondElement && e.secondElement.select()
            }), e.amPM !== void 0 && w(e.amPM, "click", function(r) {
                E(r)
            })
        }
        e.config.allowInput && w(e._input, "blur", Dn)
    }

    function T(n, t) {
        var r = n !== void 0 ? e.parseDate(n) : e.latestSelectedDateObj || (e.config.minDate && e.config.minDate > e.now ? e.config.minDate : e.config.maxDate && e.config.maxDate < e.now ? e.config.maxDate : e.now),
            o = e.currentYear,
            l = e.currentMonth;
        try {
            r !== void 0 && (e.currentYear = r.getFullYear(), e.currentMonth = r.getMonth())
        } catch (f) {
            f.message = "Invalid date supplied: " + r, e.config.errorHandler(f)
        }
        t && e.currentYear !== o && (S("onYearChange"), $()), t && (e.currentYear !== o || e.currentMonth !== l) && S("onMonthChange"), e.redraw()
    }

    function J(n) {
        var t = H(n);
        ~t.className.indexOf("arrow") && q(n, t.classList.contains("arrowUp") ? 1 : -1)
    }

    function q(n, t, r) {
        var o = n && H(n),
            l = r || o && o.parentNode && o.parentNode.firstChild,
            f = xe("increment");
        f.delta = t, l && l.dispatchEvent(f)
    }

    function C() {
        var n = window.document.createDocumentFragment();
        if (e.calendarContainer = x("div", "flatpickr-calendar"), e.calendarContainer.tabIndex = -1, !e.config.noCalendar) {
            if (n.appendChild(cn()), e.innerContainer = x("div", "flatpickr-innerContainer"), e.config.weekNumbers) {
                var t = gn(),
                    r = t.weekWrapper,
                    o = t.weekNumbers;
                e.innerContainer.appendChild(r), e.weekNumbers = o, e.weekWrapper = r
            }
            e.rContainer = x("div", "flatpickr-rContainer"), e.rContainer.appendChild(We()), e.daysContainer || (e.daysContainer = x("div", "flatpickr-days"), e.daysContainer.tabIndex = -1), fe(), e.rContainer.appendChild(e.daysContainer), e.innerContainer.appendChild(e.rContainer), n.appendChild(e.innerContainer)
        }
        e.config.enableTime && n.appendChild(mn()), N(e.calendarContainer, "rangeMode", e.config.mode === "range"), N(e.calendarContainer, "animate", e.config.animate === !0), N(e.calendarContainer, "multiMonth", e.config.showMonths > 1), e.calendarContainer.appendChild(n);
        var l = e.config.appendTo !== void 0 && e.config.appendTo.nodeType !== void 0;
        if ((e.config.inline || e.config.static) && (e.calendarContainer.classList.add(e.config.inline ? "inline" : "static"), e.config.inline && (!l && e.element.parentNode ? e.element.parentNode.insertBefore(e.calendarContainer, e._input.nextSibling) : e.config.appendTo !== void 0 && e.config.appendTo.appendChild(e.calendarContainer)), e.config.static)) {
            var f = x("div", "flatpickr-wrapper");
            e.element.parentNode && e.element.parentNode.insertBefore(f, e.element), f.appendChild(e.element), e.altInput && f.appendChild(e.altInput), f.appendChild(e.calendarContainer)
        }!e.config.static && !e.config.inline && (e.config.appendTo !== void 0 ? e.config.appendTo : window.document.body).appendChild(e.calendarContainer)
    }

    function z(n, t, r, o) {
        var l = Z(t, !0),
            f = x("span", n, t.getDate().toString());
        return f.dateObj = t, f.$i = o, f.setAttribute("aria-label", e.formatDate(t, e.config.ariaDateFormat)), n.indexOf("hidden") === -1 && j(t, e.now) === 0 && (e.todayDateElem = f, f.classList.add("today"), f.setAttribute("aria-current", "date")), l ? (f.tabIndex = -1, Ee(t) && (f.classList.add("selected"), e.selectedDateElem = f, e.config.mode === "range" && (N(f, "startRange", e.selectedDates[0] && j(t, e.selectedDates[0], !0) === 0), N(f, "endRange", e.selectedDates[1] && j(t, e.selectedDates[1], !0) === 0), n === "nextMonthDay" && f.classList.add("inRange")))) : f.classList.add("flatpickr-disabled"), e.config.mode === "range" && In(t) && !Ee(t) && f.classList.add("inRange"), e.weekNumbers && e.config.showMonths === 1 && n !== "prevMonthDay" && o % 7 === 6 && e.weekNumbers.insertAdjacentHTML("beforeend", "<span class='flatpickr-day'>" + e.config.getWeek(t) + "</span>"), S("onDayCreate", f), f
    }

    function Q(n) {
        n.focus(), e.config.mode === "range" && ce(n)
    }

    function W(n) {
        for (var t = n > 0 ? 0 : e.config.showMonths - 1, r = n > 0 ? e.config.showMonths : -1, o = t; o != r; o += n)
            for (var l = e.daysContainer.children[o], f = n > 0 ? 0 : l.children.length - 1, v = n > 0 ? l.children.length : -1, c = f; c != v; c += n) {
                var D = l.children[c];
                if (D.className.indexOf("hidden") === -1 && Z(D.dateObj)) return D
            }
    }

    function G(n, t) {
        for (var r = n.className.indexOf("Month") === -1 ? n.dateObj.getMonth() : e.currentMonth, o = t > 0 ? e.config.showMonths : -1, l = t > 0 ? 1 : -1, f = r - e.currentMonth; f != o; f += l)
            for (var v = e.daysContainer.children[f], c = r - e.currentMonth === f ? n.$i + t : t < 0 ? v.children.length - 1 : 0, D = v.children.length, d = c; d >= 0 && d < D && d != (t > 0 ? D : -1); d += l) {
                var g = v.children[d];
                if (g.className.indexOf("hidden") === -1 && Z(g.dateObj) && Math.abs(n.$i - d) >= Math.abs(t)) return Q(g)
            }
        e.changeMonth(l), ie(W(l), 0)
    }

    function ie(n, t) {
        var r = m(),
            o = de(r || document.body),
            l = n !== void 0 ? n : o ? r : e.selectedDateElem !== void 0 && de(e.selectedDateElem) ? e.selectedDateElem : e.todayDateElem !== void 0 && de(e.todayDateElem) ? e.todayDateElem : W(t > 0 ? 1 : -1);
        l === void 0 ? e._input.focus() : o ? G(l, t) : Q(l)
    }

    function sn(n, t) {
        for (var r = (new Date(n, t, 1).getDay() - e.l10n.firstDayOfWeek + 7) % 7, o = e.utils.getDaysInMonth((t - 1 + 12) % 12, n), l = e.utils.getDaysInMonth(t, n), f = window.document.createDocumentFragment(), v = e.config.showMonths > 1, c = v ? "prevMonthDay hidden" : "prevMonthDay", D = v ? "nextMonthDay hidden" : "nextMonthDay", d = o + 1 - r, g = 0; d <= o; d++, g++) f.appendChild(z("flatpickr-day " + c, new Date(n, t - 1, d), d, g));
        for (d = 1; d <= l; d++, g++) f.appendChild(z("flatpickr-day", new Date(n, t, d), d, g));
        for (var _ = l + 1; _ <= 42 - r && (e.config.showMonths === 1 || g % 7 !== 0); _++, g++) f.appendChild(z("flatpickr-day " + D, new Date(n, t + 1, _ % l), _, g));
        var B = x("div", "dayContainer");
        return B.appendChild(f), B
    }

    function fe() {
        if (e.daysContainer !== void 0) {
            ve(e.daysContainer), e.weekNumbers && ve(e.weekNumbers);
            for (var n = document.createDocumentFragment(), t = 0; t < e.config.showMonths; t++) {
                var r = new Date(e.currentYear, e.currentMonth, 1);
                r.setMonth(e.currentMonth + t), n.appendChild(sn(r.getFullYear(), r.getMonth()))
            }
            e.daysContainer.appendChild(n), e.days = e.daysContainer.firstChild, e.config.mode === "range" && e.selectedDates.length === 1 && ce()
        }
    }

    function $() {
        if (!(e.config.showMonths > 1 || e.config.monthSelectorType !== "dropdown")) {
            var n = function(o) {
                return e.config.minDate !== void 0 && e.currentYear === e.config.minDate.getFullYear() && o < e.config.minDate.getMonth() ? !1 : !(e.config.maxDate !== void 0 && e.currentYear === e.config.maxDate.getFullYear() && o > e.config.maxDate.getMonth())
            };
            e.monthsDropdownContainer.tabIndex = -1, e.monthsDropdownContainer.innerHTML = "";
            for (var t = 0; t < 12; t++)
                if (n(t)) {
                    var r = x("option", "flatpickr-monthDropdown-month");
                    r.value = new Date(e.currentYear, t).getMonth().toString(), r.textContent = Me(t, e.config.shorthandCurrentMonth, e.l10n), r.tabIndex = -1, e.currentMonth === t && (r.selected = !0), e.monthsDropdownContainer.appendChild(r)
                }
        }
    }

    function dn() {
        var n = x("div", "flatpickr-month"),
            t = window.document.createDocumentFragment(),
            r;
        e.config.showMonths > 1 || e.config.monthSelectorType === "static" ? r = x("span", "cur-month") : (e.monthsDropdownContainer = x("select", "flatpickr-monthDropdown-months"), e.monthsDropdownContainer.setAttribute("aria-label", e.l10n.monthAriaLabel), w(e.monthsDropdownContainer, "change", function(v) {
            var c = H(v),
                D = parseInt(c.value, 10);
            e.changeMonth(D - e.currentMonth), S("onMonthChange")
        }), $(), r = e.monthsDropdownContainer);
        var o = De("cur-year", {
                tabindex: "-1"
            }),
            l = o.getElementsByTagName("input")[0];
        l.setAttribute("aria-label", e.l10n.yearAriaLabel), e.config.minDate && l.setAttribute("min", e.config.minDate.getFullYear().toString()), e.config.maxDate && (l.setAttribute("max", e.config.maxDate.getFullYear().toString()), l.disabled = !!e.config.minDate && e.config.minDate.getFullYear() === e.config.maxDate.getFullYear());
        var f = x("div", "flatpickr-current-month");
        return f.appendChild(r), f.appendChild(o), t.appendChild(f), n.appendChild(t), {
            container: n,
            yearElement: l,
            monthElement: r
        }
    }

    function Le() {
        ve(e.monthNav), e.monthNav.appendChild(e.prevMonthNav), e.config.showMonths && (e.yearElements = [], e.monthElements = []);
        for (var n = e.config.showMonths; n--;) {
            var t = dn();
            e.yearElements.push(t.yearElement), e.monthElements.push(t.monthElement), e.monthNav.appendChild(t.container)
        }
        e.monthNav.appendChild(e.nextMonthNav)
    }

    function cn() {
        return e.monthNav = x("div", "flatpickr-months"), e.yearElements = [], e.monthElements = [], e.prevMonthNav = x("span", "flatpickr-prev-month"), e.prevMonthNav.innerHTML = e.config.prevArrow, e.nextMonthNav = x("span", "flatpickr-next-month"), e.nextMonthNav.innerHTML = e.config.nextArrow, Le(), Object.defineProperty(e, "_hidePrevMonthArrow", {
            get: function() {
                return e.__hidePrevMonthArrow
            },
            set: function(n) {
                e.__hidePrevMonthArrow !== n && (N(e.prevMonthNav, "flatpickr-disabled", n), e.__hidePrevMonthArrow = n)
            }
        }), Object.defineProperty(e, "_hideNextMonthArrow", {
            get: function() {
                return e.__hideNextMonthArrow
            },
            set: function(n) {
                e.__hideNextMonthArrow !== n && (N(e.nextMonthNav, "flatpickr-disabled", n), e.__hideNextMonthArrow = n)
            }
        }), e.currentYearElement = e.yearElements[0], pe(), e.monthNav
    }

    function mn() {
        e.calendarContainer.classList.add("hasTime"), e.config.noCalendar && e.calendarContainer.classList.add("noCalendar");
        var n = Ae(e.config);
        e.timeContainer = x("div", "flatpickr-time"), e.timeContainer.tabIndex = -1;
        var t = x("span", "flatpickr-time-separator", ":"),
            r = De("flatpickr-hour", {
                "aria-label": e.l10n.hourAriaLabel
            });
        e.hourElement = r.getElementsByTagName("input")[0];
        var o = De("flatpickr-minute", {
            "aria-label": e.l10n.minuteAriaLabel
        });
        if (e.minuteElement = o.getElementsByTagName("input")[0], e.hourElement.tabIndex = e.minuteElement.tabIndex = -1, e.hourElement.value = P(e.latestSelectedDateObj ? e.latestSelectedDateObj.getHours() : e.config.time_24hr ? n.hours : h(n.hours)), e.minuteElement.value = P(e.latestSelectedDateObj ? e.latestSelectedDateObj.getMinutes() : n.minutes), e.hourElement.setAttribute("step", e.config.hourIncrement.toString()), e.minuteElement.setAttribute("step", e.config.minuteIncrement.toString()), e.hourElement.setAttribute("min", e.config.time_24hr ? "0" : "1"), e.hourElement.setAttribute("max", e.config.time_24hr ? "23" : "12"), e.hourElement.setAttribute("maxlength", "2"), e.minuteElement.setAttribute("min", "0"), e.minuteElement.setAttribute("max", "59"), e.minuteElement.setAttribute("maxlength", "2"), e.timeContainer.appendChild(r), e.timeContainer.appendChild(t), e.timeContainer.appendChild(o), e.config.time_24hr && e.timeContainer.classList.add("time24hr"), e.config.enableSeconds) {
            e.timeContainer.classList.add("hasSeconds");
            var l = De("flatpickr-second");
            e.secondElement = l.getElementsByTagName("input")[0], e.secondElement.value = P(e.latestSelectedDateObj ? e.latestSelectedDateObj.getSeconds() : n.seconds), e.secondElement.setAttribute("step", e.minuteElement.getAttribute("step")), e.secondElement.setAttribute("min", "0"), e.secondElement.setAttribute("max", "59"), e.secondElement.setAttribute("maxlength", "2"), e.timeContainer.appendChild(x("span", "flatpickr-time-separator", ":")), e.timeContainer.appendChild(l)
        }
        return e.config.time_24hr || (e.amPM = x("span", "flatpickr-am-pm", e.l10n.amPM[L((e.latestSelectedDateObj ? e.hourElement.value : e.config.defaultHour) > 11)]), e.amPM.title = e.l10n.toggleTitle, e.amPM.tabIndex = -1, e.timeContainer.appendChild(e.amPM)), e.timeContainer
    }

    function We() {
        e.weekdayContainer ? ve(e.weekdayContainer) : e.weekdayContainer = x("div", "flatpickr-weekdays");
        for (var n = e.config.showMonths; n--;) {
            var t = x("div", "flatpickr-weekdaycontainer");
            e.weekdayContainer.appendChild(t)
        }
        return Re(), e.weekdayContainer
    }

    function Re() {
        if (e.weekdayContainer) {
            var n = e.l10n.firstDayOfWeek,
                t = tn(e.l10n.weekdays.shorthand);
            n > 0 && n < t.length && (t = tn(t.splice(n, t.length), t.splice(0, n)));
            for (var r = e.config.showMonths; r--;) e.weekdayContainer.children[r].innerHTML = `
      <span class='flatpickr-weekday'>
        ` + t.join("</span><span class='flatpickr-weekday'>") + `
      </span>
      `
        }
    }

    function gn() {
        e.calendarContainer.classList.add("hasWeeks");
        var n = x("div", "flatpickr-weekwrapper");
        n.appendChild(x("span", "flatpickr-weekday", e.l10n.weekAbbreviation));
        var t = x("div", "flatpickr-weeks");
        return n.appendChild(t), {
            weekWrapper: n,
            weekNumbers: t
        }
    }

    function we(n, t) {
        t === void 0 && (t = !0);
        var r = t ? n : n - e.currentMonth;
        r < 0 && e._hidePrevMonthArrow === !0 || r > 0 && e._hideNextMonthArrow === !0 || (e.currentMonth += r, (e.currentMonth < 0 || e.currentMonth > 11) && (e.currentYear += e.currentMonth > 11 ? 1 : -1, e.currentMonth = (e.currentMonth + 12) % 12, S("onYearChange"), $()), fe(), S("onMonthChange"), pe())
    }

    function pn(n, t) {
        if (n === void 0 && (n = !0), t === void 0 && (t = !0), e.input.value = "", e.altInput !== void 0 && (e.altInput.value = ""), e.mobileInput !== void 0 && (e.mobileInput.value = ""), e.selectedDates = [], e.latestSelectedDateObj = void 0, t === !0 && (e.currentYear = e._initialDate.getFullYear(), e.currentMonth = e._initialDate.getMonth()), e.config.enableTime === !0) {
            var r = Ae(e.config),
                o = r.hours,
                l = r.minutes,
                f = r.seconds;
            F(o, l, f)
        }
        e.redraw(), n && S("onChange")
    }

    function hn() {
        e.isOpen = !1, e.isMobile || (e.calendarContainer !== void 0 && e.calendarContainer.classList.remove("open"), e._input !== void 0 && e._input.classList.remove("active")), S("onClose")
    }

    function vn() {
        e.config !== void 0 && S("onDestroy");
        for (var n = e._handlers.length; n--;) e._handlers[n].remove();
        if (e._handlers = [], e.mobileInput) e.mobileInput.parentNode && e.mobileInput.parentNode.removeChild(e.mobileInput), e.mobileInput = void 0;
        else if (e.calendarContainer && e.calendarContainer.parentNode)
            if (e.config.static && e.calendarContainer.parentNode) {
                var t = e.calendarContainer.parentNode;
                if (t.lastChild && t.removeChild(t.lastChild), t.parentNode) {
                    for (; t.firstChild;) t.parentNode.insertBefore(t.firstChild, t);
                    t.parentNode.removeChild(t)
                }
            } else e.calendarContainer.parentNode.removeChild(e.calendarContainer);
        e.altInput && (e.input.type = "text", e.altInput.parentNode && e.altInput.parentNode.removeChild(e.altInput), delete e.altInput), e.input && (e.input.type = e.input._type, e.input.classList.remove("flatpickr-input"), e.input.removeAttribute("readonly")), ["_showTimeInput", "latestSelectedDateObj", "_hideNextMonthArrow", "_hidePrevMonthArrow", "__hideNextMonthArrow", "__hidePrevMonthArrow", "isMobile", "isOpen", "selectedDateElem", "minDateHasTime", "maxDateHasTime", "days", "daysContainer", "_input", "_positionElement", "innerContainer", "rContainer", "monthNav", "todayDateElem", "calendarContainer", "weekdayContainer", "prevMonthNav", "nextMonthNav", "monthsDropdownContainer", "currentMonthElement", "currentYearElement", "navigationCurrentMonth", "selectedDateElem", "config"].forEach(function(r) {
            try {
                delete e[r]
            } catch {}
        })
    }

    function re(n) {
        return e.calendarContainer.contains(n)
    }

    function ye(n) {
        if (e.isOpen && !e.config.inline) {
            var t = H(n),
                r = re(t),
                o = t === e.input || t === e.altInput || e.element.contains(t) || n.path && n.path.indexOf && (~n.path.indexOf(e.input) || ~n.path.indexOf(e.altInput)),
                l = !o && !r && !re(n.relatedTarget),
                f = !e.config.ignoredFocusElements.some(function(v) {
                    return v.contains(t)
                });
            l && f && (e.config.allowInput && e.setDate(e._input.value, !1, e.config.altInput ? e.config.altFormat : e.config.dateFormat), e.timeContainer !== void 0 && e.minuteElement !== void 0 && e.hourElement !== void 0 && e.input.value !== "" && e.input.value !== void 0 && E(), e.close(), e.config && e.config.mode === "range" && e.selectedDates.length === 1 && e.clear(!1))
        }
    }

    function se(n) {
        if (!(!n || e.config.minDate && n < e.config.minDate.getFullYear() || e.config.maxDate && n > e.config.maxDate.getFullYear())) {
            var t = n,
                r = e.currentYear !== t;
            e.currentYear = t || e.currentYear, e.config.maxDate && e.currentYear === e.config.maxDate.getFullYear() ? e.currentMonth = Math.min(e.config.maxDate.getMonth(), e.currentMonth) : e.config.minDate && e.currentYear === e.config.minDate.getFullYear() && (e.currentMonth = Math.max(e.config.minDate.getMonth(), e.currentMonth)), r && (e.redraw(), S("onYearChange"), $())
        }
    }

    function Z(n, t) {
        var r;
        t === void 0 && (t = !0);
        var o = e.parseDate(n, void 0, t);
        if (e.config.minDate && o && j(o, e.config.minDate, t !== void 0 ? t : !e.minDateHasTime) < 0 || e.config.maxDate && o && j(o, e.config.maxDate, t !== void 0 ? t : !e.maxDateHasTime) > 0) return !1;
        if (!e.config.enable && e.config.disable.length === 0) return !0;
        if (o === void 0) return !1;
        for (var l = !!e.config.enable, f = (r = e.config.enable) !== null && r !== void 0 ? r : e.config.disable, v = 0, c = void 0; v < f.length; v++) {
            if (c = f[v], typeof c == "function" && c(o)) return l;
            if (c instanceof Date && o !== void 0 && c.getTime() === o.getTime()) return l;
            if (typeof c == "string") {
                var D = e.parseDate(c, void 0, !0);
                return D && D.getTime() === o.getTime() ? l : !l
            } else if (typeof c == "object" && o !== void 0 && c.from && c.to && o.getTime() >= c.from.getTime() && o.getTime() <= c.to.getTime()) return l
        }
        return !l
    }

    function de(n) {
        return e.daysContainer !== void 0 ? n.className.indexOf("hidden") === -1 && n.className.indexOf("flatpickr-disabled") === -1 && e.daysContainer.contains(n) : !1
    }

    function Dn(n) {
        var t = n.target === e._input,
            r = e._input.value.trimEnd() !== ke();
        t && r && !(n.relatedTarget && re(n.relatedTarget)) && e.setDate(e._input.value, !0, n.target === e.altInput ? e.config.altFormat : e.config.dateFormat)
    }

    function Be(n) {
        var t = H(n),
            r = e.config.wrap ? a.contains(t) : t === e._input,
            o = e.config.allowInput,
            l = e.isOpen && (!o || !r),
            f = e.config.inline && r && !o;
        if (n.keyCode === 13 && r) {
            if (o) return e.setDate(e._input.value, !0, t === e.altInput ? e.config.altFormat : e.config.dateFormat), e.close(), t.blur();
            e.open()
        } else if (re(t) || l || f) {
            var v = !!e.timeContainer && e.timeContainer.contains(t);
            switch (n.keyCode) {
                case 13:
                    v ? (n.preventDefault(), E(), Ce()) : qe(n);
                    break;
                case 27:
                    n.preventDefault(), Ce();
                    break;
                case 8:
                case 46:
                    r && !e.config.allowInput && (n.preventDefault(), e.clear());
                    break;
                case 37:
                case 39:
                    if (!v && !r) {
                        n.preventDefault();
                        var c = m();
                        if (e.daysContainer !== void 0 && (o === !1 || c && de(c))) {
                            var D = n.keyCode === 39 ? 1 : -1;
                            n.ctrlKey ? (n.stopPropagation(), we(D), ie(W(1), 0)) : ie(void 0, D)
                        }
                    } else e.hourElement && e.hourElement.focus();
                    break;
                case 38:
                case 40:
                    n.preventDefault();
                    var d = n.keyCode === 40 ? 1 : -1;
                    e.daysContainer && t.$i !== void 0 || t === e.input || t === e.altInput ? n.ctrlKey ? (n.stopPropagation(), se(e.currentYear - d), ie(W(1), 0)) : v || ie(void 0, d * 7) : t === e.currentYearElement ? se(e.currentYear - d) : e.config.enableTime && (!v && e.hourElement && e.hourElement.focus(), E(n), e._debouncedChange());
                    break;
                case 9:
                    if (v) {
                        var g = [e.hourElement, e.minuteElement, e.secondElement, e.amPM].concat(e.pluginElements).filter(function(Y) {
                                return Y
                            }),
                            _ = g.indexOf(t);
                        if (_ !== -1) {
                            var B = g[_ + (n.shiftKey ? -1 : 1)];
                            n.preventDefault(), (B || e._input).focus()
                        }
                    } else !e.config.noCalendar && e.daysContainer && e.daysContainer.contains(t) && n.shiftKey && (n.preventDefault(), e._input.focus());
                    break
            }
        }
        if (e.amPM !== void 0 && t === e.amPM) switch (n.key) {
            case e.l10n.amPM[0].charAt(0):
            case e.l10n.amPM[0].charAt(0).toLowerCase():
                e.amPM.textContent = e.l10n.amPM[0], k(), K();
                break;
            case e.l10n.amPM[1].charAt(0):
            case e.l10n.amPM[1].charAt(0).toLowerCase():
                e.amPM.textContent = e.l10n.amPM[1], k(), K();
                break
        }(r || re(t)) && S("onKeyDown", n)
    }

    function ce(n, t) {
        if (t === void 0 && (t = "flatpickr-day"), !(e.selectedDates.length !== 1 || n && (!n.classList.contains(t) || n.classList.contains("flatpickr-disabled")))) {
            for (var r = n ? n.dateObj.getTime() : e.days.firstElementChild.dateObj.getTime(), o = e.parseDate(e.selectedDates[0], void 0, !0).getTime(), l = Math.min(r, e.selectedDates[0].getTime()), f = Math.max(r, e.selectedDates[0].getTime()), v = !1, c = 0, D = 0, d = l; d < f; d += ut.DAY) Z(new Date(d), !0) || (v = v || d > l && d < f, d < o && (!c || d > c) ? c = d : d > o && (!D || d < D) && (D = d));
            var g = Array.from(e.rContainer.querySelectorAll("*:nth-child(-n+" + e.config.showMonths + ") > ." + t));
            g.forEach(function(_) {
                var B = _.dateObj,
                    Y = B.getTime(),
                    oe = c > 0 && Y < c || D > 0 && Y > D;
                if (oe) {
                    _.classList.add("notAllowed"), ["inRange", "startRange", "endRange"].forEach(function(ee) {
                        _.classList.remove(ee)
                    });
                    return
                } else if (v && !oe) return;
                ["startRange", "inRange", "endRange", "notAllowed"].forEach(function(ee) {
                    _.classList.remove(ee)
                }), n !== void 0 && (n.classList.add(r <= e.selectedDates[0].getTime() ? "startRange" : "endRange"), o < r && Y === o ? _.classList.add("startRange") : o > r && Y === o && _.classList.add("endRange"), Y >= c && (D === 0 || Y <= D) && ot(Y, o, r) && _.classList.add("inRange"))
            })
        }
    }

    function bn() {
        e.isOpen && !e.config.static && !e.config.inline && me()
    }

    function Mn(n, t) {
        if (t === void 0 && (t = e._positionElement), e.isMobile === !0) {
            if (n) {
                n.preventDefault();
                var r = H(n);
                r && r.blur()
            }
            e.mobileInput !== void 0 && (e.mobileInput.focus(), e.mobileInput.click()), S("onOpen");
            return
        } else if (e._input.disabled || e.config.inline) return;
        var o = e.isOpen;
        e.isOpen = !0, o || (e.calendarContainer.classList.add("open"), e._input.classList.add("active"), S("onOpen"), me(t)), e.config.enableTime === !0 && e.config.noCalendar === !0 && e.config.allowInput === !1 && (n === void 0 || !e.timeContainer.contains(n.relatedTarget)) && setTimeout(function() {
            return e.hourElement.select()
        }, 50)
    }

    function Je(n) {
        return function(t) {
            var r = e.config["_" + n + "Date"] = e.parseDate(t, e.config.dateFormat),
                o = e.config["_" + (n === "min" ? "max" : "min") + "Date"];
            r !== void 0 && (e[n === "min" ? "minDateHasTime" : "maxDateHasTime"] = r.getHours() > 0 || r.getMinutes() > 0 || r.getSeconds() > 0), e.selectedDates && (e.selectedDates = e.selectedDates.filter(function(l) {
                return Z(l)
            }), !e.selectedDates.length && n === "min" && O(r), K()), e.daysContainer && (Ve(), r !== void 0 ? e.currentYearElement[n] = r.getFullYear().toString() : e.currentYearElement.removeAttribute(n), e.currentYearElement.disabled = !!o && r !== void 0 && o.getFullYear() === r.getFullYear())
        }
    }

    function wn() {
        var n = ["wrap", "weekNumbers", "allowInput", "allowInvalidPreload", "clickOpens", "time_24hr", "enableTime", "noCalendar", "altInput", "shorthandCurrentMonth", "inline", "static", "enableSeconds", "disableMobile"],
            t = A(A({}, JSON.parse(JSON.stringify(a.dataset || {}))), i),
            r = {};
        e.config.parseDate = t.parseDate, e.config.formatDate = t.formatDate, Object.defineProperty(e.config, "enable", {
            get: function() {
                return e.config._enable
            },
            set: function(g) {
                e.config._enable = Qe(g)
            }
        }), Object.defineProperty(e.config, "disable", {
            get: function() {
                return e.config._disable
            },
            set: function(g) {
                e.config._disable = Qe(g)
            }
        });
        var o = t.mode === "time";
        if (!t.dateFormat && (t.enableTime || o)) {
            var l = I.defaultConfig.dateFormat || te.dateFormat;
            r.dateFormat = t.noCalendar || o ? "H:i" + (t.enableSeconds ? ":S" : "") : l + " H:i" + (t.enableSeconds ? ":S" : "")
        }
        if (t.altInput && (t.enableTime || o) && !t.altFormat) {
            var f = I.defaultConfig.altFormat || te.altFormat;
            r.altFormat = t.noCalendar || o ? "h:i" + (t.enableSeconds ? ":S K" : " K") : f + (" h:i" + (t.enableSeconds ? ":S" : "") + " K")
        }
        Object.defineProperty(e.config, "minDate", {
            get: function() {
                return e.config._minDate
            },
            set: Je("min")
        }), Object.defineProperty(e.config, "maxDate", {
            get: function() {
                return e.config._maxDate
            },
            set: Je("max")
        });
        var v = function(g) {
            return function(_) {
                e.config[g === "min" ? "_minTime" : "_maxTime"] = e.parseDate(_, "H:i:S")
            }
        };
        Object.defineProperty(e.config, "minTime", {
            get: function() {
                return e.config._minTime
            },
            set: v("min")
        }), Object.defineProperty(e.config, "maxTime", {
            get: function() {
                return e.config._maxTime
            },
            set: v("max")
        }), t.mode === "time" && (e.config.noCalendar = !0, e.config.enableTime = !0), Object.assign(e.config, r, t);
        for (var c = 0; c < n.length; c++) e.config[n[c]] = e.config[n[c]] === !0 || e.config[n[c]] === "true";
        Te.filter(function(g) {
            return e.config[g] !== void 0
        }).forEach(function(g) {
            e.config[g] = Ie(e.config[g] || []).map(p)
        }), e.isMobile = !e.config.disableMobile && !e.config.inline && e.config.mode === "single" && !e.config.disable.length && !e.config.enable && !e.config.weekNumbers && /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        for (var c = 0; c < e.config.plugins.length; c++) {
            var D = e.config.plugins[c](e) || {};
            for (var d in D) Te.indexOf(d) > -1 ? e.config[d] = Ie(D[d]).map(p).concat(e.config[d]) : typeof t[d] > "u" && (e.config[d] = D[d])
        }
        t.altInputClass || (e.config.altInputClass = Ke().className + " " + e.config.altInputClass), S("onParseConfig")
    }

    function Ke() {
        return e.config.wrap ? a.querySelector("[data-input]") : a
    }

    function Ue() {
        typeof e.config.locale != "object" && typeof I.l10ns[e.config.locale] > "u" && e.config.errorHandler(new Error("flatpickr: invalid locale " + e.config.locale)), e.l10n = A(A({}, I.l10ns.default), typeof e.config.locale == "object" ? e.config.locale : e.config.locale !== "default" ? I.l10ns[e.config.locale] : void 0), X.D = "(" + e.l10n.weekdays.shorthand.join("|") + ")", X.l = "(" + e.l10n.weekdays.longhand.join("|") + ")", X.M = "(" + e.l10n.months.shorthand.join("|") + ")", X.F = "(" + e.l10n.months.longhand.join("|") + ")", X.K = "(" + e.l10n.amPM[0] + "|" + e.l10n.amPM[1] + "|" + e.l10n.amPM[0].toLowerCase() + "|" + e.l10n.amPM[1].toLowerCase() + ")";
        var n = A(A({}, i), JSON.parse(JSON.stringify(a.dataset || {})));
        n.time_24hr === void 0 && I.defaultConfig.time_24hr === void 0 && (e.config.time_24hr = e.l10n.time_24hr), e.formatDate = fn(e), e.parseDate = je({
            config: e.config,
            l10n: e.l10n
        })
    }

    function me(n) {
        if (typeof e.config.position == "function") return void e.config.position(e, n);
        if (e.calendarContainer !== void 0) {
            S("onPreCalendarPosition");
            var t = n || e._positionElement,
                r = Array.prototype.reduce.call(e.calendarContainer.children, function(Wn, Rn) {
                    return Wn + Rn.offsetHeight
                }, 0),
                o = e.calendarContainer.offsetWidth,
                l = e.config.position.split(" "),
                f = l[0],
                v = l.length > 1 ? l[1] : null,
                c = t.getBoundingClientRect(),
                D = window.innerHeight - c.bottom,
                d = f === "above" || f !== "below" && D < r && c.top > r,
                g = window.pageYOffset + c.top + (d ? -r - 2 : t.offsetHeight + 2);
            if (N(e.calendarContainer, "arrowTop", !d), N(e.calendarContainer, "arrowBottom", d), !e.config.inline) {
                var _ = window.pageXOffset + c.left,
                    B = !1,
                    Y = !1;
                v === "center" ? (_ -= (o - c.width) / 2, B = !0) : v === "right" && (_ -= o - c.width, Y = !0), N(e.calendarContainer, "arrowLeft", !B && !Y), N(e.calendarContainer, "arrowCenter", B), N(e.calendarContainer, "arrowRight", Y);
                var oe = window.document.body.offsetWidth - (window.pageXOffset + c.right),
                    ee = _ + o > window.document.body.offsetWidth,
                    An = oe + o > window.document.body.offsetWidth;
                if (N(e.calendarContainer, "rightMost", ee), !e.config.static)
                    if (e.calendarContainer.style.top = g + "px", !ee) e.calendarContainer.style.left = _ + "px", e.calendarContainer.style.right = "auto";
                    else if (!An) e.calendarContainer.style.left = "auto", e.calendarContainer.style.right = oe + "px";
                else {
                    var _e = yn();
                    if (_e === void 0) return;
                    var Nn = window.document.body.offsetWidth,
                        Pn = Math.max(0, Nn / 2 - o / 2),
                        Yn = ".flatpickr-calendar.centerMost:before",
                        Hn = ".flatpickr-calendar.centerMost:after",
                        jn = _e.cssRules.length,
                        Ln = "{left:" + c.left + "px;right:auto;}";
                    N(e.calendarContainer, "rightMost", !1), N(e.calendarContainer, "centerMost", !0), _e.insertRule(Yn + "," + Hn + Ln, jn), e.calendarContainer.style.left = Pn + "px", e.calendarContainer.style.right = "auto"
                }
            }
        }
    }

    function yn() {
        for (var n = null, t = 0; t < document.styleSheets.length; t++) {
            var r = document.styleSheets[t];
            if (r.cssRules) {
                try {
                    r.cssRules
                } catch {
                    continue
                }
                n = r;
                break
            }
        }
        return n ? ? Cn()
    }

    function Cn() {
        var n = document.createElement("style");
        return document.head.appendChild(n), n.sheet
    }

    function Ve() {
        e.config.noCalendar || e.isMobile || ($(), pe(), fe())
    }

    function Ce() {
        e._input.focus(), window.navigator.userAgent.indexOf("MSIE") !== -1 || navigator.msMaxTouchPoints !== void 0 ? setTimeout(e.close, 0) : e.close()
    }

    function qe(n) {
        n.preventDefault(), n.stopPropagation();
        var t = function(g) {
                return g.classList && g.classList.contains("flatpickr-day") && !g.classList.contains("flatpickr-disabled") && !g.classList.contains("notAllowed")
            },
            r = un(H(n), t);
        if (r !== void 0) {
            var o = r,
                l = e.latestSelectedDateObj = new Date(o.dateObj.getTime()),
                f = (l.getMonth() < e.currentMonth || l.getMonth() > e.currentMonth + e.config.showMonths - 1) && e.config.mode !== "range";
            if (e.selectedDateElem = o, e.config.mode === "single") e.selectedDates = [l];
            else if (e.config.mode === "multiple") {
                var v = Ee(l);
                v ? e.selectedDates.splice(parseInt(v), 1) : e.selectedDates.push(l)
            } else e.config.mode === "range" && (e.selectedDates.length === 2 && e.clear(!1, !1), e.latestSelectedDateObj = l, e.selectedDates.push(l), j(l, e.selectedDates[0], !0) !== 0 && e.selectedDates.sort(function(g, _) {
                return g.getTime() - _.getTime()
            }));
            if (k(), f) {
                var c = e.currentYear !== l.getFullYear();
                e.currentYear = l.getFullYear(), e.currentMonth = l.getMonth(), c && (S("onYearChange"), $()), S("onMonthChange")
            }
            if (pe(), fe(), K(), !f && e.config.mode !== "range" && e.config.showMonths === 1 ? Q(o) : e.selectedDateElem !== void 0 && e.hourElement === void 0 && e.selectedDateElem && e.selectedDateElem.focus(), e.hourElement !== void 0 && e.hourElement !== void 0 && e.hourElement.focus(), e.config.closeOnSelect) {
                var D = e.config.mode === "single" && !e.config.enableTime,
                    d = e.config.mode === "range" && e.selectedDates.length === 2 && !e.config.enableTime;
                (D || d) && Ce()
            }
            y()
        }
    }
    var ge = {
        locale: [Ue, Re],
        showMonths: [Le, M, We],
        minDate: [T],
        maxDate: [T],
        positionElement: [Ge],
        clickOpens: [function() {
            e.config.clickOpens === !0 ? (w(e._input, "focus", e.open), w(e._input, "click", e.open)) : (e._input.removeEventListener("focus", e.open), e._input.removeEventListener("click", e.open))
        }]
    };

    function xn(n, t) {
        if (n !== null && typeof n == "object") {
            Object.assign(e.config, n);
            for (var r in n) ge[r] !== void 0 && ge[r].forEach(function(o) {
                return o()
            })
        } else e.config[n] = t, ge[n] !== void 0 ? ge[n].forEach(function(o) {
            return o()
        }) : Te.indexOf(n) > -1 && (e.config[n] = Ie(t));
        e.redraw(), K(!0)
    }

    function ze(n, t) {
        var r = [];
        if (n instanceof Array) r = n.map(function(o) {
            return e.parseDate(o, t)
        });
        else if (n instanceof Date || typeof n == "number") r = [e.parseDate(n, t)];
        else if (typeof n == "string") switch (e.config.mode) {
            case "single":
            case "time":
                r = [e.parseDate(n, t)];
                break;
            case "multiple":
                r = n.split(e.config.conjunction).map(function(o) {
                    return e.parseDate(o, t)
                });
                break;
            case "range":
                r = n.split(e.l10n.rangeSeparator).map(function(o) {
                    return e.parseDate(o, t)
                });
                break
        } else e.config.errorHandler(new Error("Invalid date supplied: " + JSON.stringify(n)));
        e.selectedDates = e.config.allowInvalidPreload ? r : r.filter(function(o) {
            return o instanceof Date && Z(o, !1)
        }), e.config.mode === "range" && e.selectedDates.sort(function(o, l) {
            return o.getTime() - l.getTime()
        })
    }

    function En(n, t, r) {
        if (t === void 0 && (t = !1), r === void 0 && (r = e.config.dateFormat), n !== 0 && !n || n instanceof Array && n.length === 0) return e.clear(t);
        ze(n, r), e.latestSelectedDateObj = e.selectedDates[e.selectedDates.length - 1], e.redraw(), T(void 0, t), O(), e.selectedDates.length === 0 && e.clear(!1), K(t), t && S("onChange")
    }

    function Qe(n) {
        return n.slice().map(function(t) {
            return typeof t == "string" || typeof t == "number" || t instanceof Date ? e.parseDate(t, void 0, !0) : t && typeof t == "object" && t.from && t.to ? {
                from: e.parseDate(t.from, void 0),
                to: e.parseDate(t.to, void 0)
            } : t
        }).filter(function(t) {
            return t
        })
    }

    function kn() {
        e.selectedDates = [], e.now = e.parseDate(e.config.now) || new Date;
        var n = e.config.defaultDate || ((e.input.nodeName === "INPUT" || e.input.nodeName === "TEXTAREA") && e.input.placeholder && e.input.value === e.input.placeholder ? null : e.input.value);
        n && ze(n, e.config.dateFormat), e._initialDate = e.selectedDates.length > 0 ? e.selectedDates[0] : e.config.minDate && e.config.minDate.getTime() > e.now.getTime() ? e.config.minDate : e.config.maxDate && e.config.maxDate.getTime() < e.now.getTime() ? e.config.maxDate : e.now, e.currentYear = e._initialDate.getFullYear(), e.currentMonth = e._initialDate.getMonth(), e.selectedDates.length > 0 && (e.latestSelectedDateObj = e.selectedDates[0]), e.config.minTime !== void 0 && (e.config.minTime = e.parseDate(e.config.minTime, "H:i")), e.config.maxTime !== void 0 && (e.config.maxTime = e.parseDate(e.config.maxTime, "H:i")), e.minDateHasTime = !!e.config.minDate && (e.config.minDate.getHours() > 0 || e.config.minDate.getMinutes() > 0 || e.config.minDate.getSeconds() > 0), e.maxDateHasTime = !!e.config.maxDate && (e.config.maxDate.getHours() > 0 || e.config.maxDate.getMinutes() > 0 || e.config.maxDate.getSeconds() > 0)
    }

    function _n() {
        if (e.input = Ke(), !e.input) {
            e.config.errorHandler(new Error("Invalid input element specified"));
            return
        }
        e.input._type = e.input.type, e.input.type = "text", e.input.classList.add("flatpickr-input"), e._input = e.input, e.config.altInput && (e.altInput = x(e.input.nodeName, e.config.altInputClass), e._input = e.altInput, e.altInput.placeholder = e.input.placeholder, e.altInput.disabled = e.input.disabled, e.altInput.required = e.input.required, e.altInput.tabIndex = e.input.tabIndex, e.altInput.type = "text", e.input.setAttribute("type", "hidden"), !e.config.static && e.input.parentNode && e.input.parentNode.insertBefore(e.altInput, e.input.nextSibling)), e.config.allowInput || e._input.setAttribute("readonly", "readonly"), Ge()
    }

    function Ge() {
        e._positionElement = e.config.positionElement || e._input
    }

    function Sn() {
        var n = e.config.enableTime ? e.config.noCalendar ? "time" : "datetime-local" : "date";
        e.mobileInput = x("input", e.input.className + " flatpickr-mobile"), e.mobileInput.tabIndex = 1, e.mobileInput.type = n, e.mobileInput.disabled = e.input.disabled, e.mobileInput.required = e.input.required, e.mobileInput.placeholder = e.input.placeholder, e.mobileFormatStr = n === "datetime-local" ? "Y-m-d\\TH:i:S" : n === "date" ? "Y-m-d" : "H:i:S", e.selectedDates.length > 0 && (e.mobileInput.defaultValue = e.mobileInput.value = e.formatDate(e.selectedDates[0], e.mobileFormatStr)), e.config.minDate && (e.mobileInput.min = e.formatDate(e.config.minDate, "Y-m-d")), e.config.maxDate && (e.mobileInput.max = e.formatDate(e.config.maxDate, "Y-m-d")), e.input.getAttribute("step") && (e.mobileInput.step = String(e.input.getAttribute("step"))), e.input.type = "hidden", e.altInput !== void 0 && (e.altInput.type = "hidden");
        try {
            e.input.parentNode && e.input.parentNode.insertBefore(e.mobileInput, e.input.nextSibling)
        } catch {}
        w(e.mobileInput, "change", function(t) {
            e.setDate(H(t).value, !1, e.mobileFormatStr), S("onChange"), S("onClose")
        })
    }

    function Tn(n) {
        if (e.isOpen === !0) return e.close();
        e.open(n)
    }

    function S(n, t) {
        if (e.config !== void 0) {
            var r = e.config[n];
            if (r !== void 0 && r.length > 0)
                for (var o = 0; r[o] && o < r.length; o++) r[o](e.selectedDates, e.input.value, e, t);
            n === "onChange" && (e.input.dispatchEvent(xe("change")), e.input.dispatchEvent(xe("input")))
        }
    }

    function xe(n) {
        var t = document.createEvent("Event");
        return t.initEvent(n, !0, !0), t
    }

    function Ee(n) {
        for (var t = 0; t < e.selectedDates.length; t++) {
            var r = e.selectedDates[t];
            if (r instanceof Date && j(r, n) === 0) return "" + t
        }
        return !1
    }

    function In(n) {
        return e.config.mode !== "range" || e.selectedDates.length < 2 ? !1 : j(n, e.selectedDates[0]) >= 0 && j(n, e.selectedDates[1]) <= 0
    }

    function pe() {
        e.config.noCalendar || e.isMobile || !e.monthNav || (e.yearElements.forEach(function(n, t) {
            var r = new Date(e.currentYear, e.currentMonth, 1);
            r.setMonth(e.currentMonth + t), e.config.showMonths > 1 || e.config.monthSelectorType === "static" ? e.monthElements[t].textContent = Me(r.getMonth(), e.config.shorthandCurrentMonth, e.l10n) + " " : e.monthsDropdownContainer.value = r.getMonth().toString(), n.value = r.getFullYear().toString()
        }), e._hidePrevMonthArrow = e.config.minDate !== void 0 && (e.currentYear === e.config.minDate.getFullYear() ? e.currentMonth <= e.config.minDate.getMonth() : e.currentYear < e.config.minDate.getFullYear()), e._hideNextMonthArrow = e.config.maxDate !== void 0 && (e.currentYear === e.config.maxDate.getFullYear() ? e.currentMonth + 1 > e.config.maxDate.getMonth() : e.currentYear > e.config.maxDate.getFullYear()))
    }

    function ke(n) {
        var t = n || (e.config.altInput ? e.config.altFormat : e.config.dateFormat);
        return e.selectedDates.map(function(r) {
            return e.formatDate(r, t)
        }).filter(function(r, o, l) {
            return e.config.mode !== "range" || e.config.enableTime || l.indexOf(r) === o
        }).join(e.config.mode !== "range" ? e.config.conjunction : e.l10n.rangeSeparator)
    }

    function K(n) {
        n === void 0 && (n = !0), e.mobileInput !== void 0 && e.mobileFormatStr && (e.mobileInput.value = e.latestSelectedDateObj !== void 0 ? e.formatDate(e.latestSelectedDateObj, e.mobileFormatStr) : ""), e.input.value = ke(e.config.dateFormat), e.altInput !== void 0 && (e.altInput.value = ke(e.config.altFormat)), n !== !1 && S("onValueUpdate")
    }

    function On(n) {
        var t = H(n),
            r = e.prevMonthNav.contains(t),
            o = e.nextMonthNav.contains(t);
        r || o ? we(r ? -1 : 1) : e.yearElements.indexOf(t) >= 0 ? t.select() : t.classList.contains("arrowUp") ? e.changeYear(e.currentYear + 1) : t.classList.contains("arrowDown") && e.changeYear(e.currentYear - 1)
    }

    function Fn(n) {
        n.preventDefault();
        var t = n.type === "keydown",
            r = H(n),
            o = r;
        e.amPM !== void 0 && r === e.amPM && (e.amPM.textContent = e.l10n.amPM[L(e.amPM.textContent === e.l10n.amPM[0])]);
        var l = parseFloat(o.getAttribute("min")),
            f = parseFloat(o.getAttribute("max")),
            v = parseFloat(o.getAttribute("step")),
            c = parseInt(o.value, 10),
            D = n.delta || (t ? n.which === 38 ? 1 : -1 : 0),
            d = c + v * D;
        if (typeof o.value < "u" && o.value.length === 2) {
            var g = o === e.hourElement,
                _ = o === e.minuteElement;
            d < l ? (d = f + d + L(!g) + (L(g) && L(!e.amPM)), _ && q(void 0, -1, e.hourElement)) : d > f && (d = o === e.hourElement ? d - f - L(!e.amPM) : l, _ && q(void 0, 1, e.hourElement)), e.amPM && g && (v === 1 ? d + c === 23 : Math.abs(d - c) > v) && (e.amPM.textContent = e.l10n.amPM[L(e.amPM.textContent === e.l10n.amPM[0])]), o.value = P(d)
        }
    }
    return s(), e
}

function ae(a, i) {
    for (var e = Array.prototype.slice.call(a).filter(function(p) {
            return p instanceof HTMLElement
        }), u = [], s = 0; s < e.length; s++) {
        var m = e[s];
        try {
            if (m.getAttribute("data-fp-omit") !== null) continue;
            m._flatpickr !== void 0 && (m._flatpickr.destroy(), m._flatpickr = void 0), m._flatpickr = st(m, i || {}), u.push(m._flatpickr)
        } catch (p) {
            console.error(p)
        }
    }
    return u.length === 1 ? u[0] : u
}
typeof HTMLElement < "u" && typeof HTMLCollection < "u" && typeof NodeList < "u" && (HTMLCollection.prototype.flatpickr = NodeList.prototype.flatpickr = function(a) {
    return ae(this, a)
}, HTMLElement.prototype.flatpickr = function(a) {
    return ae([this], a)
});
var I = function(a, i) {
    return typeof a == "string" ? ae(window.document.querySelectorAll(a), i) : a instanceof Node ? ae([a], i) : ae(a, i)
};
I.defaultConfig = {};
I.l10ns = {
    en: A({}, ue),
    default: A({}, ue)
};
I.localize = function(a) {
    I.l10ns.default = A(A({}, I.l10ns.default), a)
};
I.setDefaults = function(a) {
    I.defaultConfig = A(A({}, I.defaultConfig), a)
};
I.parseDate = je({});
I.formatDate = fn({});
I.compareDates = j;
typeof jQuery < "u" && typeof jQuery.fn < "u" && (jQuery.fn.flatpickr = function(a) {
    return ae(this, a)
});
Date.prototype.fp_incr = function(a) {
    return new Date(this.getFullYear(), this.getMonth(), this.getDate() + (typeof a == "string" ? parseInt(a, 10) : a))
};
typeof window < "u" && (window.flatpickr = I);

function dt(a) {
    let i, e, u, s, m;
    return {
        c() {
            i = Ye("input"), this.h()
        },
        l(p) {
            i = Pe(p, "INPUT", {
                class: !0,
                type: !0,
                id: !0,
                placeholder: !0,
                style: !0
            }), this.h()
        },
        h() {
            var p;
            R(i, "class", e = "border-[1px] rounded-sm4 " + (a[2] ? "max-w-[142px] sm:max-w-[150px]" : "") + " !p-[8px] outline-none bg-transparent z-10 placeholder:!text-[#b4b7bd] focus:border-[#005AE3] placeholder:!text-opacity-70 " + (((p = a[7]) == null ? void 0 : p.theme) === "Dark" ? "border-[#3B4253] placeholder:!text-[#d0d2d6] !text-[#b4b7bd]" : "border-[#d8d6de] placeholder:!text-[#444444] !text-[#444444]")), R(i, "type", "text"), R(i, "id", a[1]), R(i, "placeholder", a[4]), R(i, "style", u = a[2] ? `max-width: ${a[3]}px;` : ""), i.readOnly = !0
        },
        m(p, M) {
            be(p, i, M), a[11](i), Xe(i, a[0]), s || (m = [Se(i, "input", a[12]), Se(i, "input", function() {
                Jn(a[5]) && a[5].apply(this, arguments)
            }), Se(i, "change", a[8])], s = !0)
        },
        p(p, [M]) {
            var E;
            a = p, M & 132 && e !== (e = "border-[1px] rounded-sm4 " + (a[2] ? "max-w-[142px] sm:max-w-[150px]" : "") + " !p-[8px] outline-none bg-transparent z-10 placeholder:!text-[#b4b7bd] focus:border-[#005AE3] placeholder:!text-opacity-70 " + (((E = a[7]) == null ? void 0 : E.theme) === "Dark" ? "border-[#3B4253] placeholder:!text-[#d0d2d6] !text-[#b4b7bd]" : "border-[#d8d6de] placeholder:!text-[#444444] !text-[#444444]")) && R(i, "class", e), M & 2 && R(i, "id", a[1]), M & 16 && R(i, "placeholder", a[4]), M & 12 && u !== (u = a[2] ? `max-width: ${a[3]}px;` : "") && R(i, "style", u), M & 1 && i.value !== a[0] && Xe(i, a[0])
        },
        i: Ze,
        o: Ze,
        d(p) {
            p && ne(i), a[11](null), s = !1, Bn(m)
        }
    }
}

function ct(a, i, e) {
    let u;
    Kn(a, at, y => e(7, u = y));
    let {
        options: s = {}
    } = i, {
        id: m = ""
    } = i, {
        value: p
    } = i, {
        limitWidth: M = !0
    } = i, {
        styleMaxWidth: E = 150
    } = i, {
        placeholder: b = "dd/mm/aaaa hh:mm"
    } = i, {
        onInput: h = () => {}
    } = i, {
        dashboardHoursOffset: k
    } = i, O;
    const F = () => {
        const y = it.getDateNumberForOffset(new Date, k);
        document.querySelectorAll("span.flatpickr-day").forEach(T => {
            T.className.includes("today") && (T.className = T.className.replace("today", "")), T.innerText === `${y}` && (T.className = `${T.className} today`)
        })
    };
    Un(() => {
        I(O, s), F()
    });

    function U(y) {
        rn[y ? "unshift" : "push"](() => {
            O = y, e(6, O)
        })
    }

    function w() {
        p = this.value, e(0, p)
    }
    return a.$$set = y => {
        "options" in y && e(9, s = y.options), "id" in y && e(1, m = y.id), "value" in y && e(0, p = y.value), "limitWidth" in y && e(2, M = y.limitWidth), "styleMaxWidth" in y && e(3, E = y.styleMaxWidth), "placeholder" in y && e(4, b = y.placeholder), "onInput" in y && e(5, h = y.onInput), "dashboardHoursOffset" in y && e(10, k = y.dashboardHoursOffset)
    }, [p, m, M, E, b, h, O, u, F, s, k, U, w]
}
class mt extends on {
    constructor(i) {
        super(), ln(this, i, ct, dt, an, {
            options: 9,
            id: 1,
            value: 0,
            limitWidth: 2,
            styleMaxWidth: 3,
            placeholder: 4,
            onInput: 5,
            dashboardHoursOffset: 10
        })
    }
}

function gt(a) {
    let i, e, u, s, m, p;

    function M(b) {
        a[12](b)
    }
    let E = {
        options: a[6],
        placeholder: a[0],
        onInput: a[4],
        styleMaxWidth: a[2] ? ? 260,
        limitWidth: a[1],
        dashboardHoursOffset: a[3]
    };
    return a[5] !== void 0 && (E.value = a[5]), s = new mt({
        props: E
    }), rn.push(() => Qn(s, "value", M)), {
        c() {
            i = Ye("div"), e = zn(), u = Ye("div"), nt(s.$$.fragment), this.h()
        },
        l(b) {
            i = Pe(b, "DIV", {
                class: !0
            }), $e(i).forEach(ne), e = qn(b), u = Pe(b, "DIV", {
                class: !0,
                style: !0
            });
            var h = $e(u);
            et(s.$$.fragment, h), h.forEach(ne), this.h()
        },
        h() {
            R(i, "class", "h-2"), R(u, "class", "flex items-center gap-[4px] !pt-1 flex-1 min-w-0"), he(u, "--date-input-width", "5px"), he(u, "font-family", "'UberMove'"), he(u, "--date-picker-highlight-border", "#005AE3"), he(u, "--date-picker-selected-background", "#D8ECFC")
        },
        m(b, h) {
            be(b, i, h), be(b, e, h), be(b, u, h), $n(s, u, null), p = !0
        },
        p(b, [h]) {
            const k = {};
            h & 1 && (k.placeholder = b[0]), h & 16 && (k.onInput = b[4]), h & 4 && (k.styleMaxWidth = b[2] ? ? 260), h & 2 && (k.limitWidth = b[1]), h & 8 && (k.dashboardHoursOffset = b[3]), !m && h & 32 && (m = !0, k.value = b[5], Vn(() => m = !1)), s.$set(k)
        },
        i(b) {
            p || (Xn(s.$$.fragment, b), p = !0)
        },
        o(b) {
            Zn(s.$$.fragment, b), p = !1
        },
        d(b) {
            b && (ne(i), ne(e), ne(u)), Gn(s)
        }
    }
}

function Ne(a) {
    const i = e => String(e).padStart(2, "0");
    return `${i(a.getDate())}/${i(a.getMonth()+1)}/${a.getFullYear()} ${i(a.getHours())}:${i(a.getMinutes())}`
}

function pt(a, i, e) {
    let {
        customDateFrom: u
    } = i, {
        customDateTo: s
    } = i, {
        placeholder: m = void 0
    } = i, {
        limitWidth: p = !0
    } = i, {
        inputMaxWidth: M = void 0
    } = i, {
        dashboardHoursOffset: E
    } = i, {
        minDate: b = null
    } = i, {
        maxDate: h = null
    } = i, {
        onChange: k = null
    } = i, {
        onInput: O = () => {}
    } = i, F;
    const U = () => setTimeout(() => k == null ? void 0 : k(), 200),
        w = { ...en.Portuguese,
            rangeSeparator: " - "
        },
        y = {
            enableTime: !0,
            closeOnSelect: !1,
            dateFormat: "d/m/Y H:i",
            time_24hr: !0,
            disableMobile: !0,
            defaultHour: 0,
            defaultMinute: 0,
            minuteIncrement: 1,
            locale: en.Portuguese,
            ...b ? {
                minDate: b
            } : {},
            ...h ? {
                maxDate: h
            } : {}
        };
    let V = !1,
        T = !1;
    const J = { ...y,
        closeOnSelect: !1,
        locale: w,
        mode: "range",
        ...u || s ? {
            defaultDate: [u, s].filter(Boolean)
        } : {},
        onOpen: () => {
            V = !1, T = !1
        },
        onChange: (C, z, Q) => {
            if (C.length === 1) {
                const W = new Date(C[0]);
                e(7, u = Ne(W)), e(8, s = void 0), T = !0
            }
            if (C.length === 2) {
                const W = new Date(C[0]),
                    G = new Date(C[1]);
                T && (G.setHours(23, 59, 0, 0), Q.setDate([W, G], !1)), e(7, u = Ne(W)), e(8, s = Ne(G)), T = !1
            }
            V = !0
        },
        onClose: () => {
            V && u && s && U()
        }
    };

    function q(C) {
        F = C, e(5, F)
    }
    return a.$$set = C => {
        "customDateFrom" in C && e(7, u = C.customDateFrom), "customDateTo" in C && e(8, s = C.customDateTo), "placeholder" in C && e(0, m = C.placeholder), "limitWidth" in C && e(1, p = C.limitWidth), "inputMaxWidth" in C && e(2, M = C.inputMaxWidth), "dashboardHoursOffset" in C && e(3, E = C.dashboardHoursOffset), "minDate" in C && e(9, b = C.minDate), "maxDate" in C && e(10, h = C.maxDate), "onChange" in C && e(11, k = C.onChange), "onInput" in C && e(4, O = C.onInput)
    }, [m, p, M, E, O, F, J, u, s, b, h, k, q]
}
class wt extends on {
    constructor(i) {
        super(), ln(this, i, pt, gt, an, {
            customDateFrom: 7,
            customDateTo: 8,
            placeholder: 0,
            limitWidth: 1,
            inputMaxWidth: 2,
            dashboardHoursOffset: 3,
            minDate: 9,
            maxDate: 10,
            onChange: 11,
            onInput: 4
        })
    }
}
export {
    mt as D, wt as S, en as p
};