import {
    s as at,
    H as St,
    d as E,
    I as Et,
    J as Ct,
    K as wt,
    m as w,
    i as G,
    b as j,
    c as se,
    e as x,
    g as R,
    h as ae,
    j as U,
    E as ot,
    a as yt,
    q as Ke,
    f as It,
    t as kt,
    k as Fe,
    v as Dt,
    w as qe,
    P as rt,
    ae as ut,
    x as We,
    r as At,
    z as Ve,
    u as et,
    C as tt,
    D as nt,
    n as Ot,
    F as Je
} from "./DDNnt9XD.js";
import {
    S as it,
    i as lt,
    t as L,
    a as T,
    d as B,
    g as Xe,
    f as Qe,
    b as F,
    m as V,
    c as K,
    e as Ge
} from "./qWASNxYk.js";
import {
    e as mt,
    u as Tt,
    o as Lt
} from "./D4UMIlhj.js";
import {
    n as dt,
    U as Ht,
    R as H,
    L as J,
    o as Pt,
    p as Rt,
    q as Ut,
    E as Wt,
    u as Mt
} from "./B5WePDbK.js";
import {
    I as z,
    L as Bt,
    p as ft,
    u as ct
} from "./DGPp_bW9.js";
import {
    t as Nt
} from "./BszCcFfc.js";
import {
    s as ht
} from "./BhzxD5oF.js";
import {
    L as Ft
} from "./FqFtzvE-.js";
import {
    S as Vt
} from "./DwsiLpv2.js";
import {
    p as Gt
} from "./-FoHBm-c.js";

function Kt(n) {
    let s;
    return {
        c() {
            s = ae("div"), this.h()
        },
        l(e) {
            s = se(e, "DIV", {
                class: !0
            }), x(s).forEach(E), this.h()
        },
        h() {
            w(s, "class", "pt-8")
        },
        m(e, l) {
            G(e, s, l)
        },
        d(e) {
            e && E(s)
        }
    }
}

function zt(n) {
    let s, e, l;
    return {
        c() {
            s = ae("div"), e = U(), l = ae("div"), this.h()
        },
        l(i) {
            s = se(i, "DIV", {
                class: !0
            }), x(s).forEach(E), e = R(i), l = se(i, "DIV", {
                class: !0
            }), x(l).forEach(E), this.h()
        },
        h() {
            w(s, "class", "content-overlay"), w(l, "class", "header-navbar-shadow")
        },
        m(i, f) {
            G(i, s, f), G(i, e, f), G(i, l, f)
        },
        d(i) {
            i && (E(s), E(e), E(l))
        }
    }
}

function jt(n) {
    let s, e, l, i, f, h, a, r;

    function m(C, N) {
        return C[0] ? zt : Kt
    }
    let v = m(n),
        d = v(n);
    const b = n[2].default,
        _ = St(b, n, n[1], null);
    return {
        c() {
            s = ae("div"), d.c(), e = U(), l = ae("div"), i = ae("div"), f = U(), h = ae("div"), _ && _.c(), this.h()
        },
        l(C) {
            s = se(C, "DIV", {
                class: !0
            });
            var N = x(s);
            d.l(N), e = R(N), l = se(N, "DIV", {
                class: !0
            });
            var I = x(l);
            i = se(I, "DIV", {
                class: !0
            }), x(i).forEach(E), f = R(I), h = se(I, "DIV", {
                class: !0
            });
            var u = x(h);
            _ && _.l(u), u.forEach(E), I.forEach(E), N.forEach(E), this.h()
        },
        h() {
            w(i, "class", "content-header row"), w(h, "class", "content-body h-full"), w(l, "class", "content-wrapper container-xxl p-0 h-full"), w(s, "class", a = "app-content content margin-left-content h-full " + (n[0] ? "" : "!pt-0 padding-zero-top") + " svelte-qxpnce")
        },
        m(C, N) {
            G(C, s, N), d.m(s, null), j(s, e), j(s, l), j(l, i), j(l, f), j(l, h), _ && _.m(h, null), r = !0
        },
        p(C, [N]) {
            v !== (v = m(C)) && (d.d(1), d = v(C), d && (d.c(), d.m(s, e))), _ && _.p && (!r || N & 2) && Et(_, b, C, C[1], r ? wt(b, C[1], N, null) : Ct(C[1]), null), (!r || N & 1 && a !== (a = "app-content content margin-left-content h-full " + (C[0] ? "" : "!pt-0 padding-zero-top") + " svelte-qxpnce")) && w(s, "class", a)
        },
        i(C) {
            r || (T(_, C), r = !0)
        },
        o(C) {
            L(_, C), r = !1
        },
        d(C) {
            C && E(s), d.d(), _ && _.d(C)
        }
    }
}

function qt(n, s, e) {
    let {
        $$slots: l = {},
        $$scope: i
    } = s, {
        navbarOpen: f = !0
    } = s;
    return n.$$set = h => {
        "navbarOpen" in h && e(0, f = h.navbarOpen), "$$scope" in h && e(1, i = h.$$scope)
    }, [f, i, l]
}
class gn extends it {
    constructor(s) {
        super(), lt(this, s, qt, jt, at, {
            navbarOpen: 0
        })
    }
}
const Jt = function() {
        (function(n, s, e) {
            var l = n.innerHeight * .01;
            s.documentElement.style.setProperty("--vh", l + "px"), e.app = e.app || {};
            var i = e("body");
            e(n);
            var f = e('div[data-menu="menu-wrapper"]').html(),
                h = e('div[data-menu="menu-wrapper"]').attr("class");
            e.app.menu = {
                expanded: null,
                collapsed: null,
                hidden: null,
                container: null,
                horizontalMenu: !1,
                is_touch_device: function() {
                    var a = " -webkit- -moz- -o- -ms- ".split(" "),
                        r = function(v) {
                            return n.matchMedia(v).matches
                        };
                    if ("ontouchstart" in n || n.DocumentTouch && s instanceof DocumentTouch) return !0;
                    var m = ["(", a.join("touch-enabled),("), "heartz", ")"].join("");
                    return r(m)
                },
                manualScroller: {
                    obj: null,
                    init: function() {
                        if (e(".main-menu").hasClass("menu-dark"), e.app.menu.is_touch_device()) e(".main-menu").addClass("menu-native-scroll");
                        else try {
                            this.obj = new PerfectScrollbar(".main-menu-content", {
                                suppressScrollX: !0,
                                wheelPropagation: !1
                            })
                        } catch {
                            e(".main-menu").addClass("menu-native-scroll")
                        }
                    },
                    update: function() {
                        if (e(".main-menu").data("scroll-to-active") === !0) {
                            var a, r, m;
                            if (a = s.querySelector(".main-menu-content li.active"), r = s.querySelector(".main-menu-content"), i.hasClass("menu-collapsed") && e(".main-menu-content li.sidebar-group-active").length && (a = s.querySelector(".main-menu-content li.sidebar-group-active")), a && (m = a.getBoundingClientRect().top + r.scrollTop), m > parseInt(r.clientHeight * 2 / 3)) var v = r.scrollTop,
                                d = m - v - parseInt(r.clientHeight / 2);
                            setTimeout(function() {
                                e.app.menu.container.stop().animate({
                                    scrollTop: d
                                }, 300), e(".main-menu").data("scroll-to-active", "false")
                            }, 300)
                        }
                    },
                    enable: function() {
                        e(".main-menu-content").hasClass("ps") || this.init()
                    },
                    disable: function() {
                        this.obj && typeof this.obj.destroy == "function" && this.obj.destroy()
                    },
                    updateHeight: function() {
                        (i.data("menu") == "vertical-menu" || i.data("menu") == "vertical-menu-modern" || i.data("menu") == "vertical-overlay-menu") && e(".main-menu").hasClass("menu-fixed") && (e(".main-menu-content").css("height", e(n).height() - e(".header-navbar").height() - e(".main-menu-header").outerHeight() - e(".main-menu-footer").outerHeight()), this.update())
                    }
                },
                init: function(a) {
                    e(".main-menu-content").length > 0 && (this.container = e(".main-menu-content"), this.change(a))
                },
                change: function(a) {
                    var r = dt.fetch.now();
                    this.reset();
                    var m = i.data("menu");
                    if (r) switch (r.name) {
                        case "xl":
                            m === "vertical-overlay-menu" ? this.hide() : a === !0 ? this.collapse(a) : this.expand();
                            break;
                        case "lg":
                            m === "vertical-overlay-menu" || m === "vertical-menu-modern" || m === "horizontal-menu" ? this.hide() : this.collapse();
                            break;
                        case "md":
                        case "sm":
                            this.hide();
                            break;
                        case "xs":
                            this.hide();
                            break
                    }
                    r = {
                        name: "xl"
                    }, (m === "vertical-menu" || m === "vertical-menu-modern") && this.toOverlayMenu(r, m), i.is(".horizontal-layout") && !i.hasClass(".horizontal-menu-demo") && (this.changeMenu(r.name), e(".menu-toggle").removeClass("is-active")), r.name == "xl" && e('body[data-open="hover"] .main-menu-content .dropdown').on("mouseenter", function() {
                        e(this).hasClass("show") ? e(this).removeClass("show") : e(this).addClass("show")
                    }).on("mouseleave", function(v) {
                        e(this).removeClass("show")
                    }), r.name == "sm" || r.name == "xs" ? e(".header-navbar[data-nav=brand-center]").removeClass("navbar-brand-center") : e(".header-navbar[data-nav=brand-center]").addClass("navbar-brand-center"), r.name == "xl" && m == "horizontal-menu" && e(".main-menu-content").find("li.active").parents("li").addClass("sidebar-group-active active"), r.name !== "xl" && m == "horizontal-menu" && e("#navbar-type").toggleClass("d-none d-xl-block"), e("ul.dropdown-menu [data-bs-toggle=dropdown]").on("click", function(v) {
                        e(this).siblings("ul.dropdown-menu").length > 0 && v.preventDefault(), v.stopPropagation(), e(this).parent().siblings().removeClass("show"), e(this).parent().toggleClass("show")
                    }), m == "horizontal-menu" && (e("li.dropdown-submenu").on("mouseenter", function() {
                        e(this).parent(".dropdown").hasClass("show") || e(this).removeClass("openLeft");
                        var v = e(this).find(".dropdown-menu");
                        if (v) {
                            var d = e(n).height(),
                                b = e(this).position().top,
                                _ = v.offset().left,
                                C = v.width(),
                                N = v.height();
                            if (d - b - N - 28 < 1) {
                                var I = d - b - 170;
                                e(this).find(".dropdown-menu").css({
                                    "max-height": I + "px",
                                    "overflow-y": "auto",
                                    "overflow-x": "hidden"
                                }), new PerfectScrollbar("li.dropdown-submenu.show .dropdown-menu", {
                                    wheelPropagation: !1
                                })
                            }
                            _ + C - (n.innerWidth - 16) >= 0 && e(this).addClass("openLeft")
                        }
                    }), e(".theme-layouts").find(".semi-dark").hide())
                },
                transit: function(a, r) {
                    var m = this;
                    i.addClass("changing-menu"), a.call(m), i.hasClass("vertical-layout") && (i.hasClass("menu-open") || i.hasClass("menu-expanded") ? (e(".menu-toggle").addClass("is-active"), i.data("menu") === "vertical-menu" && e(".main-menu-header") && e(".main-menu-header").show()) : (e(".menu-toggle").removeClass("is-active"), i.data("menu") === "vertical-menu" && e(".main-menu-header") && e(".main-menu-header").hide())), setTimeout(function() {
                        r.call(m), i.removeClass("changing-menu"), m.update()
                    }, 500)
                },
                open: function() {
                    this.transit(function() {
                        i.removeClass("menu-hide menu-collapsed").addClass("menu-open"), this.hidden = !1, this.expanded = !0, i.hasClass("vertical-overlay-menu") && e(".sidenav-overlay").addClass("show")
                    }, function() {
                        !e(".main-menu").hasClass("menu-native-scroll") && e(".main-menu").hasClass("menu-fixed") && (this.manualScroller.enable(), e(".main-menu-content").css("height", e(n).height() - e(".header-navbar").height() - e(".main-menu-header").outerHeight() - e(".main-menu-footer").outerHeight())), i.hasClass("vertical-overlay-menu") || e(".sidenav-overlay").removeClass("show")
                    })
                },
                hide: function() {
                    this.transit(function() {
                        i.removeClass("menu-open menu-expanded").addClass("menu-hide"), this.hidden = !0, this.expanded = !1, i.hasClass("vertical-overlay-menu") && e(".sidenav-overlay").removeClass("show")
                    }, function() {
                        !e(".main-menu").hasClass("menu-native-scroll") && e(".main-menu").hasClass("menu-fixed") && this.manualScroller.enable(), i.hasClass("vertical-overlay-menu") || e(".sidenav-overlay").removeClass("show")
                    })
                },
                expand: function() {
                    this.expanded === !1 && (i.data("menu") == "vertical-menu-modern" && e(".modern-nav-toggle").find(".collapse-toggle-icon").replaceWith(feather.icons.disc.toSvg({
                        class: "d-none d-xl-block collapse-toggle-icon primary font-medium-4"
                    })), this.transit(function() {
                        i.removeClass("menu-collapsed").addClass("menu-expanded"), this.collapsed = !1, this.expanded = !0, e(".sidenav-overlay").removeClass("show")
                    }, function() {
                        e(".main-menu").hasClass("menu-native-scroll") || i.data("menu") == "horizontal-menu" ? this.manualScroller.disable() : e(".main-menu").hasClass("menu-fixed") && this.manualScroller.enable(), (i.data("menu") == "vertical-menu" || i.data("menu") == "vertical-menu-modern") && e(".main-menu").hasClass("menu-fixed") && e(".main-menu-content").css("height", e(n).height() - e(".header-navbar").height() - e(".main-menu-header").outerHeight() - e(".main-menu-footer").outerHeight())
                    }))
                },
                collapse: function() {
                    this.collapsed === !1 && (i.data("menu") == "vertical-menu-modern" && e(".modern-nav-toggle").find(".collapse-toggle-icon").replaceWith(feather.icons.circle.toSvg({
                        class: "d-none d-xl-block collapse-toggle-icon primary font-medium-4"
                    })), this.transit(function() {
                        i.removeClass("menu-expanded").addClass("menu-collapsed"), this.collapsed = !0, this.expanded = !1, e(".content-overlay").removeClass("d-block d-none")
                    }, function() {
                        i.data("menu") == "horizontal-menu" && i.hasClass("vertical-overlay-menu") && e(".main-menu").hasClass("menu-fixed") && this.manualScroller.enable(), (i.data("menu") == "vertical-menu" || i.data("menu") == "vertical-menu-modern") && e(".main-menu").hasClass("menu-fixed") && e(".main-menu-content").css("height", e(n).height() - e(".header-navbar").height()), i.data("menu") == "vertical-menu-modern" && e(".main-menu").hasClass("menu-fixed") && this.manualScroller.enable()
                    }))
                },
                toOverlayMenu: function(a, r) {
                    var m = i.data("menu");
                    r == "vertical-menu-modern" ? a == "lg" || a == "md" || a == "sm" || a == "xs" ? i.hasClass(m) && i.removeClass(m).addClass("vertical-overlay-menu") : i.hasClass("vertical-overlay-menu") && i.removeClass("vertical-overlay-menu").addClass(m) : a == "sm" || a == "xs" ? i.hasClass(m) && i.removeClass(m).addClass("vertical-overlay-menu") : i.hasClass("vertical-overlay-menu") && i.removeClass("vertical-overlay-menu").addClass(m)
                },
                changeMenu: function(a) {
                    e('div[data-menu="menu-wrapper"]').html(""), e('div[data-menu="menu-wrapper"]').html(f);
                    var r = e('div[data-menu="menu-wrapper"]');
                    e('div[data-menu="menu-container"]');
                    var m = e('ul[data-menu="menu-navigation"]'),
                        v = e('li[data-menu="dropdown"]'),
                        d = e('li[data-menu="dropdown-submenu"]');
                    a === "xl" ? (i.removeClass("vertical-layout vertical-overlay-menu fixed-navbar").addClass(i.data("menu")), e("nav.header-navbar").removeClass("fixed-top"), r.removeClass().addClass(h), e("a.dropdown-item.nav-has-children").on("click", function() {
                        event.preventDefault(), event.stopPropagation()
                    }), e("a.dropdown-item.nav-has-parent").on("click", function() {
                        event.preventDefault(), event.stopPropagation()
                    })) : (i.removeClass(i.data("menu")).addClass("vertical-layout vertical-overlay-menu fixed-navbar"), e("nav.header-navbar").addClass("fixed-top"), r.removeClass().addClass("main-menu menu-light menu-fixed menu-shadow"), m.removeClass().addClass("navigation navigation-main"), v.removeClass("dropdown").addClass("has-sub"), v.find("a").removeClass("dropdown-toggle nav-link"), v.find("a").attr("data-bs-toggle", ""), v.children("ul").find("a").removeClass("dropdown-item"), v.find("ul").removeClass("dropdown-menu"), d.removeClass().addClass("has-sub"), e.app.nav.init(), e("ul.dropdown-menu [data-bs-toggle=dropdown]").on("click", function(b) {
                        b.preventDefault(), b.stopPropagation(), e(this).parent().siblings().removeClass("open"), e(this).parent().toggleClass("open")
                    }), e(".main-menu-content").find("li.active").parents("li").addClass("sidebar-group-active"), e(".main-menu-content").find("li.active").closest("li.nav-item").addClass("open")), feather && feather.replace({
                        width: 14,
                        height: 14
                    })
                },
                toggle: function() {
                    var a = dt.fetch.now();
                    this.collapsed;
                    var r = this.expanded,
                        m = this.hidden,
                        v = i.data("menu");
                    switch (a.name) {
                        case "xl":
                            r === !0 ? v == "vertical-overlay-menu" ? this.hide() : this.collapse() : v == "vertical-overlay-menu" ? this.open() : this.expand();
                            break;
                        case "lg":
                            r === !0 ? v == "vertical-overlay-menu" || v == "vertical-menu-modern" || v == "horizontal-menu" ? this.hide() : this.collapse() : v == "vertical-overlay-menu" || v == "vertical-menu-modern" || v == "horizontal-menu" ? this.open() : this.expand();
                            break;
                        case "md":
                        case "sm":
                            m === !0 ? this.open() : this.hide();
                            break;
                        case "xs":
                            m === !0 ? this.open() : this.hide();
                            break
                    }
                },
                update: function() {
                    this.manualScroller.update()
                },
                reset: function() {
                    this.expanded = !1, this.collapsed = !1, this.hidden = !1, i.removeClass("menu-hide menu-open menu-collapsed menu-expanded")
                }
            }, e.app.nav = {
                container: e(".navigation-main"),
                initialized: !1,
                navItem: e(".navigation-main").find("li").not(".navigation-category"),
                TRANSITION_EVENTS: ["transitionend", "webkitTransitionEnd", "oTransitionEnd"],
                TRANSITION_PROPERTIES: ["transition", "MozTransition", "webkitTransition", "WebkitTransition", "OTransition"],
                config: {
                    speed: 300
                },
                init: function(a) {
                    this.initialized = !0, e.extend(this.config, a), this.bind_events()
                },
                bind_events: function() {
                    var a = this;
                    let r = {
                        target: null,
                        timestamp: null,
                        count: 0
                    };
                    e(".navigation-main").on("mouseenter.app.menu", "li", function() {
                        var d = e(this);
                        if (i.hasClass("menu-collapsed") && i.data("menu") != "vertical-menu-modern") {
                            e(".main-menu-content").children("span.menu-title").remove(), e(".main-menu-content").children("a.menu-title").remove(), e(".main-menu-content").children("ul.menu-content").remove();
                            var b = d.find("span.menu-title").clone(),
                                _, C;
                            d.hasClass("has-sub") || (_ = d.find("span.menu-title").text(), C = d.children("a").attr("href"), _ !== "" && (b = e("<a>"), b.attr("href", C), b.attr("title", _), b.text(_), b.addClass("menu-title")));
                            var N;
                            d.css("border-top") ? N = d.position().top + parseInt(d.css("border-top"), 10) : N = d.position().top, i.data("menu") !== "vertical-compact-menu" && b.appendTo(".main-menu-content").css({
                                position: "fixed",
                                top: N
                            })
                        }
                    }).on("mouseleave.app.menu", "li", function() {}).on("active.app.menu", "li", function(d) {
                        e(this).addClass("active"), d.stopPropagation()
                    }).on("deactive.app.menu", "li.active", function(d) {
                        e(this).removeClass("active"), d.stopPropagation()
                    }).on("open.app.menu", "li", function(d) {
                        var b = e(this);
                        if (a.expand(b), e(".main-menu").hasClass("menu-collapsible")) return !1;
                        b.siblings(".open").find("li.open").trigger("close.app.menu"), d.stopPropagation()
                    }).on("close.app.menu", "li.open", function(d) {
                        var b = e(this);
                        a.collapse(b), d.stopPropagation()
                    }).on("click.app.menu", "li", function(d) {
                        if (d.target === r.target && d.timeStamp === r.timestamp ? r.count++ : (r.count = 1, r.target = d.target, r.timestamp = d.timeStamp), !(r.count > 1)) {
                            var b = e(this);
                            b.is(".disabled") || i.hasClass("menu-collapsed") && i.data("menu") != "vertical-menu-modern" ? d.preventDefault() : b.has("ul").length ? b.is(".open") ? b.trigger("close.app.menu") : b.trigger("open.app.menu") : b.is(".active") || (b.siblings(".active").trigger("deactive.app.menu"), b.trigger("active.app.menu"))
                        }
                    }), e(".navbar-header, .main-menu").on("mouseenter", m).on("mouseleave", v);

                    function m() {
                        if (i.data("menu") == "vertical-menu-modern" && (e(".main-menu, .navbar-header").addClass("expanded"), i.hasClass("menu-collapsed"))) {
                            e(".main-menu li.open").length === 0 && e(".main-menu-content").find("li.active").parents("li").addClass("open");
                            var d = e(".main-menu li.menu-collapsed-open"),
                                b = d.children("ul");
                            b.hide().slideDown(200, function() {
                                e(this).css("display", "")
                            }), d.addClass("open").removeClass("menu-collapsed-open")
                        }
                    }

                    function v() {
                        i.hasClass("menu-collapsed") && i.data("menu") == "vertical-menu-modern" && setTimeout(function() {
                            if (e(".main-menu:hover").length === 0 && e(".navbar-header:hover").length === 0 && (e(".main-menu, .navbar-header").removeClass("expanded"), i.hasClass("menu-collapsed"))) {
                                var d = e(".main-menu li.open"),
                                    b = d.children("ul");
                                d.addClass("menu-collapsed-open"), b.show().slideUp(200, function() {
                                    e(this).css("display", "")
                                }), d.removeClass("open")
                            }
                        }, 1)
                    }
                    e(".main-menu-content").on("mouseleave", function() {
                        i.hasClass("menu-collapsed") && (e(".main-menu-content").children("span.menu-title").remove(), e(".main-menu-content").children("a.menu-title").remove(), e(".main-menu-content").children("ul.menu-content").remove()), e(".hover", ".navigation-main").removeClass("hover")
                    }), e(".navigation-main li.has-sub > a").on("click", function(d) {
                        d.preventDefault()
                    })
                },
                collapse: function(a, r) {
                    var m = a.children("ul"),
                        v = a.children().first(),
                        d = e(v).outerHeight();
                    a.css({
                        height: d + m.outerHeight() + "px",
                        overflow: "hidden"
                    }), a.addClass("menu-item-animating"), a.addClass("menu-item-closing"), e.app.nav._bindAnimationEndEvent(a, function() {
                        a.removeClass("open"), e.app.nav._clearItemStyle(a)
                    }), setTimeout(function() {
                        a.css({
                            height: d + "px"
                        })
                    }, 50)
                },
                expand: function(a, r) {
                    var m = a.children("ul"),
                        v = a.children().first(),
                        d = e(v).outerHeight();
                    a.addClass("menu-item-animating"), a.css({
                        overflow: "hidden",
                        height: d + "px"
                    }), a.addClass("open"), e.app.nav._bindAnimationEndEvent(a, function() {
                        e.app.nav._clearItemStyle(a)
                    }), setTimeout(function() {
                        a.css({
                            height: d + m.outerHeight() + "px"
                        })
                    }, 50)
                },
                _bindAnimationEndEvent(a, r) {
                    a = a[0];
                    var m = function(d) {
                        d.target === a && (e.app.nav._unbindAnimationEndEvent(a), r(d))
                    };
                    let v = n.getComputedStyle(a).transitionDuration;
                    v = parseFloat(v) * (v.indexOf("ms") !== -1 ? 1 : 1e3), a._menuAnimationEndEventCb = m, e.app.nav.TRANSITION_EVENTS.forEach(function(d) {
                        a.addEventListener(d, a._menuAnimationEndEventCb, !1)
                    }), a._menuAnimationEndEventTimeout = setTimeout(function() {
                        m({
                            target: a
                        })
                    }, v + 50)
                },
                _unbindAnimationEndEvent(a) {
                    var r = a._menuAnimationEndEventCb;
                    a._menuAnimationEndEventTimeout && (clearTimeout(a._menuAnimationEndEventTimeout), a._menuAnimationEndEventTimeout = null), r && (e.app.nav.TRANSITION_EVENTS.forEach(function(m) {
                        a.removeEventListener(m, r, !1)
                    }), a._menuAnimationEndEventCb = null)
                },
                _clearItemStyle: function(a) {
                    a.removeClass("menu-item-animating"), a.removeClass("menu-item-closing"), a.css({
                        overflow: "",
                        height: ""
                    })
                },
                refresh: function() {
                    e.app.nav.container.find(".open").removeClass("open")
                }
            }, e(s).on("click", 'a[href="#"]', function(a) {
                a.preventDefault()
            })
        })(window, document, jQuery), window.addEventListener("resize", function() {
            var n = window.innerHeight * .01;
            document.documentElement.style.setProperty("--vh", n + "px")
        })
    },
    Xt = () => {
        (function(n, s, e) {
            var l = e(".select2"),
                i = e(".select2-icons"),
                f = e(".max-length"),
                h = e(".hide-search"),
                a = e(".select2-data-array"),
                r = e(".select2-data-ajax"),
                m = e(".select2-size-lg"),
                v = e(".select2-size-sm"),
                d = e(".select2InModal");
            const b = "createdByThisFile";
            l.each(function() {
                var u = e(this);
                u.wrap('<div class="position-relative"></div>'), u.select2({
                    dropdownAutoWidth: !0,
                    width: "100%",
                    dropdownParent: u.parent()
                });
                const D = (k, P, c) => {
                    const p = new CustomEvent(P, {
                        detail: c
                    });
                    k.dispatchEvent(p)
                };
                u.on("change", function(k) {
                    k.detail !== b && D(u[0], "change", b)
                })
            }), i.each(function() {
                var u = e(this);
                u.wrap('<div class="position-relative"></div>'), u.select2({
                    dropdownAutoWidth: !0,
                    width: "100%",
                    minimumResultsForSearch: 1 / 0,
                    dropdownParent: u.parent(),
                    templateResult: _,
                    templateSelection: _,
                    escapeMarkup: function(D) {
                        return D
                    }
                })
            });

            function _(u) {
                if (u.element, !u.id) return u.text;
                var D = feather.icons[e(u.element).data("icon")].toSvg() + u.text;
                return D
            }
            f.wrap('<div class="position-relative"></div>').select2({
                dropdownAutoWidth: !0,
                width: "100%",
                maximumSelectionLength: 2,
                dropdownParent: f.parent(),
                placeholder: "Select maximum 2 items"
            }), h.select2({
                placeholder: "Selecione uma opção",
                minimumResultsForSearch: 1 / 0
            });
            var C = [{
                id: 0,
                text: "enhancement"
            }, {
                id: 1,
                text: "bug"
            }, {
                id: 2,
                text: "duplicate"
            }, {
                id: 3,
                text: "invalid"
            }, {
                id: 4,
                text: "wontfix"
            }];
            a.wrap('<div class="position-relative"></div>').select2({
                dropdownAutoWidth: !0,
                dropdownParent: a.parent(),
                width: "100%",
                data: C
            }), r.wrap('<div class="position-relative"></div>').select2({
                dropdownAutoWidth: !0,
                dropdownParent: r.parent(),
                width: "100%",
                ajax: {
                    url: "https://api.github.com/search/repositories",
                    dataType: "json",
                    delay: 250,
                    data: function(u) {
                        return {
                            q: u.term,
                            page: u.page
                        }
                    },
                    processResults: function(u, D) {
                        return D.page = D.page || 1, {
                            results: u.items,
                            pagination: {
                                more: D.page * 30 < u.total_count
                            }
                        }
                    },
                    cache: !0
                },
                placeholder: "Search for a repository",
                escapeMarkup: function(u) {
                    return u
                },
                minimumInputLength: 1,
                templateResult: N,
                templateSelection: I
            });

            function N(u) {
                if (u.loading) return u.text;
                var D = "<div class='select2-result-repository clearfix'><div class='select2-result-repository__avatar'><img src='" + u.owner.avatar_url + "' /></div><div class='select2-result-repository__meta'><div class='select2-result-repository__title'>" + u.full_name + "</div>";
                return u.description && (D += "<div class='select2-result-repository__description'>" + u.description + "</div>"), D += "<div class='select2-result-repository__statistics'><div class='select2-result-repository__forks'>" + feather.icons["share-2"].toSvg({
                    class: "me-50"
                }) + u.forks_count + " Forks</div><div class='select2-result-repository__stargazers'>" + feather.icons.star.toSvg({
                    class: "me-50"
                }) + u.stargazers_count + " Stars</div><div class='select2-result-repository__watchers'>" + feather.icons.eye.toSvg({
                    class: "me-50"
                }) + u.watchers_count + " Watchers</div></div></div></div>", D
            }

            function I(u) {
                return u.full_name || u.text
            }
            m.each(function() {
                var u = e(this);
                u.wrap('<div class="position-relative"></div>'), u.select2({
                    dropdownAutoWidth: !0,
                    dropdownParent: u.parent(),
                    width: "100%",
                    containerCssClass: "select-lg"
                })
            }), v.each(function() {
                var u = e(this);
                u.wrap('<div class="position-relative"></div>'), u.select2({
                    dropdownAutoWidth: !0,
                    dropdownParent: u.parent(),
                    width: "100%",
                    containerCssClass: "select-sm"
                })
            }), e("#select2InModal").on("shown.bs.modal", function() {
                d.select2({
                    placeholder: "Select a state"
                })
            })
        })(window, document, jQuery)
    };
var M = (n => (n.TRUE = "true", n.FALSE = "false", n))(M || {}),
    O = (n => (n.IS_SHOWING = "IS_SHOWING", n.IS_LOCKED = "IS_LOCKED", n.WAS_UNLOCKED = "WAS_UNLOCKED", n.HAS_DASHBOARD_MENU_OPENED = "HAS_DASHBOARD_MENU_OPENED", n.HAS_RUNNED_ON_FIRST_LOGIN = "HAS_RUNNED_ON_FIRST_LOGIN", n))(O || {}),
    je = (n => (n.SHOW = "inset(0% 0% 0% 0%)", n.HIDE = "inset(0% 69% 0% 0%)", n))(je || {}),
    ze = (n => (n[n.BIG_DEVICES = 1670] = "BIG_DEVICES", n[n.SMALL_DEVICES = 1200] = "SMALL_DEVICES", n))(ze || {});
class Qt {
    static async execute(s) {
        var l;
        const e = await Ht.get("/news", {
            token: ((l = s.authData) == null ? void 0 : l.token) ? ? ""
        });
        return e.statusCode === 401 ? {
            status: "UNAUTHORIZED"
        } : e.statusCode === 200 ? {
            status: "SUCCESS",
            data: {
                news: e.data
            }
        } : {
            status: "UNKNOWN"
        }
    }
}
const st = Vt.createStore("sidebar", null);

function pt(n) {
    let s;
    return {
        c() {
            s = ae("i")
        },
        l(e) {
            s = se(e, "I", {}), x(s).forEach(E)
        },
        m(e, l) {
            G(e, s, l)
        },
        d(e) {
            e && E(s)
        }
    }
}

function gt(n) {
    let s, e = (n[5] > 99 ? "99+" : n[5]) + "",
        l, i, f;
    return {
        c() {
            s = ae("span"), l = kt(e), this.h()
        },
        l(h) {
            s = se(h, "SPAN", {
                class: !0,
                "aria-label": !0
            });
            var a = x(s);
            l = It(a, e), a.forEach(E), this.h()
        },
        h() {
            w(s, "class", i = (n[3] ? "menu-item max-w-[100px]" : "menu-title") + " text-truncate ml-auto bg-red-500 text-white text-sm font-bold w-6 h-6 rounded-full flex items-center justify-center shadow-lg animate-pulse aspect-square"), w(s, "aria-label", f = "Notificações: " + n[5])
        },
        m(h, a) {
            G(h, s, a), j(s, l)
        },
        p(h, a) {
            a & 32 && e !== (e = (h[5] > 99 ? "99+" : h[5]) + "") && yt(l, e), a & 8 && i !== (i = (h[3] ? "menu-item max-w-[100px]" : "menu-title") + " text-truncate ml-auto bg-red-500 text-white text-sm font-bold w-6 h-6 rounded-full flex items-center justify-center shadow-lg animate-pulse aspect-square") && w(s, "class", i), a & 32 && f !== (f = "Notificações: " + h[5]) && w(s, "aria-label", f)
        },
        d(h) {
            h && E(s)
        }
    }
}

function Zt(n) {
    let s, e, l;
    const i = n[12].default,
        f = St(i, n, n[11], null);
    return {
        c() {
            s = ae("ul"), f && f.c(), this.h()
        },
        l(h) {
            s = se(h, "UL", {
                class: !0,
                id: !0
            });
            var a = x(s);
            f && f.l(a), a.forEach(E), this.h()
        },
        h() {
            var h;
            w(s, "class", "menu-content"), w(s, "id", e = ((h = n[7]) == null ? void 0 : h.theme) === "Dark" ? "menuContent-dark" : "menuContent-light")
        },
        m(h, a) {
            G(h, s, a), f && f.m(s, null), l = !0
        },
        p(h, a) {
            var r;
            f && f.p && (!l || a & 2048) && Et(f, i, h, h[11], l ? wt(i, h[11], a, null) : Ct(h[11]), null), (!l || a & 128 && e !== (e = ((r = h[7]) == null ? void 0 : r.theme) === "Dark" ? "menuContent-dark" : "menuContent-light")) && w(s, "id", e)
        },
        i(h) {
            l || (T(f, h), l = !0)
        },
        o(h) {
            L(f, h), l = !1
        },
        d(h) {
            h && E(s), f && f.d(h)
        }
    }
}

function Yt(n) {
    let s, e, l, i, f, h, a, r, m, v, d, b, _, C, N, I = n[3] && pt();
    var u = n[4] ? z.lock : n[0];

    function D(c, p) {
        return {}
    }
    u && (i = ot(u, D()));
    let k = n[5] != null && n[5] > 0 && gt(n),
        P = n[9] && Zt(n);
    return {
        c() {
            s = ae("li"), e = ae("a"), I && I.c(), l = U(), i && F(i.$$.fragment), f = U(), h = ae("span"), a = kt(n[1]), m = U(), k && k.c(), d = U(), P && P.c(), this.h()
        },
        l(c) {
            s = se(c, "LI", {
                class: !0
            });
            var p = x(s);
            e = se(p, "A", {
                class: !0,
                href: !0
            });
            var g = x(e);
            I && I.l(g), l = R(g), i && K(i.$$.fragment, g), f = R(g), h = se(g, "SPAN", {
                class: !0,
                title: !0
            });
            var A = x(h);
            a = It(A, n[1]), A.forEach(E), m = R(g), k && k.l(g), g.forEach(E), d = R(p), P && P.l(p), p.forEach(E), this.h()
        },
        h() {
            w(h, "class", r = (n[3] ? "menu-item max-w-[100px]" : "menu-title") + " text-truncate"), w(h, "title", n[1]), w(e, "class", "d-flex align-items-center main"), w(e, "href", v = n[4] ? "" : n[2]), w(s, "class", b = (n[3] ? "" : "nav-item") + " " + (n[4] ? "disabled" : "") + " " + (n[8] ? "active" : ""))
        },
        m(c, p) {
            G(c, s, p), j(s, e), I && I.m(e, null), j(e, l), i && V(i, e, null), j(e, f), j(e, h), j(h, a), j(e, m), k && k.m(e, null), j(s, d), P && P.m(s, null), n[13](s), _ = !0, C || (N = Ke(e, "click", n[10]), C = !0)
        },
        p(c, [p]) {
            if (c[3] ? I || (I = pt(), I.c(), I.m(e, l)) : I && (I.d(1), I = null), p & 17 && u !== (u = c[4] ? z.lock : c[0])) {
                if (i) {
                    Xe();
                    const g = i;
                    L(g.$$.fragment, 1, 0, () => {
                        B(g, 1)
                    }), Qe()
                }
                u ? (i = ot(u, D()), F(i.$$.fragment), T(i.$$.fragment, 1), V(i, e, f)) : i = null
            }(!_ || p & 2) && yt(a, c[1]), (!_ || p & 8 && r !== (r = (c[3] ? "menu-item max-w-[100px]" : "menu-title") + " text-truncate")) && w(h, "class", r), (!_ || p & 2) && w(h, "title", c[1]), c[5] != null && c[5] > 0 ? k ? k.p(c, p) : (k = gt(c), k.c(), k.m(e, null)) : k && (k.d(1), k = null), (!_ || p & 20 && v !== (v = c[4] ? "" : c[2])) && w(e, "href", v), c[9] && P.p(c, p), (!_ || p & 24 && b !== (b = (c[3] ? "" : "nav-item") + " " + (c[4] ? "disabled" : "") + " " + (c[8] ? "active" : ""))) && w(s, "class", b)
        },
        i(c) {
            _ || (i && T(i.$$.fragment, c), T(P), _ = !0)
        },
        o(c) {
            i && L(i.$$.fragment, c), L(P), _ = !1
        },
        d(c) {
            c && E(s), I && I.d(), i && B(i), k && k.d(), P && P.d(), n[13](null), C = !1, N()
        }
    }
}

function xt(n, s, e) {
    let l, i, f;
    Fe(n, st, g => e(14, l = g)), Fe(n, Gt, g => e(15, i = g)), Fe(n, Nt, g => e(7, f = g));
    let {
        $$slots: h = {},
        $$scope: a
    } = s, {
        icon: r
    } = s, {
        title: m
    } = s, {
        href: v
    } = s, {
        subItem: d = !1
    } = s, {
        isDisabled: b = !1
    } = s, {
        notificationCount: _ = void 0
    } = s;
    const C = i.url.pathname,
        N = C === v || C === `${v}/`,
        u = s.$$slots != null,
        k = u && (g => l != null && l[g] === !0)(m);
    let P;
    const c = () => {
        if (u) {
            const g = P.classList.contains("open");
            qe(st, l = { ...l,
                [m]: !g
            }, l)
        }
    };
    Dt(() => {
        k && P.classList.add("open"), u && P.querySelector(".active") != null && (qe(st, l = { ...l,
            [m]: !0
        }, l), localStorage.setItem(O.HAS_DASHBOARD_MENU_OPENED, M.TRUE))
    });

    function p(g) {
        We[g ? "unshift" : "push"](() => {
            P = g, e(6, P)
        })
    }
    return n.$$set = g => {
        e(20, s = rt(rt({}, s), ut(g))), "icon" in g && e(0, r = g.icon), "title" in g && e(1, m = g.title), "href" in g && e(2, v = g.href), "subItem" in g && e(3, d = g.subItem), "isDisabled" in g && e(4, b = g.isDisabled), "notificationCount" in g && e(5, _ = g.notificationCount), "$$scope" in g && e(11, a = g.$$scope)
    }, s = ut(s), [r, m, v, d, b, _, P, f, N, u, c, a, h, p]
}
class q extends it {
    constructor(s) {
        super(), lt(this, s, xt, Yt, at, {
            icon: 0,
            title: 1,
            href: 2,
            subItem: 3,
            isDisabled: 4,
            notificationCount: 5
        })
    }
}

function vt(n, s, e) {
    const l = n.slice();
    return l[58] = s[e], l
}

function $t(n) {
    let s, e;
    return s = new q({
        props: {
            icon: z.multipleDashboards,
            title: "Dashboards",
            href: null,
            $$slots: {
                default: [nn]
            },
            $$scope: {
                ctx: n
            }
        }
    }), {
        c() {
            F(s.$$.fragment)
        },
        l(l) {
            K(s.$$.fragment, l)
        },
        m(l, i) {
            V(s, l, i), e = !0
        },
        p(l, i) {
            const f = {};
            i[0] & 32 | i[1] & 1073741824 && (f.$$scope = {
                dirty: i,
                ctx: l
            }), s.$set(f)
        },
        i(l) {
            e || (T(s.$$.fragment, l), e = !0)
        },
        o(l) {
            L(s.$$.fragment, l), e = !1
        },
        d(l) {
            B(s, l)
        }
    }
}

function en(n) {
    var ne, W, X, $, ie, le, re, fe, ce, Z, Ee, ue, ve, o, y, me, oe, te, he, ge, de, be, Ce, ye, Ie, ke, De, _e, Me, Ne, Ae, pe, Oe, Q, Te, Le;
    let s, e, l, i, f, h, a, r, m, v, d, b, _, C, N, I, u, D, k, P, c, p, g, A;
    return s = new q({
        props: {
            icon: z.summary,
            title: J.summary,
            isDisabled: !((ne = n[19]) != null && ne.access.resume) || !1,
            href: H.summary((X = (W = n[19]) == null ? void 0 : W.dashboard) == null ? void 0 : X.id)
        }
    }), l = new q({
        props: {
            icon: z.campaigns,
            title: J.campaigns,
            isDisabled: !(($ = n[19]) != null && $.access.campaigns) || !1,
            href: H.campaigns((le = (ie = n[19]) == null ? void 0 : ie.dashboard) == null ? void 0 : le.id)
        }
    }), f = new q({
        props: {
            icon: z.google,
            title: J.google,
            isDisabled: !((re = n[19]) != null && re.access.google) || !1,
            href: H.google((ce = (fe = n[19]) == null ? void 0 : fe.dashboard) == null ? void 0 : ce.id)
        }
    }), a = new q({
        props: {
            icon: z.kwai,
            title: J.kwai,
            isDisabled: !((Z = n[19]) != null && Z.access.kwai) || !1,
            href: H.kwai((ue = (Ee = n[19]) == null ? void 0 : Ee.dashboard) == null ? void 0 : ue.id)
        }
    }), m = new q({
        props: {
            icon: z.tikTok,
            title: J.tikTok,
            isDisabled: !((ve = n[19]) != null && ve.access.tikTok) || !1,
            href: H.tikTok((y = (o = n[19]) == null ? void 0 : o.dashboard) == null ? void 0 : y.id)
        }
    }), d = new q({
        props: {
            icon: z.utms,
            title: J.utms,
            isDisabled: !((me = n[19]) != null && me.access.utms) || !1,
            href: H.utms((te = (oe = n[19]) == null ? void 0 : oe.dashboard) == null ? void 0 : te.id)
        }
    }), _ = new q({
        props: {
            icon: z.integrations,
            title: J.integrations,
            isDisabled: !((he = n[19]) != null && he.access.integrations) || !1,
            href: H.integrations((de = (ge = n[19]) == null ? void 0 : ge.dashboard) == null ? void 0 : de.id)
        }
    }), N = new q({
        props: {
            icon: z.rules,
            title: J.rules,
            isDisabled: !((be = n[19]) != null && be.access.rules) || !1,
            href: H.rules((ye = (Ce = n[19]) == null ? void 0 : Ce.dashboard) == null ? void 0 : ye.id)
        }
    }), u = new q({
        props: {
            icon: z.additionalValues,
            title: J.additionalValues,
            isDisabled: !((Ie = n[19]) != null && Ie.access.fees) || !1,
            href: H.additionalValues((De = (ke = n[19]) == null ? void 0 : ke.dashboard) == null ? void 0 : De.id)
        }
    }), k = new q({
        props: {
            icon: z.customSpendings,
            title: J.customSpendings,
            isDisabled: !((_e = n[19]) != null && _e.access.customSpending) || !1,
            href: H.customSpendings((Ne = (Me = n[19]) == null ? void 0 : Me.dashboard) == null ? void 0 : Ne.id)
        }
    }), c = new q({
        props: {
            icon: z.reports,
            title: J.reports,
            isDisabled: !((Ae = n[19]) != null && Ae.access.reports) || !1,
            href: H.reports((Oe = (pe = n[19]) == null ? void 0 : pe.dashboard) == null ? void 0 : Oe.id)
        }
    }), g = new q({
        props: {
            icon: z.notifications,
            title: J.notifications,
            isDisabled: !((Q = n[19]) != null && Q.access.notifications) || !1,
            href: H.notifications((Le = (Te = n[19]) == null ? void 0 : Te.dashboard) == null ? void 0 : Le.id)
        }
    }), {
        c() {
            F(s.$$.fragment), e = U(), F(l.$$.fragment), i = U(), F(f.$$.fragment), h = U(), F(a.$$.fragment), r = U(), F(m.$$.fragment), v = U(), F(d.$$.fragment), b = U(), F(_.$$.fragment), C = U(), F(N.$$.fragment), I = U(), F(u.$$.fragment), D = U(), F(k.$$.fragment), P = U(), F(c.$$.fragment), p = U(), F(g.$$.fragment)
        },
        l(t) {
            K(s.$$.fragment, t), e = R(t), K(l.$$.fragment, t), i = R(t), K(f.$$.fragment, t), h = R(t), K(a.$$.fragment, t), r = R(t), K(m.$$.fragment, t), v = R(t), K(d.$$.fragment, t), b = R(t), K(_.$$.fragment, t), C = R(t), K(N.$$.fragment, t), I = R(t), K(u.$$.fragment, t), D = R(t), K(k.$$.fragment, t), P = R(t), K(c.$$.fragment, t), p = R(t), K(g.$$.fragment, t)
        },
        m(t, S) {
            V(s, t, S), G(t, e, S), V(l, t, S), G(t, i, S), V(f, t, S), G(t, h, S), V(a, t, S), G(t, r, S), V(m, t, S), G(t, v, S), V(d, t, S), G(t, b, S), V(_, t, S), G(t, C, S), V(N, t, S), G(t, I, S), V(u, t, S), G(t, D, S), V(k, t, S), G(t, P, S), V(c, t, S), G(t, p, S), V(g, t, S), A = !0
        },
        p: Ot,
        i(t) {
            A || (T(s.$$.fragment, t), T(l.$$.fragment, t), T(f.$$.fragment, t), T(a.$$.fragment, t), T(m.$$.fragment, t), T(d.$$.fragment, t), T(_.$$.fragment, t), T(N.$$.fragment, t), T(u.$$.fragment, t), T(k.$$.fragment, t), T(c.$$.fragment, t), T(g.$$.fragment, t), A = !0)
        },
        o(t) {
            L(s.$$.fragment, t), L(l.$$.fragment, t), L(f.$$.fragment, t), L(a.$$.fragment, t), L(m.$$.fragment, t), L(d.$$.fragment, t), L(_.$$.fragment, t), L(N.$$.fragment, t), L(u.$$.fragment, t), L(k.$$.fragment, t), L(c.$$.fragment, t), L(g.$$.fragment, t), A = !1
        },
        d(t) {
            t && (E(e), E(i), E(h), E(r), E(v), E(b), E(C), E(I), E(D), E(P), E(p)), B(s, t), B(l, t), B(f, t), B(a, t), B(m, t), B(d, t), B(_, t), B(N, t), B(u, t), B(k, t), B(c, t), B(g, t)
        }
    }
}

function tn(n) {
    var W, X, $, ie, le, re, fe, ce, Z, Ee, ue, ve;
    let s, e, l, i, f, h, a, r, m, v, d, b, _, C, N, I, u, D, k, P, c, p, g, A, ne;
    return s = new q({
        props: {
            subItem: !0,
            icon: z.summary,
            title: J.summary,
            isDisabled: !((W = n[58].access) != null && W.resume) || !1,
            href: H.summary(n[58].dashboard.id)
        }
    }), l = new q({
        props: {
            subItem: !0,
            icon: z.campaigns,
            title: J.campaigns,
            isDisabled: !((X = n[58].access) != null && X.campaigns) || !1,
            href: H.campaigns(n[58].dashboard.id)
        }
    }), f = new q({
        props: {
            subItem: !0,
            icon: z.google,
            title: J.google,
            isDisabled: !(($ = n[58].access) != null && $.google) || !1,
            href: H.google(n[58].dashboard.id)
        }
    }), a = new q({
        props: {
            subItem: !0,
            icon: z.kwai,
            title: J.kwai,
            isDisabled: !((ie = n[58].access) != null && ie.kwai) || !1,
            href: H.kwai(n[58].dashboard.id)
        }
    }), m = new q({
        props: {
            subItem: !0,
            icon: z.tikTok,
            title: J.tikTok,
            isDisabled: !((le = n[58].access) != null && le.tikTok) || !1,
            href: H.tikTok(n[58].dashboard.id)
        }
    }), d = new q({
        props: {
            subItem: !0,
            icon: z.utms,
            title: J.utms,
            isDisabled: !((re = n[58].access) != null && re.utms) || !1,
            href: H.utms(n[58].dashboard.id)
        }
    }), _ = new q({
        props: {
            subItem: !0,
            icon: z.integrations,
            title: J.integrations,
            isDisabled: !((fe = n[58].access) != null && fe.integrations) || !1,
            href: H.integrations(n[58].dashboard.id)
        }
    }), N = new q({
        props: {
            subItem: !0,
            icon: z.rules,
            title: J.rules,
            isDisabled: !((ce = n[58].access) != null && ce.rules) || !1,
            href: H.rules(n[58].dashboard.id)
        }
    }), u = new q({
        props: {
            subItem: !0,
            icon: z.additionalValues,
            title: J.additionalValues,
            isDisabled: !((Z = n[58].access) != null && Z.fees) || !1,
            href: H.additionalValues(n[58].dashboard.id)
        }
    }), k = new q({
        props: {
            subItem: !0,
            icon: z.customSpendings,
            title: J.customSpendings,
            isDisabled: !((Ee = n[58].access) != null && Ee.customSpending) || !1,
            href: H.customSpendings(n[58].dashboard.id)
        }
    }), c = new q({
        props: {
            subItem: !0,
            icon: z.reports,
            title: J.reports,
            isDisabled: !((ue = n[58].access) != null && ue.reports) || !1,
            href: H.reports(n[58].dashboard.id)
        }
    }), g = new q({
        props: {
            subItem: !0,
            icon: z.notifications,
            title: J.notifications,
            isDisabled: !((ve = n[58].access) != null && ve.notifications) || !1,
            href: H.notifications(n[58].dashboard.id)
        }
    }), {
        c() {
            F(s.$$.fragment), e = U(), F(l.$$.fragment), i = U(), F(f.$$.fragment), h = U(), F(a.$$.fragment), r = U(), F(m.$$.fragment), v = U(), F(d.$$.fragment), b = U(), F(_.$$.fragment), C = U(), F(N.$$.fragment), I = U(), F(u.$$.fragment), D = U(), F(k.$$.fragment), P = U(), F(c.$$.fragment), p = U(), F(g.$$.fragment), A = U()
        },
        l(o) {
            K(s.$$.fragment, o), e = R(o), K(l.$$.fragment, o), i = R(o), K(f.$$.fragment, o), h = R(o), K(a.$$.fragment, o), r = R(o), K(m.$$.fragment, o), v = R(o), K(d.$$.fragment, o), b = R(o), K(_.$$.fragment, o), C = R(o), K(N.$$.fragment, o), I = R(o), K(u.$$.fragment, o), D = R(o), K(k.$$.fragment, o), P = R(o), K(c.$$.fragment, o), p = R(o), K(g.$$.fragment, o), A = R(o)
        },
        m(o, y) {
            V(s, o, y), G(o, e, y), V(l, o, y), G(o, i, y), V(f, o, y), G(o, h, y), V(a, o, y), G(o, r, y), V(m, o, y), G(o, v, y), V(d, o, y), G(o, b, y), V(_, o, y), G(o, C, y), V(N, o, y), G(o, I, y), V(u, o, y), G(o, D, y), V(k, o, y), G(o, P, y), V(c, o, y), G(o, p, y), V(g, o, y), G(o, A, y), ne = !0
        },
        p(o, y) {
            var _e, Me, Ne, Ae, pe, Oe, Q, Te, Le, t, S, Y;
            const me = {};
            y[0] & 32 && (me.isDisabled = !((_e = o[58].access) != null && _e.resume) || !1), y[0] & 32 && (me.href = H.summary(o[58].dashboard.id)), s.$set(me);
            const oe = {};
            y[0] & 32 && (oe.isDisabled = !((Me = o[58].access) != null && Me.campaigns) || !1), y[0] & 32 && (oe.href = H.campaigns(o[58].dashboard.id)), l.$set(oe);
            const te = {};
            y[0] & 32 && (te.isDisabled = !((Ne = o[58].access) != null && Ne.google) || !1), y[0] & 32 && (te.href = H.google(o[58].dashboard.id)), f.$set(te);
            const he = {};
            y[0] & 32 && (he.isDisabled = !((Ae = o[58].access) != null && Ae.kwai) || !1), y[0] & 32 && (he.href = H.kwai(o[58].dashboard.id)), a.$set(he);
            const ge = {};
            y[0] & 32 && (ge.isDisabled = !((pe = o[58].access) != null && pe.tikTok) || !1), y[0] & 32 && (ge.href = H.tikTok(o[58].dashboard.id)), m.$set(ge);
            const de = {};
            y[0] & 32 && (de.isDisabled = !((Oe = o[58].access) != null && Oe.utms) || !1), y[0] & 32 && (de.href = H.utms(o[58].dashboard.id)), d.$set(de);
            const be = {};
            y[0] & 32 && (be.isDisabled = !((Q = o[58].access) != null && Q.integrations) || !1), y[0] & 32 && (be.href = H.integrations(o[58].dashboard.id)), _.$set(be);
            const Ce = {};
            y[0] & 32 && (Ce.isDisabled = !((Te = o[58].access) != null && Te.rules) || !1), y[0] & 32 && (Ce.href = H.rules(o[58].dashboard.id)), N.$set(Ce);
            const ye = {};
            y[0] & 32 && (ye.isDisabled = !((Le = o[58].access) != null && Le.fees) || !1), y[0] & 32 && (ye.href = H.additionalValues(o[58].dashboard.id)), u.$set(ye);
            const Ie = {};
            y[0] & 32 && (Ie.isDisabled = !((t = o[58].access) != null && t.customSpending) || !1), y[0] & 32 && (Ie.href = H.customSpendings(o[58].dashboard.id)), k.$set(Ie);
            const ke = {};
            y[0] & 32 && (ke.isDisabled = !((S = o[58].access) != null && S.reports) || !1), y[0] & 32 && (ke.href = H.reports(o[58].dashboard.id)), c.$set(ke);
            const De = {};
            y[0] & 32 && (De.isDisabled = !((Y = o[58].access) != null && Y.notifications) || !1), y[0] & 32 && (De.href = H.notifications(o[58].dashboard.id)), g.$set(De)
        },
        i(o) {
            ne || (T(s.$$.fragment, o), T(l.$$.fragment, o), T(f.$$.fragment, o), T(a.$$.fragment, o), T(m.$$.fragment, o), T(d.$$.fragment, o), T(_.$$.fragment, o), T(N.$$.fragment, o), T(u.$$.fragment, o), T(k.$$.fragment, o), T(c.$$.fragment, o), T(g.$$.fragment, o), ne = !0)
        },
        o(o) {
            L(s.$$.fragment, o), L(l.$$.fragment, o), L(f.$$.fragment, o), L(a.$$.fragment, o), L(m.$$.fragment, o), L(d.$$.fragment, o), L(_.$$.fragment, o), L(N.$$.fragment, o), L(u.$$.fragment, o), L(k.$$.fragment, o), L(c.$$.fragment, o), L(g.$$.fragment, o), ne = !1
        },
        d(o) {
            o && (E(e), E(i), E(h), E(r), E(v), E(b), E(C), E(I), E(D), E(P), E(p), E(A)), B(s, o), B(l, o), B(f, o), B(a, o), B(m, o), B(d, o), B(_, o), B(N, o), B(u, o), B(k, o), B(c, o), B(g, o)
        }
    }
}

function bt(n, s) {
    let e, l, i;
    return l = new q({
        props: {
            subItem: !0,
            icon: z.dashboard,
            title: s[58].dashboard.name,
            href: null,
            $$slots: {
                default: [tn]
            },
            $$scope: {
                ctx: s
            }
        }
    }), {
        key: n,
        first: null,
        c() {
            e = Je(), F(l.$$.fragment), this.h()
        },
        l(f) {
            e = Je(), K(l.$$.fragment, f), this.h()
        },
        h() {
            this.first = e
        },
        m(f, h) {
            G(f, e, h), V(l, f, h), i = !0
        },
        p(f, h) {
            s = f;
            const a = {};
            h[0] & 32 && (a.title = s[58].dashboard.name), h[0] & 32 | h[1] & 1073741824 && (a.$$scope = {
                dirty: h,
                ctx: s
            }), l.$set(a)
        },
        i(f) {
            i || (T(l.$$.fragment, f), i = !0)
        },
        o(f) {
            L(l.$$.fragment, f), i = !1
        },
        d(f) {
            f && E(e), B(l, f)
        }
    }
}

function nn(n) {
    let s = [],
        e = new Map,
        l, i, f = mt(n[5]);
    const h = a => a[58].dashboard.id;
    for (let a = 0; a < f.length; a += 1) {
        let r = vt(n, f, a),
            m = h(r);
        e.set(m, s[a] = bt(m, r))
    }
    return {
        c() {
            for (let a = 0; a < s.length; a += 1) s[a].c();
            l = Je()
        },
        l(a) {
            for (let r = 0; r < s.length; r += 1) s[r].l(a);
            l = Je()
        },
        m(a, r) {
            for (let m = 0; m < s.length; m += 1) s[m] && s[m].m(a, r);
            G(a, l, r), i = !0
        },
        p(a, r) {
            r[0] & 32 && (f = mt(a[5]), Xe(), s = Tt(s, r, h, 1, a, f, e, l.parentNode, Lt, bt, l, vt), Qe())
        },
        i(a) {
            if (!i) {
                for (let r = 0; r < f.length; r += 1) T(s[r]);
                i = !0
            }
        },
        o(a) {
            for (let r = 0; r < s.length; r += 1) L(s[r]);
            i = !1
        },
        d(a) {
            a && E(l);
            for (let r = 0; r < s.length; r += 1) s[r].d(a)
        }
    }
}

function _t(n) {
    let s, e;
    return s = new q({
        props: {
            icon: z.queue,
            title: J.queue,
            href: H.queue
        }
    }), {
        c() {
            F(s.$$.fragment)
        },
        l(l) {
            K(s.$$.fragment, l)
        },
        m(l, i) {
            V(s, l, i), e = !0
        },
        i(l) {
            e || (T(s.$$.fragment, l), e = !0)
        },
        o(l) {
            L(s.$$.fragment, l), e = !1
        },
        d(l) {
            B(s, l)
        }
    }
}

function sn(n) {
    var Te, Le;
    let s, e, l, i, f, h, a, r, m, v, d, b, _, C, N, I, u, D, k, P, c, p, g, A, ne, W, X, $, ie, le, re, fe, ce, Z, Ee, ue, ve, o, y, me, oe, te, he, ge, de, be, Ce;

    function ye(t) {
        n[22](t)
    }

    function Ie(t) {
        n[23](t)
    }

    function ke(t) {
        n[24](t)
    }

    function De(t) {
        n[25](t)
    }
    let _e = {
        showEditButton: n[2]
    };
    n[0] !== void 0 && (_e.isEditing = n[0]), n[8] !== void 0 && (_e.navbarContainer = n[8]), n[6] !== void 0 && (_e.navThemebtt = n[6]), n[4] !== void 0 && (_e.editPanelbtt = n[4]), e = new Bt({
        props: _e
    }), We.push(() => Ge(e, "isEditing", ye)), We.push(() => Ge(e, "navbarContainer", Ie)), We.push(() => Ge(e, "navThemebtt", ke)), We.push(() => Ge(e, "editPanelbtt", De));

    function Me(t) {
        n[26](t)
    }
    let Ne = {
        navbarBrandStyle: !0
    };
    n[10] !== void 0 && (Ne.logo = n[10]), _ = new Ft({
        props: Ne
    }), We.push(() => Ge(_, "logo", Me));
    const Ae = [en, $t],
        pe = [];

    function Oe(t, S) {
        return t[5].length <= 1 ? 0 : 1
    }
    X = Oe(n), $ = pe[X] = Ae[X](n), le = new q({
        props: {
            icon: z.subscription,
            title: J.subscription,
            href: H.subscription
        }
    }), fe = new q({
        props: {
            icon: z.account,
            title: J.account,
            href: H.account
        }
    }), Z = new q({
        props: {
            icon: z.advanced,
            title: J.advanced,
            href: H.advanced
        }
    }), ue = new q({
        props: {
            icon: z.affiliate,
            title: J.affiliate,
            href: H.affiliate
        }
    }), o = new q({
        props: {
            icon: z.help,
            title: J.help,
            href: H.help
        }
    }), me = new q({
        props: {
            icon: z.news,
            title: J.news,
            href: H.news,
            notificationCount: n[13]
        }
    }), te = new q({
        props: {
            icon: z.app,
            title: J.app,
            href: H.app
        }
    });
    let Q = ((Le = (Te = n[3]) == null ? void 0 : Te.user) == null ? void 0 : Le.isSupport) && _t();
    return {
        c() {
            s = ae("div"), F(e.$$.fragment), r = U(), m = ae("div"), v = ae("div"), d = ae("ul"), b = ae("li"), F(_.$$.fragment), N = U(), I = ae("button"), u = nt("svg"), D = nt("circle"), k = nt("circle"), p = U(), g = ae("div"), A = U(), ne = ae("div"), W = ae("ul"), $.c(), ie = U(), F(le.$$.fragment), re = U(), F(fe.$$.fragment), ce = U(), F(Z.$$.fragment), Ee = U(), F(ue.$$.fragment), ve = U(), F(o.$$.fragment), y = U(), F(me.$$.fragment), oe = U(), F(te.$$.fragment), he = U(), Q && Q.c(), this.h()
        },
        l(t) {
            s = se(t, "DIV", {
                class: !0
            });
            var S = x(s);
            K(e.$$.fragment, S), S.forEach(E), r = R(t), m = se(t, "DIV", {
                class: !0,
                id: !0,
                "data-scroll-to-active": !0
            });
            var Y = x(m);
            v = se(Y, "DIV", {
                class: !0
            });
            var He = x(v);
            d = se(He, "UL", {
                class: !0
            });
            var Pe = x(d);
            b = se(Pe, "LI", {
                class: !0
            });
            var Se = x(b);
            K(_.$$.fragment, Se), N = R(Se), I = se(Se, "BUTTON", {
                style: !0,
                class: !0,
                id: !0
            });
            var we = x(I);
            u = tt(we, "svg", {
                xmlns: !0,
                width: !0,
                height: !0,
                viewBox: !0,
                fill: !0,
                stroke: !0,
                "stroke-width": !0,
                "stroke-linecap": !0,
                "stroke-linejoin": !0,
                class: !0
            });
            var Be = x(u);
            D = tt(Be, "circle", {
                cx: !0,
                cy: !0,
                r: !0
            }), x(D).forEach(E), k = tt(Be, "circle", {
                cx: !0,
                cy: !0,
                r: !0,
                class: !0,
                style: !0
            }), x(k).forEach(E), Be.forEach(E), we.forEach(E), Se.forEach(E), Pe.forEach(E), He.forEach(E), p = R(Y), g = se(Y, "DIV", {
                class: !0
            }), x(g).forEach(E), A = R(Y), ne = se(Y, "DIV", {
                class: !0,
                id: !0
            });
            var Re = x(ne);
            W = se(Re, "UL", {
                class: !0,
                id: !0,
                "data-menu": !0
            });
            var ee = x(W);
            $.l(ee), ie = R(ee), K(le.$$.fragment, ee), re = R(ee), K(fe.$$.fragment, ee), ce = R(ee), K(Z.$$.fragment, ee), Ee = R(ee), K(ue.$$.fragment, ee), ve = R(ee), K(o.$$.fragment, ee), y = R(ee), K(me.$$.fragment, ee), oe = R(ee), K(te.$$.fragment, ee), he = R(ee), Q && Q.l(ee), ee.forEach(E), Re.forEach(E), Y.forEach(E), this.h()
        },
        h() {
            var t, S, Y;
            w(s, "class", a = "!hidden xl:!block " + (n[1] ? "" : "opacity-0 !transition-none")), w(D, "cx", "12"), w(D, "cy", "12"), w(D, "r", "10"), w(k, "cx", "12"), w(k, "cy", "12"), w(k, "r", "3"), w(k, "class", "hidd"), et(k, "visibility", "hidden"), w(u, "xmlns", "http://www.w3.org/2000/svg"), w(u, "width", "24"), w(u, "height", "24"), w(u, "viewBox", "0 0 24 24"), w(u, "fill", "none"), w(u, "stroke", P = ((t = n[14]) == null ? void 0 : t.theme) === "Dark" ? "#d0d2d6" : "currentColor"), w(u, "stroke-width", "2"), w(u, "stroke-linecap", "round"), w(u, "stroke-linejoin", "round"), w(u, "class", ""), et(I, "width", "24px"), et(I, "height", "24px"), w(I, "class", "!mt-6 mr-6"), w(I, "id", c = ((S = n[14]) == null ? void 0 : S.theme) === "Dark" ? "lockBarbtt-dark" : "lockBarbtt-light"), w(b, "class", "nav-item me-auto flex !flex-row !items-center"), w(d, "class", "flex-row nav navbar-nav"), w(v, "class", "navbar-header"), w(g, "class", "shadow-bottom"), w(W, "class", "navigation navigation-main"), w(W, "id", "main-menu-navigation"), w(W, "data-menu", "menu-navigation"), w(ne, "class", "main-menu-content mt-2 svelte-eki4fs"), w(ne, "id", "sideDiv"), w(m, "class", "main-menu menu-fixed menu-light menu-accordion menu-shadow pb-2"), w(m, "id", ge = ((Y = n[14]) == null ? void 0 : Y.theme) === "Dark" ? "sideBar-dark" : "sideBar-light"), w(m, "data-scroll-to-active", "true")
        },
        m(t, S) {
            G(t, s, S), V(e, s, null), G(t, r, S), G(t, m, S), j(m, v), j(v, d), j(d, b), V(_, b, null), j(b, N), j(b, I), j(I, u), j(u, D), j(u, k), n[27](k), n[28](I), j(m, p), j(m, g), j(m, A), j(m, ne), j(ne, W), pe[X].m(W, null), j(W, ie), V(le, W, null), j(W, re), V(fe, W, null), j(W, ce), V(Z, W, null), j(W, Ee), V(ue, W, null), j(W, ve), V(o, W, null), j(W, y), V(me, W, null), j(W, oe), V(te, W, null), j(W, he), Q && Q.m(W, null), n[29](ne), n[30](m), de = !0, be || (Ce = [Ke(I, "click", n[17]), Ke(ne, "scroll", n[18]), Ke(m, "mouseover", n[15]), Ke(m, "mouseleave", n[16])], be = !0)
        },
        p(t, S) {
            var we, Be, Re, ee, Ue;
            const Y = {};
            S[0] & 4 && (Y.showEditButton = t[2]), !l && S[0] & 1 && (l = !0, Y.isEditing = t[0], Ve(() => l = !1)), !i && S[0] & 256 && (i = !0, Y.navbarContainer = t[8], Ve(() => i = !1)), !f && S[0] & 64 && (f = !0, Y.navThemebtt = t[6], Ve(() => f = !1)), !h && S[0] & 16 && (h = !0, Y.editPanelbtt = t[4], Ve(() => h = !1)), e.$set(Y), (!de || S[0] & 2 && a !== (a = "!hidden xl:!block " + (t[1] ? "" : "opacity-0 !transition-none"))) && w(s, "class", a);
            const He = {};
            !C && S[0] & 1024 && (C = !0, He.logo = t[10], Ve(() => C = !1)), _.$set(He), (!de || S[0] & 16384 && P !== (P = ((we = t[14]) == null ? void 0 : we.theme) === "Dark" ? "#d0d2d6" : "currentColor")) && w(u, "stroke", P), (!de || S[0] & 16384 && c !== (c = ((Be = t[14]) == null ? void 0 : Be.theme) === "Dark" ? "lockBarbtt-dark" : "lockBarbtt-light")) && w(I, "id", c);
            let Pe = X;
            X = Oe(t), X === Pe ? pe[X].p(t, S) : (Xe(), L(pe[Pe], 1, 1, () => {
                pe[Pe] = null
            }), Qe(), $ = pe[X], $ ? $.p(t, S) : ($ = pe[X] = Ae[X](t), $.c()), T($, 1), $.m(W, ie));
            const Se = {};
            S[0] & 8192 && (Se.notificationCount = t[13]), me.$set(Se), (ee = (Re = t[3]) == null ? void 0 : Re.user) != null && ee.isSupport ? Q ? S[0] & 8 && T(Q, 1) : (Q = _t(), Q.c(), T(Q, 1), Q.m(W, null)) : Q && (Xe(), L(Q, 1, 1, () => {
                Q = null
            }), Qe()), (!de || S[0] & 16384 && ge !== (ge = ((Ue = t[14]) == null ? void 0 : Ue.theme) === "Dark" ? "sideBar-dark" : "sideBar-light")) && w(m, "id", ge)
        },
        i(t) {
            de || (T(e.$$.fragment, t), T(_.$$.fragment, t), T($), T(le.$$.fragment, t), T(fe.$$.fragment, t), T(Z.$$.fragment, t), T(ue.$$.fragment, t), T(o.$$.fragment, t), T(me.$$.fragment, t), T(te.$$.fragment, t), T(Q), de = !0)
        },
        o(t) {
            L(e.$$.fragment, t), L(_.$$.fragment, t), L($), L(le.$$.fragment, t), L(fe.$$.fragment, t), L(Z.$$.fragment, t), L(ue.$$.fragment, t), L(o.$$.fragment, t), L(me.$$.fragment, t), L(te.$$.fragment, t), L(Q), de = !1
        },
        d(t) {
            t && (E(s), E(r), E(m)), B(e), B(_), n[27](null), n[28](null), pe[X].d(), B(le), B(fe), B(Z), B(ue), B(o), B(me), B(te), Q && Q.d(), n[29](null), n[30](null), be = !1, At(Ce)
        }
    }
}

function an(n, s, e) {
    let l, i, f, h, a;
    Fe(n, Mt, t => e(3, l = t)), Fe(n, ht, t => e(38, i = t)), Fe(n, ft, t => e(21, f = t)), Fe(n, ct, t => e(13, h = t)), Fe(n, Nt, t => e(14, a = t));
    let {
        isEditing: r = !1
    } = s, {
        showNavbar: m = !0
    } = s, {
        showEditButton: v = !1
    } = s, {
        refreshDashboards: d = null
    } = s, b = !1, _, C = [], N = [], I = [], u = [];
    const D = document.getElementsByClassName("app-content content margin-left-content h-full"),
        k = () => !!document.querySelector('.modal.show, .modal[aria-hidden="false"]');
    let P, c, p, g, A, ne, W, X = "",
        $ = "";
    const ie = () => localStorage.getItem(O.IS_SHOWING) === M.TRUE,
        le = () => localStorage.getItem(O.IS_SHOWING) === M.FALSE,
        re = () => localStorage.getItem(O.HAS_DASHBOARD_MENU_OPENED) === M.TRUE,
        fe = () => localStorage.getItem(O.HAS_DASHBOARD_MENU_OPENED) === M.FALSE,
        ce = () => localStorage.getItem(O.IS_LOCKED) === M.TRUE,
        Z = () => localStorage.getItem(O.IS_LOCKED) === M.FALSE,
        Ee = () => localStorage.getItem(O.WAS_UNLOCKED) === M.TRUE,
        ue = () => {
            u.length !== 0 && (u[0].style.transition = `max-height ${X} ease-in-out`, u[0].style.overflow = "hidden", u[0].style.maxHeight = "0em", u[0].style.display = $)
        },
        ve = () => {
            u.length !== 0 && (u[0].style.maxHeight = `${((C==null?void 0:C.length)??4)*36}em`, u[0].style.transition = `max-height ${X} ease-in-out`, u[0].style.overflow = "hidden", u[0].style.display = $)
        },
        o = async () => {
            var S;
            const t = await Qt.execute({
                authData: l == null ? void 0 : l.authData
            });
            switch (t.status) {
                case "SUCCESS":
                    const {
                        news: Y
                    } = t.data, He = Y.map(Se => Se._id), Pe = ((S = l == null ? void 0 : l.user) == null ? void 0 : S.readNewsIds) ? ? [];
                    qe(ct, h = He.filter(Se => !Pe.includes(Se)).length, h);
                    break;
                case "UNAUTHORIZED":
                    Wt.navigateTo("/sessao-expirada");
                    break
            }
        };

    function y() {
        I.length !== 0 && (I[0].onclick = () => {
            b = !b, localStorage.setItem(O.HAS_DASHBOARD_MENU_OPENED, b.toString()), re() && (b = !0, localStorage.setItem(O.HAS_DASHBOARD_MENU_OPENED, M.TRUE), X = "0.4s", $ = "block", ve()), fe() && (b = !1, localStorage.setItem(O.HAS_DASHBOARD_MENU_OPENED, M.FALSE), setTimeout(() => {
                X = "0s", $ = "none", ue()
            }, 200))
        }, (Z() && ie() && re() || ce() && ie() && re() || Z() && le() && re()) && (b = !0, localStorage.setItem(O.HAS_DASHBOARD_MENU_OPENED, M.TRUE)), le() && Z() && (re() ? (b = !0, localStorage.setItem(O.HAS_DASHBOARD_MENU_OPENED, M.TRUE), I[0].style.setProperty("--alternate-display", "none"), X = "0s", ue()) : I[0].style.setProperty("--alternate-display", "none")), ie() && Z() && fe() && (b = !1, X = "0s", ue()))
    }

    function me() {
        localStorage.removeItem(O.HAS_RUNNED_ON_FIRST_LOGIN), O.HAS_RUNNED_ON_FIRST_LOGIN in localStorage || (!(O.IS_SHOWING in localStorage) && !(O.IS_LOCKED in localStorage) && (localStorage.setItem(O.IS_SHOWING, M.TRUE), localStorage.setItem(O.IS_LOCKED, M.TRUE), C.length > 1 && localStorage.setItem(O.HAS_DASHBOARD_MENU_OPENED, M.TRUE)), localStorage.setItem(O.HAS_RUNNED_ON_FIRST_LOGIN, M.TRUE))
    }
    me();

    function oe() {
        var ee;
        const t = (D == null ? void 0 : D[0]) ? ? document.querySelector(".app-content.content.margin-left-content.h-full");
        if (!p || !t) return;
        const S = window.innerWidth >= ze.BIG_DEVICES,
            Y = window.innerWidth <= ze.BIG_DEVICES && window.innerWidth >= ze.SMALL_DEVICES,
            He = window.innerWidth <= ze.SMALL_DEVICES,
            Pe = ((ee = document == null ? void 0 : document.body) == null ? void 0 : ee.clientWidth) ? ? 0,
            Se = (t == null ? void 0 : t.clientWidth) ? ? 0,
            we = Math.max(0, Pe - Se),
            Be = t.clientHeight < t.scrollHeight,
            Re = we > 0;
        if (Z()) {
            let Ue = "9.65rem";
            we > 65 && we <= 69 ? Ue = Re ? "10.9rem" : "9.7rem" : we <= 65 && (Ue = Re ? "10.8rem" : "9.7rem");
            const Ze = "1.3rem auto 0 2rem",
                Ye = "0 0.5rem",
                xe = "85px",
                $e = "4.5rem";
            S || Y ? (e(8, p.style.left = xe, p), e(8, p.style.padding = Ye, p), e(8, p.style.margin = Ze, p), e(8, p.style.width = `calc(100% - 5px - ${Ue} + 0vw)`, p), t.style.paddingLeft = $e) : He && (t.style.paddingLeft = "2rem", localStorage.setItem(O.IS_SHOWING, M.FALSE), localStorage.setItem(O.IS_LOCKED, M.FALSE))
        } else {
            let Ue = Be ? "23.45rem" : "22.2rem";
            we > 65 ? Ue = Re ? "23.45rem" : "22.2rem" : we <= 65 && (Ue = Re ? "23.3rem" : "22.2rem");
            const Ze = "1.3rem auto 0 16.45rem",
                Ye = "0 0.5rem",
                xe = "58px",
                $e = "17rem";
            S || Y ? (e(8, p.style.margin = Ze, p), e(8, p.style.width = `calc(100% - 5px - ${Ue} + 0vw)`, p), e(8, p.style.padding = Ye, p), e(8, p.style.left = xe, p), t.style.paddingLeft = $e) : He && (localStorage.setItem(O.IS_SHOWING, M.FALSE), localStorage.setItem(O.IS_LOCKED, M.FALSE))
        }
    }

    function te() {
        c !== null && (localStorage.setItem(O.IS_SHOWING, M.TRUE), ie() ? (e(7, c.style.transition = "all .6s", c), c.style.setProperty("--alternate-width", "260px"), e(10, A.style.clipPath = je.SHOW, A), C.length > 1 && (I[0].style.setProperty("--alternate-display", "inline-block"), re() && (setTimeout(() => {
            X = "0.4s", ve()
        }, 50), $ = "block"))) : (localStorage.setItem(O.IS_SHOWING, M.FALSE), e(10, A.style.clipPath = je.HIDE, A), C.length > 1 && I[0].style.setProperty("--alternate-display", "none")))
    }

    function he() {
        localStorage.setItem(O.IS_SHOWING, M.FALSE), c !== null && (ie() ? te() : Z() && (e(7, c.style.transition = "all .6s", c), e(10, A.style.transition = "all .5s", A), c.style.setProperty("--alternate-width", "82px"), e(10, A.style.clipPath = je.HIDE, A), C.length > 1 && (I[0].style.setProperty("--alternate-display", "none"), re() && setTimeout(() => {
            X = "0.2s", ue()
        }, 100))))
    }

    function ge() {
        v && (e(4, _.onclick = () => {
            Z() && r === !0 && (localStorage.setItem(O.WAS_UNLOCKED, M.TRUE), localStorage.setItem(O.IS_SHOWING, M.TRUE), localStorage.setItem(O.IS_LOCKED, M.TRUE), e(9, g.style.visibility = "visible", g), oe()), te(), D[0].style.transition = "all .0s", e(8, p.style.transition = "all .0s", p), e(7, c.style.transition = "all .0s", c), e(10, A.style.transition = "all .0s", A)
        }, _), Ee() && r === !1 && (localStorage.setItem(O.IS_SHOWING, M.FALSE), localStorage.setItem(O.IS_LOCKED, M.FALSE), e(9, g.style.visibility = "hidden", g), oe(), he(), D[0].style.transition = "all .0s", e(8, p.style.transition = "all .0s", p), e(7, c.style.transition = "all .0s", c), e(10, A.style.transition = "all .0s", A), localStorage.setItem(O.WAS_UNLOCKED, M.FALSE)))
    }

    function de() {
        if (ne !== null) {
            if (ce()) {
                let t = !0;
                t = !t, localStorage.setItem(O.IS_LOCKED, t.toString())
            } else {
                let t = !1;
                t = !t, localStorage.setItem(O.IS_LOCKED, t.toString())
            }
            ce() ? (localStorage.setItem(O.IS_SHOWING, M.TRUE), localStorage.setItem(O.IS_LOCKED, M.TRUE), e(9, g.style.visibility = "visible", g), oe()) : (localStorage.setItem(O.IS_LOCKED, M.FALSE), e(9, g.style.visibility = "hidden", g), oe()), Z() && ie() && (te(), e(7, c.style.transition = "all .0s", c), e(10, A.style.transition = "all .0s", A), D[0].style.transition = "all .6s", e(8, p.style.transition = "all .6s", p)), ce() && ie() && (te(), e(7, c.style.transition = "all .0s", c), e(10, A.style.transition = "all .0s", A), D[0].style.transition = "all .6s", e(8, p.style.transition = "all .6s", p)), ge(), setTimeout(() => {
                e(7, c.style.transition = "none", c), e(10, A.style.transition = "none", A), D[0].style.transition = "none", e(8, p.style.transition = "none", p)
            }, 600)
        }
    }

    function be() {
        window.onmousemove = t => {
            t.clientX > 260 && !k() ? setTimeout(() => {
                localStorage.setItem(O.IS_SHOWING, M.FALSE), Ee() && le() && Z() && (localStorage.setItem(O.IS_SHOWING, M.FALSE), localStorage.setItem(O.IS_LOCKED, M.FALSE), e(9, g.style.visibility = "hidden", g), oe(), he(), D[0].style.transition = "all .6s", e(8, p.style.transition = "all .6s", p), e(7, c.style.transition = "all .6s", c), e(10, A.style.transition = "all .5s", A))
            }, 140) : t.clientX < 80 && !k() && (localStorage.setItem(O.IS_SHOWING, M.TRUE), te())
        }
    }

    function Ce() {
        P != null && e(6, P.onclick = () => {
            D[0].style.transition = "all .0s", e(8, p.style.transition = "all .0s", p), c !== null && e(7, c.style.transition = "all .0s", c)
        }, P)
    }

    function ye() {
        ce() ? (localStorage.setItem(O.IS_SHOWING, M.TRUE), localStorage.setItem(O.IS_LOCKED, M.TRUE), e(9, g.style.visibility = "visible", g), ce() && ie() && (te(), D[0].style.transition = "all .0s", e(8, p.style.transition = "all .0s", p), e(7, c.style.transition = "all .0s", c), e(10, A.style.transition = "all .0s", A), C.length > 1 && re() && (X = "0s", ve())), oe()) : (localStorage.setItem(O.IS_LOCKED, M.FALSE), e(9, g.style.visibility = "hidden", g), D[0].style.transition = "all .0s", e(8, p.style.transition = "all .0s", p), setTimeout(() => {
            be()
        }, 140), Z() && ie() && c && p && A !== null && (te(), D[0].style.transition = "all .0s", e(8, p.style.transition = "all .0s", p), e(7, c.style.transition = "all .0s", c), e(10, A.style.transition = "all .0s", A), setTimeout(() => {
            Z() && le() && c && p && A !== null && (D[0].style.transition = "all .0s", e(8, p.style.transition = "all .0s", p), he())
        }, 280)), Z() && le() && c && p && A !== null && (D[0].style.transition = "all .0s", e(8, p.style.transition = "all .0s", p), he()), ge(), oe(), Ce())
    }

    function Ie() {
        qe(ht, i = {
            top: W != null && W.scrollTop ? W.scrollTop : 0
        }, i)
    }

    function ke() {
        const t = i == null ? void 0 : i.top;
        t && W.scrollTo(0, t)
    }
    d = () => {
        e(5, N = Pt(l)), C = (l == null ? void 0 : l.user.dashboards) ? ? [], setTimeout(() => {
            Rt()
        }, 0), setTimeout(() => {
            C.length > 1 && y()
        }, 100)
    }, d();
    const De = N.length > 0 ? N[0] : null;
    Dt(() => {
        I = Array.from(document.getElementsByClassName("d-flex align-items-center main")), u = Array.from(document.getElementsByClassName("menu-content")), o(), Jt(), Ut(), Xt(), ye(), ge(), oe(), Ce(), ke();
        const t = () => {
                setTimeout(() => {
                    be()
                }, 140)
            },
            S = () => {
                c.removeEventListener("mouseleave", t), c.addEventListener("mouseleave", t)
            };
        document.removeEventListener("DOMContentLoaded", S), document.addEventListener("DOMContentLoaded", S), C.length > 1 && y()
    });

    function _e(t) {
        r = t, e(0, r)
    }

    function Me(t) {
        p = t, e(8, p)
    }

    function Ne(t) {
        P = t, e(6, P)
    }

    function Ae(t) {
        _ = t, e(4, _)
    }

    function pe(t) {
        A = t, e(10, A)
    }

    function Oe(t) {
        We[t ? "unshift" : "push"](() => {
            g = t, e(9, g)
        })
    }

    function Q(t) {
        We[t ? "unshift" : "push"](() => {
            ne = t, e(11, ne)
        })
    }

    function Te(t) {
        We[t ? "unshift" : "push"](() => {
            W = t, e(12, W)
        })
    }

    function Le(t) {
        We[t ? "unshift" : "push"](() => {
            c = t, e(7, c)
        })
    }
    return n.$$set = t => {
        "isEditing" in t && e(0, r = t.isEditing), "showNavbar" in t && e(1, m = t.showNavbar), "showEditButton" in t && e(2, v = t.showEditButton), "refreshDashboards" in t && e(20, d = t.refreshDashboards)
    }, n.$$.update = () => {
        var t;
        if (n.$$.dirty[0] & 2097160) {
            const S = ((t = l == null ? void 0 : l.user) == null ? void 0 : t.readNewsIds) ? ? [],
                Y = f;
            JSON.stringify(S) !== JSON.stringify(Y) && (o(), ft.set([...S]))
        }
    }, [r, m, v, l, _, N, P, c, p, g, A, ne, W, h, a, te, he, de, Ie, De, d, f, _e, Me, Ne, Ae, pe, Oe, Q, Te, Le]
}
class vn extends it {
    constructor(s) {
        super(), lt(this, s, an, sn, at, {
            isEditing: 0,
            showNavbar: 1,
            showEditButton: 2,
            refreshDashboards: 20
        }, null, [-1, -1])
    }
}
export {
    gn as B, ze as D, Qt as G, M as L, vn as S, O as a
};