import {
    s as L,
    d as _,
    i as V,
    F as j,
    k as P,
    m as p,
    b as d,
    c as b,
    e as y,
    f as S,
    g as N,
    h as v,
    t as H,
    j as B,
    n as z,
    q as G,
    o as Q
} from "./DDNnt9XD.js";
import {
    S as W,
    i as Y,
    t as T,
    a as w,
    g as J,
    f as K,
    d as $,
    m as ee,
    c as te,
    b as le
} from "./qWASNxYk.js";
import {
    A as oe,
    S as se
} from "./X1MWkxH0.js";
import {
    E as ae,
    u as O
} from "./B5WePDbK.js";
import {
    D as re
} from "./D2nDshhL.js";
import {
    T as ie
} from "./BioHA4eS.js";
import {
    t as ne
} from "./BszCcFfc.js";
import {
    X as fe
} from "./BtulAGCG.js";
import {
    i as X
} from "./DwsiLpv2.js";
import {
    i as x
} from "./BK3ENVoJ.js";

function F(a) {
    let t, o, r, l, e, i, m, C, D, I, U = !a[1] || x(new Date, a[1]),
        k, h, E = !a[1] || x(new Date, a[1]),
        A, n, f = U && M(a),
        s = E && Z(a);
    return {
        c() {
            t = v("div"), o = v("h4"), r = H(a[4]), l = B(), e = v("div"), i = H(a[5]), m = B(), C = v("br"), D = v("br"), I = B(), f && f.c(), k = B(), h = v("div"), s && s.c(), this.h()
        },
        l(c) {
            t = b(c, "DIV", {
                class: !0,
                role: !0
            });
            var u = y(t);
            o = b(u, "H4", {
                class: !0
            });
            var q = y(o);
            r = S(q, a[4]), q.forEach(_), l = N(u), e = b(u, "DIV", {
                class: !0
            });
            var g = y(e);
            i = S(g, a[5]), m = N(g), C = b(g, "BR", {}), D = b(g, "BR", {}), I = N(g), f && f.l(g), g.forEach(_), k = N(u), h = b(u, "DIV", {
                class: !0
            });
            var R = y(h);
            s && s.l(R), R.forEach(_), u.forEach(_), this.h()
        },
        h() {
            p(o, "class", "alert-heading"), p(e, "class", "alert-body text-justify"), p(h, "class", "absolute right-2 top-0"), p(t, "class", A = "alert alert-" + a[2]), p(t, "role", "alert")
        },
        m(c, u) {
            V(c, t, u), d(t, o), d(o, r), d(t, l), d(t, e), d(e, i), d(e, m), d(e, C), d(e, D), d(e, I), f && f.m(e, null), d(t, k), d(t, h), s && s.m(h, null), n = !0
        },
        p(c, u) {
            u & 2 && (U = !c[1] || x(new Date, c[1])), U ? f ? f.p(c, u) : (f = M(c), f.c(), f.m(e, null)) : f && (f.d(1), f = null), u & 2 && (E = !c[1] || x(new Date, c[1])), E ? s ? (s.p(c, u), u & 2 && w(s, 1)) : (s = Z(c), s.c(), w(s, 1), s.m(h, null)) : s && (J(), T(s, 1, 1, () => {
                s = null
            }), K()), (!n || u & 4 && A !== (A = "alert alert-" + c[2])) && p(t, "class", A)
        },
        i(c) {
            n || (w(s), n = !0)
        },
        o(c) {
            T(s), n = !1
        },
        d(c) {
            c && _(t), f && f.d(), s && s.d()
        }
    }
}

function M(a) {
    let t, o = "Compreendo e não quero que essa mensagem volte a aparecer.",
        r, l;
    return {
        c() {
            t = v("span"), t.textContent = o, this.h()
        },
        l(e) {
            t = b(e, "SPAN", {
                class: !0,
                "data-svelte-h": !0
            }), Q(t) !== "svelte-2l16a4" && (t.textContent = o), this.h()
        },
        h() {
            p(t, "class", "italic underline cursor-pointer")
        },
        m(e, i) {
            V(e, t, i), r || (l = G(t, "click", a[6]), r = !0)
        },
        p: z,
        d(e) {
            e && _(t), r = !1, l()
        }
    }
}

function Z(a) {
    let t, o, r, l, e;
    return o = new fe({
        props: {
            class: "!w-[21px] !h-[21px] !cursor-pointer !stroke-[2px]"
        }
    }), {
        c() {
            t = v("div"), le(o.$$.fragment), this.h()
        },
        l(i) {
            t = b(i, "DIV", {
                class: !0
            });
            var m = y(t);
            te(o.$$.fragment, m), m.forEach(_), this.h()
        },
        h() {
            p(t, "class", "!w-[38px] !h-[38px] hover:bg-yellow-500 hover:bg-opacity-10 rounded-md flex flex-col justify-center items-center")
        },
        m(i, m) {
            V(i, t, m), ee(o, t, null), r = !0, l || (e = G(t, "click", a[6]), l = !0)
        },
        p: z,
        i(i) {
            r || (w(o.$$.fragment, i), r = !0)
        },
        o(i) {
            T(o.$$.fragment, i), r = !1
        },
        d(i) {
            i && _(t), $(o), l = !1, e()
        }
    }
}

function ce(a) {
    let t = !a[3] && (!a[0] || X(new Date, a[0])),
        o, r, l = t && F(a);
    return {
        c() {
            l && l.c(), o = j()
        },
        l(e) {
            l && l.l(e), o = j()
        },
        m(e, i) {
            l && l.m(e, i), V(e, o, i), r = !0
        },
        p(e, [i]) {
            i & 9 && (t = !e[3] && (!e[0] || X(new Date, e[0]))), t ? l ? (l.p(e, i), i & 9 && w(l, 1)) : (l = F(e), l.c(), w(l, 1), l.m(o.parentNode, o)) : l && (J(), T(l, 1, 1, () => {
                l = null
            }), K())
        },
        i(e) {
            r || (w(l), r = !0)
        },
        o(e) {
            T(l), r = !1
        },
        d(e) {
            e && _(o), l && l.d(e)
        }
    }
}

function ue(a, t, o) {
    var E, A;
    let r, l;
    P(a, O, n => o(8, r = n)), P(a, ne, n => o(9, l = n));
    let {
        type: e
    } = t, {
        showAlertUntil: i = null
    } = t, {
        canNotCloseAlertUntil: m = null
    } = t, {
        bsColor: C = "warning"
    } = t;
    const {
        title: D,
        text: I,
        confirmBeforeClose: U
    } = oe[e];
    let k = ((A = (E = r == null ? void 0 : r.user) == null ? void 0 : E.notAlertInfo) == null ? void 0 : A[e]) ? ? !1;
    const h = async () => {
        let n = !0;
        if (U && (n = await re.dialog({
                title: "Atenção!",
                text: "A informação presente neste alerta é importante. Você confirma ter lido?",
                confirmButtonText: "Sim, dispensar",
                cancelButtonText: "Não, vou ler",
                confirmType: "danger",
                iconColor: "danger",
                iconType: "warning",
                allowOutsideClick: !0,
                theme: l
            })), n) switch (o(3, k = !0), (await se.execute({
            authData: r == null ? void 0 : r.authData,
            notAlertInfo: e
        })).status) {
            case "SUCCESS":
                O.update(s => (s != null && s.user && s.user.notAlertInfo && (s.user.notAlertInfo[e] = !0), s));
                break;
            case "UNAUTHORIZED":
                ae.navigateTo("/sessao-expirada");
                break;
            default:
                ie.error("Algo deu errado ao salvar mensagem! Tente novamente mais tarde.");
                break
        }
    };
    return a.$$set = n => {
        "type" in n && o(7, e = n.type), "showAlertUntil" in n && o(0, i = n.showAlertUntil), "canNotCloseAlertUntil" in n && o(1, m = n.canNotCloseAlertUntil), "bsColor" in n && o(2, C = n.bsColor)
    }, [i, m, C, k, D, I, h, e]
}
class Ce extends W {
    constructor(t) {
        super(), Y(this, t, ue, ce, L, {
            type: 7,
            showAlertUntil: 0,
            canNotCloseAlertUntil: 1,
            bsColor: 2
        })
    }
}
export {
    Ce as A
};