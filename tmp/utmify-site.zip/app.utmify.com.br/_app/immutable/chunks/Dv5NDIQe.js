var i = Object.defineProperty;
var n = (s, t, r) => t in s ? i(s, t, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: r
}) : s[t] = r;
var e = (s, t, r) => n(s, typeof t != "symbol" ? t + "" : t, r);
class h {
    constructor() {
        e(this, "statements", [])
    }
    add(t) {
        return this.statements.push(t), this
    }
    withUrl(t) {
        return t + this.stringify()
    }
    stringify() {
        return `?${this.statements.join("&")}`
    }
}
export {
    h as Q
};