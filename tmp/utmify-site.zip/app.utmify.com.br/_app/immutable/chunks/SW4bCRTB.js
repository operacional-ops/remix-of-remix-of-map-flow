class c {
    string(t, r) {
        let a = "";
        const s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
            e = "0123456789",
            o = "!@#$%^&*()_+~`|}{[]\\:;?><,./-=";
        let n = "";
        if (r === "alpha") n = s;
        else if (r === "numeric") n = e;
        else if (r === "special") n = o;
        else if (r === "alphanumeric") n = s + e;
        else if (r === "alphanumericSpecial") n = s + e + o;
        else if (r === "numericSpecial") n = e + o;
        else if (r === "alphaSpecial") n = s + o;
        else throw new Error("Invalid type");
        const l = n.length;
        for (let i = 0; i < t; i++) a += n.charAt(Math.floor(Math.random() * l));
        return a
    }
    number(t = 0, r = 100) {
        return Math.floor(Math.random() * (r - t + 1) + t)
    }
    email(t = 10) {
        return `${this.string(t,"alphanumeric")}@${this.string(t,"alphanumeric")}.com`
    }
    securePassword() {
        const t = this.string(3, "special"),
            r = this.string(3, "alpha").toUpperCase(),
            a = this.string(3, "alpha").toLowerCase(),
            s = this.string(3, "numeric");
        return this.shuffle(t + r + a + s)
    }
    shuffle(t) {
        const r = t.split(""),
            a = r.length;
        for (let s = a - 1; s > 0; s--) {
            const e = Math.floor(Math.random() * (s + 1)),
                o = r[s];
            r[s] = r[e], r[e] = o
        }
        return r.join("")
    }
    shuffleList(t) {
        const r = t,
            a = r.length;
        for (let s = a - 1; s > 0; s--) {
            const e = Math.floor(Math.random() * (s + 1)),
                o = r[s];
            r[s] = r[e], r[e] = o
        }
        return r
    }
    uuid() {
        const t = () => Math.floor((1 + Math.random()) * 65536).toString(16).substring(1);
        return `${t()+t()}-${t()}-${t()}-${t()}-${t()+t()+t()}`
    }
}
const u = new c;
export {
    u as r
};