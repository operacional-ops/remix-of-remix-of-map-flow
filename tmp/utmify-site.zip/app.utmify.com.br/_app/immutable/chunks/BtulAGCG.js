import {
    s as K,
    n as D,
    d as x,
    m as l,
    i as Z,
    b as B,
    C as A,
    e as C,
    D as E,
    R as Xt,
    c as Gt,
    h as Yt,
    B as qt
} from "./DDNnt9XD.js";
import {
    S as J,
    i as Q,
    d as Kt,
    t as Zt,
    a as Jt,
    m as Qt,
    c as $t,
    b as te
} from "./qWASNxYk.js";

function ee(e) {
    let t, i, n, r;
    return {
        c() {
            t = E("svg"), i = E("path"), n = E("line"), this.h()
        },
        l(s) {
            t = A(s, "svg", {
                xmlns: !0,
                width: !0,
                height: !0,
                fill: !0,
                viewBox: !0,
                stroke: !0,
                "stroke-width": !0,
                "stroke-linecap": !0,
                "stroke-linejoin": !0,
                class: !0
            });
            var o = C(t);
            i = A(o, "path", {
                d: !0
            }), C(i).forEach(x), n = A(o, "line", {
                x1: !0,
                y1: !0,
                x2: !0,
                y2: !0
            }), C(n).forEach(x), o.forEach(x), this.h()
        },
        h() {
            l(i, "d", "M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"), l(n, "x1", "1"), l(n, "y1", "1"), l(n, "x2", "23"), l(n, "y2", "23"), l(t, "xmlns", "http://www.w3.org/2000/svg"), l(t, "width", e[0]), l(t, "height", e[0]), l(t, "fill", "none"), l(t, "viewBox", "0 0 24 24"), l(t, "stroke", "currentColor"), l(t, "stroke-width", e[1]), l(t, "stroke-linecap", "round"), l(t, "stroke-linejoin", "round"), l(t, "class", r = "feather feather-eye-off " + e[2])
        },
        m(s, o) {
            Z(s, t, o), B(t, i), B(t, n)
        },
        p(s, [o]) {
            o & 1 && l(t, "width", s[0]), o & 1 && l(t, "height", s[0]), o & 2 && l(t, "stroke-width", s[1]), o & 4 && r !== (r = "feather feather-eye-off " + s[2]) && l(t, "class", r)
        },
        i: D,
        o: D,
        d(s) {
            s && x(t)
        }
    }
}

function ne(e, t, i) {
    let {
        size: n = "24"
    } = t, {
        strokeWidth: r = 2
    } = t, {
        class: s = ""
    } = t;
    return n !== "100%" && (n = n.slice(-1) === "x" ? n.slice(0, n.length - 1) + "em" : parseInt(n) + "px"), e.$$set = o => {
        "size" in o && i(0, n = o.size), "strokeWidth" in o && i(1, r = o.strokeWidth), "class" in o && i(2, s = o.class)
    }, [n, r, s]
}
class an extends J {
    constructor(t) {
        super(), Q(this, t, ne, ee, K, {
            size: 0,
            strokeWidth: 1,
            class: 2
        })
    }
}

function ie(e) {
    let t, i, n, r;
    return {
        c() {
            t = E("svg"), i = E("path"), n = E("circle"), this.h()
        },
        l(s) {
            t = A(s, "svg", {
                xmlns: !0,
                width: !0,
                height: !0,
                fill: !0,
                viewBox: !0,
                stroke: !0,
                "stroke-width": !0,
                "stroke-linecap": !0,
                "stroke-linejoin": !0,
                class: !0
            });
            var o = C(t);
            i = A(o, "path", {
                d: !0
            }), C(i).forEach(x), n = A(o, "circle", {
                cx: !0,
                cy: !0,
                r: !0
            }), C(n).forEach(x), o.forEach(x), this.h()
        },
        h() {
            l(i, "d", "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"), l(n, "cx", "12"), l(n, "cy", "12"), l(n, "r", "3"), l(t, "xmlns", "http://www.w3.org/2000/svg"), l(t, "width", e[0]), l(t, "height", e[0]), l(t, "fill", "none"), l(t, "viewBox", "0 0 24 24"), l(t, "stroke", "currentColor"), l(t, "stroke-width", e[1]), l(t, "stroke-linecap", "round"), l(t, "stroke-linejoin", "round"), l(t, "class", r = "feather feather-eye " + e[2])
        },
        m(s, o) {
            Z(s, t, o), B(t, i), B(t, n)
        },
        p(s, [o]) {
            o & 1 && l(t, "width", s[0]), o & 1 && l(t, "height", s[0]), o & 2 && l(t, "stroke-width", s[1]), o & 4 && r !== (r = "feather feather-eye " + s[2]) && l(t, "class", r)
        },
        i: D,
        o: D,
        d(s) {
            s && x(t)
        }
    }
}

function oe(e, t, i) {
    let {
        size: n = "24"
    } = t, {
        strokeWidth: r = 2
    } = t, {
        class: s = ""
    } = t;
    return n !== "100%" && (n = n.slice(-1) === "x" ? n.slice(0, n.length - 1) + "em" : parseInt(n) + "px"), e.$$set = o => {
        "size" in o && i(0, n = o.size), "strokeWidth" in o && i(1, r = o.strokeWidth), "class" in o && i(2, s = o.class)
    }, [n, r, s]
}
class fn extends J {
    constructor(t) {
        super(), Q(this, t, oe, ie, K, {
            size: 0,
            strokeWidth: 1,
            class: 2
        })
    }
}

function se(e) {
    let t, i, n, r, s;
    return {
        c() {
            t = E("svg"), i = E("circle"), n = E("line"), r = E("line"), this.h()
        },
        l(o) {
            t = A(o, "svg", {
                xmlns: !0,
                width: !0,
                height: !0,
                fill: !0,
                viewBox: !0,
                stroke: !0,
                "stroke-width": !0,
                "stroke-linecap": !0,
                "stroke-linejoin": !0,
                class: !0
            });
            var c = C(t);
            i = A(c, "circle", {
                cx: !0,
                cy: !0,
                r: !0
            }), C(i).forEach(x), n = A(c, "line", {
                x1: !0,
                y1: !0,
                x2: !0,
                y2: !0
            }), C(n).forEach(x), r = A(c, "line", {
                x1: !0,
                y1: !0,
                x2: !0,
                y2: !0
            }), C(r).forEach(x), c.forEach(x), this.h()
        },
        h() {
            l(i, "cx", "12"), l(i, "cy", "12"), l(i, "r", "10"), l(n, "x1", "12"), l(n, "y1", "16"), l(n, "x2", "12"), l(n, "y2", "12"), l(r, "x1", "12"), l(r, "y1", "8"), l(r, "x2", "12.01"), l(r, "y2", "8"), l(t, "xmlns", "http://www.w3.org/2000/svg"), l(t, "width", e[0]), l(t, "height", e[0]), l(t, "fill", "none"), l(t, "viewBox", "0 0 24 24"), l(t, "stroke", "currentColor"), l(t, "stroke-width", e[1]), l(t, "stroke-linecap", "round"), l(t, "stroke-linejoin", "round"), l(t, "class", s = "feather feather-info " + e[2])
        },
        m(o, c) {
            Z(o, t, c), B(t, i), B(t, n), B(t, r)
        },
        p(o, [c]) {
            c & 1 && l(t, "width", o[0]), c & 1 && l(t, "height", o[0]), c & 2 && l(t, "stroke-width", o[1]), c & 4 && s !== (s = "feather feather-info " + o[2]) && l(t, "class", s)
        },
        i: D,
        o: D,
        d(o) {
            o && x(t)
        }
    }
}

function re(e, t, i) {
    let {
        size: n = "24"
    } = t, {
        strokeWidth: r = 2
    } = t, {
        class: s = ""
    } = t;
    return n !== "100%" && (n = n.slice(-1) === "x" ? n.slice(0, n.length - 1) + "em" : parseInt(n) + "px"), e.$$set = o => {
        "size" in o && i(0, n = o.size), "strokeWidth" in o && i(1, r = o.strokeWidth), "class" in o && i(2, s = o.class)
    }, [n, r, s]
}
class le extends J {
    constructor(t) {
        super(), Q(this, t, re, se, K, {
            size: 0,
            strokeWidth: 1,
            class: 2
        })
    }
}

function ce(e) {
    let t, i, n, r;
    return {
        c() {
            t = E("svg"), i = E("line"), n = E("line"), this.h()
        },
        l(s) {
            t = A(s, "svg", {
                xmlns: !0,
                width: !0,
                height: !0,
                fill: !0,
                viewBox: !0,
                stroke: !0,
                "stroke-width": !0,
                "stroke-linecap": !0,
                "stroke-linejoin": !0,
                class: !0
            });
            var o = C(t);
            i = A(o, "line", {
                x1: !0,
                y1: !0,
                x2: !0,
                y2: !0
            }), C(i).forEach(x), n = A(o, "line", {
                x1: !0,
                y1: !0,
                x2: !0,
                y2: !0
            }), C(n).forEach(x), o.forEach(x), this.h()
        },
        h() {
            l(i, "x1", "18"), l(i, "y1", "6"), l(i, "x2", "6"), l(i, "y2", "18"), l(n, "x1", "6"), l(n, "y1", "6"), l(n, "x2", "18"), l(n, "y2", "18"), l(t, "xmlns", "http://www.w3.org/2000/svg"), l(t, "width", e[0]), l(t, "height", e[0]), l(t, "fill", "none"), l(t, "viewBox", "0 0 24 24"), l(t, "stroke", "currentColor"), l(t, "stroke-width", e[1]), l(t, "stroke-linecap", "round"), l(t, "stroke-linejoin", "round"), l(t, "class", r = "feather feather-x " + e[2])
        },
        m(s, o) {
            Z(s, t, o), B(t, i), B(t, n)
        },
        p(s, [o]) {
            o & 1 && l(t, "width", s[0]), o & 1 && l(t, "height", s[0]), o & 2 && l(t, "stroke-width", s[1]), o & 4 && r !== (r = "feather feather-x " + s[2]) && l(t, "class", r)
        },
        i: D,
        o: D,
        d(s) {
            s && x(t)
        }
    }
}

function ae(e, t, i) {
    let {
        size: n = "24"
    } = t, {
        strokeWidth: r = 2
    } = t, {
        class: s = ""
    } = t;
    return n !== "100%" && (n = n.slice(-1) === "x" ? n.slice(0, n.length - 1) + "em" : parseInt(n) + "px"), e.$$set = o => {
        "size" in o && i(0, n = o.size), "strokeWidth" in o && i(1, r = o.strokeWidth), "class" in o && i(2, s = o.class)
    }, [n, r, s]
}
class un extends J {
    constructor(t) {
        super(), Q(this, t, ae, ce, K, {
            size: 0,
            strokeWidth: 1,
            class: 2
        })
    }
}
var fe = (e => (e.BRL = "BRL", e.USD = "USD", e.EUR = "EUR", e.GBP = "GBP", e.CAD = "CAD", e.COP = "COP", e.MXN = "MXN", e.PYG = "PYG", e.CLP = "CLP", e.PEN = "PEN", e.PLN = "PLN", e.UAH = "UAH", e.CHF = "CHF", e.THB = "THB", e.AUD = "AUD", e))(fe || {});
const hn = e => {
        switch (e) {
            case "BRL":
                return "Real Brasileiro (R$)";
            case "USD":
                return "Dólar Americano (US$)";
            case "EUR":
                return "Euro (€)";
            case "GBP":
                return "Libra Esterlina (£)";
            case "CAD":
                return "Dólar Canadense (C$)";
            case "COP":
                return "Peso Colombiano ($)";
            case "MXN":
                return "Peso Mexicano ($)";
            case "PYG":
                return "Peso Paraguayo (₲)";
            case "CLP":
                return "Peso Chileno ($)";
            case "PEN":
                return "Sol Peruano (S/)";
            case "PLN":
                return "Zloti polonês (zł)";
            case "UAH":
                return "Hryvnia Ucraniana (₴)";
            case "CHF":
                return "Franco Suíço (CHF)";
            case "THB":
                return "Baht Tailandês (฿)";
            case "AUD":
                return "Dólar Australiano ($)";
            default:
                return ""
        }
    },
    dn = e => {
        switch (e) {
            case "BRL":
                return "R$";
            case "USD":
                return "$";
            case "EUR":
                return "€";
            case "GBP":
                return "£";
            case "CAD":
                return "$";
            case "COP":
                return "$";
            case "MXN":
                return "$";
            case "PYG":
                return "₲";
            case "CLP":
                return "$";
            case "PEN":
                return "S/";
            case "PLN":
                return "zł";
            case "UAH":
                return "₴";
            case "CHF":
                return "CHF";
            case "THB":
                return "฿";
            case "AUD":
                return "$";
            default:
                return ""
        }
    },
    dt = Math.min,
    U = Math.max,
    et = Math.round,
    O = e => ({
        x: e,
        y: e
    }),
    ue = {
        left: "right",
        right: "left",
        bottom: "top",
        top: "bottom"
    },
    he = {
        start: "end",
        end: "start"
    };

function kt(e, t, i) {
    return U(e, dt(t, i))
}

function ot(e, t) {
    return typeof e == "function" ? e(t) : e
}

function z(e) {
    return e.split("-")[0]
}

function st(e) {
    return e.split("-")[1]
}

function Tt(e) {
    return e === "x" ? "y" : "x"
}

function Ot(e) {
    return e === "y" ? "height" : "width"
}
const de = new Set(["top", "bottom"]);

function M(e) {
    return de.has(z(e)) ? "y" : "x"
}

function Wt(e) {
    return Tt(M(e))
}

function me(e, t, i) {
    i === void 0 && (i = !1);
    const n = st(e),
        r = Wt(e),
        s = Ot(r);
    let o = r === "x" ? n === (i ? "end" : "start") ? "right" : "left" : n === "start" ? "bottom" : "top";
    return t.reference[s] > t.floating[s] && (o = nt(o)), [o, nt(o)]
}

function ge(e) {
    const t = nt(e);
    return [mt(e), t, mt(t)]
}

function mt(e) {
    return e.replace(/start|end/g, t => he[t])
}
const Ct = ["left", "right"],
    At = ["right", "left"],
    we = ["top", "bottom"],
    pe = ["bottom", "top"];

function xe(e, t, i) {
    switch (e) {
        case "top":
        case "bottom":
            return i ? t ? At : Ct : t ? Ct : At;
        case "left":
        case "right":
            return t ? we : pe;
        default:
            return []
    }
}

function ye(e, t, i, n) {
    const r = st(e);
    let s = xe(z(e), i === "start", n);
    return r && (s = s.map(o => o + "-" + r), t && (s = s.concat(s.map(mt)))), s
}

function nt(e) {
    return e.replace(/left|right|bottom|top/g, t => ue[t])
}

function ve(e) {
    return {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        ...e
    }
}

function be(e) {
    return typeof e != "number" ? ve(e) : {
        top: e,
        right: e,
        bottom: e,
        left: e
    }
}

function it(e) {
    const {
        x: t,
        y: i,
        width: n,
        height: r
    } = e;
    return {
        width: n,
        height: r,
        top: i,
        left: t,
        right: t + n,
        bottom: i + r,
        x: t,
        y: i
    }
}

function Et(e, t, i) {
    let {
        reference: n,
        floating: r
    } = e;
    const s = M(t),
        o = Wt(t),
        c = Ot(o),
        a = z(t),
        f = s === "y",
        u = n.x + n.width / 2 - r.width / 2,
        h = n.y + n.height / 2 - r.height / 2,
        m = n[c] / 2 - r[c] / 2;
    let d;
    switch (a) {
        case "top":
            d = {
                x: u,
                y: n.y - r.height
            };
            break;
        case "bottom":
            d = {
                x: u,
                y: n.y + n.height
            };
            break;
        case "right":
            d = {
                x: n.x + n.width,
                y: h
            };
            break;
        case "left":
            d = {
                x: n.x - r.width,
                y: h
            };
            break;
        default:
            d = {
                x: n.x,
                y: n.y
            }
    }
    switch (st(t)) {
        case "start":
            d[o] -= m * (i && f ? -1 : 1);
            break;
        case "end":
            d[o] += m * (i && f ? -1 : 1);
            break
    }
    return d
}
const ke = async (e, t, i) => {
    const {
        placement: n = "bottom",
        strategy: r = "absolute",
        middleware: s = [],
        platform: o
    } = i, c = s.filter(Boolean), a = await (o.isRTL == null ? void 0 : o.isRTL(t));
    let f = await o.getElementRects({
            reference: e,
            floating: t,
            strategy: r
        }),
        {
            x: u,
            y: h
        } = Et(f, n, a),
        m = n,
        d = {},
        g = 0;
    for (let w = 0; w < c.length; w++) {
        const {
            name: p,
            fn: v
        } = c[w], {
            x: y,
            y: k,
            data: L,
            reset: b
        } = await v({
            x: u,
            y: h,
            initialPlacement: n,
            placement: m,
            strategy: r,
            middlewareData: d,
            rects: f,
            platform: o,
            elements: {
                reference: e,
                floating: t
            }
        });
        u = y ? ? u, h = k ? ? h, d = { ...d,
            [p]: { ...d[p],
                ...L
            }
        }, b && g <= 50 && (g++, typeof b == "object" && (b.placement && (m = b.placement), b.rects && (f = b.rects === !0 ? await o.getElementRects({
            reference: e,
            floating: t,
            strategy: r
        }) : b.rects), {
            x: u,
            y: h
        } = Et(f, m, a)), w = -1)
    }
    return {
        x: u,
        y: h,
        placement: m,
        strategy: r,
        middlewareData: d
    }
};
async function Bt(e, t) {
    var i;
    t === void 0 && (t = {});
    const {
        x: n,
        y: r,
        platform: s,
        rects: o,
        elements: c,
        strategy: a
    } = e, {
        boundary: f = "clippingAncestors",
        rootBoundary: u = "viewport",
        elementContext: h = "floating",
        altBoundary: m = !1,
        padding: d = 0
    } = ot(t, e), g = be(d), p = c[m ? h === "floating" ? "reference" : "floating" : h], v = it(await s.getClippingRect({
        element: (i = await (s.isElement == null ? void 0 : s.isElement(p))) == null || i ? p : p.contextElement || await (s.getDocumentElement == null ? void 0 : s.getDocumentElement(c.floating)),
        boundary: f,
        rootBoundary: u,
        strategy: a
    })), y = h === "floating" ? {
        x: n,
        y: r,
        width: o.floating.width,
        height: o.floating.height
    } : o.reference, k = await (s.getOffsetParent == null ? void 0 : s.getOffsetParent(c.floating)), L = await (s.isElement == null ? void 0 : s.isElement(k)) ? await (s.getScale == null ? void 0 : s.getScale(k)) || {
        x: 1,
        y: 1
    } : {
        x: 1,
        y: 1
    }, b = it(s.convertOffsetParentRelativeRectToViewportRelativeRect ? await s.convertOffsetParentRelativeRectToViewportRelativeRect({
        elements: c,
        rect: y,
        offsetParent: k,
        strategy: a
    }) : y);
    return {
        top: (v.top - b.top + g.top) / L.y,
        bottom: (b.bottom - v.bottom + g.bottom) / L.y,
        left: (v.left - b.left + g.left) / L.x,
        right: (b.right - v.right + g.right) / L.x
    }
}
const Ce = function(e) {
        return e === void 0 && (e = {}), {
            name: "flip",
            options: e,
            async fn(t) {
                var i, n;
                const {
                    placement: r,
                    middlewareData: s,
                    rects: o,
                    initialPlacement: c,
                    platform: a,
                    elements: f
                } = t, {
                    mainAxis: u = !0,
                    crossAxis: h = !0,
                    fallbackPlacements: m,
                    fallbackStrategy: d = "bestFit",
                    fallbackAxisSideDirection: g = "none",
                    flipAlignment: w = !0,
                    ...p
                } = ot(e, t);
                if ((i = s.arrow) != null && i.alignmentOffset) return {};
                const v = z(r),
                    y = M(c),
                    k = z(c) === c,
                    L = await (a.isRTL == null ? void 0 : a.isRTL(f.floating)),
                    b = m || (k || !w ? [nt(c)] : ge(c)),
                    xt = g !== "none";
                !m && xt && b.push(...ye(c, w, g, L));
                const Ut = [c, ...b],
                    ft = await Bt(t, p),
                    tt = [];
                let V = ((n = s.flip) == null ? void 0 : n.overflows) || [];
                if (u && tt.push(ft[v]), h) {
                    const H = me(r, o, L);
                    tt.push(ft[H[0]], ft[H[1]])
                }
                if (V = [...V, {
                        placement: r,
                        overflows: tt
                    }], !tt.every(H => H <= 0)) {
                    var yt, vt;
                    const H = (((yt = s.flip) == null ? void 0 : yt.index) || 0) + 1,
                        ut = Ut[H];
                    if (ut && (!(h === "alignment" ? y !== M(ut) : !1) || V.every(R => M(R.placement) === y ? R.overflows[0] > 0 : !0))) return {
                        data: {
                            index: H,
                            overflows: V
                        },
                        reset: {
                            placement: ut
                        }
                    };
                    let Y = (vt = V.filter(I => I.overflows[0] <= 0).sort((I, R) => I.overflows[1] - R.overflows[1])[0]) == null ? void 0 : vt.placement;
                    if (!Y) switch (d) {
                        case "bestFit":
                            {
                                var bt;
                                const I = (bt = V.filter(R => {
                                    if (xt) {
                                        const N = M(R.placement);
                                        return N === y || N === "y"
                                    }
                                    return !0
                                }).map(R => [R.placement, R.overflows.filter(N => N > 0).reduce((N, jt) => N + jt, 0)]).sort((R, N) => R[1] - N[1])[0]) == null ? void 0 : bt[0];I && (Y = I);
                                break
                            }
                        case "initialPlacement":
                            Y = c;
                            break
                    }
                    if (r !== Y) return {
                        reset: {
                            placement: Y
                        }
                    }
                }
                return {}
            }
        }
    },
    Ae = new Set(["left", "top"]);
async function Ee(e, t) {
    const {
        placement: i,
        platform: n,
        elements: r
    } = e, s = await (n.isRTL == null ? void 0 : n.isRTL(r.floating)), o = z(i), c = st(i), a = M(i) === "y", f = Ae.has(o) ? -1 : 1, u = s && a ? -1 : 1, h = ot(t, e);
    let {
        mainAxis: m,
        crossAxis: d,
        alignmentAxis: g
    } = typeof h == "number" ? {
        mainAxis: h,
        crossAxis: 0,
        alignmentAxis: null
    } : {
        mainAxis: h.mainAxis || 0,
        crossAxis: h.crossAxis || 0,
        alignmentAxis: h.alignmentAxis
    };
    return c && typeof g == "number" && (d = c === "end" ? g * -1 : g), a ? {
        x: d * u,
        y: m * f
    } : {
        x: m * f,
        y: d * u
    }
}
const Se = function(e) {
        return e === void 0 && (e = 0), {
            name: "offset",
            options: e,
            async fn(t) {
                var i, n;
                const {
                    x: r,
                    y: s,
                    placement: o,
                    middlewareData: c
                } = t, a = await Ee(t, e);
                return o === ((i = c.offset) == null ? void 0 : i.placement) && (n = c.arrow) != null && n.alignmentOffset ? {} : {
                    x: r + a.x,
                    y: s + a.y,
                    data: { ...a,
                        placement: o
                    }
                }
            }
        }
    },
    Le = function(e) {
        return e === void 0 && (e = {}), {
            name: "shift",
            options: e,
            async fn(t) {
                const {
                    x: i,
                    y: n,
                    placement: r
                } = t, {
                    mainAxis: s = !0,
                    crossAxis: o = !1,
                    limiter: c = {
                        fn: p => {
                            let {
                                x: v,
                                y
                            } = p;
                            return {
                                x: v,
                                y
                            }
                        }
                    },
                    ...a
                } = ot(e, t), f = {
                    x: i,
                    y: n
                }, u = await Bt(t, a), h = M(z(r)), m = Tt(h);
                let d = f[m],
                    g = f[h];
                if (s) {
                    const p = m === "y" ? "top" : "left",
                        v = m === "y" ? "bottom" : "right",
                        y = d + u[p],
                        k = d - u[v];
                    d = kt(y, d, k)
                }
                if (o) {
                    const p = h === "y" ? "top" : "left",
                        v = h === "y" ? "bottom" : "right",
                        y = g + u[p],
                        k = g - u[v];
                    g = kt(y, g, k)
                }
                const w = c.fn({ ...t,
                    [m]: d,
                    [h]: g
                });
                return { ...w,
                    data: {
                        x: w.x - i,
                        y: w.y - n,
                        enabled: {
                            [m]: s,
                            [h]: o
                        }
                    }
                }
            }
        }
    };

function rt() {
    return typeof window < "u"
}

function G(e) {
    return _t(e) ? (e.nodeName || "").toLowerCase() : "#document"
}

function S(e) {
    var t;
    return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window
}

function _(e) {
    var t;
    return (t = (_t(e) ? e.ownerDocument : e.document) || window.document) == null ? void 0 : t.documentElement
}

function _t(e) {
    return rt() ? e instanceof Node || e instanceof S(e).Node : !1
}

function P(e) {
    return rt() ? e instanceof Element || e instanceof S(e).Element : !1
}

function W(e) {
    return rt() ? e instanceof HTMLElement || e instanceof S(e).HTMLElement : !1
}

function St(e) {
    return !rt() || typeof ShadowRoot > "u" ? !1 : e instanceof ShadowRoot || e instanceof S(e).ShadowRoot
}
const Re = new Set(["inline", "contents"]);

function $(e) {
    const {
        overflow: t,
        overflowX: i,
        overflowY: n,
        display: r
    } = T(e);
    return /auto|scroll|overlay|hidden|clip/.test(t + n + i) && !Re.has(r)
}
const Pe = new Set(["table", "td", "th"]);

function Te(e) {
    return Pe.has(G(e))
}
const Oe = [":popover-open", ":modal"];

function lt(e) {
    return Oe.some(t => {
        try {
            return e.matches(t)
        } catch {
            return !1
        }
    })
}
const We = ["transform", "translate", "scale", "rotate", "perspective"],
    Be = ["transform", "translate", "scale", "rotate", "perspective", "filter"],
    _e = ["paint", "layout", "strict", "content"];

function wt(e) {
    const t = pt(),
        i = P(e) ? T(e) : e;
    return We.some(n => i[n] ? i[n] !== "none" : !1) || (i.containerType ? i.containerType !== "normal" : !1) || !t && (i.backdropFilter ? i.backdropFilter !== "none" : !1) || !t && (i.filter ? i.filter !== "none" : !1) || Be.some(n => (i.willChange || "").includes(n)) || _e.some(n => (i.contain || "").includes(n))
}

function Ne(e) {
    let t = F(e);
    for (; W(t) && !X(t);) {
        if (wt(t)) return t;
        if (lt(t)) return null;
        t = F(t)
    }
    return null
}

function pt() {
    return typeof CSS > "u" || !CSS.supports ? !1 : CSS.supports("-webkit-backdrop-filter", "none")
}
const Me = new Set(["html", "body", "#document"]);

function X(e) {
    return Me.has(G(e))
}

function T(e) {
    return S(e).getComputedStyle(e)
}

function ct(e) {
    return P(e) ? {
        scrollLeft: e.scrollLeft,
        scrollTop: e.scrollTop
    } : {
        scrollLeft: e.scrollX,
        scrollTop: e.scrollY
    }
}

function F(e) {
    if (G(e) === "html") return e;
    const t = e.assignedSlot || e.parentNode || St(e) && e.host || _(e);
    return St(t) ? t.host : t
}

function Nt(e) {
    const t = F(e);
    return X(t) ? e.ownerDocument ? e.ownerDocument.body : e.body : W(t) && $(t) ? t : Nt(t)
}

function Mt(e, t, i) {
    var n;
    t === void 0 && (t = []);
    const r = Nt(e),
        s = r === ((n = e.ownerDocument) == null ? void 0 : n.body),
        o = S(r);
    return s ? (gt(o), t.concat(o, o.visualViewport || [], $(r) ? r : [], [])) : t.concat(r, Mt(r, []))
}

function gt(e) {
    return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null
}

function Dt(e) {
    const t = T(e);
    let i = parseFloat(t.width) || 0,
        n = parseFloat(t.height) || 0;
    const r = W(e),
        s = r ? e.offsetWidth : i,
        o = r ? e.offsetHeight : n,
        c = et(i) !== s || et(n) !== o;
    return c && (i = s, n = o), {
        width: i,
        height: n,
        $: c
    }
}

function Ft(e) {
    return P(e) ? e : e.contextElement
}

function j(e) {
    const t = Ft(e);
    if (!W(t)) return O(1);
    const i = t.getBoundingClientRect(),
        {
            width: n,
            height: r,
            $: s
        } = Dt(t);
    let o = (s ? et(i.width) : i.width) / n,
        c = (s ? et(i.height) : i.height) / r;
    return (!o || !Number.isFinite(o)) && (o = 1), (!c || !Number.isFinite(c)) && (c = 1), {
        x: o,
        y: c
    }
}
const De = O(0);

function Ht(e) {
    const t = S(e);
    return !pt() || !t.visualViewport ? De : {
        x: t.visualViewport.offsetLeft,
        y: t.visualViewport.offsetTop
    }
}

function Fe(e, t, i) {
    return t === void 0 && (t = !1), !i || t && i !== S(e) ? !1 : t
}

function q(e, t, i, n) {
    t === void 0 && (t = !1), i === void 0 && (i = !1);
    const r = e.getBoundingClientRect(),
        s = Ft(e);
    let o = O(1);
    t && (n ? P(n) && (o = j(n)) : o = j(e));
    const c = Fe(s, i, n) ? Ht(s) : O(0);
    let a = (r.left + c.x) / o.x,
        f = (r.top + c.y) / o.y,
        u = r.width / o.x,
        h = r.height / o.y;
    if (s) {
        const m = S(s),
            d = n && P(n) ? S(n) : n;
        let g = m,
            w = gt(g);
        for (; w && n && d !== g;) {
            const p = j(w),
                v = w.getBoundingClientRect(),
                y = T(w),
                k = v.left + (w.clientLeft + parseFloat(y.paddingLeft)) * p.x,
                L = v.top + (w.clientTop + parseFloat(y.paddingTop)) * p.y;
            a *= p.x, f *= p.y, u *= p.x, h *= p.y, a += k, f += L, g = S(w), w = gt(g)
        }
    }
    return it({
        width: u,
        height: h,
        x: a,
        y: f
    })
}

function at(e, t) {
    const i = ct(e).scrollLeft;
    return t ? t.left + i : q(_(e)).left + i
}

function It(e, t) {
    const i = e.getBoundingClientRect(),
        n = i.left + t.scrollLeft - at(e, i),
        r = i.top + t.scrollTop;
    return {
        x: n,
        y: r
    }
}

function He(e) {
    let {
        elements: t,
        rect: i,
        offsetParent: n,
        strategy: r
    } = e;
    const s = r === "fixed",
        o = _(n),
        c = t ? lt(t.floating) : !1;
    if (n === o || c && s) return i;
    let a = {
            scrollLeft: 0,
            scrollTop: 0
        },
        f = O(1);
    const u = O(0),
        h = W(n);
    if ((h || !h && !s) && ((G(n) !== "body" || $(o)) && (a = ct(n)), W(n))) {
        const d = q(n);
        f = j(n), u.x = d.x + n.clientLeft, u.y = d.y + n.clientTop
    }
    const m = o && !h && !s ? It(o, a) : O(0);
    return {
        width: i.width * f.x,
        height: i.height * f.y,
        x: i.x * f.x - a.scrollLeft * f.x + u.x + m.x,
        y: i.y * f.y - a.scrollTop * f.y + u.y + m.y
    }
}

function Ie(e) {
    return Array.from(e.getClientRects())
}

function ze(e) {
    const t = _(e),
        i = ct(e),
        n = e.ownerDocument.body,
        r = U(t.scrollWidth, t.clientWidth, n.scrollWidth, n.clientWidth),
        s = U(t.scrollHeight, t.clientHeight, n.scrollHeight, n.clientHeight);
    let o = -i.scrollLeft + at(e);
    const c = -i.scrollTop;
    return T(n).direction === "rtl" && (o += U(t.clientWidth, n.clientWidth) - r), {
        width: r,
        height: s,
        x: o,
        y: c
    }
}
const Lt = 25;

function Ve(e, t) {
    const i = S(e),
        n = _(e),
        r = i.visualViewport;
    let s = n.clientWidth,
        o = n.clientHeight,
        c = 0,
        a = 0;
    if (r) {
        s = r.width, o = r.height;
        const u = pt();
        (!u || u && t === "fixed") && (c = r.offsetLeft, a = r.offsetTop)
    }
    const f = at(n);
    if (f <= 0) {
        const u = n.ownerDocument,
            h = u.body,
            m = getComputedStyle(h),
            d = u.compatMode === "CSS1Compat" && parseFloat(m.marginLeft) + parseFloat(m.marginRight) || 0,
            g = Math.abs(n.clientWidth - h.clientWidth - d);
        g <= Lt && (s -= g)
    } else f <= Lt && (s += f);
    return {
        width: s,
        height: o,
        x: c,
        y: a
    }
}
const Ue = new Set(["absolute", "fixed"]);

function je(e, t) {
    const i = q(e, !0, t === "fixed"),
        n = i.top + e.clientTop,
        r = i.left + e.clientLeft,
        s = W(e) ? j(e) : O(1),
        o = e.clientWidth * s.x,
        c = e.clientHeight * s.y,
        a = r * s.x,
        f = n * s.y;
    return {
        width: o,
        height: c,
        x: a,
        y: f
    }
}

function Rt(e, t, i) {
    let n;
    if (t === "viewport") n = Ve(e, i);
    else if (t === "document") n = ze(_(e));
    else if (P(t)) n = je(t, i);
    else {
        const r = Ht(e);
        n = {
            x: t.x - r.x,
            y: t.y - r.y,
            width: t.width,
            height: t.height
        }
    }
    return it(n)
}

function zt(e, t) {
    const i = F(e);
    return i === t || !P(i) || X(i) ? !1 : T(i).position === "fixed" || zt(i, t)
}

function Xe(e, t) {
    const i = t.get(e);
    if (i) return i;
    let n = Mt(e, []).filter(c => P(c) && G(c) !== "body"),
        r = null;
    const s = T(e).position === "fixed";
    let o = s ? F(e) : e;
    for (; P(o) && !X(o);) {
        const c = T(o),
            a = wt(o);
        !a && c.position === "fixed" && (r = null), (s ? !a && !r : !a && c.position === "static" && !!r && Ue.has(r.position) || $(o) && !a && zt(e, o)) ? n = n.filter(u => u !== o) : r = c, o = F(o)
    }
    return t.set(e, n), n
}

function Ge(e) {
    let {
        element: t,
        boundary: i,
        rootBoundary: n,
        strategy: r
    } = e;
    const o = [...i === "clippingAncestors" ? lt(t) ? [] : Xe(t, this._c) : [].concat(i), n],
        c = o[0],
        a = o.reduce((f, u) => {
            const h = Rt(t, u, r);
            return f.top = U(h.top, f.top), f.right = dt(h.right, f.right), f.bottom = dt(h.bottom, f.bottom), f.left = U(h.left, f.left), f
        }, Rt(t, c, r));
    return {
        width: a.right - a.left,
        height: a.bottom - a.top,
        x: a.left,
        y: a.top
    }
}

function Ye(e) {
    const {
        width: t,
        height: i
    } = Dt(e);
    return {
        width: t,
        height: i
    }
}

function qe(e, t, i) {
    const n = W(t),
        r = _(t),
        s = i === "fixed",
        o = q(e, !0, s, t);
    let c = {
        scrollLeft: 0,
        scrollTop: 0
    };
    const a = O(0);

    function f() {
        a.x = at(r)
    }
    if (n || !n && !s)
        if ((G(t) !== "body" || $(r)) && (c = ct(t)), n) {
            const d = q(t, !0, s, t);
            a.x = d.x + t.clientLeft, a.y = d.y + t.clientTop
        } else r && f();
    s && !n && r && f();
    const u = r && !n && !s ? It(r, c) : O(0),
        h = o.left + c.scrollLeft - a.x - u.x,
        m = o.top + c.scrollTop - a.y - u.y;
    return {
        x: h,
        y: m,
        width: o.width,
        height: o.height
    }
}

function ht(e) {
    return T(e).position === "static"
}

function Pt(e, t) {
    if (!W(e) || T(e).position === "fixed") return null;
    if (t) return t(e);
    let i = e.offsetParent;
    return _(e) === i && (i = i.ownerDocument.body), i
}

function Vt(e, t) {
    const i = S(e);
    if (lt(e)) return i;
    if (!W(e)) {
        let r = F(e);
        for (; r && !X(r);) {
            if (P(r) && !ht(r)) return r;
            r = F(r)
        }
        return i
    }
    let n = Pt(e, t);
    for (; n && Te(n) && ht(n);) n = Pt(n, t);
    return n && X(n) && ht(n) && !wt(n) ? i : n || Ne(e) || i
}
const Ke = async function(e) {
    const t = this.getOffsetParent || Vt,
        i = this.getDimensions,
        n = await i(e.floating);
    return {
        reference: qe(e.reference, await t(e.floating), e.strategy),
        floating: {
            x: 0,
            y: 0,
            width: n.width,
            height: n.height
        }
    }
};

function Ze(e) {
    return T(e).direction === "rtl"
}
const Je = {
        convertOffsetParentRelativeRectToViewportRelativeRect: He,
        getDocumentElement: _,
        getClippingRect: Ge,
        getOffsetParent: Vt,
        getElementRects: Ke,
        getClientRects: Ie,
        getDimensions: Ye,
        getScale: j,
        isElement: P,
        isRTL: Ze
    },
    Qe = Se,
    $e = Le,
    tn = Ce,
    en = (e, t, i) => {
        const n = new Map,
            r = {
                platform: Je,
                ...i
            },
            s = { ...r.platform,
                _c: n
            };
        return ke(e, t, { ...r,
            platform: s
        })
    };
class nn {
    static floatToCents(t) {
        return Math.round(t * 100)
    }
    static safeDivide(t, i, n = 1) {
        return t / (i === 0 ? n : i)
    }
    static toLocaleString(t) {
        return t.toLocaleString("pt-BR")
    }
    static clamp(t, i, n) {
        return Math.min(Math.max(t, i), n)
    }
    static percentToString(t, i = 1) {
        return `${t.toFixed(i)}%`
    }
    static brazilNumberToFloat(t) {
        const i = parseFloat(t.replace(".", "").replace(",", "."));
        return Number.isNaN(i) ? null : i
    }
    static brazilNumberToInteger(t) {
        const i = parseInt(t.replace(".", "").replace(",", "."), 10);
        return Number.isNaN(i) ? null : i
    }
    static floatToBrazilNumber(t, i = 1) {
        const n = t.toLocaleString("pt-BR", {
            minimumFractionDigits: i,
            maximumFractionDigits: i
        });
        return parseFloat(n)
    }
}
const on = (e, t) => {
    if (!t.text) return {
        destroy() {}
    };
    const i = t.widthMode ? ? "free",
        s = (u => {
            const h = document.getElementById(u);
            if (h) return h;
            const m = document.createElement("div");
            return m.id = u, document.body.appendChild(m), m
        })("tooltip-parent");
    s.style.position = "absolute", s.style.pointerEvents = "none", s.style.top = "0px", s.style.left = "0px", s.style.overflow = "hidden", s.style.width = "100%", s.style.height = "100%";
    const o = document.createElement("div");
    if (s.appendChild(o), o.style.position = "absolute", o.classList.add("custom-tooltip"), o.setAttribute("role", "tooltip"), o.innerHTML = t.text, i === "parent") {
        const u = window.getComputedStyle(e),
            h = nn.clamp(parseFloat(u.width) * .1, 0, 10);
        o.style.maxWidth = `${parseFloat(u.width)+h}px`
    } else i === "sm" ? o.style.maxWidth = "9vw" : i === "md" ? o.style.maxWidth = "19vw" : i === "lg" ? o.style.maxWidth = "29vw" : i === "xl" ? o.style.maxWidth = "39vw" : i === "2xl" ? o.style.maxWidth = "49vw" : i === "3xl" ? o.style.maxWidth = "59vw" : i === "4xl" ? o.style.maxWidth = "69vw" : i === "5xl" && (o.style.maxWidth = "79vw");

    function c() {
        en(e, o, {
            placement: t.placement ? ? "top",
            middleware: [tn(), $e({
                padding: 5
            }), Qe(6)]
        }).then(({
            x: u,
            y: h
        }) => {
            Object.assign(o.style, {
                left: `${u}px`,
                top: `${h}px`
            })
        })
    }
    c();

    function a() {
        setTimeout(() => {
            o.classList.add("show"), c()
        }, t.delay ? ? 0)
    }

    function f() {
        setTimeout(() => {
            o.classList.remove("show")
        }, t.delay ? ? 0)
    }
    return [
        ["mouseenter", a],
        ["mouseleave", f],
        ["focus", a],
        ["blur", f]
    ].forEach(([u, h]) => {
        e.addEventListener(u, h)
    }), {
        destroy() {
            o.remove(), [
                ["mouseenter", a],
                ["mouseleave", f],
                ["focus", a],
                ["blur", f]
            ].forEach(([u, h]) => {
                e.removeEventListener(u, h)
            })
        }
    }
};

function sn(e) {
    let t, i, n, r, s, o, c;
    return i = new le({
        props: {
            class: (e[3] ? "ml-3" : "") + " mb-[2px]",
            size: "15",
            strokeWidth: e[5]
        }
    }), {
        c() {
            t = Yt("i"), te(i.$$.fragment), this.h()
        },
        l(a) {
            t = Gt(a, "I", {
                class: !0
            });
            var f = C(t);
            $t(i.$$.fragment, f), f.forEach(x), this.h()
        },
        h() {
            l(t, "class", n = e[2] === "default" ? "" : e[2] === "success" ? "text-successful" : "text-error")
        },
        m(a, f) {
            Z(a, t, f), Qt(i, t, null), s = !0, o || (c = Xt(r = on.call(null, t, {
                text: e[0],
                placement: e[1],
                widthMode: e[4] ? ? void 0
            })), o = !0)
        },
        p(a, [f]) {
            const u = {};
            f & 8 && (u.class = (a[3] ? "ml-3" : "") + " mb-[2px]"), f & 32 && (u.strokeWidth = a[5]), i.$set(u), (!s || f & 4 && n !== (n = a[2] === "default" ? "" : a[2] === "success" ? "text-successful" : "text-error")) && l(t, "class", n), r && qt(r.update) && f & 19 && r.update.call(null, {
                text: a[0],
                placement: a[1],
                widthMode: a[4] ? ? void 0
            })
        },
        i(a) {
            s || (Jt(i.$$.fragment, a), s = !0)
        },
        o(a) {
            Zt(i.$$.fragment, a), s = !1
        },
        d(a) {
            a && x(t), Kt(i), o = !1, c()
        }
    }
}

function rn(e, t, i) {
    let {
        text: n
    } = t, {
        placement: r = "top"
    } = t, {
        style: s = "default"
    } = t, {
        margin: o = !0
    } = t, {
        widthMode: c = null
    } = t, {
        strokeWidth: a = 2.5
    } = t;
    return e.$$set = f => {
        "text" in f && i(0, n = f.text), "placement" in f && i(1, r = f.placement), "style" in f && i(2, s = f.style), "margin" in f && i(3, o = f.margin), "widthMode" in f && i(4, c = f.widthMode), "strokeWidth" in f && i(5, a = f.strokeWidth)
    }, [n, r, s, o, c, a]
}
class mn extends J {
    constructor(t) {
        super(), Q(this, t, rn, sn, K, {
            text: 0,
            placement: 1,
            style: 2,
            margin: 3,
            widthMode: 4,
            strokeWidth: 5
        })
    }
}
export {
    fe as D, fn as E, mn as I, nn as N, un as X, on as a, an as b, le as c, dn as g, hn as h
};