import {
    s as F,
    d as h,
    a as U,
    m as b,
    i as j,
    b as k,
    q as D,
    B as G,
    c as S,
    e as T,
    g as H,
    f as I,
    h as C,
    j as J,
    t as K,
    E as O,
    F as W
} from "./DDNnt9XD.js";
import {
    S as L,
    i as M,
    t as w,
    a as g,
    g as z,
    f as A,
    d as B,
    b as E,
    m as P,
    c as Q
} from "./qWASNxYk.js";

function q(t) {
    let e, n, o;
    var s = t[10];

    function c(a, r) {
        return {
            props: {
                class: "mr-2",
                size: "16"
            }
        }
    }
    return s && (e = O(s, c())), {
        c() {
            e && E(e.$$.fragment), n = W()
        },
        l(a) {
            e && Q(e.$$.fragment, a), n = W()
        },
        m(a, r) {
            e && P(e, a, r), j(a, n, r), o = !0
        },
        p(a, r) {
            if (r & 1024 && s !== (s = a[10])) {
                if (e) {
                    z();
                    const f = e;
                    w(f.$$.fragment, 1, 0, () => {
                        B(f, 1)
                    }), A()
                }
                s ? (e = O(s, c()), E(e.$$.fragment), g(e.$$.fragment, 1), P(e, n.parentNode, n)) : e = null
            }
        },
        i(a) {
            o || (e && g(e.$$.fragment, a), o = !0)
        },
        o(a) {
            e && w(e.$$.fragment, a), o = !1
        },
        d(a) {
            a && h(n), e && B(e, a)
        }
    }
}

function R(t) {
    let e, n, o, s = (t[1] ? t[2] ? ? t[0] : t[0]) + "",
        c, a, r, f, _, y, l = t[10] && q(t);
    return {
        c() {
            e = C("button"), n = C("span"), l && l.c(), o = J(), c = K(s), this.h()
        },
        l(m) {
            e = S(m, "BUTTON", {
                class: !0,
                type: !0
            });
            var u = T(e);
            n = S(u, "SPAN", {});
            var d = T(n);
            l && l.l(d), o = H(d), c = I(d, s), d.forEach(h), u.forEach(h), this.h()
        },
        h() {
            b(e, "class", a = (t[5] ? "w-40 text-left" : "w-100") + " btn btn" + (t[6] ? "-outline" : "") + "-" + (t[4] ? t[7] === "primary" ? "primary" : t[7] === "danger" ? "danger" : "secondary" : "secondary") + " " + (t[8] ? "" : "!m-0") + " " + (t[11] === "kwai" ? "btn-kwai" : "") + " " + (t[12] ? "!rounded-full py-1" : "") + " svelte-115npm2"), e.disabled = r = t[1] || !t[4], b(e, "type", t[9])
        },
        m(m, u) {
            j(m, e, u), k(e, n), l && l.m(n, null), k(n, o), k(n, c), f = !0, _ || (y = D(e, "click", function() {
                G(t[3]) && t[3].apply(this, arguments)
            }), _ = !0)
        },
        p(m, [u]) {
            t = m, t[10] ? l ? (l.p(t, u), u & 1024 && g(l, 1)) : (l = q(t), l.c(), g(l, 1), l.m(n, o)) : l && (z(), w(l, 1, 1, () => {
                l = null
            }), A()), (!f || u & 7) && s !== (s = (t[1] ? t[2] ? ? t[0] : t[0]) + "") && U(c, s), (!f || u & 6640 && a !== (a = (t[5] ? "w-40 text-left" : "w-100") + " btn btn" + (t[6] ? "-outline" : "") + "-" + (t[4] ? t[7] === "primary" ? "primary" : t[7] === "danger" ? "danger" : "secondary" : "secondary") + " " + (t[8] ? "" : "!m-0") + " " + (t[11] === "kwai" ? "btn-kwai" : "") + " " + (t[12] ? "!rounded-full py-1" : "") + " svelte-115npm2")) && b(e, "class", a), (!f || u & 18 && r !== (r = t[1] || !t[4])) && (e.disabled = r), (!f || u & 512) && b(e, "type", t[9])
        },
        i(m) {
            f || (g(l), f = !0)
        },
        o(m) {
            w(l), f = !1
        },
        d(m) {
            m && h(e), l && l.d(), _ = !1, y()
        }
    }
}

function V(t, e, n) {
    let {
        text: o
    } = e, {
        loading: s = !1
    } = e, {
        loadingText: c = null
    } = e, {
        onClick: a = null
    } = e, {
        enabled: r = !0
    } = e, {
        restrictWidth: f = !1
    } = e, {
        isOutline: _ = !1
    } = e, {
        style: y = "primary"
    } = e, {
        margin: l = !0
    } = e, {
        type: m = null
    } = e, {
        icon: u = null
    } = e, {
        customStyle: d = null
    } = e, {
        isNew: N = !1
    } = e;
    return t.$$set = i => {
        "text" in i && n(0, o = i.text), "loading" in i && n(1, s = i.loading), "loadingText" in i && n(2, c = i.loadingText), "onClick" in i && n(3, a = i.onClick), "enabled" in i && n(4, r = i.enabled), "restrictWidth" in i && n(5, f = i.restrictWidth), "isOutline" in i && n(6, _ = i.isOutline), "style" in i && n(7, y = i.style), "margin" in i && n(8, l = i.margin), "type" in i && n(9, m = i.type), "icon" in i && n(10, u = i.icon), "customStyle" in i && n(11, d = i.customStyle), "isNew" in i && n(12, N = i.isNew)
    }, [o, s, c, a, r, f, _, y, l, m, u, d, N]
}
class Z extends L {
    constructor(e) {
        super(), M(this, e, V, R, F, {
            text: 0,
            loading: 1,
            loadingText: 2,
            onClick: 3,
            enabled: 4,
            restrictWidth: 5,
            isOutline: 6,
            style: 7,
            margin: 8,
            type: 9,
            icon: 10,
            customStyle: 11,
            isNew: 12
        })
    }
}
export {
    Z as P
};