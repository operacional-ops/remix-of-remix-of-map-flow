class t {
    static init() {
        fbq("init", "446608397700232")
    }
    static trackPageView() {
        t._delayedFbq("track", "PageView")
    }
    static trackViewContent() {
        t._delayedFbq("track", "ViewContent"), console.log("viewContent")
    }
    static trackLead() {
        t._delayedFbq("track", "Lead"), console.log("lead")
    }
    static trackRegistration() {
        t._delayedFbq("track", "CompleteRegistration"), console.log("registration")
    }
    static trackSubscribe(c) {
        t._delayedFbq("track", "Subscribe"), t._delayedFbq("track", "Purchase", {
            value: c,
            currency: "BRL"
        }), console.log("subscribe")
    }
    static _delayedFbq(c, e) {
        setTimeout(() => {
            typeof fbq == "function" ? e ? (fbq("track", c, e), console.log("track", c, e)) : (fbq("track", c), console.log("track", c)) : console.warn("fbq function is not defined")
        }, 100)
    }
}
export {
    t as M
};