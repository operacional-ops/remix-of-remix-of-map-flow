import {
    s as te,
    d as h,
    m as _,
    S as M,
    i as N,
    b as g,
    q as ne,
    p as V,
    T as ae,
    c as p,
    e as E,
    g as P,
    f as B,
    h as S,
    j as q,
    t as D,
    a as X,
    n as U,
    F as G,
    x as ie,
    U as se
} from "./DDNnt9XD.js";
import {
    S as oe,
    i as fe,
    d as Y,
    t as C,
    a as T,
    g as Z,
    f as y,
    m as x,
    c as ee,
    b as le
} from "./qWASNxYk.js";
import {
    e as H,
    u as re,
    d as ue
} from "./D4UMIlhj.js";
import {
    I as ce
} from "./BtulAGCG.js";
import {
    I as _e
} from "./s1mAKLjT.js";

function he(o, e) {
    $(o).val(e).trigger("change")
}

function J(o, e, l) {
    const n = o.slice();
    return n[16] = e[l], n
}

function me(o) {
    let e, l;
    return {
        c() {
            e = S("label"), l = D("‍"), this.h()
        },
        l(n) {
            e = p(n, "LABEL", {
                class: !0,
                for: !0
            });
            var f = E(e);
            l = B(f, "‍"), f.forEach(h), this.h()
        },
        h() {
            _(e, "class", "form-label"), _(e, "for", o[2])
        },
        m(n, f) {
            N(n, e, f), g(e, l)
        },
        p(n, f) {
            f & 4 && _(e, "for", n[2])
        },
        i: U,
        o: U,
        d(n) {
            n && h(e)
        }
    }
}

function de(o) {
    let e, l, n, f, a, t = o[8] && K(o);
    return {
        c() {
            e = S("div"), l = S("label"), n = D(o[3]), f = q(), t && t.c(), this.h()
        },
        l(i) {
            e = p(i, "DIV", {
                class: !0
            });
            var r = E(e);
            l = p(r, "LABEL", {
                class: !0,
                for: !0
            });
            var m = E(l);
            n = B(m, o[3]), m.forEach(h), f = P(r), t && t.l(r), r.forEach(h), this.h()
        },
        h() {
            _(l, "class", "form-label overflow-x-hidden whitespace-nowrap text-ellipsis"), _(l, "for", o[2]), _(e, "class", "flex items-center !gap-1")
        },
        m(i, r) {
            N(i, e, r), g(e, l), g(l, n), g(e, f), t && t.m(e, null), a = !0
        },
        p(i, r) {
            (!a || r & 8) && X(n, i[3]), (!a || r & 4) && _(l, "for", i[2]), i[8] ? t ? (t.p(i, r), r & 256 && T(t, 1)) : (t = K(i), t.c(), T(t, 1), t.m(e, null)) : t && (Z(), C(t, 1, 1, () => {
                t = null
            }), y())
        },
        i(i) {
            a || (T(t), a = !0)
        },
        o(i) {
            C(t), a = !1
        },
        d(i) {
            i && h(e), t && t.d()
        }
    }
}

function K(o) {
    let e, l, n;
    return l = new ce({
        props: {
            margin: !1,
            text: o[8]
        }
    }), {
        c() {
            e = S("span"), le(l.$$.fragment), this.h()
        },
        l(f) {
            e = p(f, "SPAN", {
                class: !0
            });
            var a = E(e);
            ee(l.$$.fragment, a), a.forEach(h), this.h()
        },
        h() {
            _(e, "class", "!-mt-[7px]")
        },
        m(f, a) {
            N(f, e, a), x(l, e, null), n = !0
        },
        p(f, a) {
            const t = {};
            a & 256 && (t.text = f[8]), l.$set(t)
        },
        i(f) {
            n || (T(l.$$.fragment, f), n = !0)
        },
        o(f) {
            C(l.$$.fragment, f), n = !1
        },
        d(f) {
            f && h(e), Y(l)
        }
    }
}

function Q(o) {
    let e = [],
        l = new Map,
        n, f = H(o[1]);
    const a = t => t[16].value;
    for (let t = 0; t < f.length; t += 1) {
        let i = J(o, f, t),
            r = a(i);
        l.set(r, e[t] = W(r, i))
    }
    return {
        c() {
            for (let t = 0; t < e.length; t += 1) e[t].c();
            n = G()
        },
        l(t) {
            for (let i = 0; i < e.length; i += 1) e[i].l(t);
            n = G()
        },
        m(t, i) {
            for (let r = 0; r < e.length; r += 1) e[r] && e[r].m(t, i);
            N(t, n, i)
        },
        p(t, i) {
            i & 2 && (f = H(t[1]), e = re(e, i, a, 1, t, f, l, n.parentNode, ue, W, n, J))
        },
        d(t) {
            t && h(n);
            for (let i = 0; i < e.length; i += 1) e[i].d(t)
        }
    }
}

function W(o, e) {
    let l, n = e[16].label + "",
        f, a, t;
    return {
        key: o,
        first: null,
        c() {
            l = S("option"), f = D(n), a = q(), this.h()
        },
        l(i) {
            l = p(i, "OPTION", {
                class: !0
            });
            var r = E(l);
            f = B(r, n), a = P(r), r.forEach(h), this.h()
        },
        h() {
            _(l, "class", "text-white text-xl bg-black"), l.__value = t = e[16].value, V(l, l.__value), this.first = l
        },
        m(i, r) {
            N(i, l, r), g(l, f), g(l, a)
        },
        p(i, r) {
            e = i, r & 2 && n !== (n = e[16].label + "") && X(f, n), r & 2 && t !== (t = e[16].value) && (l.__value = t, V(l, l.__value))
        },
        d(i) {
            i && h(l)
        }
    }
}

function be(o) {
    var j;
    let e, l, n, f, a, t, i, r, m, z, b, L, d, k, I;
    const R = [de, me],
        v = [];

    function A(u, c) {
        return u[3] ? 0 : u[4] ? 1 : -1
    }~(l = A(o)) && (n = v[l] = R[l](o));
    let s = ((j = o[1]) == null ? void 0 : j.length) > 0 && Q(o);
    return b = new _e({
        props: {
            error: o[9]
        }
    }), {
        c() {
            e = S("div"), n && n.c(), f = q(), a = S("select"), t = S("option"), i = D(`Selecione uma opção
    `), s && s.c(), z = q(), le(b.$$.fragment), this.h()
        },
        l(u) {
            e = p(u, "DIV", {
                class: !0
            });
            var c = E(e);
            n && n.l(c), f = P(c), a = p(c, "SELECT", {
                id: !0,
                class: !0,
                name: !0
            });
            var w = E(a);
            t = p(w, "OPTION", {});
            var O = E(t);
            i = B(O, `Selecione uma opção
    `), O.forEach(h), s && s.l(w), w.forEach(h), z = P(c), ee(b.$$.fragment, c), c.forEach(h), this.h()
        },
        h() {
            t.__value = "", V(t, t.__value), t.disabled = !0, t.selected = r = o[0] === "", t.hidden = !0, _(a, "id", o[2]), a.disabled = o[5], _(a, "class", m = "select2 hide-search form-select " + (o[7] ? "!rounded-l-none" : "")), _(a, "name", o[2]), o[0] === void 0 && ae(() => o[14].call(a)), _(e, "class", L = o[6] ? "mb-1" : "")
        },
        m(u, c) {
            N(u, e, c), ~l && v[l].m(e, null), g(e, f), g(e, a), g(a, t), g(t, i), s && s.m(a, null), o[13](a), M(a, o[0], !0), g(e, z), x(b, e, null), d = !0, k || (I = ne(a, "change", o[14]), k = !0)
        },
        p(u, [c]) {
            var F;
            let w = l;
            l = A(u), l === w ? ~l && v[l].p(u, c) : (n && (Z(), C(v[w], 1, 1, () => {
                v[w] = null
            }), y()), ~l ? (n = v[l], n ? n.p(u, c) : (n = v[l] = R[l](u), n.c()), T(n, 1), n.m(e, f)) : n = null), (!d || c & 3 && r !== (r = u[0] === "")) && (t.selected = r), ((F = u[1]) == null ? void 0 : F.length) > 0 ? s ? s.p(u, c) : (s = Q(u), s.c(), s.m(a, null)) : s && (s.d(1), s = null), (!d || c & 4) && _(a, "id", u[2]), (!d || c & 32) && (a.disabled = u[5]), (!d || c & 128 && m !== (m = "select2 hide-search form-select " + (u[7] ? "!rounded-l-none" : ""))) && _(a, "class", m), (!d || c & 4) && _(a, "name", u[2]), c & 3 && M(a, u[0]);
            const O = {};
            c & 512 && (O.error = u[9]), b.$set(O), (!d || c & 64 && L !== (L = u[6] ? "mb-1" : "")) && _(e, "class", L)
        },
        i(u) {
            d || (T(n), T(b.$$.fragment, u), d = !0)
        },
        o(u) {
            C(n), C(b.$$.fragment, u), d = !1
        },
        d(u) {
            u && h(e), ~l && v[l].d(), s && s.d(), o[13](null), Y(b), k = !1, I()
        }
    }
}

function ge(o, e, l) {
    let {
        options: n
    } = e, {
        name: f
    } = e, {
        value: a = ""
    } = e, {
        label: t
    } = e, {
        useLabelSize: i = !0
    } = e, {
        disabled: r = !1
    } = e, {
        onChange: m = null
    } = e, {
        margin: z = !1
    } = e, {
        removeLeftRounded: b = !1
    } = e, {
        tooltip: L = null
    } = e, {
        error: d = null
    } = e, k, I = !1;
    const R = s => {
        k && he(k, s), I && (m == null || m(s))
    };

    function v(s) {
        ie[s ? "unshift" : "push"](() => {
            k = s, l(10, k)
        })
    }

    function A() {
        a = se(this), l(0, a), l(1, n)
    }
    return o.$$set = s => {
        "options" in s && l(1, n = s.options), "name" in s && l(2, f = s.name), "value" in s && l(0, a = s.value), "label" in s && l(3, t = s.label), "useLabelSize" in s && l(4, i = s.useLabelSize), "disabled" in s && l(5, r = s.disabled), "onChange" in s && l(11, m = s.onChange), "margin" in s && l(6, z = s.margin), "removeLeftRounded" in s && l(7, b = s.removeLeftRounded), "tooltip" in s && l(8, L = s.tooltip), "error" in s && l(9, d = s.error)
    }, o.$$.update = () => {
        o.$$.dirty & 4097 && (I ? R(a) : l(12, I = !0))
    }, [a, n, f, t, i, r, z, b, L, d, k, m, I, v, A]
}
class Le extends oe {
    constructor(e) {
        super(), fe(this, e, ge, be, te, {
            options: 1,
            name: 2,
            value: 0,
            label: 3,
            useLabelSize: 4,
            disabled: 5,
            onChange: 11,
            margin: 6,
            removeLeftRounded: 7,
            tooltip: 8,
            error: 9
        })
    }
}
export {
    Le as S
};