import {
    s as r,
    n as o,
    d,
    i as n,
    c as l,
    o as c,
    h as m
} from "./DDNnt9XD.js";
import {
    S as u,
    i as p
} from "./qWASNxYk.js";

function f(i) {
    let e, s = `<h2 class="text-3xl font-bold my-2 text-center">TERMO DE ADESÃO AO PROGRAMA DE AFILIADOS UTMIFY</h2> <p class="mb-2 text-justify text-md">Este Termo de Adesão ao Programa de Afiliados UTMify formaliza o acordo
    completo entre o Afiliado e UTMIFY TECNOLOGIA LTDA, doravante denominada
    como “UTMIFY”, pessoa jurídica de direito privado, regularmente registrada
    sob o CNPJ n° 44.105.337/0001-39, com sede à Rua Moyses Braga Lima, n° 271,
    Bairro Goiabal, Barra Mansa – RJ, CEP 27.340-110. Sendo a UTMIFY a única
    proprietária dos direitos de propriedade intelectual e detentora dos
    direitos sobre o Software UTMify, concedendo ao Afiliado, por meio deste
    documento, o direito de disponibilizar link de acesso a terceiros para
    compra dos planos de acesso à Plataforma UTMify (“Plataforma”), percebendo
    remuneração correspondente. Este contrato define o escopo da relação entre
    as partes, sendo que o Afiliado afirma ter lido, entendido e aceitado todas
    as condições apresentadas neste acordo.</p> <p class="mb-2 text-justify text-md">Considerando que:</p> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">(I) A UTMIFY é uma plataforma de Software como Serviço (SaaS) que oferece
      soluções avançadas para otimização de campanhas de marketing digital,
      facilitando a operacionalização de profissionais e empresas que atuam com
      tráfego direto, através de funcionalidades como geração de relatórios,
      integração com diversas plataformas, otimização rápida de campanhas e
      unificação de múltiplos dashboards.</li> <li class="mb-2 text-justify text-md">(II) O presente Termo de Adesão ao Programa de Afiliados tem como objetivo
      estabelecer a parceria entre a UTMIFY e o AFILIADO para a promoção dos
      serviços oferecidos pela plataforma, visando aumentar a visibilidade e o
      alcance da UTMIFY no mercado.</li> <li class="mb-2 text-justify text-md">(III) O AFILIADO, ao aderir ao Programa de Afiliados da UTMIFY,
      compromete-se a cumprir todas as diretrizes estabelecidas neste Termo, bem
      como seguir rigorosamente a Política de Privacidade e os Termos de Uso da
      UTMIFY, garantindo que suas ações estejam em conformidade com as leis
      aplicáveis de proteção de dados e práticas comerciais éticas.</li> <li class="mb-2 text-justify text-md">(IV) É interesse mútuo que as atividades desenvolvidas no âmbito deste
      programa de afiliados sejam conduzidas de maneira ética e transparente,
      visando a promoção dos serviços da UTMIFY de forma positiva e construtiva,
      sem causar danos à imagem ou reputação da plataforma.</li></ul> <p class="mb-2 text-justify text-md">Firmam entre si o presente Termo de Adesão ao Programa de Afiliados UTMIFY,
    que reger-se-á pelas cláusulas e condições a seguir pactuadas:</p> <h3 class="text-xl font-bold mb-2">CLÁUSULA PRIMEIRA – DO OBJETIVO DO PROGRAMA</h3> <p class="mb-2 text-justify text-md">1.1. O objeto do presente termo de adesão é a afiliação ao Programa De
    Afiliados UTMIFY, na plataforma https://app.utmify.com.br, sendo um serviço
    oferecido por meio de página eletrônica na internet que oferece ao parceiro,
    a possibilidade de disponibilizar link específico (de produção, propriedade
    e vinculado à UTMIFY) ao consumidor final, que comprará produto ou serviço
    da UTMIFY, recebendo o AFILIADO, em contrapartida, uma comissão, após a
    confirmação da compra e o recebimento de valores do cliente, que adquiriu o
    produto ou serviço por meio de link.</p> <h3 class="text-xl font-bold mb-2">CLÁUSULA SEGUNDA – DO REGISTRO NO PROGRAMA</h3> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">2.1. Não serão cobrados quaisquer valores do Afiliado para a vinculação ao
      programa, sua vinculação ocorrerá de forma gratuita, o que lhe garantirá
      integração e acesso ao Programa De Afiliados UTMIFY, bem como acesso a aba
      específica no Dashboard da Plataforma UTMIFY voltada à gestão do presente
      Programa de Afiliados.</li> <li class="mb-2 text-justify text-md">2.2. O AFILIADO declara que leu e concorda com todos os termos e condições
      previstos neste termo de adesão. Para participar do Programa, o AFILIADO
      declara que preencheu corretamente na plataforma https://app.utmify.com.br,
      com as informações solicitadas na ficha de cadastro.</li> <li class="mb-2 text-justify text-md">2.3. A partir da finalização do cadastro na Plataforma
      https://app.utmify.com.br, o AFILIADO será aceito automaticamente no programa,
      estando a UTMIFY autorizada a solicitar dados adicionais do mesmo, tanto
      da pessoa jurídica cadastrada quanto do sócio e/ou empresário individual
      pessoa física, ou da pessoa física cadastrada, bem como a ou a retificação
      de informações, para a manutenção da pessoa cadastrada no Programa.</li> <li class="mb-2 text-justify text-md">2.4. A plataforma https://app.utmify.com.br reserva-se no direito de não
      aprovar o cadastro do AFILIADO ou excluí-lo do Programa de Afiliados
      UTMIFY na hipótese de divulgação de qualquer material, imagem ou conteúdo
      em discordância com quaisquer de seus princípios, políticas ou legislação
      vigente.</li> <li class="mb-2 text-justify text-md">2.5. A UTMIFY reserva-se, ainda, ao direito de descadastrar do Programa o
      AFILIADO, a qualquer tempo e por mera liberalidade, sem que isso implique
      responsabilidades indenizatórias para a UTMIFY.</li></ul> <h3 class="text-xl font-bold mb-2">CLÁUSULA TERCEIRA – CARACTERÍSTICAS DO PROGRAMA DE EMPREENDEDOR DIGITAL</h3> <p class="mb-2 text-justify text-md">3.1. O AFILIADO declara-se ciente que a Plataforma UTMIFY é de propriedade
    exclusiva da UTMIFY, portanto, constituindo relação comercial/jurídica com o
    Site Parceiro, responsabilizando o AFILIADO pelas infrações aos regramentos
    dispostos no presente termo de adesão.</p> <p class="mb-2 text-justify text-md">3.2. São condutas permitidas ao Afiliado:</p> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">(a) Realizar a divulgação por meio de listas de prospecção de contatos,
      incluindo WhatsApp, SMS, e-mail, Telegram e chamadas telefônicas, sempre
      respeitando a propriedade intelectual da UTMIFY, assim como sua missão e
      valores, além de cumprir com as exigências da Lei Geral de Proteção de
      Dados (LGPD).</li> <li class="mb-2 text-justify text-md">(b) Realizar vendas tanto para o segmento B2B (business-to-business)
      quanto B2C (business-to-consumer), desde que o AFILIADO seja devidamente
      identificado e autorizado para atuar conforme estabelecido no Programa de
      Afiliados UTMIFY.</li> <li class="mb-2 text-justify text-md">(c) Impulsionar vendas através de estratégias de tráfego pago ou orgânico,
      respeitando as demais regras oriundas da lei e do presente contrato, bem
      como os princípios da boa-fé e da transparência;</li> <li class="mb-2 text-justify text-md">(d) Investir em qualquer tipo de serviço de publicidade paga fornecido por
      plataformas ou motores de busca, como Google e Bing, sendo importante
      destacar que quaisquer vendas geradas por tráfego advindo desses anúncios
      resultarão no estorno das comissões que seriam originalmente atribuídas ao
      AFILIADO;</li></ul> <p class="mb-2 text-justify text-md">3.3. Constituem práticas vedadas ao AFILIADO:</p> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">(a) Comercializar produtos ou serviços em marketplaces e e-commerces onde
      lojistas se inscrevem para vender, tais como Mercado Livre, Americanas,
      entre outros que, por sua natureza, bem como vontade do proprietário,
      usuário ou da UTMIFY, seja vedada a divulgação;</li> <li class="mb-2 text-justify text-md">(b) Recrutar ou tentar recrutar clientes diretamente nas redes sociais
      oficiais da UTMIFY;</li> <li class="mb-2 text- justify text-md">(c) Recrutar ou tentar recrutar clientes durante transmissões ao vivo
      (lives) da UTMIFY, ou quaisquer propagandas por si utilizadas;</li> <li class="mb-2 text-justify text-md">(d) Falsamente se declarar como funcionário, sócio, acionista e/ou
      terceirizado da UTMIFY;</li> <li class="mb-2 text-justify text-md">(e) Realizar a divulgação dos produtos e serviços em sites de conteúdo
      ilícito, imoral ou degradante, incompatível com os princípios da empresa,
      ou em contextos que possam comprometer a imagem da UTMIFY;</li> <li class="mb-2 text-justify text-md">(f) Cadastrar uma Pessoa Jurídica já registrada por outro afiliado, sendo
      que qualquer sócio adicional não registrado que deseje participar do
      programa deve vincular-se a uma nova Pessoa Jurídica para fins de
      recebimento de comissão;</li> <li class="mb-2 text-justify text-md">(g) Executar campanhas de links patrocinados em motores de busca que
      utilizem a marca ou imagem da UTMIFY de forma isolada ou associada a
      concorrentes, derivativos, prefixos, sufixos ou termos similares;</li> <li class="mb-2 text-justify text-md">(h) Copiar, modificar, reproduzir, distribuir, fazer download, armazenar,
      transmitir, vender, revender, realizar engenharia reversa, traduzir,
      decompilar, copiar, alugar, emprestar, licenciar ou criar produtos
      derivados de qualquer conteúdo da plataforma sem a devida autorização
      expressa e por escrito;</li> <li class="mb-2 text-justify text-md">(i) Violar ou tentar violar medidas de segurança da plataforma, seus
      termos de uso ou políticas de privacidade, aproveitar-se de falhas do
      sistema para obter vantagens indevidas, acessar contas de outros usuários,
      ou divulgar senhas de outros AFILIADOS ou usuários;</li> <li class="mb-2 text-justify text-md">(j) Submeter à UTMIFY informações falsas, imprecisas ou incompletas;</li> <li class="mb-2 text-justify text-md">(k) Impersonar outra pessoa ou entidade, bem como praticar, face à UTMIFY,
      crimes de falsidade ideológica;</li> <li class="mb-2 text-justify text-md">(l) Agredir, caluniar, injuriar ou difamar outros AFILIADOS, terceiros ou
      potenciais clientes, usar linguagem imprópria ou ofensiva, ou praticar
      atos prejudiciais à marca ou à reputação da UTMIFY ou empresas associadas.</li> <li class="mb-2 text-justify text-md">(m) Engajar-se em publicidade enganosa ou abusiva, incluindo a prática de
      enviar comunicações não solicitadas (spam), fazer afirmações falsas sobre
      produtos ou serviços, ou utilizar qualquer forma de promoção que possa ser
      interpretada como enganosa ou abusiva pelo público.</li></ul> <p class="mb-2 text-justify text-md">3.3. Toda política comercial adotada pelo AFILIADO deverá seguir as regras
    da UTMIFY, acerca do preço, promoção e parcelas, não podendo ser cobrado
    pelo AFILIADO taxas adicionais do possível novo Usuário pelo envio do link.</p> <p class="mb-2 text-justify text-md">3.4. A prática pelo AFILIADO, direta ou indiretamente, de qualquer conduta
    contrária aos termos desta cláusula implicará em estorno e não pagamento das
    comissões futuras, além de medidas punitivas, a serem aplicadas de acordo
    com a gravidade, tais como encerramento do cadastro do AFILIADO, inclusive
    podendo encerrar o cadastro do mesmo como Usuário da Plataforma, a critério
    da UTMIFY.</p> <h3 class="text-xl font-bold mb-2">CLÁUSULA QUARTA – CADASTRAMENTO NO PROGRAMA UTMIFY AFILIADO</h3> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">4.1. O AFILIADO declara que para o início no Programa de Afiliados UTMify,
      o mesmo se cadastrou na plataforma https://app.utmify.com.br, cadastrando-se
      como pessoa física ou jurídica, declarando para estes fins que prestou
      todas as informações de dados de identificação, pagamento e contato de
      maneira verídica, e tão exatas quanto necessárias, comprometendo-se a
      altera-las ou corrigi-las, tão logo identifique incorreções ou alterações
      nos dados fornecidos.</li> <li class="mb-2 text-justify text-md">4.2. O AFILIADO declara que leu atentamente e concorda integralmente com
      todos os termos e condições estipulados neste Termo de Adesão ao Programa
      de Afiliados, declarando especial ciência, reconhecendo e aceitando que o
      presente Termo pode ser rescindido unilateralmente e a qualquer momento,
      por mera liberalidade de qualquer das partes, conforme previsto neste
      contrato. Entende também que a UTMIFY não está obrigada a manter
      indefinidamente o programa de afiliados e pode decidir pelo seu
      encerramento ou pela exclusão de participantes a seu exclusivo critério.
      Em caso de descumprimento das obrigações contratuais por parte do
      AFILIADO, a UTMIFY reserva-se o direito de desligá-lo do programa e negar
      o pagamento de quaisquer comissões futuras, protegendo-se contra possíveis
      prejuízos ou inconformidades contratuais.</li> <li class="mb-2 text-justify text-md">4.3. Na eventualidade de a UTMIFY sofrer prejuízos decorrentes de uma ação
      judicial ou administrativa, cuja ação originária da respectiva demanda
      seja atribuída a ato ou fato do AFILIADO, este último deverá indenizar a
      UTMIFY por todos os danos causados, bem como assumir única e
      exclusivamente para si a responsabilidade pelo eventual ressarcimento de
      terceiro, podendo a UTMIFY incluir o AFILIADO no processo para assegurar o
      ressarcimento de quaisquer prejuízos sofridos, bem como reivindicar
      compensação por perdas e danos resultantes de atos ilícitos cometidos pelo
      AFILIADO, este que compromete-se também a cobrir os honorários
      advocatícios e demais custas processuais necessárias que a UTMIFY
      porventura venha a ter sofrido.</li></ul> <h3 class="text-xl font-bold mb-2">CLÁUSULA QUINTA – DA COMISSÃO E DAS PROGRESSÕES</h3> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">5.1. O AFILIADO terá direito a remuneração a título de comissão na
      importância de 10% sobre o lucro líquido de cada plano contratado por meio
      de seu link de afiliado. O lucro líquido é definido como o valor da
      receita obtida com cada plano após a dedução de impostos, taxas de
      transação e quaisquer outros custos diretos associados à venda. Esta
      comissão será paga mensalmente, pelo período de seis meses a contar da
      data em que o novo Usuário se vincular à plataforma através do link do
      afiliado.</li> <li class="mb-2 text-justify text-md">5.2. Os pagamentos das comissões serão efetuados 33 dias após a vinculação
      do novo usuário à plataforma. O crédito correspondente só estará
      disponível para o afiliado após esse período. Os valores das comissões
      poderão ser consultados pelo AFILIADO em uma aba própria dentro de sua
      conta de usuário na plataforma UTMIFY, facilitando o acompanhamento e
      gestão de suas receitas.</li> <li class="mb-2 text-justify text-md">5.3. A obrigatoriedade do pagamento da comissão ao AFILIADO está
      condicionada ao efetivo pagamento do plano pelo Usuário. Caso o usuário
      não efetue o pagamento, solicite o cancelamento ou a devolução da
      comissão, o afiliado não terá direito a receber a comissão correspondente.</li> <li class="mb-2 text-justify text-md">5.4. Os pagamentos das comissões serão realizados diretamente na conta
      bancária informado pelo AFILIADO e regularmente cadastrada na Plataforma
      UTMify, sendo deste a responsabilidade pelas corretas declarações e
      informações de pagamento e contato informadas na plataforma.</li> <li class="mb-2 text-justify text-md">5.5. A UTMIFY estará autorizada a reter temporariamente os repasses de
      comissões ao AFILIADO em caso de verificação de irregularidades nas
      atividades do mesmo. Além disso, a UTMIFY poderá reter definitivamente e
      não proceder ao pagamento das comissões caso seja constatado pelo AFILIADO
      um sério descumprimento contratual ou legal. Caso haja dívidas pendentes,
      ou exista demanda administrativa ou judicial que possa gerar prejuízos à
      UTMIFY, esta poderá suspender as comissões do AFILIADO no patamar do
      possível prejuízo, até finalização do procedimento, e/ou utilizá-lo para
      os gastos envolvidos.</li></ul> <h3 class="text-xl font-bold mb-2">CLÁUSULA SEXTA – DA PROPRIEDADE INTELECTUAL</h3> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">6.1. A UTMIFY detém todos os direitos de propriedade intelectual,
      abrangendo direitos morais e patrimoniais, sobre a Plataforma e seus
      componentes, bem como somo a marca “UTMIFY” e suas variáveis, incluindo
      funcionalidades, marcas registradas, software, domínios, e qualquer outro
      direito de propriedade intelectual associado à Plataforma e aos Serviços
      fornecidos.</li> <li class="mb-2 text-justify text-md">6.2. A UTMIFY é igualmente detentora de qualquer conteúdo e material
      disponível e/ou exibido na plataforma e/ou seus sites, declarando ser de
      sua propriedade intelectual, razão pela qual reserva a si todos os
      direitos de propriedade intelectual, incluindo mas não se limitando a
      gráficos, documentos, textos, imagens, ícones, fotografias, logos,
      gravações, softwares, marcas, programas de computador, banco de dados,
      redes, arquivos e códigos-fonte, dentre outros.</li> <li class="mb-2 text-justify text-md">6.3. UTMIFY não outorga ao AFILIADO quaisquer direitos, expressa ou
      implicitamente, sobre seus direitos intelectuais (de natureza industrial
      ou autoral), ou sobre qualquer outro direito sob a plataforma, que não
      esteja expressamente previsto neste contrato, enquanto o mesmo ocupe a
      qualidade de Afiliado, ou nos Termos de Uso, enquanto ocupe a qualidade de
      Usuário, independentemente da natureza pela qual foi adquirido, antes ou
      após a data de vigência deste instrumento, igualmente.</li></ul> <h3 class="text-xl font-bold mb-2">CLÁUSULA SÉTIMA – DAS OBRIGAÇÕES E RESPONSABILIDADES DO AFILIADO</h3> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">7.1. Além das obrigações e responsabilidades assumidas neste termo, o
      AFILIADO declara e se compromete a:</li> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">(a) Não promover, na qualidade de afiliado ou influenciador digital,
        produtos ou serviços que sejam diretamente concorrentes aos oferecidos
        pela UTMIFY, tanto em ambientes online quanto offline.</li> <li class="mb-2 text-justify text-md">(b) Cumprir rigorosamente todas as cláusulas estipuladas neste termo.</li> <li class="mb-2 text-justify text-md">(c) Manter suas informações pessoais e de contato atualizadas na
        plataforma da UTMIFY, realizando atualizações sempre que ocorrerem
        alterações, sob pena de se considerarem válidas as informações
        previamente fornecidas.</li> <li class="mb-2 text-justify text-md">(d) Observar as leis aplicáveis que proíbem fraude, bem como a
        veiculação de conteúdos e a realização de comércio ilegais.</li> <li class="mb-2 text-justify text-md">(e) Garantir que tanto ele quanto seus representantes, prepostos e
        terceiros que obtenham acesso à plataforma por seu intermédio respeitem
        todos os direitos relacionados aos programas, marcas, sistemas, códigos
        e outros bens imateriais de propriedade da UTMIFY e de seus parceiros.</li> <li class="mb-2 text-justify text-md">(f) Abster-se de utilizar ou permitir o uso de métodos fraudulentos ou
        artificiais para gerar vendas ou receitas no âmbito do Programa de
        Afiliados UTMIFY.</li> <li class="mb-2 text-justify text-md">(g) Possuir mais de 18 anos ou ser emancipado, estar em pleno exercício
        de suas capacidades civis, possuir CPF válido e atender a outros
        requisitos legais necessários para a operacionalização junto à empresa.</li> <li class="mb-2 text-justify text-md">(h) Preservar e promover a boa reputação da marca UTMIFY, agindo sempre
        com diligência e zelo pelo nome, marca e/ou produtos da empresa.</li> <li class="mb-2 text-justify text-md">(i) Assumir todos os ônus e responsabilidades decorrentes de seus atos,
        bem como responder por atos praticados por terceiros em seu nome,
        garantindo à UTMIFY o direito de regresso, caso esta venha a ser
        responsabilizada administrativa ou judicialmente em decorrência de tais
        atos.</li></ul> <li class="mb-2 text-justify text-md">7.2. O AFILIADO é inteiramente responsável por fornecer informações
      precisas e verdadeiras sobre os serviços e produtos oferecidos pela UTMIFY
      na veiculação e ao prestar informações a terceiros, também se
      responsabilizando integralmente por quaisquer promessas feitas ao Usuários
      finais e clientes que não estejam claramente descritas na descrição dos
      produtos disponibilizada no link de acesso fornecido aos clientes.</li> <li class="mb-2 text-justify text-md">7.3. Ao AFILIADO é expressamente vedada a cobrança de valores mensais ou
      de adesão a terceiros pelo acesso a produtos ou serviços da UTMIFY.</li> <li class="mb-2 text-justify text-md">7.4. Caso o AFILIADO utilize sua conta de maneira irregular, nela
      adicionando clientes e/ou consumidores finais, e/ou cobre taxa mensal dos
      mesmos sem o conhecimento e expressa anuência da UTMIFY, será
      imediatamente excluído do programa de parceiros, independentemente de
      interpelação judicial ou extrajudicial, sem que lhe seja devido qualquer
      penalidade, perdendo ainda o direito de recebimento de comissões futuras.</li></ul> <h3 class="text-xl font-bold mb-2">CLÁUSULA OITAVA – DAS OBRIGAÇÕES E RESPONSABILIDADES DA UTMIFY</h3> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">8.1. Além das obrigações e responsabilidades assumidas no presente termo,
      a UTMIFY se compromete em:</li> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">(a) Checar os dados informados pelo AFILIADO no cadastro, e enviar uma
        notificação via plataforma e/ou e-mail, informando se a disposição
        solicitada foi aceita ou recusada. Não serão aceitos contratos duplos,
        ou seja, somente é aceito um contrato por CPF ou CNPJ;</li> <li class="mb-2 text-justify text-md">(b) Disponibilizar o acesso do AFILIADO à Plataforma, mediante o
        fornecimento de login e senha de acesso, bem como e um Link de vendas
        para divulgação e computo de vendas a terceiros;</li> <li class="mb-2 text-justify text-md">(c) Efetuar ao AFILIADO os pagamentos nos valores, nas datas e modo
        ajustados;</li></ul> <li class="mb-2 text-justify text-md">8.2. A UTMIFY não se responsabiliza por quaisquer danos ou prejuízos
      decorrentes da indisponibilidade total ou parcial da Plataforma e do
      cumprimento do objeto deste contrato causados ao AFILIADO ou de Terceiros,
      em decorrência de:</li> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">(a) Manutenções emergenciais necessárias devido a falhas técnicas
        inesperadas que comprometam o funcionamento da Plataforma;</li> <li class="mb-2 text-justify text-md">(b) Atualizações significativas no software ou hardware vinculado a
        Plataforma, visando aprimorar funcionalidades ou corrigir
        vulnerabilidades de segurança, com comunicação prévia sempre que
        possível;</li> <li class="mb-2 text-justify text-md">(c) Incidentes de segurança cibernética, como ataques de negação de
        serviço (DDoS) ou suspeitas de invasão, que exigem intervenção imediata
        para proteger os dados dos Usuários e a integridade da plataforma;</li> <li class="mb-2 text-justify text-md">(d) Problemas significativos de infraestrutura de rede ou falhas de
        serviços de terceiros críticos para o funcionamento da UTMify;</li> <li class="mb-2 text-justify text-md">(e) Solicitações legais ou judiciais que exijam a suspensão temporária
        dos serviços ou a análise de dados específicos;</li> <li class="mb-2 text-justify text-md">(f) eventos fora do controle da Contratada, incluindo mas não se
        limitando a eventos causados por ações ou omissões do Usuário, eventos
        resultantes de falhas de hardware, software ou outras tecnologias
        utilizados pelo Usuário e, por fim, qualquer ato ou fato que importe em
        caso fortuito ou força maior, conforme art. 393 do Código Civil.</li> <li class="mb-2 text-justify text-md">(g) Falhas operacionais ou de servidores que não sejam diretamente
        atribuíveis à UTMIFY;</li></ul></ul> <h3 class="text-xl font-bold mb-2">CLÁUSULA NONA – DA VIGÊNCIA</h3> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">9.1. O contrato entrará em vigor na data de cadastro do AFILIADO ao
      Programa de Afiliados UTMIFY, e terá validade por prazo indeterminado,
      podendo ser rescindido a qualquer tempo pela vontade das partes, por mera
      liberalidade, sem que importe na aplicação de qualquer penalidade.</li> <li class="mb-2 text-justify text-md">9.2. Em caso de desinteresse no prosseguimento da relação pelo AFILIADO, o
      mesmo poderá proceder ao cancelamento da presente relação de maneira
      automática, na própria Plataforma UTMify, na página de Dashboard do
      Afiliado.</li> <li class="mb-2 text-justify text-md">9.3. Caso seja identificado qualquer descumprimento contratual ou legal
      pelo AFILIADO, poderá a UTMIFY proceder à exclusão do mesmo do Programa de
      Afiliados, automaticamente, independentemente de notificação, bem como
      suspender ou reter pagamentos devidos, em virtude de eventual dano ou
      prejuízo efetivamente sofrido, ou potencial, desde que de média e alta
      probabilidade.</li></ul> <h3 class="text-xl font-bold mb-2">CLÁUSULA DÉCIMA – DO SIGILO E DA CONFIDENCIALIDADE</h3> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">10.1. São consideradas informações de natureza confidencial, sendo vedada
      as partes a divulgação de referidas informações pelo prazo que vigorar
      este contrato, e por 5 (cinco) anos contados de sua resolução,
      independentemente do motivo que a fundamenta, as seguintes, mas não se
      limitando a: dados relacionados a operações comerciais, estratégias
      financeiras, detalhes de produtos, procedimentos operacionais, informações
      de bancos de dados, expertise exclusivo, descobertas inovadoras, propostas
      conceituais, avanços tecnológicos, softwares, esquemáticos, sequências
      operacionais, progressos em desenvolvimento, e registros de clientes e
      parceiros, ou qualquer outra informação de natureza técnica, econômica ou
      de mercado obtida durante o curso desta relação contratual.</li> <li class="mb-2 text-justify text-md">10.2. Não são consideradas informações de natureza confidenciais:</li> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">(a) qualquer informação que se torne amplamente disponível para o
        público sem que haja o descumprimento desta disposição;</li> <li class="mb-2 text-justify text-md">(b) qualquer informação que seja legalmente obtida pela Parte receptora
        de um terceiro ou de terceiros, sem que haja o descumprimento desta
        disposição pela Parte receptora, conforme demonstrado por documentação
        suficiente para confirmar o terceiro como a fonte da informação;</li> <li class="mb-2 text-justify text-md">(c) qualquer informação que tenha sido conhecida pela Parte receptora
        antes de tal revelação, conforme demonstrado por documentação suficiente
        para confirmar tal conhecimento;</li> <li class="mb-2 text-justify text-md">(d) qualquer informação cuja revelação tenha sido autorizada
        previamente, por escrito, pela outra Parte;</li> <li class="mb-2 text-justify text-md">(e) qualquer informação que se torne disponível para qualquer das Partes
        de forma não confidencial por uma fonte, a qual, de acordo com o melhor
        conhecimento de tal Parte, após devida investigação, não esteja proibida
        de revelar tal informação por qualquer obrigação legal ou contratual;</li> <li class="mb-2 text-justify text-md">(f) qualquer informação que esteja ou possa estar no domínio público em
        decorrência de um entendimento específico entre as Partes a esse
        respeito</li></ul> <li class="mb-2 text-justify text-md">10.3. O AFILIADO declara-se ciente e concorda que os registros de
      aceitação destes Termos, seleções realizadas na Plataforma, e todas as
      formas de comunicação entre as partes, via e-mail ou qualquer outro meio
      de comunicação, serão armazenados no banco de dados da UTMIFY, incluindo
      data e hora dos eventos, sendo que referidos registros poderão ser
      utilizados como evidência documental, sem necessidade de formalidades
      adicionais, e que esta poderá ter acesso às informações para resolução de
      problemas, dúvidas e/ou quaisquer requisições AFILIADO ou de terceiro
      competente e legitimado para solicitar referidas informações, desde que
      exijam o conhecimento das respectivas informações, inclusive acessando-as
      por meio remoto.</li> <li class="mb-2 text-justify text-md">10.4. O AFILIADO expressamente autoriza a UTMIFY a utilizar as informações
      para (a) envio de notificações, alertas e comunicações ao Usuário; (b)
      promover o funcionamento das características dos serviços disponíveis e
      planos na plataforma; (c) aperfeiçoar as características e funcionalidades
      dos serviços oferecidos pela Plataforma; (d) gerar estatísticas para
      monitoramento de utilização da Plataforma; (e) realizar pesquisas
      relacionadas a marketing e planejamento de projetos; (f) promover
      resolução de problemas na Plataforma ou Aplicativos, verificação e
      proteção das informações contra erros, fraudes ou qualquer outro crime
      cibernético/eletrônico.</li> <li class="mb-2 text-justify text-md">10.5. Demais questões relacionadas ao uso da plataforma, confidencialidade
      e ao tratamento de dados estão dispostas e poderão ser acessadas nos
      Termos de Uso e Política de Privacidade.</li></ul> <h3 class="text-xl font-bold mb-2">CLÁUSULA DÉCIMA PRIMEIRA - DA POLÍTICA DE PRIVACIDADE</h3> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">11.1. A UTMIFY está comprometida com a proteção da privacidade e dos dados
      pessoais coletados e tratados em suas atividades, incluindo aqueles
      obtidos por meio do Programa de Afiliados. Todos os dados pessoais
      relacionados ao AFILIADO e aos usuários da plataforma são processados de
      acordo com as disposições contidas na Política de Privacidade da UTMIFY.</li> <li class="mb-2 text-justify text-md">11.2. A Política de Privacidade da UTMIFY detalha como os dados pessoais
      são coletados, usados, compartilhados e protegidos, bem como esclarece os
      direitos dos titulares desses dados. O AFILIADO deve compreender e
      concordar com esses termos, reconhecendo que a participação no Programa de
      Afiliados implica a aceitação da referida política.</li> <li class="mb-2 text-justify text-md">11.3. Adicionalmente, a UTMIFY utiliza cookies e tecnologias semelhantes
      conforme descrito em sua Política de Cookies, disponível junto à Política
      de Privacidade. Estas políticas explicam como tais tecnologias são
      empregadas para melhorar a experiência do usuário na plataforma,
      personalizar conteúdo e anúncios, fornecer funcionalidades de redes
      sociais e analisar o tráfego. O AFILIADO deve assegurar-se de estar
      informado e de consentir com o uso dessas tecnologias, conforme descrito
      na política pertinente.</li> <li class="mb-2 text-justify text-md">11.4. A UTMIFY reserva-se o direito de atualizar ou modificar suas
      políticas de privacidade e cookies a qualquer momento. Essas alterações
      serão comunicadas aos AFILIADOS de forma clara e acessível, garantindo que
      sempre estejam informados sobre como as informações são coletadas, usadas
      e protegidas pela empresa.</li> <li class="mb-2 text-justify text-md">11.5. O AFILIADO é responsável por garantir que todas as atividades
      conduzidas em conexão com o Programa de Afiliados estejam em conformidade
      com as políticas da UTMIFY e com a legislação aplicável sobre proteção de
      dados e privacidade. O não cumprimento dessas diretrizes pode resultar na
      imediata rescisão do contrato e outras ações cabíveis conforme necessário
      para proteger os interesses da UTMIFY e de seus usuários.</li></ul> <h3 class="text-xl font-bold mb-2">CLÁUSULA DÉCIMA SEGUNDA – DAS DISPOSIÇÕES FINAIS</h3> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">12.1. Obrigam-se as partes e anuentes por si, seus herdeiros e sucessores,
      em caráter irretratável e irrevogável, sendo vedada a cessão a terceiro
      pelo AFILIADO dos direitos, obrigações e responsabilidades oriundas do
      presente sem a prévia e expressa anuência da outra parte, sob todos os
      termos e condições expressamente previstos neste instrumento de contrato.
      Fica a UTMIFY desde já autorizada a ceder a terceiros os direitos e
      obrigações do presente instrumento de contrato, independentemente de
      prévia autorização da outra parte, estando vinculada tão somente à
      informação da operação.</li> <li class="mb-2 text-justify text-md">12.2. Qualquer comunicação por e-mail ou troca de mensagens em diferentes
      meios ou plataformas, relativas às validações necessárias para o
      cumprimento do objeto deste contrato, será considerada parte integrante
      deste contrato. Em caso de discrepância entre os termos destes documentos
      e o presente contrato, exceto no que diz respeito a detalhes técnicos,
      prevalecerão as disposições aqui contidas.</li> <li class="mb-2 text-justify text-md">12.3. O AFILIADO afirma ser pessoa física ou jurídica com capacidade civil
      plena, maior de 18 anos, aderindo a este contrato com plena ciência de seu
      conteúdo e de todo o serviço ofertado e a licença disponibilizada pela
      UTMIFY, considerando a contratação justa, adequada e equitativa, e
      assegura possuir a devida autoridade e poder para firmar referido
      compromisso.</li> <li class="mb-2 text-justify text-md">12.4. A tolerância ao descumprimento de qualquer obrigação ou condição
      estipulada neste contrato, bem como o não exercício de qualquer direito
      contratual ou legal, não constitui novação ou renúncia de direito, mas tão
      somente mera liberalidade e tolerância das partes, mantendo-se íntegros,
      para exercício a qualquer tempo, os direitos assegurados por este contrato
      e/ou por força de lei.</li> <li class="mb-2 text-justify text-md">12.5. O AFILIADO concorda que todos os atos de comunicação formal de
      natureza judicial entre si deverão ocorrer nos endereços de e-mail
      informados no ato de cadastro na Plataforma, admitindo-se inclusive a
      citação e intimação judicial, sendo presumida a ciência no primeiro dia
      útil posterior ao recebimento, estando obrigada as partes a informar
      imediatamente à outra em caso de alteração do endereço eletrônico de
      comunicações oficiais, sob pena de serem considerados válidos os atos
      realizados. As partes admitem que o acordado constitui negócio jurídico
      processual, conforme permissivo legal do art. 190 do Código de Processo
      Civil.</li> <li class="mb-2 text-justify text-md">12.6. As disposições deste Termo são independentes, exceto se
      expressamente estabelecido no presente de outra forma, caso qualquer das
      disposições ou cláusulas deste contrato seja considerada inválida, nula ou
      inexequível, no todo ou em parte, por uma autoridade governamental
      competente, ou considerada ilegal em razão de alteração na legislação
      vigente ou entendimento jurisdicional diverso, então a invalidade,
      ilegalidade, nulidade ou inexequibilidade deverá afetar somente a
      respectiva cláusula ou disposição, ou parte dela, e não deverá de maneira
      alguma afetar qualquer outra cláusula ou disposição do presente Termo,
      cuja parte remanescente permanecerá inalterada e em pleno vigor conforme
      escrita e acordada originalmente.</li> <li class="mb-2 text-justify text-md">12.7. As partes reconhecem, admitem e concordam que o presente contrato
      estabelece uma relação de natureza comercial entre si, na qual o AFILIADO,
      qualificado como profissional em seu respectivo setor de atuação, adere ao
      presente programa com o objetivo de enriquecimento pessoal e
      desenvolvimento de nova fonte de renda, portanto o AFILIADO possui
      conhecimento técnico sobre o funcionamento e operação de mercado relativa
      a programas de afiliados. Deste modo, esta relação não configura uma
      relação de consumo, visto que o AFILIADO não se posiciona como
      destinatário final do produto ou serviço.</li> <li class="mb-2 text-justify text-md">12.8. O AFILIADO admite ciência e concorda que o presente Termo de Adesão
      ao Programa de Afiliados UTMIFY poderá ser a qualquer tempo modificado
      unilateralmente pela UTMIFY, a seu exclusivo critério, sendo que o aceite
      do AFILIADO em novo Termo de Adesão importa na vinculação dos mesmos, em
      todos os seus termos e condições. A UTMIFY compromete-se a comunicar
      referida alteração via e-mail e/ou plataforma. A partir da data de
      publicação da versão atualizada do presente, a parceria passará a ser
      regulados pelo documento atualizado, podendo o AFILIADO, em caso de
      discordância de referida alteração, solicitar a resolução do contrato, nos
      moldes da cláusula competente, sendo que a continuidade na oferta do link
      de pagamento ao público será considerada como aceite nas novas condições
      contratuais.</li> <li class="mb-2 text-justify text-md">12.9. Este acordo é regido e deverá ser interpretado de acordo com as leis
      vigentes na República Federativa do Brasil, aplicando-se a todos os termos
      e condições aqui estabelecidos.</li> <li class="mb-2 text-justify text-md">12.10. A UTMIFY poderá, a qualquer tempo e independentemente de prévio
      aviso, encerrar o Programa UTMIFY AFILIADO, não sendo devida nenhuma
      indenização ao AFILIADO em decorrência desta decisão, exceto os valores
      decorrentes de negócios efetivamente realizados e ainda não pagos.</li> <li class="mb-2 text-justify text-md">12.11. Fica eleito o foro da comarca de Rio de Janeiro – RJ como o
      competente para dirimir eventuais dúvidas ou conflitos oriundos do
      presente contrato, em detrimento de todos os outros, por mais privilegiado
      que seja ou possa vir a ser.</li></ul>`;
    return {
        c() {
            e = m("div"), e.innerHTML = s
        },
        l(a) {
            e = l(a, "DIV", {
                "data-svelte-h": !0
            }), c(e) !== "svelte-16s9arv" && (e.innerHTML = s)
        },
        m(a, t) {
            n(a, e, t)
        },
        p: o,
        i: o,
        o,
        d(a) {
            a && d(e)
        }
    }
}
class x extends u {
    constructor(e) {
        super(), p(this, e, null, f, r, {})
    }
}
export {
    x as P
};