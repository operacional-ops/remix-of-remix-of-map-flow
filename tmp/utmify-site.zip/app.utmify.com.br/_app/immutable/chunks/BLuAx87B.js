import {
    s as bt,
    H as Et,
    d as st,
    I as At,
    J as yt,
    K as Tt,
    m as F,
    i as Dt,
    c as vt,
    e as wt,
    h as St,
    v as Nt
} from "./DDNnt9XD.js";
import {
    S as Ct,
    i as Ot,
    t as kt,
    a as Mt
} from "./qWASNxYk.js";
import {
    b as I,
    g as Lt
} from "./DwsiLpv2.js";
var gt = {
        exports: {}
    },
    H = {
        exports: {}
    },
    J = {
        exports: {}
    };
/*!
 * Bootstrap data.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
var rt;

function It() {
    return rt || (rt = 1, function(A, m) {
        (function(s, r) {
            A.exports = r()
        })(I, function() {
            const s = new Map;
            return {
                set(h, n, i) {
                    s.has(h) || s.set(h, new Map);
                    const e = s.get(h);
                    if (!e.has(n) && e.size !== 0) {
                        console.error(`Bootstrap doesn't allow more than one instance per element. Bound instance: ${Array.from(e.keys())[0]}.`);
                        return
                    }
                    e.set(n, i)
                },
                get(h, n) {
                    return s.has(h) && s.get(h).get(n) || null
                },
                remove(h, n) {
                    if (!s.has(h)) return;
                    const i = s.get(h);
                    i.delete(n), i.size === 0 && s.delete(h)
                }
            }
        })
    }(J)), J.exports
}
var G = {
        exports: {}
    },
    U = {
        exports: {}
    };
/*!
 * Bootstrap index.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
var ot;

function P() {
    return ot || (ot = 1, function(A, m) {
        (function(s, r) {
            r(m)
        })(I, function(s) {
            const n = "transitionend",
                i = t => (t && window.CSS && window.CSS.escape && (t = t.replace(/#([^\s"#']+)/g, (c, u) => `#${CSS.escape(u)}`)), t),
                e = t => t == null ? `${t}` : Object.prototype.toString.call(t).match(/\s([a-z]+)/i)[1].toLowerCase(),
                o = t => {
                    do t += Math.floor(Math.random() * 1e6); while (document.getElementById(t));
                    return t
                },
                a = t => {
                    if (!t) return 0;
                    let {
                        transitionDuration: c,
                        transitionDelay: u
                    } = window.getComputedStyle(t);
                    const T = Number.parseFloat(c),
                        v = Number.parseFloat(u);
                    return !T && !v ? 0 : (c = c.split(",")[0], u = u.split(",")[0], (Number.parseFloat(c) + Number.parseFloat(u)) * 1e3)
                },
                y = t => {
                    t.dispatchEvent(new Event(n))
                },
                p = t => !t || typeof t != "object" ? !1 : (typeof t.jquery < "u" && (t = t[0]), typeof t.nodeType < "u"),
                l = t => p(t) ? t.jquery ? t[0] : t : typeof t == "string" && t.length > 0 ? document.querySelector(i(t)) : null,
                _ = t => {
                    if (!p(t) || t.getClientRects().length === 0) return !1;
                    const c = getComputedStyle(t).getPropertyValue("visibility") === "visible",
                        u = t.closest("details:not([open])");
                    if (!u) return c;
                    if (u !== t) {
                        const T = t.closest("summary");
                        if (T && T.parentNode !== u || T === null) return !1
                    }
                    return c
                },
                S = t => !t || t.nodeType !== Node.ELEMENT_NODE || t.classList.contains("disabled") ? !0 : typeof t.disabled < "u" ? t.disabled : t.hasAttribute("disabled") && t.getAttribute("disabled") !== "false",
                O = t => {
                    if (!document.documentElement.attachShadow) return null;
                    if (typeof t.getRootNode == "function") {
                        const c = t.getRootNode();
                        return c instanceof ShadowRoot ? c : null
                    }
                    return t instanceof ShadowRoot ? t : t.parentNode ? O(t.parentNode) : null
                },
                k = () => {},
                D = t => {
                    t.offsetHeight
                },
                L = () => window.jQuery && !document.body.hasAttribute("data-bs-no-jquery") ? window.jQuery : null,
                M = [],
                K = t => {
                    document.readyState === "loading" ? (M.length || document.addEventListener("DOMContentLoaded", () => {
                        for (const c of M) c()
                    }), M.push(t)) : t()
                },
                B = () => document.documentElement.dir === "rtl",
                f = t => {
                    K(() => {
                        const c = L();
                        if (c) {
                            const u = t.NAME,
                                T = c.fn[u];
                            c.fn[u] = t.jQueryInterface, c.fn[u].Constructor = t, c.fn[u].noConflict = () => (c.fn[u] = T, t.jQueryInterface)
                        }
                    })
                },
                d = (t, c = [], u = t) => typeof t == "function" ? t.call(...c) : u,
                g = (t, c, u = !0) => {
                    if (!u) {
                        d(t);
                        return
                    }
                    const v = a(c) + 5;
                    let w = !1;
                    const C = ({
                        target: V
                    }) => {
                        V === c && (w = !0, c.removeEventListener(n, C), d(t))
                    };
                    c.addEventListener(n, C), setTimeout(() => {
                        w || y(c)
                    }, v)
                },
                b = (t, c, u, T) => {
                    const v = t.length;
                    let w = t.indexOf(c);
                    return w === -1 ? !u && T ? t[v - 1] : t[0] : (w += u ? 1 : -1, T && (w = (w + v) % v), t[Math.max(0, Math.min(w, v - 1))])
                };
            s.defineJQueryPlugin = f, s.execute = d, s.executeAfterTransition = g, s.findShadowRoot = O, s.getElement = l, s.getNextActiveElement = b, s.getTransitionDurationFromElement = a, s.getUID = o, s.getjQuery = L, s.isDisabled = S, s.isElement = p, s.isRTL = B, s.isVisible = _, s.noop = k, s.onDOMContentLoaded = K, s.parseSelector = i, s.reflow = D, s.toType = e, s.triggerTransitionEnd = y, Object.defineProperty(s, Symbol.toStringTag, {
                value: "Module"
            })
        })
    }(U, U.exports)), U.exports
}
/*!
 * Bootstrap event-handler.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
var at;

function W() {
    return at || (at = 1, function(A, m) {
        (function(s, r) {
            A.exports = r(P())
        })(I, function(s) {
            const r = /[^.]*(?=\..*)\.|.*/,
                h = /\..*/,
                n = /::\d+$/,
                i = {};
            let e = 1;
            const o = {
                    mouseenter: "mouseover",
                    mouseleave: "mouseout"
                },
                a = new Set(["click", "dblclick", "mouseup", "mousedown", "contextmenu", "mousewheel", "DOMMouseScroll", "mouseover", "mouseout", "mousemove", "selectstart", "selectend", "keydown", "keypress", "keyup", "orientationchange", "touchstart", "touchmove", "touchend", "touchcancel", "pointerdown", "pointermove", "pointerup", "pointerleave", "pointercancel", "gesturestart", "gesturechange", "gestureend", "focus", "blur", "change", "reset", "select", "submit", "focusin", "focusout", "load", "unload", "beforeunload", "resize", "move", "DOMContentLoaded", "readystatechange", "error", "abort", "scroll"]);

            function y(f, d) {
                return d && `${d}::${e++}` || f.uidEvent || e++
            }

            function p(f) {
                const d = y(f);
                return f.uidEvent = d, i[d] = i[d] || {}, i[d]
            }

            function l(f, d) {
                return function g(b) {
                    return B(b, {
                        delegateTarget: f
                    }), g.oneOff && K.off(f, b.type, d), d.apply(f, [b])
                }
            }

            function _(f, d, g) {
                return function b(t) {
                    const c = f.querySelectorAll(d);
                    for (let {
                            target: u
                        } = t; u && u !== this; u = u.parentNode)
                        for (const T of c)
                            if (T === u) return B(t, {
                                delegateTarget: u
                            }), b.oneOff && K.off(f, t.type, d, g), g.apply(u, [t])
                }
            }

            function S(f, d, g = null) {
                return Object.values(f).find(b => b.callable === d && b.delegationSelector === g)
            }

            function O(f, d, g) {
                const b = typeof d == "string",
                    t = b ? g : d || g;
                let c = M(f);
                return a.has(c) || (c = f), [b, t, c]
            }

            function k(f, d, g, b, t) {
                if (typeof d != "string" || !f) return;
                let [c, u, T] = O(d, g, b);
                d in o && (u = (j => function(E) {
                    if (!E.relatedTarget || E.relatedTarget !== E.delegateTarget && !E.delegateTarget.contains(E.relatedTarget)) return j.call(this, E)
                })(u));
                const v = p(f),
                    w = v[T] || (v[T] = {}),
                    C = S(w, u, c ? g : null);
                if (C) {
                    C.oneOff = C.oneOff && t;
                    return
                }
                const V = y(u, d.replace(r, "")),
                    R = c ? _(f, g, u) : l(f, u);
                R.delegationSelector = c ? g : null, R.callable = u, R.oneOff = t, R.uidEvent = V, w[V] = R, f.addEventListener(T, R, c)
            }

            function D(f, d, g, b, t) {
                const c = S(d[g], b, t);
                c && (f.removeEventListener(g, c, !!t), delete d[g][c.uidEvent])
            }

            function L(f, d, g, b) {
                const t = d[g] || {};
                for (const [c, u] of Object.entries(t)) c.includes(b) && D(f, d, g, u.callable, u.delegationSelector)
            }

            function M(f) {
                return f = f.replace(h, ""), o[f] || f
            }
            const K = {
                on(f, d, g, b) {
                    k(f, d, g, b, !1)
                },
                one(f, d, g, b) {
                    k(f, d, g, b, !0)
                },
                off(f, d, g, b) {
                    if (typeof d != "string" || !f) return;
                    const [t, c, u] = O(d, g, b), T = u !== d, v = p(f), w = v[u] || {}, C = d.startsWith(".");
                    if (typeof c < "u") {
                        if (!Object.keys(w).length) return;
                        D(f, v, u, c, t ? g : null);
                        return
                    }
                    if (C)
                        for (const V of Object.keys(v)) L(f, v, V, d.slice(1));
                    for (const [V, R] of Object.entries(w)) {
                        const q = V.replace(n, "");
                        (!T || d.includes(q)) && D(f, v, u, R.callable, R.delegationSelector)
                    }
                },
                trigger(f, d, g) {
                    if (typeof d != "string" || !f) return null;
                    const b = s.getjQuery(),
                        t = M(d),
                        c = d !== t;
                    let u = null,
                        T = !0,
                        v = !0,
                        w = !1;
                    c && b && (u = b.Event(d, g), b(f).trigger(u), T = !u.isPropagationStopped(), v = !u.isImmediatePropagationStopped(), w = u.isDefaultPrevented());
                    const C = B(new Event(d, {
                        bubbles: T,
                        cancelable: !0
                    }), g);
                    return w && C.preventDefault(), v && f.dispatchEvent(C), C.defaultPrevented && u && u.preventDefault(), C
                }
            };

            function B(f, d = {}) {
                for (const [g, b] of Object.entries(d)) try {
                    f[g] = b
                } catch {
                    Object.defineProperty(f, g, {
                        configurable: !0,
                        get() {
                            return b
                        }
                    })
                }
                return f
            }
            return K
        })
    }(G)), G.exports
}
var $ = {
        exports: {}
    },
    X = {
        exports: {}
    };
/*!
 * Bootstrap manipulator.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
var lt;

function pt() {
    return lt || (lt = 1, function(A, m) {
        (function(s, r) {
            A.exports = r()
        })(I, function() {
            function s(n) {
                if (n === "true") return !0;
                if (n === "false") return !1;
                if (n === Number(n).toString()) return Number(n);
                if (n === "" || n === "null") return null;
                if (typeof n != "string") return n;
                try {
                    return JSON.parse(decodeURIComponent(n))
                } catch {
                    return n
                }
            }

            function r(n) {
                return n.replace(/[A-Z]/g, i => `-${i.toLowerCase()}`)
            }
            return {
                setDataAttribute(n, i, e) {
                    n.setAttribute(`data-bs-${r(i)}`, e)
                },
                removeDataAttribute(n, i) {
                    n.removeAttribute(`data-bs-${r(i)}`)
                },
                getDataAttributes(n) {
                    if (!n) return {};
                    const i = {},
                        e = Object.keys(n.dataset).filter(o => o.startsWith("bs") && !o.startsWith("bsConfig"));
                    for (const o of e) {
                        let a = o.replace(/^bs/, "");
                        a = a.charAt(0).toLowerCase() + a.slice(1), i[a] = s(n.dataset[o])
                    }
                    return i
                },
                getDataAttribute(n, i) {
                    return s(n.getAttribute(`data-bs-${r(i)}`))
                }
            }
        })
    }(X)), X.exports
}
/*!
 * Bootstrap config.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
var ut;

function it() {
    return ut || (ut = 1, function(A, m) {
        (function(s, r) {
            A.exports = r(pt(), P())
        })(I, function(s, r) {
            class h {
                static get Default() {
                    return {}
                }
                static get DefaultType() {
                    return {}
                }
                static get NAME() {
                    throw new Error('You have to implement the static method "NAME", for each component!')
                }
                _getConfig(i) {
                    return i = this._mergeConfigObj(i), i = this._configAfterMerge(i), this._typeCheckConfig(i), i
                }
                _configAfterMerge(i) {
                    return i
                }
                _mergeConfigObj(i, e) {
                    const o = r.isElement(e) ? s.getDataAttribute(e, "config") : {};
                    return { ...this.constructor.Default,
                        ...typeof o == "object" ? o : {},
                        ...r.isElement(e) ? s.getDataAttributes(e) : {},
                        ...typeof i == "object" ? i : {}
                    }
                }
                _typeCheckConfig(i, e = this.constructor.DefaultType) {
                    for (const [o, a] of Object.entries(e)) {
                        const y = i[o],
                            p = r.isElement(y) ? "element" : r.toType(y);
                        if (!new RegExp(a).test(p)) throw new TypeError(`${this.constructor.NAME.toUpperCase()}: Option "${o}" provided type "${p}" but expected type "${a}".`)
                    }
                }
            }
            return h
        })
    }($)), $.exports
}
/*!
 * Bootstrap base-component.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
var ct;

function Rt() {
    return ct || (ct = 1, function(A, m) {
        (function(s, r) {
            A.exports = r(It(), W(), it(), P())
        })(I, function(s, r, h, n) {
            const i = "5.3.8";
            class e extends h {
                constructor(a, y) {
                    super(), a = n.getElement(a), a && (this._element = a, this._config = this._getConfig(y), s.set(this._element, this.constructor.DATA_KEY, this))
                }
                dispose() {
                    s.remove(this._element, this.constructor.DATA_KEY), r.off(this._element, this.constructor.EVENT_KEY);
                    for (const a of Object.getOwnPropertyNames(this)) this[a] = null
                }
                _queueCallback(a, y, p = !0) {
                    n.executeAfterTransition(a, y, p)
                }
                _getConfig(a) {
                    return a = this._mergeConfigObj(a, this._element), a = this._configAfterMerge(a), this._typeCheckConfig(a), a
                }
                static getInstance(a) {
                    return s.get(n.getElement(a), this.DATA_KEY)
                }
                static getOrCreateInstance(a, y = {}) {
                    return this.getInstance(a) || new this(a, typeof y == "object" ? y : null)
                }
                static get VERSION() {
                    return i
                }
                static get DATA_KEY() {
                    return `bs.${this.NAME}`
                }
                static get EVENT_KEY() {
                    return `.${this.DATA_KEY}`
                }
                static eventName(a) {
                    return `${a}${this.EVENT_KEY}`
                }
            }
            return e
        })
    }(H)), H.exports
}
var Z = {
    exports: {}
};
/*!
 * Bootstrap selector-engine.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
var dt;

function z() {
    return dt || (dt = 1, function(A, m) {
        (function(s, r) {
            A.exports = r(P())
        })(I, function(s) {
            const r = n => {
                    let i = n.getAttribute("data-bs-target");
                    if (!i || i === "#") {
                        let e = n.getAttribute("href");
                        if (!e || !e.includes("#") && !e.startsWith(".")) return null;
                        e.includes("#") && !e.startsWith("#") && (e = `#${e.split("#")[1]}`), i = e && e !== "#" ? e.trim() : null
                    }
                    return i ? i.split(",").map(e => s.parseSelector(e)).join(",") : null
                },
                h = {
                    find(n, i = document.documentElement) {
                        return [].concat(...Element.prototype.querySelectorAll.call(i, n))
                    },
                    findOne(n, i = document.documentElement) {
                        return Element.prototype.querySelector.call(i, n)
                    },
                    children(n, i) {
                        return [].concat(...n.children).filter(e => e.matches(i))
                    },
                    parents(n, i) {
                        const e = [];
                        let o = n.parentNode.closest(i);
                        for (; o;) e.push(o), o = o.parentNode.closest(i);
                        return e
                    },
                    prev(n, i) {
                        let e = n.previousElementSibling;
                        for (; e;) {
                            if (e.matches(i)) return [e];
                            e = e.previousElementSibling
                        }
                        return []
                    },
                    next(n, i) {
                        let e = n.nextElementSibling;
                        for (; e;) {
                            if (e.matches(i)) return [e];
                            e = e.nextElementSibling
                        }
                        return []
                    },
                    focusableChildren(n) {
                        const i = ["a", "button", "input", "textarea", "select", "details", "[tabindex]", '[contenteditable="true"]'].map(e => `${e}:not([tabindex^="-"])`).join(",");
                        return this.find(i, n).filter(e => !s.isDisabled(e) && s.isVisible(e))
                    },
                    getSelectorFromElement(n) {
                        const i = r(n);
                        return i && h.findOne(i) ? i : null
                    },
                    getElementFromSelector(n) {
                        const i = r(n);
                        return i ? h.findOne(i) : null
                    },
                    getMultipleElementsFromSelector(n) {
                        const i = r(n);
                        return i ? h.find(i) : []
                    }
                };
            return h
        })
    }(Z)), Z.exports
}
var tt = {
    exports: {}
};
/*!
 * Bootstrap backdrop.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
var ft;

function xt() {
    return ft || (ft = 1, function(A, m) {
        (function(s, r) {
            A.exports = r(W(), it(), P())
        })(I, function(s, r, h) {
            const n = "backdrop",
                i = "fade",
                e = "show",
                o = `mousedown.bs.${n}`,
                a = {
                    className: "modal-backdrop",
                    clickCallback: null,
                    isAnimated: !1,
                    isVisible: !0,
                    rootElement: "body"
                },
                y = {
                    className: "string",
                    clickCallback: "(function|null)",
                    isAnimated: "boolean",
                    isVisible: "boolean",
                    rootElement: "(element|string)"
                };
            class p extends r {
                constructor(_) {
                    super(), this._config = this._getConfig(_), this._isAppended = !1, this._element = null
                }
                static get Default() {
                    return a
                }
                static get DefaultType() {
                    return y
                }
                static get NAME() {
                    return n
                }
                show(_) {
                    if (!this._config.isVisible) {
                        h.execute(_);
                        return
                    }
                    this._append();
                    const S = this._getElement();
                    this._config.isAnimated && h.reflow(S), S.classList.add(e), this._emulateAnimation(() => {
                        h.execute(_)
                    })
                }
                hide(_) {
                    if (!this._config.isVisible) {
                        h.execute(_);
                        return
                    }
                    this._getElement().classList.remove(e), this._emulateAnimation(() => {
                        this.dispose(), h.execute(_)
                    })
                }
                dispose() {
                    this._isAppended && (s.off(this._element, o), this._element.remove(), this._isAppended = !1)
                }
                _getElement() {
                    if (!this._element) {
                        const _ = document.createElement("div");
                        _.className = this._config.className, this._config.isAnimated && _.classList.add(i), this._element = _
                    }
                    return this._element
                }
                _configAfterMerge(_) {
                    return _.rootElement = h.getElement(_.rootElement), _
                }
                _append() {
                    if (this._isAppended) return;
                    const _ = this._getElement();
                    this._config.rootElement.append(_), s.on(_, o, () => {
                        h.execute(this._config.clickCallback)
                    }), this._isAppended = !0
                }
                _emulateAnimation(_) {
                    h.executeAfterTransition(_, this._getElement(), this._config.isAnimated)
                }
            }
            return p
        })
    }(tt)), tt.exports
}
var Q = {
    exports: {}
};
/*!
 * Bootstrap component-functions.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
var ht;

function Vt() {
    return ht || (ht = 1, function(A, m) {
        (function(s, r) {
            r(m, W(), z(), P())
        })(I, function(s, r, h, n) {
            const i = (e, o = "hide") => {
                const a = `click.dismiss${e.EVENT_KEY}`,
                    y = e.NAME;
                r.on(document, a, `[data-bs-dismiss="${y}"]`, function(p) {
                    if (["A", "AREA"].includes(this.tagName) && p.preventDefault(), n.isDisabled(this)) return;
                    const l = h.getElementFromSelector(this) || this.closest(`.${y}`);
                    e.getOrCreateInstance(l)[o]()
                })
            };
            s.enableDismissTrigger = i, Object.defineProperty(s, Symbol.toStringTag, {
                value: "Module"
            })
        })
    }(Q, Q.exports)), Q.exports
}
var et = {
    exports: {}
};
/*!
 * Bootstrap focustrap.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
var mt;

function qt() {
    return mt || (mt = 1, function(A, m) {
        (function(s, r) {
            A.exports = r(W(), z(), it())
        })(I, function(s, r, h) {
            const n = "focustrap",
                e = ".bs.focustrap",
                o = `focusin${e}`,
                a = `keydown.tab${e}`,
                y = "Tab",
                p = "forward",
                l = "backward",
                _ = {
                    autofocus: !0,
                    trapElement: null
                },
                S = {
                    autofocus: "boolean",
                    trapElement: "element"
                };
            class O extends h {
                constructor(D) {
                    super(), this._config = this._getConfig(D), this._isActive = !1, this._lastTabNavDirection = null
                }
                static get Default() {
                    return _
                }
                static get DefaultType() {
                    return S
                }
                static get NAME() {
                    return n
                }
                activate() {
                    this._isActive || (this._config.autofocus && this._config.trapElement.focus(), s.off(document, e), s.on(document, o, D => this._handleFocusin(D)), s.on(document, a, D => this._handleKeydown(D)), this._isActive = !0)
                }
                deactivate() {
                    this._isActive && (this._isActive = !1, s.off(document, e))
                }
                _handleFocusin(D) {
                    const {
                        trapElement: L
                    } = this._config;
                    if (D.target === document || D.target === L || L.contains(D.target)) return;
                    const M = r.focusableChildren(L);
                    M.length === 0 ? L.focus() : this._lastTabNavDirection === l ? M[M.length - 1].focus() : M[0].focus()
                }
                _handleKeydown(D) {
                    D.key === y && (this._lastTabNavDirection = D.shiftKey ? l : p)
                }
            }
            return O
        })
    }(et)), et.exports
}
var nt = {
    exports: {}
};
/*!
 * Bootstrap scrollbar.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
var _t;

function Ft() {
    return _t || (_t = 1, function(A, m) {
        (function(s, r) {
            A.exports = r(pt(), z(), P())
        })(I, function(s, r, h) {
            const n = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top",
                i = ".sticky-top",
                e = "padding-right",
                o = "margin-right";
            class a {
                constructor() {
                    this._element = document.body
                }
                getWidth() {
                    const p = document.documentElement.clientWidth;
                    return Math.abs(window.innerWidth - p)
                }
                hide() {
                    const p = this.getWidth();
                    this._disableOverFlow(), this._setElementAttributes(this._element, e, l => l + p), this._setElementAttributes(n, e, l => l + p), this._setElementAttributes(i, o, l => l - p)
                }
                reset() {
                    this._resetElementAttributes(this._element, "overflow"), this._resetElementAttributes(this._element, e), this._resetElementAttributes(n, e), this._resetElementAttributes(i, o)
                }
                isOverflowing() {
                    return this.getWidth() > 0
                }
                _disableOverFlow() {
                    this._saveInitialAttribute(this._element, "overflow"), this._element.style.overflow = "hidden"
                }
                _setElementAttributes(p, l, _) {
                    const S = this.getWidth(),
                        O = k => {
                            if (k !== this._element && window.innerWidth > k.clientWidth + S) return;
                            this._saveInitialAttribute(k, l);
                            const D = window.getComputedStyle(k).getPropertyValue(l);
                            k.style.setProperty(l, `${_(Number.parseFloat(D))}px`)
                        };
                    this._applyManipulationCallback(p, O)
                }
                _saveInitialAttribute(p, l) {
                    const _ = p.style.getPropertyValue(l);
                    _ && s.setDataAttribute(p, l, _)
                }
                _resetElementAttributes(p, l) {
                    const _ = S => {
                        const O = s.getDataAttribute(S, l);
                        if (O === null) {
                            S.style.removeProperty(l);
                            return
                        }
                        s.removeDataAttribute(S, l), S.style.setProperty(l, O)
                    };
                    this._applyManipulationCallback(p, _)
                }
                _applyManipulationCallback(p, l) {
                    if (h.isElement(p)) {
                        l(p);
                        return
                    }
                    for (const _ of r.find(p, this._element)) l(_)
                }
            }
            return a
        })
    }(nt)), nt.exports
}
/*!
 * Bootstrap modal.js v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
(function(A, m) {
    (function(s, r) {
        A.exports = r(Rt(), W(), z(), xt(), Vt(), qt(), P(), Ft())
    })(I, function(s, r, h, n, i, e, o, a) {
        const y = "modal",
            l = ".bs.modal",
            _ = ".data-api",
            S = "Escape",
            O = `hide${l}`,
            k = `hidePrevented${l}`,
            D = `hidden${l}`,
            L = `show${l}`,
            M = `shown${l}`,
            K = `resize${l}`,
            B = `click.dismiss${l}`,
            f = `mousedown.dismiss${l}`,
            d = `keydown.dismiss${l}`,
            g = `click${l}${_}`,
            b = "modal-open",
            t = "fade",
            c = "show",
            u = "modal-static",
            T = ".modal.show",
            v = ".modal-dialog",
            w = ".modal-body",
            C = '[data-bs-toggle="modal"]',
            V = {
                backdrop: !0,
                focus: !0,
                keyboard: !0
            },
            R = {
                backdrop: "(boolean|string)",
                focus: "boolean",
                keyboard: "boolean"
            };
        class q extends s {
            constructor(E, N) {
                super(E, N), this._dialog = h.findOne(v, this._element), this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._isShown = !1, this._isTransitioning = !1, this._scrollBar = new a, this._addEventListeners()
            }
            static get Default() {
                return V
            }
            static get DefaultType() {
                return R
            }
            static get NAME() {
                return y
            }
            toggle(E) {
                return this._isShown ? this.hide() : this.show(E)
            }
            show(E) {
                this._isShown || this._isTransitioning || r.trigger(this._element, L, {
                    relatedTarget: E
                }).defaultPrevented || (this._isShown = !0, this._isTransitioning = !0, this._scrollBar.hide(), document.body.classList.add(b), this._adjustDialog(), this._backdrop.show(() => this._showElement(E)))
            }
            hide() {
                !this._isShown || this._isTransitioning || r.trigger(this._element, O).defaultPrevented || (this._isShown = !1, this._isTransitioning = !0, this._focustrap.deactivate(), this._element.classList.remove(c), this._queueCallback(() => this._hideModal(), this._element, this._isAnimated()))
            }
            dispose() {
                r.off(window, l), r.off(this._dialog, l), this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose()
            }
            handleUpdate() {
                this._adjustDialog()
            }
            _initializeBackDrop() {
                return new n({
                    isVisible: !!this._config.backdrop,
                    isAnimated: this._isAnimated()
                })
            }
            _initializeFocusTrap() {
                return new e({
                    trapElement: this._element
                })
            }
            _showElement(E) {
                document.body.contains(this._element) || document.body.append(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.scrollTop = 0;
                const N = h.findOne(w, this._dialog);
                N && (N.scrollTop = 0), o.reflow(this._element), this._element.classList.add(c);
                const x = () => {
                    this._config.focus && this._focustrap.activate(), this._isTransitioning = !1, r.trigger(this._element, M, {
                        relatedTarget: E
                    })
                };
                this._queueCallback(x, this._dialog, this._isAnimated())
            }
            _addEventListeners() {
                r.on(this._element, d, E => {
                    if (E.key === S) {
                        if (this._config.keyboard) {
                            this.hide();
                            return
                        }
                        this._triggerBackdropTransition()
                    }
                }), r.on(window, K, () => {
                    this._isShown && !this._isTransitioning && this._adjustDialog()
                }), r.on(this._element, f, E => {
                    r.one(this._element, B, N => {
                        if (!(this._element !== E.target || this._element !== N.target)) {
                            if (this._config.backdrop === "static") {
                                this._triggerBackdropTransition();
                                return
                            }
                            this._config.backdrop && this.hide()
                        }
                    })
                })
            }
            _hideModal() {
                this._element.style.display = "none", this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._isTransitioning = !1, this._backdrop.hide(() => {
                    document.body.classList.remove(b), this._resetAdjustments(), this._scrollBar.reset(), r.trigger(this._element, D)
                })
            }
            _isAnimated() {
                return this._element.classList.contains(t)
            }
            _triggerBackdropTransition() {
                if (r.trigger(this._element, k).defaultPrevented) return;
                const N = this._element.scrollHeight > document.documentElement.clientHeight,
                    x = this._element.style.overflowY;
                x === "hidden" || this._element.classList.contains(u) || (N || (this._element.style.overflowY = "hidden"), this._element.classList.add(u), this._queueCallback(() => {
                    this._element.classList.remove(u), this._queueCallback(() => {
                        this._element.style.overflowY = x
                    }, this._dialog)
                }, this._dialog), this._element.focus())
            }
            _adjustDialog() {
                const E = this._element.scrollHeight > document.documentElement.clientHeight,
                    N = this._scrollBar.getWidth(),
                    x = N > 0;
                if (x && !E) {
                    const Y = o.isRTL() ? "paddingLeft" : "paddingRight";
                    this._element.style[Y] = `${N}px`
                }
                if (!x && E) {
                    const Y = o.isRTL() ? "paddingRight" : "paddingLeft";
                    this._element.style[Y] = `${N}px`
                }
            }
            _resetAdjustments() {
                this._element.style.paddingLeft = "", this._element.style.paddingRight = ""
            }
            static jQueryInterface(E, N) {
                return this.each(function() {
                    const x = q.getOrCreateInstance(this, E);
                    if (typeof E == "string") {
                        if (typeof x[E] > "u") throw new TypeError(`No method named "${E}"`);
                        x[E](N)
                    }
                })
            }
        }
        return r.on(document, g, C, function(j) {
            const E = h.getElementFromSelector(this);
            ["A", "AREA"].includes(this.tagName) && j.preventDefault(), r.one(E, L, Y => {
                Y.defaultPrevented || r.one(E, D, () => {
                    o.isVisible(this) && this.focus()
                })
            });
            const N = h.findOne(T);
            N && q.getInstance(N).hide(), q.getOrCreateInstance(E).toggle(this)
        }), i.enableDismissTrigger(q), o.defineJQueryPlugin(q), q
    })
})(gt);
var Kt = gt.exports;
const Pt = Lt(Kt);

function Bt(A) {
    let m, s, r, h, n;
    const i = A[7].default,
        e = Et(i, A, A[6], null);
    return {
        c() {
            m = St("div"), e && e.c(), this.h()
        },
        l(o) {
            m = vt(o, "DIV", {
                class: !0,
                id: !0,
                tabindex: !0,
                "aria-hidden": !0,
                "data-bs-keyboard": !0,
                "data-bs-backdrop": !0
            });
            var a = wt(m);
            e && e.l(a), a.forEach(st), this.h()
        },
        h() {
            F(m, "class", s = "modal " + (A[3] ? "fade" : "")), F(m, "id", A[0]), F(m, "tabindex", "-1"), F(m, "aria-hidden", "true"), F(m, "data-bs-keyboard", r = A[2] ? "true" : "false"), F(m, "data-bs-backdrop", h = A[4] ? A[1] ? "true" : "static" : "false")
        },
        m(o, a) {
            Dt(o, m, a), e && e.m(m, null), n = !0
        },
        p(o, [a]) {
            e && e.p && (!n || a & 64) && At(e, i, o, o[6], n ? Tt(i, o[6], a, null) : yt(o[6]), null), (!n || a & 8 && s !== (s = "modal " + (o[3] ? "fade" : ""))) && F(m, "class", s), (!n || a & 1) && F(m, "id", o[0]), (!n || a & 4 && r !== (r = o[2] ? "true" : "false")) && F(m, "data-bs-keyboard", r), (!n || a & 18 && h !== (h = o[4] ? o[1] ? "true" : "static" : "false")) && F(m, "data-bs-backdrop", h)
        },
        i(o) {
            n || (Mt(e, o), n = !0)
        },
        o(o) {
            kt(e, o), n = !1
        },
        d(o) {
            o && st(m), e && e.d(o)
        }
    }
}

function Yt(A, m, s) {
    let {
        $$slots: r = {},
        $$scope: h
    } = m, {
        id: n
    } = m, {
        clickOutsideToClose: i = !0
    } = m, {
        escToClose: e = !0
    } = m, {
        fade: o = !0
    } = m, {
        backdrop: a = !0
    } = m, y;
    const p = l => {
        l === !0 ? y.show() : l === !1 ? y.hide() : y.toggle()
    };
    return Nt(() => {
        y = new Pt(document.getElementById(n) ? ? "", {})
    }), A.$$set = l => {
        "id" in l && s(0, n = l.id), "clickOutsideToClose" in l && s(1, i = l.clickOutsideToClose), "escToClose" in l && s(2, e = l.escToClose), "fade" in l && s(3, o = l.fade), "backdrop" in l && s(4, a = l.backdrop), "$$scope" in l && s(6, h = l.$$scope)
    }, [n, i, e, o, a, p, h, r]
}
class zt extends Ct {
    constructor(m) {
        super(), Ot(this, m, Yt, Bt, bt, {
            id: 0,
            clickOutsideToClose: 1,
            escToClose: 2,
            fade: 3,
            backdrop: 4,
            toggle: 5
        })
    }
    get toggle() {
        return this.$$.ctx[5]
    }
}
export {
    zt as M
};