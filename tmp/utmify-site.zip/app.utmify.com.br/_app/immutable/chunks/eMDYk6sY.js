function F(m, e, t, i, s) {
    let r = (...o) => (console.warn("gridstack.js: Function `" + t + "` is deprecated in " + s + " and has been replaced with `" + i + "`. It will be **removed** in a future release"), e.apply(m, o));
    return r.prototype = e.prototype, r
}
class l {
    static getElements(e, t = document) {
        if (typeof e == "string") {
            const i = "getElementById" in t ? t : void 0;
            if (i && !isNaN(+e[0])) {
                const r = i.getElementById(e);
                return r ? [r] : []
            }
            let s = t.querySelectorAll(e);
            return !s.length && e[0] !== "." && e[0] !== "#" && (s = t.querySelectorAll("." + e), s.length || (s = t.querySelectorAll("#" + e))), Array.from(s)
        }
        return [e]
    }
    static getElement(e, t = document) {
        if (typeof e == "string") {
            const i = "getElementById" in t ? t : void 0;
            if (!e.length) return null;
            if (i && e[0] === "#") return i.getElementById(e.substring(1));
            if (e[0] === "#" || e[0] === "." || e[0] === "[") return t.querySelector(e);
            if (i && !isNaN(+e[0])) return i.getElementById(e);
            let s = t.querySelector(e);
            return i && !s && (s = i.getElementById(e)), s || (s = t.querySelector("." + e)), s
        }
        return e
    }
    static shouldSizeToContent(e, t = !1) {
        return (e == null ? void 0 : e.grid) && (t ? e.sizeToContent === !0 || e.grid.opts.sizeToContent === !0 && e.sizeToContent === void 0 : !!e.sizeToContent || e.grid.opts.sizeToContent && e.sizeToContent !== !1)
    }
    static isIntercepted(e, t) {
        return !(e.y >= t.y + t.h || e.y + e.h <= t.y || e.x + e.w <= t.x || e.x >= t.x + t.w)
    }
    static isTouching(e, t) {
        return l.isIntercepted(e, {
            x: t.x - .5,
            y: t.y - .5,
            w: t.w + 1,
            h: t.h + 1
        })
    }
    static areaIntercept(e, t) {
        let i = e.x > t.x ? e.x : t.x,
            s = e.x + e.w < t.x + t.w ? e.x + e.w : t.x + t.w;
        if (s <= i) return 0;
        let r = e.y > t.y ? e.y : t.y,
            o = e.y + e.h < t.y + t.h ? e.y + e.h : t.y + t.h;
        return o <= r ? 0 : (s - i) * (o - r)
    }
    static area(e) {
        return e.w * e.h
    }
    static sort(e, t = 1) {
        return e.sort((s, r) => {
            let o = t * ((s.y ? ? 1e4) - (r.y ? ? 1e4));
            return o === 0 ? t * ((s.x ? ? 1e4) - (r.x ? ? 1e4)) : o
        })
    }
    static find(e, t) {
        return t ? e.find(i => i.id === t) : void 0
    }
    static createStylesheet(e, t, i) {
        let s = document.createElement("style");
        const r = i == null ? void 0 : i.nonce;
        return r && (s.nonce = r), s.setAttribute("type", "text/css"), s.setAttribute("gs-style-id", e), s.styleSheet ? s.styleSheet.cssText = "" : s.appendChild(document.createTextNode("")), t ? t.insertBefore(s, t.firstChild) : (t = document.getElementsByTagName("head")[0], t.appendChild(s)), s.sheet
    }
    static removeStylesheet(e, t) {
        let s = (t || document).querySelector("STYLE[gs-style-id=" + e + "]");
        s && s.parentNode && s.remove()
    }
    static addCSSRule(e, t, i) {
        typeof e.addRule == "function" ? e.addRule(t, i) : typeof e.insertRule == "function" && e.insertRule(`${t}{${i}}`)
    }
    static toBool(e) {
        return typeof e == "boolean" ? e : typeof e == "string" ? (e = e.toLowerCase(), !(e === "" || e === "no" || e === "false" || e === "0")) : !!e
    }
    static toNumber(e) {
        return e === null || e.length === 0 ? void 0 : Number(e)
    }
    static parseHeight(e) {
        let t, i = "px";
        if (typeof e == "string")
            if (e === "auto" || e === "") t = 0;
            else {
                let s = e.match(/^(-[0-9]+\.[0-9]+|[0-9]*\.[0-9]+|-[0-9]+|[0-9]+)(px|em|rem|vh|vw|%|cm|mm)?$/);
                if (!s) throw new Error(`Invalid height val = ${e}`);
                i = s[2] || "px", t = parseFloat(s[1])
            }
        else t = e;
        return {
            h: t,
            unit: i
        }
    }
    static defaults(e, ...t) {
        return t.forEach(i => {
            for (const s in i) {
                if (!i.hasOwnProperty(s)) return;
                e[s] === null || e[s] === void 0 ? e[s] = i[s] : typeof i[s] == "object" && typeof e[s] == "object" && this.defaults(e[s], i[s])
            }
        }), e
    }
    static same(e, t) {
        if (typeof e != "object") return e == t;
        if (typeof e != typeof t || Object.keys(e).length !== Object.keys(t).length) return !1;
        for (const i in e)
            if (e[i] !== t[i]) return !1;
        return !0
    }
    static copyPos(e, t, i = !1) {
        return t.x !== void 0 && (e.x = t.x), t.y !== void 0 && (e.y = t.y), t.w !== void 0 && (e.w = t.w), t.h !== void 0 && (e.h = t.h), i && (t.minW && (e.minW = t.minW), t.minH && (e.minH = t.minH), t.maxW && (e.maxW = t.maxW), t.maxH && (e.maxH = t.maxH)), e
    }
    static samePos(e, t) {
        return e && t && e.x === t.x && e.y === t.y && (e.w || 1) === (t.w || 1) && (e.h || 1) === (t.h || 1)
    }
    static sanitizeMinMax(e) {
        e.minW || delete e.minW, e.minH || delete e.minH, e.maxW || delete e.maxW, e.maxH || delete e.maxH
    }
    static removeInternalAndSame(e, t) {
        if (!(typeof e != "object" || typeof t != "object"))
            for (let i in e) {
                const s = e[i],
                    r = t[i];
                i[0] === "_" || s === r ? delete e[i] : s && typeof s == "object" && r !== void 0 && (l.removeInternalAndSame(s, r), Object.keys(s).length || delete e[i])
            }
    }
    static removeInternalForSave(e, t = !0) {
        for (let i in e)(i[0] === "_" || e[i] === null || e[i] === void 0) && delete e[i];
        delete e.grid, t && delete e.el, e.autoPosition || delete e.autoPosition, e.noResize || delete e.noResize, e.noMove || delete e.noMove, e.locked || delete e.locked, (e.w === 1 || e.w === e.minW) && delete e.w, (e.h === 1 || e.h === e.minH) && delete e.h
    }
    static throttle(e, t) {
        let i = !1;
        return (...s) => {
            i || (i = !0, setTimeout(() => {
                e(...s), i = !1
            }, t))
        }
    }
    static removePositioningStyles(e) {
        let t = e.style;
        t.position && t.removeProperty("position"), t.left && t.removeProperty("left"), t.top && t.removeProperty("top"), t.width && t.removeProperty("width"), t.height && t.removeProperty("height")
    }
    static getScrollElement(e) {
        if (!e) return document.scrollingElement || document.documentElement;
        const t = getComputedStyle(e);
        return /(auto|scroll)/.test(t.overflow + t.overflowY) ? e : this.getScrollElement(e.parentElement)
    }
    static updateScrollPosition(e, t, i) {
        let s = e.getBoundingClientRect(),
            r = window.innerHeight || document.documentElement.clientHeight;
        if (s.top < 0 || s.bottom > r) {
            let o = s.bottom - r,
                n = s.top,
                a = this.getScrollElement(e);
            if (a !== null) {
                let u = a.scrollTop;
                s.top < 0 && i < 0 ? e.offsetHeight > r ? a.scrollTop += i : a.scrollTop += Math.abs(n) > Math.abs(i) ? i : n : i > 0 && (e.offsetHeight > r ? a.scrollTop += i : a.scrollTop += o > i ? i : o), t.top += a.scrollTop - u
            }
        }
    }
    static updateScrollResize(e, t, i) {
        const s = this.getScrollElement(t),
            r = s.clientHeight,
            o = s === this.getScrollElement() ? 0 : s.getBoundingClientRect().top,
            n = e.clientY - o,
            a = n < i,
            u = n > r - i;
        a ? s.scrollBy({
            behavior: "smooth",
            top: n - i
        }) : u && s.scrollBy({
            behavior: "smooth",
            top: i - (r - n)
        })
    }
    static clone(e) {
        return e == null || typeof e != "object" ? e : e instanceof Array ? [...e] : { ...e
        }
    }
    static cloneDeep(e) {
        const t = ["parentGrid", "el", "grid", "subGrid", "engine"],
            i = l.clone(e);
        for (const s in i) i.hasOwnProperty(s) && typeof i[s] == "object" && s.substring(0, 2) !== "__" && !t.find(r => r === s) && (i[s] = l.cloneDeep(e[s]));
        return i
    }
    static cloneNode(e) {
        const t = e.cloneNode(!0);
        return t.removeAttribute("id"), t
    }
    static appendTo(e, t) {
        let i;
        typeof t == "string" ? i = l.getElement(t) : i = t, i && i.appendChild(e)
    }
    static addElStyles(e, t) {
        if (t instanceof Object)
            for (const i in t) t.hasOwnProperty(i) && (Array.isArray(t[i]) ? t[i].forEach(s => {
                e.style[i] = s
            }) : e.style[i] = t[i])
    }
    static initEvent(e, t) {
        const i = {
                type: t.type
            },
            s = {
                button: 0,
                which: 0,
                buttons: 1,
                bubbles: !0,
                cancelable: !0,
                target: t.target ? t.target : e.target
            };
        return ["altKey", "ctrlKey", "metaKey", "shiftKey"].forEach(r => i[r] = e[r]), ["pageX", "pageY", "clientX", "clientY", "screenX", "screenY"].forEach(r => i[r] = e[r]), { ...i,
            ...s
        }
    }
    static simulateMouseEvent(e, t, i) {
        const s = document.createEvent("MouseEvents");
        s.initMouseEvent(t, !0, !0, window, 1, e.screenX, e.screenY, e.clientX, e.clientY, e.ctrlKey, e.altKey, e.shiftKey, e.metaKey, 0, e.target), (i || e.target).dispatchEvent(s)
    }
    static getValuesFromTransformedElement(e) {
        const t = document.createElement("div");
        l.addElStyles(t, {
            opacity: "0",
            position: "fixed",
            top: "0px",
            left: "0px",
            width: "1px",
            height: "1px",
            zIndex: "-999999"
        }), e.appendChild(t);
        const i = t.getBoundingClientRect();
        return e.removeChild(t), t.remove(), {
            xScale: 1 / i.width,
            yScale: 1 / i.height,
            xOffset: i.left,
            yOffset: i.top
        }
    }
    static swap(e, t, i) {
        if (!e) return;
        const s = e[t];
        e[t] = e[i], e[i] = s
    }
    static canBeRotated(e) {
        var t;
        return !(!e || e.w === e.h || e.locked || e.noResize || (t = e.grid) != null && t.opts.disableResize || e.minW && e.minW === e.maxW || e.minH && e.minH === e.maxH)
    }
}
class C {
    constructor(e = {}) {
        this.addedNodes = [], this.removedNodes = [], this.column = e.column || 12, this.maxRow = e.maxRow, this._float = e.float, this.nodes = e.nodes || [], this.onChange = e.onChange
    }
    batchUpdate(e = !0, t = !0) {
        return !!this.batchMode === e ? this : (this.batchMode = e, e ? (this._prevFloat = this._float, this._float = !0, this.cleanNodes(), this.saveInitial()) : (this._float = this._prevFloat, delete this._prevFloat, t && this._packNodes(), this._notify()), this)
    }
    _useEntireRowArea(e, t) {
        return (!this.float || this.batchMode && !this._prevFloat) && !this._hasLocked && (!e._moving || e._skipDown || t.y <= e.y)
    }
    _fixCollisions(e, t = e, i, s = {}) {
        if (this.sortNodes(-1), i = i || this.collide(e, t), !i) return !1;
        if (e._moving && !s.nested && !this.float && this.swap(e, i)) return !0;
        let r = t;
        !this._loading && this._useEntireRowArea(e, t) && (r = {
            x: 0,
            w: this.column,
            y: t.y,
            h: t.h
        }, i = this.collide(e, r, s.skip));
        let o = !1,
            n = {
                nested: !0,
                pack: !1
            };
        for (; i = i || this.collide(e, r, s.skip);) {
            let a;
            if (i.locked || this._loading || e._moving && !e._skipDown && t.y > e.y && !this.float && (!this.collide(i, { ...i,
                    y: e.y
                }, e) || !this.collide(i, { ...i,
                    y: t.y - i.h
                }, e)) ? (e._skipDown = e._skipDown || t.y > e.y, a = this.moveNode(e, { ...t,
                    y: i.y + i.h,
                    ...n
                }), (i.locked || this._loading) && a ? l.copyPos(t, e) : !i.locked && a && s.pack && (this._packNodes(), t.y = i.y + i.h, l.copyPos(e, t)), o = o || a) : a = this.moveNode(i, { ...i,
                    y: t.y + t.h,
                    skip: e,
                    ...n
                }), !a) return o;
            i = void 0
        }
        return o
    }
    collide(e, t = e, i) {
        const s = e._id,
            r = i == null ? void 0 : i._id;
        return this.nodes.find(o => o._id !== s && o._id !== r && l.isIntercepted(o, t))
    }
    collideAll(e, t = e, i) {
        const s = e._id,
            r = i == null ? void 0 : i._id;
        return this.nodes.filter(o => o._id !== s && o._id !== r && l.isIntercepted(o, t))
    }
    directionCollideCoverage(e, t, i) {
        if (!t.rect || !e._rect) return;
        let s = e._rect,
            r = { ...t.rect
            };
        r.y > s.y ? (r.h += r.y - s.y, r.y = s.y) : r.h += s.y - r.y, r.x > s.x ? (r.w += r.x - s.x, r.x = s.x) : r.w += s.x - r.x;
        let o, n = .5;
        for (let a of i) {
            if (a.locked || !a._rect) break;
            let u = a._rect,
                h = Number.MAX_VALUE,
                d = Number.MAX_VALUE;
            s.y < u.y ? h = (r.y + r.h - u.y) / u.h : s.y + s.h > u.y + u.h && (h = (u.y + u.h - r.y) / u.h), s.x < u.x ? d = (r.x + r.w - u.x) / u.w : s.x + s.w > u.x + u.w && (d = (u.x + u.w - r.x) / u.w);
            let f = Math.min(d, h);
            f > n && (n = f, o = a)
        }
        return t.collide = o, o
    }
    cacheRects(e, t, i, s, r, o) {
        return this.nodes.forEach(n => n._rect = {
            y: n.y * t + i,
            x: n.x * e + o,
            w: n.w * e - o - s,
            h: n.h * t - i - r
        }), this
    }
    swap(e, t) {
        if (!t || t.locked || !e || e.locked) return !1;

        function i() {
            let r = t.x,
                o = t.y;
            return t.x = e.x, t.y = e.y, e.h != t.h ? (e.x = r, e.y = t.y + t.h) : e.w != t.w ? (e.x = t.x + t.w, e.y = o) : (e.x = r, e.y = o), e._dirty = t._dirty = !0, !0
        }
        let s;
        if (e.w === t.w && e.h === t.h && (e.x === t.x || e.y === t.y) && (s = l.isTouching(e, t))) return i();
        if (s !== !1) {
            if (e.w === t.w && e.x === t.x && (s || (s = l.isTouching(e, t)))) {
                if (t.y < e.y) {
                    let r = e;
                    e = t, t = r
                }
                return i()
            }
            if (s !== !1) {
                if (e.h === t.h && e.y === t.y && (s || (s = l.isTouching(e, t)))) {
                    if (t.x < e.x) {
                        let r = e;
                        e = t, t = r
                    }
                    return i()
                }
                return !1
            }
        }
    }
    isAreaEmpty(e, t, i, s) {
        let r = {
            x: e || 0,
            y: t || 0,
            w: i || 1,
            h: s || 1
        };
        return !this.collide(r)
    }
    compact(e = "compact", t = !0) {
        if (this.nodes.length === 0) return this;
        t && this.sortNodes();
        const i = this.batchMode;
        i || this.batchUpdate();
        const s = this._inColumnResize;
        s || (this._inColumnResize = !0);
        let r = this.nodes;
        return this.nodes = [], r.forEach((o, n, a) => {
            let u;
            o.locked || (o.autoPosition = !0, e === "list" && n && (u = a[n - 1])), this.addNode(o, !1, u)
        }), s || delete this._inColumnResize, i || this.batchUpdate(!1), this
    }
    set float(e) {
        this._float !== e && (this._float = e || !1, e || this._packNodes()._notify())
    }
    get float() {
        return this._float || !1
    }
    sortNodes(e = 1) {
        return this.nodes = l.sort(this.nodes, e), this
    }
    _packNodes() {
        return this.batchMode ? this : (this.sortNodes(), this.float ? this.nodes.forEach(e => {
            if (e._updating || e._orig === void 0 || e.y === e._orig.y) return;
            let t = e.y;
            for (; t > e._orig.y;) --t, this.collide(e, {
                x: e.x,
                y: t,
                w: e.w,
                h: e.h
            }) || (e._dirty = !0, e.y = t)
        }) : this.nodes.forEach((e, t) => {
            if (!e.locked)
                for (; e.y > 0;) {
                    let i = t === 0 ? 0 : e.y - 1;
                    if (!(t === 0 || !this.collide(e, {
                            x: e.x,
                            y: i,
                            w: e.w,
                            h: e.h
                        }))) break;
                    e._dirty = e.y !== i, e.y = i
                }
        }), this)
    }
    prepareNode(e, t) {
        e._id = e._id ? ? C._idSeq++, (e.x === void 0 || e.y === void 0 || e.x === null || e.y === null) && (e.autoPosition = !0);
        let i = {
            x: 0,
            y: 0,
            w: 1,
            h: 1
        };
        return l.defaults(e, i), e.autoPosition || delete e.autoPosition, e.noResize || delete e.noResize, e.noMove || delete e.noMove, l.sanitizeMinMax(e), typeof e.x == "string" && (e.x = Number(e.x)), typeof e.y == "string" && (e.y = Number(e.y)), typeof e.w == "string" && (e.w = Number(e.w)), typeof e.h == "string" && (e.h = Number(e.h)), isNaN(e.x) && (e.x = i.x, e.autoPosition = !0), isNaN(e.y) && (e.y = i.y, e.autoPosition = !0), isNaN(e.w) && (e.w = i.w), isNaN(e.h) && (e.h = i.h), this.nodeBoundFix(e, t), e
    }
    nodeBoundFix(e, t) {
        let i = e._orig || l.copyPos({}, e);
        if (e.maxW && (e.w = Math.min(e.w, e.maxW)), e.maxH && (e.h = Math.min(e.h, e.maxH)), e.minW && e.minW <= this.column && (e.w = Math.max(e.w, e.minW)), e.minH && (e.h = Math.max(e.h, e.minH)), (e.x || 0) + (e.w || 1) > this.column && this.column < 12 && !this._inColumnResize && e._id && this.findCacheLayout(e, 12) === -1) {
            let r = { ...e
            };
            r.autoPosition || r.x === void 0 ? (delete r.x, delete r.y) : r.x = Math.min(11, r.x), r.w = Math.min(12, r.w || 1), this.cacheOneLayout(r, 12)
        }
        return e.w > this.column ? e.w = this.column : e.w < 1 && (e.w = 1), this.maxRow && e.h > this.maxRow ? e.h = this.maxRow : e.h < 1 && (e.h = 1), e.x < 0 && (e.x = 0), e.y < 0 && (e.y = 0), e.x + e.w > this.column && (t ? e.w = this.column - e.x : e.x = this.column - e.w), this.maxRow && e.y + e.h > this.maxRow && (t ? e.h = this.maxRow - e.y : e.y = this.maxRow - e.h), l.samePos(e, i) || (e._dirty = !0), this
    }
    getDirtyNodes(e) {
        return e ? this.nodes.filter(t => t._dirty && !l.samePos(t, t._orig)) : this.nodes.filter(t => t._dirty)
    }
    _notify(e) {
        if (this.batchMode || !this.onChange) return this;
        let t = (e || []).concat(this.getDirtyNodes());
        return this.onChange(t), this
    }
    cleanNodes() {
        return this.batchMode ? this : (this.nodes.forEach(e => {
            delete e._dirty, delete e._lastTried
        }), this)
    }
    saveInitial() {
        return this.nodes.forEach(e => {
            e._orig = l.copyPos({}, e), delete e._dirty
        }), this._hasLocked = this.nodes.some(e => e.locked), this
    }
    restoreInitial() {
        return this.nodes.forEach(e => {
            l.samePos(e, e._orig) || (l.copyPos(e, e._orig), e._dirty = !0)
        }), this._notify(), this
    }
    findEmptyPosition(e, t = this.nodes, i = this.column, s) {
        let r = s ? s.y * i + (s.x + s.w) : 0,
            o = !1;
        for (let n = r; !o; ++n) {
            let a = n % i,
                u = Math.floor(n / i);
            if (a + e.w > i) continue;
            let h = {
                x: a,
                y: u,
                w: e.w,
                h: e.h
            };
            t.find(d => l.isIntercepted(h, d)) || ((e.x !== a || e.y !== u) && (e._dirty = !0), e.x = a, e.y = u, delete e.autoPosition, o = !0)
        }
        return o
    }
    addNode(e, t = !1, i) {
        let s = this.nodes.find(o => o._id === e._id);
        if (s) return s;
        this._inColumnResize ? this.nodeBoundFix(e) : this.prepareNode(e), delete e._temporaryRemoved, delete e._removeDOM;
        let r;
        return e.autoPosition && this.findEmptyPosition(e, this.nodes, this.column, i) && (delete e.autoPosition, r = !0), this.nodes.push(e), t && this.addedNodes.push(e), r || this._fixCollisions(e), this.batchMode || this._packNodes()._notify(), e
    }
    removeNode(e, t = !0, i = !1) {
        return this.nodes.find(s => s._id === e._id) ? (i && this.removedNodes.push(e), t && (e._removeDOM = !0), this.nodes = this.nodes.filter(s => s._id !== e._id), e._isAboutToRemove || this._packNodes(), this._notify([e]), this) : this
    }
    removeAll(e = !0, t = !0) {
        if (delete this._layouts, !this.nodes.length) return this;
        e && this.nodes.forEach(s => s._removeDOM = !0);
        const i = this.nodes;
        return this.removedNodes = t ? i : [], this.nodes = [], this._notify(i)
    }
    moveNodeCheck(e, t) {
        if (!this.changedPosConstrain(e, t)) return !1;
        if (t.pack = !0, !this.maxRow) return this.moveNode(e, t);
        let i, s = new C({
            column: this.column,
            float: this.float,
            nodes: this.nodes.map(o => o._id === e._id ? (i = { ...o
            }, i) : { ...o
            })
        });
        if (!i) return !1;
        let r = s.moveNode(i, t) && s.getRow() <= Math.max(this.getRow(), this.maxRow);
        if (!r && !t.resizing && t.collide) {
            let o = t.collide.el.gridstackNode;
            if (this.swap(e, o)) return this._notify(), !0
        }
        return r ? (s.nodes.filter(o => o._dirty).forEach(o => {
            let n = this.nodes.find(a => a._id === o._id);
            n && (l.copyPos(n, o), n._dirty = !0)
        }), this._notify(), !0) : !1
    }
    willItFit(e) {
        if (delete e._willFitPos, !this.maxRow) return !0;
        let t = new C({
                column: this.column,
                float: this.float,
                nodes: this.nodes.map(s => ({ ...s
                }))
            }),
            i = { ...e
            };
        return this.cleanupNode(i), delete i.el, delete i._id, delete i.content, delete i.grid, t.addNode(i), t.getRow() <= this.maxRow ? (e._willFitPos = l.copyPos({}, i), !0) : !1
    }
    changedPosConstrain(e, t) {
        return t.w = t.w || e.w, t.h = t.h || e.h, e.x !== t.x || e.y !== t.y ? !0 : (e.maxW && (t.w = Math.min(t.w, e.maxW)), e.maxH && (t.h = Math.min(t.h, e.maxH)), e.minW && (t.w = Math.max(t.w, e.minW)), e.minH && (t.h = Math.max(t.h, e.minH)), e.w !== t.w || e.h !== t.h)
    }
    moveNode(e, t) {
        var u, h;
        if (!e || !t) return !1;
        let i;
        t.pack === void 0 && !this.batchMode && (i = t.pack = !0), typeof t.x != "number" && (t.x = e.x), typeof t.y != "number" && (t.y = e.y), typeof t.w != "number" && (t.w = e.w), typeof t.h != "number" && (t.h = e.h);
        let s = e.w !== t.w || e.h !== t.h,
            r = l.copyPos({}, e, !0);
        if (l.copyPos(r, t), this.nodeBoundFix(r, s), l.copyPos(t, r), !t.forceCollide && l.samePos(e, t)) return !1;
        let o = l.copyPos({}, e),
            n = this.collideAll(e, r, t.skip),
            a = !0;
        if (n.length) {
            let d = e._moving && !t.nested,
                f = d ? this.directionCollideCoverage(e, t, n) : n[0];
            if (d && f && ((h = (u = e.grid) == null ? void 0 : u.opts) != null && h.subGridDynamic) && !e.grid._isTemp) {
                let p = l.areaIntercept(t.rect, f._rect),
                    v = l.area(t.rect),
                    y = l.area(f._rect);
                p / (v < y ? v : y) > .8 && (f.grid.makeSubGrid(f.el, void 0, e), f = void 0)
            }
            f ? a = !this._fixCollisions(e, r, f, t) : (a = !1, i && delete t.pack)
        }
        return a && (e._dirty = !0, l.copyPos(e, r)), t.pack && this._packNodes()._notify(), !l.samePos(e, o)
    }
    getRow() {
        return this.nodes.reduce((e, t) => Math.max(e, t.y + t.h), 0)
    }
    beginUpdate(e) {
        return e._updating || (e._updating = !0, delete e._skipDown, this.batchMode || this.saveInitial()), this
    }
    endUpdate() {
        let e = this.nodes.find(t => t._updating);
        return e && (delete e._updating, delete e._skipDown), this
    }
    save(e = !0, t) {
        var o;
        let i = (o = this._layouts) == null ? void 0 : o.length,
            s = i && this.column !== i - 1 ? this._layouts[i - 1] : null,
            r = [];
        return this.sortNodes(), this.nodes.forEach(n => {
            let a = s == null ? void 0 : s.find(h => h._id === n._id),
                u = { ...n,
                    ...a || {}
                };
            l.removeInternalForSave(u, !e), t && t(n, u), r.push(u)
        }), r
    }
    layoutsNodesChange(e) {
        return !this._layouts || this._inColumnResize ? this : (this._layouts.forEach((t, i) => {
            if (!t || i === this.column) return this;
            if (i < this.column) this._layouts[i] = void 0;
            else {
                let s = i / this.column;
                e.forEach(r => {
                    if (!r._orig) return;
                    let o = t.find(n => n._id === r._id);
                    o && (o.y >= 0 && r.y !== r._orig.y && (o.y += r.y - r._orig.y), r.x !== r._orig.x && (o.x = Math.round(r.x * s)), r.w !== r._orig.w && (o.w = Math.round(r.w * s)))
                })
            }
        }), this)
    }
    columnChanged(e, t, i = "moveScale") {
        var n;
        if (!this.nodes.length || !t || e === t) return this;
        if (i === "none") return this;
        const s = i === "compact" || i === "list";
        s && this.sortNodes(1), t < e && this.cacheLayout(this.nodes, e), this.batchUpdate();
        let r = [],
            o = s ? this.nodes : l.sort(this.nodes, -1);
        if (t > e && this._layouts) {
            const a = this._layouts[t] || [];
            let u = this._layouts.length - 1;
            !a.length && e !== u && ((n = this._layouts[u]) != null && n.length) && (e = u, this._layouts[u].forEach(h => {
                let d = o.find(f => f._id === h._id);
                d && (!s && !h.autoPosition && (d.x = h.x ? ? d.x, d.y = h.y ? ? d.y), d.w = h.w ? ? d.w, (h.x == null || h.y === void 0) && (d.autoPosition = !0))
            })), a.forEach(h => {
                let d = o.findIndex(f => f._id === h._id);
                if (d !== -1) {
                    const f = o[d];
                    if (s) {
                        f.w = h.w;
                        return
                    }(h.autoPosition || isNaN(h.x) || isNaN(h.y)) && this.findEmptyPosition(h, r), h.autoPosition || (f.x = h.x ? ? f.x, f.y = h.y ? ? f.y, f.w = h.w ? ? f.w, r.push(f)), o.splice(d, 1)
                }
            })
        }
        if (s) this.compact(i, !1);
        else {
            if (o.length)
                if (typeof i == "function") i(t, e, r, o);
                else {
                    let a = s ? 1 : t / e,
                        u = i === "move" || i === "moveScale",
                        h = i === "scale" || i === "moveScale";
                    o.forEach(d => {
                        d.x = t === 1 ? 0 : u ? Math.round(d.x * a) : Math.min(d.x, t - 1), d.w = t === 1 || e === 1 ? 1 : h ? Math.round(d.w * a) || 1 : Math.min(d.w, t), r.push(d)
                    }), o = []
                }
            r = l.sort(r, -1), this._inColumnResize = !0, this.nodes = [], r.forEach(a => {
                this.addNode(a, !1), delete a._orig
            })
        }
        return this.nodes.forEach(a => delete a._orig), this.batchUpdate(!1, !s), delete this._inColumnResize, this
    }
    cacheLayout(e, t, i = !1) {
        let s = [];
        return e.forEach((r, o) => {
            if (r._id === void 0) {
                const n = r.id ? this.nodes.find(a => a.id === r.id) : void 0;
                r._id = (n == null ? void 0 : n._id) ? ? C._idSeq++
            }
            s[o] = {
                x: r.x,
                y: r.y,
                w: r.w,
                _id: r._id
            }
        }), this._layouts = i ? [] : this._layouts || [], this._layouts[t] = s, this
    }
    cacheOneLayout(e, t) {
        e._id = e._id ? ? C._idSeq++;
        let i = {
            x: e.x,
            y: e.y,
            w: e.w,
            _id: e._id
        };
        (e.autoPosition || e.x === void 0) && (delete i.x, delete i.y, e.autoPosition && (i.autoPosition = !0)), this._layouts = this._layouts || [], this._layouts[t] = this._layouts[t] || [];
        let s = this.findCacheLayout(e, t);
        return s === -1 ? this._layouts[t].push(i) : this._layouts[t][s] = i, this
    }
    findCacheLayout(e, t) {
        var i, s;
        return ((s = (i = this._layouts) == null ? void 0 : i[t]) == null ? void 0 : s.findIndex(r => r._id === e._id)) ? ? -1
    }
    removeNodeFromLayoutCache(e) {
        if (this._layouts)
            for (let t = 0; t < this._layouts.length; t++) {
                let i = this.findCacheLayout(e, t);
                i !== -1 && this._layouts[t].splice(i, 1)
            }
    }
    cleanupNode(e) {
        for (let t in e) t[0] === "_" && t !== "_id" && delete e[t];
        return this
    }
}
C._idSeq = 0;
const b = {
        alwaysShowResizeHandle: "mobile",
        animate: !0,
        auto: !0,
        cellHeight: "auto",
        cellHeightThrottle: 100,
        cellHeightUnit: "px",
        column: 12,
        draggable: {
            handle: ".grid-stack-item-content",
            appendTo: "body",
            scroll: !0
        },
        handle: ".grid-stack-item-content",
        itemClass: "grid-stack-item",
        margin: 10,
        marginUnit: "px",
        maxRow: 0,
        minRow: 0,
        placeholderClass: "grid-stack-placeholder",
        placeholderText: "",
        removableOptions: {
            accept: "grid-stack-item",
            decline: "grid-stack-non-removable"
        },
        resizable: {
            handles: "se"
        },
        rtl: "auto"
    },
    $ = {
        handle: ".grid-stack-item-content",
        appendTo: "body"
    };
class g {}
const x = typeof window < "u" && typeof document < "u" && ("ontouchstart" in document || "ontouchstart" in window || window.DocumentTouch && document instanceof window.DocumentTouch || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0);
class R {}

function S(m, e) {
    if (m.touches.length > 1) return;
    m.cancelable && m.preventDefault();
    const t = m.changedTouches[0],
        i = document.createEvent("MouseEvents");
    i.initMouseEvent(e, !0, !0, window, 1, t.screenX, t.screenY, t.clientX, t.clientY, !1, !1, !1, !1, 0, null), m.target.dispatchEvent(i)
}

function U(m, e) {
    m.cancelable && m.preventDefault();
    const t = document.createEvent("MouseEvents");
    t.initMouseEvent(e, !0, !0, window, 1, m.screenX, m.screenY, m.clientX, m.clientY, !1, !1, !1, !1, 0, null), m.target.dispatchEvent(t)
}

function N(m) {
    R.touchHandled || (R.touchHandled = !0, S(m, "mousedown"))
}

function M(m) {
    R.touchHandled && S(m, "mousemove")
}

function T(m) {
    if (!R.touchHandled) return;
    R.pointerLeaveTimeout && (window.clearTimeout(R.pointerLeaveTimeout), delete R.pointerLeaveTimeout);
    const e = !!g.dragElement;
    S(m, "mouseup"), e || S(m, "click"), R.touchHandled = !1
}

function L(m) {
    m.pointerType !== "mouse" && m.target.releasePointerCapture(m.pointerId)
}

function I(m) {
    g.dragElement && m.pointerType !== "mouse" && U(m, "mouseenter")
}

function W(m) {
    g.dragElement && m.pointerType !== "mouse" && (R.pointerLeaveTimeout = window.setTimeout(() => {
        delete R.pointerLeaveTimeout, U(m, "mouseleave")
    }, 10))
}
class k {
    constructor(e, t, i) {
        this.host = e, this.dir = t, this.option = i, this.moving = !1, this._mouseDown = this._mouseDown.bind(this), this._mouseMove = this._mouseMove.bind(this), this._mouseUp = this._mouseUp.bind(this), this._keyEvent = this._keyEvent.bind(this), this._init()
    }
    _init() {
        const e = this.el = document.createElement("div");
        return e.classList.add("ui-resizable-handle"), e.classList.add(`${k.prefix}${this.dir}`), e.style.zIndex = "100", e.style.userSelect = "none", this.host.appendChild(this.el), this.el.addEventListener("mousedown", this._mouseDown), x && (this.el.addEventListener("touchstart", N), this.el.addEventListener("pointerdown", L)), this
    }
    destroy() {
        return this.moving && this._mouseUp(this.mouseDownEvent), this.el.removeEventListener("mousedown", this._mouseDown), x && (this.el.removeEventListener("touchstart", N), this.el.removeEventListener("pointerdown", L)), this.host.removeChild(this.el), delete this.el, delete this.host, this
    }
    _mouseDown(e) {
        this.mouseDownEvent = e, document.addEventListener("mousemove", this._mouseMove, {
            capture: !0,
            passive: !0
        }), document.addEventListener("mouseup", this._mouseUp, !0), x && (this.el.addEventListener("touchmove", M), this.el.addEventListener("touchend", T)), e.stopPropagation(), e.preventDefault()
    }
    _mouseMove(e) {
        let t = this.mouseDownEvent;
        this.moving ? this._triggerEvent("move", e) : Math.abs(e.x - t.x) + Math.abs(e.y - t.y) > 2 && (this.moving = !0, this._triggerEvent("start", this.mouseDownEvent), this._triggerEvent("move", e), document.addEventListener("keydown", this._keyEvent)), e.stopPropagation()
    }
    _mouseUp(e) {
        this.moving && (this._triggerEvent("stop", e), document.removeEventListener("keydown", this._keyEvent)), document.removeEventListener("mousemove", this._mouseMove, !0), document.removeEventListener("mouseup", this._mouseUp, !0), x && (this.el.removeEventListener("touchmove", M), this.el.removeEventListener("touchend", T)), delete this.moving, delete this.mouseDownEvent, e.stopPropagation(), e.preventDefault()
    }
    _keyEvent(e) {
        var t, i;
        e.key === "Escape" && ((i = (t = this.host.gridstackNode) == null ? void 0 : t.grid) == null || i.engine.restoreInitial(), this._mouseUp(this.mouseDownEvent))
    }
    _triggerEvent(e, t) {
        return this.option[e] && this.option[e](t), this
    }
}
k.prefix = "ui-resizable-";
class P {
    constructor() {
        this._eventRegister = {}
    }
    get disabled() {
        return this._disabled
    }
    on(e, t) {
        this._eventRegister[e] = t
    }
    off(e) {
        delete this._eventRegister[e]
    }
    enable() {
        this._disabled = !1
    }
    disable() {
        this._disabled = !0
    }
    destroy() {
        delete this._eventRegister
    }
    triggerEvent(e, t) {
        if (!this.disabled && this._eventRegister && this._eventRegister[e]) return this._eventRegister[e](t)
    }
}
class H extends P {
    constructor(e, t = {}) {
        super(), this.el = e, this.option = t, this.rectScale = {
            x: 1,
            y: 1
        }, this._ui = () => {
            const s = this.el.parentElement.getBoundingClientRect(),
                r = {
                    width: this.originalRect.width,
                    height: this.originalRect.height + this.scrolled,
                    left: this.originalRect.left,
                    top: this.originalRect.top - this.scrolled
                },
                o = this.temporalRect || r;
            return {
                position: {
                    left: (o.left - s.left) * this.rectScale.x,
                    top: (o.top - s.top) * this.rectScale.y
                },
                size: {
                    width: o.width * this.rectScale.x,
                    height: o.height * this.rectScale.y
                }
            }
        }, this._mouseOver = this._mouseOver.bind(this), this._mouseOut = this._mouseOut.bind(this), this.enable(), this._setupAutoHide(this.option.autoHide), this._setupHandlers()
    }
    on(e, t) {
        super.on(e, t)
    }
    off(e) {
        super.off(e)
    }
    enable() {
        super.enable(), this.el.classList.remove("ui-resizable-disabled"), this._setupAutoHide(this.option.autoHide)
    }
    disable() {
        super.disable(), this.el.classList.add("ui-resizable-disabled"), this._setupAutoHide(!1)
    }
    destroy() {
        this._removeHandlers(), this._setupAutoHide(!1), delete this.el, super.destroy()
    }
    updateOption(e) {
        let t = e.handles && e.handles !== this.option.handles,
            i = e.autoHide && e.autoHide !== this.option.autoHide;
        return Object.keys(e).forEach(s => this.option[s] = e[s]), t && (this._removeHandlers(), this._setupHandlers()), i && this._setupAutoHide(this.option.autoHide), this
    }
    _setupAutoHide(e) {
        return e ? (this.el.classList.add("ui-resizable-autohide"), this.el.addEventListener("mouseover", this._mouseOver), this.el.addEventListener("mouseout", this._mouseOut)) : (this.el.classList.remove("ui-resizable-autohide"), this.el.removeEventListener("mouseover", this._mouseOver), this.el.removeEventListener("mouseout", this._mouseOut), g.overResizeElement === this && delete g.overResizeElement), this
    }
    _mouseOver(e) {
        g.overResizeElement || g.dragElement || (g.overResizeElement = this, this.el.classList.remove("ui-resizable-autohide"))
    }
    _mouseOut(e) {
        g.overResizeElement === this && (delete g.overResizeElement, this.el.classList.add("ui-resizable-autohide"))
    }
    _setupHandlers() {
        return this.handlers = this.option.handles.split(",").map(e => e.trim()).map(e => new k(this.el, e, {
            start: t => {
                this._resizeStart(t)
            },
            stop: t => {
                this._resizeStop(t)
            },
            move: t => {
                this._resizing(t, e)
            }
        })), this
    }
    _resizeStart(e) {
        this.sizeToContent = l.shouldSizeToContent(this.el.gridstackNode, !0), this.originalRect = this.el.getBoundingClientRect(), this.scrollEl = l.getScrollElement(this.el), this.scrollY = this.scrollEl.scrollTop, this.scrolled = 0, this.startEvent = e, this._setupHelper(), this._applyChange();
        const t = l.initEvent(e, {
            type: "resizestart",
            target: this.el
        });
        return this.option.start && this.option.start(t, this._ui()), this.el.classList.add("ui-resizable-resizing"), this.triggerEvent("resizestart", t), this
    }
    _resizing(e, t) {
        this.scrolled = this.scrollEl.scrollTop - this.scrollY, this.temporalRect = this._getChange(e, t), this._applyChange();
        const i = l.initEvent(e, {
            type: "resize",
            target: this.el
        });
        return this.option.resize && this.option.resize(i, this._ui()), this.triggerEvent("resize", i), this
    }
    _resizeStop(e) {
        const t = l.initEvent(e, {
            type: "resizestop",
            target: this.el
        });
        return this.option.stop && this.option.stop(t), this.el.classList.remove("ui-resizable-resizing"), this.triggerEvent("resizestop", t), this._cleanHelper(), delete this.startEvent, delete this.originalRect, delete this.temporalRect, delete this.scrollY, delete this.scrolled, this
    }
    _setupHelper() {
        this.elOriginStyleVal = H._originStyleProp.map(i => this.el.style[i]), this.parentOriginStylePosition = this.el.parentElement.style.position;
        const e = this.el.parentElement,
            t = l.getValuesFromTransformedElement(e);
        return this.rectScale = {
            x: t.xScale,
            y: t.yScale
        }, getComputedStyle(this.el.parentElement).position.match(/static/) && (this.el.parentElement.style.position = "relative"), this.el.style.position = "absolute", this.el.style.opacity = "0.8", this
    }
    _cleanHelper() {
        return H._originStyleProp.forEach((e, t) => {
            this.el.style[e] = this.elOriginStyleVal[t] || null
        }), this.el.parentElement.style.position = this.parentOriginStylePosition || null, this
    }
    _getChange(e, t) {
        const i = this.startEvent,
            s = {
                width: this.originalRect.width,
                height: this.originalRect.height + this.scrolled,
                left: this.originalRect.left,
                top: this.originalRect.top - this.scrolled
            },
            r = e.clientX - i.clientX,
            o = this.sizeToContent ? 0 : e.clientY - i.clientY;
        let n, a;
        t.indexOf("e") > -1 ? s.width += r : t.indexOf("w") > -1 && (s.width -= r, s.left += r, n = !0), t.indexOf("s") > -1 ? s.height += o : t.indexOf("n") > -1 && (s.height -= o, s.top += o, a = !0);
        const u = this._constrainSize(s.width, s.height, n, a);
        return Math.round(s.width) !== Math.round(u.width) && (t.indexOf("w") > -1 && (s.left += s.width - u.width), s.width = u.width), Math.round(s.height) !== Math.round(u.height) && (t.indexOf("n") > -1 && (s.top += s.height - u.height), s.height = u.height), s
    }
    _constrainSize(e, t, i, s) {
        const r = this.option,
            o = (i ? r.maxWidthMoveLeft : r.maxWidth) || Number.MAX_SAFE_INTEGER,
            n = r.minWidth / this.rectScale.x || e,
            a = (s ? r.maxHeightMoveUp : r.maxHeight) || Number.MAX_SAFE_INTEGER,
            u = r.minHeight / this.rectScale.y || t,
            h = Math.min(o, Math.max(n, e)),
            d = Math.min(a, Math.max(u, t));
        return {
            width: h,
            height: d
        }
    }
    _applyChange() {
        let e = {
            left: 0,
            top: 0,
            width: 0,
            height: 0
        };
        if (this.el.style.position === "absolute") {
            const t = this.el.parentElement,
                {
                    left: i,
                    top: s
                } = t.getBoundingClientRect();
            e = {
                left: i,
                top: s,
                width: 0,
                height: 0
            }
        }
        return this.temporalRect ? (Object.keys(this.temporalRect).forEach(t => {
            const i = this.temporalRect[t],
                s = t === "width" || t === "left" ? this.rectScale.x : t === "height" || t === "top" ? this.rectScale.y : 1;
            this.el.style[t] = (i - e[t]) * s + "px"
        }), this) : this
    }
    _removeHandlers() {
        return this.handlers.forEach(e => e.destroy()), delete this.handlers, this
    }
}
H._originStyleProp = ["width", "height", "position", "left", "top", "opacity", "zIndex"];
const Y = 'input,textarea,button,select,option,[contenteditable="true"],.ui-resizable-handle';
class D extends P {
    constructor(e, t = {}) {
        super(), this.el = e, this.option = t, this.dragTransform = {
            xScale: 1,
            yScale: 1,
            xOffset: 0,
            yOffset: 0
        };
        const i = t.handle.substring(1),
            s = e.gridstackNode;
        this.dragEls = e.classList.contains(i) ? [e] : s != null && s.subGrid ? [e.querySelector(t.handle) || e] : Array.from(e.querySelectorAll(t.handle)), this.dragEls.length === 0 && (this.dragEls = [e]), this._mouseDown = this._mouseDown.bind(this), this._mouseMove = this._mouseMove.bind(this), this._mouseUp = this._mouseUp.bind(this), this._keyEvent = this._keyEvent.bind(this), this.enable()
    }
    on(e, t) {
        super.on(e, t)
    }
    off(e) {
        super.off(e)
    }
    enable() {
        this.disabled !== !1 && (super.enable(), this.dragEls.forEach(e => {
            e.addEventListener("mousedown", this._mouseDown), x && (e.addEventListener("touchstart", N), e.addEventListener("pointerdown", L))
        }), this.el.classList.remove("ui-draggable-disabled"))
    }
    disable(e = !1) {
        this.disabled !== !0 && (super.disable(), this.dragEls.forEach(t => {
            t.removeEventListener("mousedown", this._mouseDown), x && (t.removeEventListener("touchstart", N), t.removeEventListener("pointerdown", L))
        }), e || this.el.classList.add("ui-draggable-disabled"))
    }
    destroy() {
        this.dragTimeout && window.clearTimeout(this.dragTimeout), delete this.dragTimeout, this.mouseDownEvent && this._mouseUp(this.mouseDownEvent), this.disable(!0), delete this.el, delete this.helper, delete this.option, super.destroy()
    }
    updateOption(e) {
        return Object.keys(e).forEach(t => this.option[t] = e[t]), this
    }
    _mouseDown(e) {
        if (!g.mouseHandled) return e.button !== 0 || !this.dragEls.find(t => t === e.target) && e.target.closest(Y) || this.option.cancel && e.target.closest(this.option.cancel) || (this.mouseDownEvent = e, delete this.dragging, delete g.dragElement, delete g.dropElement, document.addEventListener("mousemove", this._mouseMove, {
            capture: !0,
            passive: !0
        }), document.addEventListener("mouseup", this._mouseUp, !0), x && (e.target.addEventListener("touchmove", M), e.target.addEventListener("touchend", T)), e.preventDefault(), document.activeElement && document.activeElement.blur(), g.mouseHandled = !0), !0
    }
    _callDrag(e) {
        if (!this.dragging) return;
        const t = l.initEvent(e, {
            target: this.el,
            type: "drag"
        });
        this.option.drag && this.option.drag(t, this.ui()), this.triggerEvent("drag", t)
    }
    _mouseMove(e) {
        var i;
        let t = this.mouseDownEvent;
        if (this.lastDrag = e, this.dragging)
            if (this._dragFollow(e), g.pauseDrag) {
                const s = Number.isInteger(g.pauseDrag) ? g.pauseDrag : 100;
                this.dragTimeout && window.clearTimeout(this.dragTimeout), this.dragTimeout = window.setTimeout(() => this._callDrag(e), s)
            } else this._callDrag(e);
        else if (Math.abs(e.x - t.x) + Math.abs(e.y - t.y) > 3) {
            this.dragging = !0, g.dragElement = this;
            let s = (i = this.el.gridstackNode) == null ? void 0 : i.grid;
            s ? g.dropElement = s.el.ddElement.ddDroppable : delete g.dropElement, this.helper = this._createHelper(e), this._setupHelperContainmentStyle(), this.dragTransform = l.getValuesFromTransformedElement(this.helperContainment), this.dragOffset = this._getDragOffset(e, this.el, this.helperContainment), this._setupHelperStyle(e);
            const r = l.initEvent(e, {
                target: this.el,
                type: "dragstart"
            });
            this.option.start && this.option.start(r, this.ui()), this.triggerEvent("dragstart", r), document.addEventListener("keydown", this._keyEvent)
        }
        return !0
    }
    _mouseUp(e) {
        var t, i;
        if (document.removeEventListener("mousemove", this._mouseMove, !0), document.removeEventListener("mouseup", this._mouseUp, !0), x && (e.target.removeEventListener("touchmove", M, !0), e.target.removeEventListener("touchend", T, !0)), this.dragging) {
            delete this.dragging, (t = this.el.gridstackNode) == null || delete t._origRotate, document.removeEventListener("keydown", this._keyEvent), ((i = g.dropElement) == null ? void 0 : i.el) === this.el.parentElement && delete g.dropElement, this.helperContainment.style.position = this.parentOriginStylePosition || null, this.helper === this.el ? this._removeHelperStyle() : this.helper.remove();
            const s = l.initEvent(e, {
                target: this.el,
                type: "dragstop"
            });
            this.option.stop && this.option.stop(s), this.triggerEvent("dragstop", s), g.dropElement && g.dropElement.drop(e)
        }
        delete this.helper, delete this.mouseDownEvent, delete g.dragElement, delete g.dropElement, delete g.mouseHandled, e.preventDefault()
    }
    _keyEvent(e) {
        const t = this.el.gridstackNode;
        if (!(t != null && t.grid)) return;
        const i = t.grid;
        if (e.key === "Escape") t._origRotate && (t._orig = t._origRotate, delete t._origRotate), i.engine.restoreInitial(), this._mouseUp(this.mouseDownEvent);
        else if (e.key === "r" || e.key === "R") {
            if (!l.canBeRotated(t)) return;
            t._origRotate = t._origRotate || { ...t._orig
            }, delete t._moving, i.setAnimation(!1).rotate(t.el, {
                top: -this.dragOffset.offsetTop,
                left: -this.dragOffset.offsetLeft
            }).setAnimation(), t._moving = !0, this.dragOffset = this._getDragOffset(this.lastDrag, t.el, this.helperContainment), this.helper.style.width = this.dragOffset.width + "px", this.helper.style.height = this.dragOffset.height + "px", l.swap(t._orig, "w", "h"), delete t._rect, this._mouseMove(this.lastDrag)
        }
    }
    _createHelper(e) {
        let t = this.el;
        return typeof this.option.helper == "function" ? t = this.option.helper(e) : this.option.helper === "clone" && (t = l.cloneNode(this.el)), document.body.contains(t) || l.appendTo(t, this.option.appendTo === "parent" ? this.el.parentElement : this.option.appendTo), t === this.el && (this.dragElementOriginStyle = D.originStyleProp.map(i => this.el.style[i])), t
    }
    _setupHelperStyle(e) {
        this.helper.classList.add("ui-draggable-dragging");
        const t = this.helper.style;
        return t.pointerEvents = "none", t.width = this.dragOffset.width + "px", t.height = this.dragOffset.height + "px", t.willChange = "left, top", t.position = "fixed", this._dragFollow(e), t.transition = "none", setTimeout(() => {
            this.helper && (t.transition = null)
        }, 0), this
    }
    _removeHelperStyle() {
        var t;
        this.helper.classList.remove("ui-draggable-dragging");
        let e = (t = this.helper) == null ? void 0 : t.gridstackNode;
        if (!(e != null && e._isAboutToRemove) && this.dragElementOriginStyle) {
            let i = this.helper,
                s = this.dragElementOriginStyle.transition || null;
            i.style.transition = this.dragElementOriginStyle.transition = "none", D.originStyleProp.forEach(r => i.style[r] = this.dragElementOriginStyle[r] || null), setTimeout(() => i.style.transition = s, 50)
        }
        return delete this.dragElementOriginStyle, this
    }
    _dragFollow(e) {
        let t = {
            left: 0,
            top: 0
        };
        const i = this.helper.style,
            s = this.dragOffset;
        i.left = (e.clientX + s.offsetLeft - t.left) * this.dragTransform.xScale + "px", i.top = (e.clientY + s.offsetTop - t.top) * this.dragTransform.yScale + "px"
    }
    _setupHelperContainmentStyle() {
        return this.helperContainment = this.helper.parentElement, this.helper.style.position !== "fixed" && (this.parentOriginStylePosition = this.helperContainment.style.position, getComputedStyle(this.helperContainment).position.match(/static/) && (this.helperContainment.style.position = "relative")), this
    }
    _getDragOffset(e, t, i) {
        let s = 0,
            r = 0;
        i && (s = this.dragTransform.xOffset, r = this.dragTransform.yOffset);
        const o = t.getBoundingClientRect();
        return {
            left: o.left,
            top: o.top,
            offsetLeft: -e.clientX + o.left - s,
            offsetTop: -e.clientY + o.top - r,
            width: o.width * this.dragTransform.xScale,
            height: o.height * this.dragTransform.yScale
        }
    }
    ui() {
        const t = this.el.parentElement.getBoundingClientRect(),
            i = this.helper.getBoundingClientRect();
        return {
            position: {
                top: (i.top - t.top) * this.dragTransform.yScale,
                left: (i.left - t.left) * this.dragTransform.xScale
            }
        }
    }
}
D.originStyleProp = ["transition", "pointerEvents", "position", "left", "top", "minWidth", "willChange"];
class X extends P {
    constructor(e, t = {}) {
        super(), this.el = e, this.option = t, this._mouseEnter = this._mouseEnter.bind(this), this._mouseLeave = this._mouseLeave.bind(this), this.enable(), this._setupAccept()
    }
    on(e, t) {
        super.on(e, t)
    }
    off(e) {
        super.off(e)
    }
    enable() {
        this.disabled !== !1 && (super.enable(), this.el.classList.add("ui-droppable"), this.el.classList.remove("ui-droppable-disabled"), this.el.addEventListener("mouseenter", this._mouseEnter), this.el.addEventListener("mouseleave", this._mouseLeave), x && (this.el.addEventListener("pointerenter", I), this.el.addEventListener("pointerleave", W)))
    }
    disable(e = !1) {
        this.disabled !== !0 && (super.disable(), this.el.classList.remove("ui-droppable"), e || this.el.classList.add("ui-droppable-disabled"), this.el.removeEventListener("mouseenter", this._mouseEnter), this.el.removeEventListener("mouseleave", this._mouseLeave), x && (this.el.removeEventListener("pointerenter", I), this.el.removeEventListener("pointerleave", W)))
    }
    destroy() {
        this.disable(!0), this.el.classList.remove("ui-droppable"), this.el.classList.remove("ui-droppable-disabled"), super.destroy()
    }
    updateOption(e) {
        return Object.keys(e).forEach(t => this.option[t] = e[t]), this._setupAccept(), this
    }
    _mouseEnter(e) {
        if (!g.dragElement || !this._canDrop(g.dragElement.el)) return;
        e.preventDefault(), e.stopPropagation(), g.dropElement && g.dropElement !== this && g.dropElement._mouseLeave(e, !0), g.dropElement = this;
        const t = l.initEvent(e, {
            target: this.el,
            type: "dropover"
        });
        this.option.over && this.option.over(t, this._ui(g.dragElement)), this.triggerEvent("dropover", t), this.el.classList.add("ui-droppable-over")
    }
    _mouseLeave(e, t = !1) {
        var s;
        if (!g.dragElement || g.dropElement !== this) return;
        e.preventDefault(), e.stopPropagation();
        const i = l.initEvent(e, {
            target: this.el,
            type: "dropout"
        });
        if (this.option.out && this.option.out(i, this._ui(g.dragElement)), this.triggerEvent("dropout", i), g.dropElement === this && (delete g.dropElement, !t)) {
            let r, o = this.el.parentElement;
            for (; !r && o;) r = (s = o.ddElement) == null ? void 0 : s.ddDroppable, o = o.parentElement;
            r && r._mouseEnter(e)
        }
    }
    drop(e) {
        e.preventDefault();
        const t = l.initEvent(e, {
            target: this.el,
            type: "drop"
        });
        this.option.drop && this.option.drop(t, this._ui(g.dragElement)), this.triggerEvent("drop", t)
    }
    _canDrop(e) {
        return e && (!this.accept || this.accept(e))
    }
    _setupAccept() {
        return this.option.accept ? (typeof this.option.accept == "string" ? this.accept = e => e.classList.contains(this.option.accept) || e.matches(this.option.accept) : this.accept = this.option.accept, this) : this
    }
    _ui(e) {
        return {
            draggable: e.el,
            ...e.ui()
        }
    }
}
class B {
    static init(e) {
        return e.ddElement || (e.ddElement = new B(e)), e.ddElement
    }
    constructor(e) {
        this.el = e
    }
    on(e, t) {
        return this.ddDraggable && ["drag", "dragstart", "dragstop"].indexOf(e) > -1 ? this.ddDraggable.on(e, t) : this.ddDroppable && ["drop", "dropover", "dropout"].indexOf(e) > -1 ? this.ddDroppable.on(e, t) : this.ddResizable && ["resizestart", "resize", "resizestop"].indexOf(e) > -1 && this.ddResizable.on(e, t), this
    }
    off(e) {
        return this.ddDraggable && ["drag", "dragstart", "dragstop"].indexOf(e) > -1 ? this.ddDraggable.off(e) : this.ddDroppable && ["drop", "dropover", "dropout"].indexOf(e) > -1 ? this.ddDroppable.off(e) : this.ddResizable && ["resizestart", "resize", "resizestop"].indexOf(e) > -1 && this.ddResizable.off(e), this
    }
    setupDraggable(e) {
        return this.ddDraggable ? this.ddDraggable.updateOption(e) : this.ddDraggable = new D(this.el, e), this
    }
    cleanDraggable() {
        return this.ddDraggable && (this.ddDraggable.destroy(), delete this.ddDraggable), this
    }
    setupResizable(e) {
        return this.ddResizable ? this.ddResizable.updateOption(e) : this.ddResizable = new H(this.el, e), this
    }
    cleanResizable() {
        return this.ddResizable && (this.ddResizable.destroy(), delete this.ddResizable), this
    }
    setupDroppable(e) {
        return this.ddDroppable ? this.ddDroppable.updateOption(e) : this.ddDroppable = new X(this.el, e), this
    }
    cleanDroppable() {
        return this.ddDroppable && (this.ddDroppable.destroy(), delete this.ddDroppable), this
    }
}
class q {
    resizable(e, t, i, s) {
        return this._getDDElements(e).forEach(r => {
            if (t === "disable" || t === "enable") r.ddResizable && r.ddResizable[t]();
            else if (t === "destroy") r.ddResizable && r.cleanResizable();
            else if (t === "option") r.setupResizable({
                [i]: s
            });
            else {
                const n = r.el.gridstackNode.grid;
                let a = r.el.getAttribute("gs-resize-handles") || n.opts.resizable.handles || "e,s,se";
                a === "all" && (a = "n,e,s,w,se,sw,ne,nw");
                const u = !n.opts.alwaysShowResizeHandle;
                r.setupResizable({ ...n.opts.resizable,
                    handles: a,
                    autoHide: u,
                    start: t.start,
                    stop: t.stop,
                    resize: t.resize
                })
            }
        }), this
    }
    draggable(e, t, i, s) {
        return this._getDDElements(e).forEach(r => {
            if (t === "disable" || t === "enable") r.ddDraggable && r.ddDraggable[t]();
            else if (t === "destroy") r.ddDraggable && r.cleanDraggable();
            else if (t === "option") r.setupDraggable({
                [i]: s
            });
            else {
                const o = r.el.gridstackNode.grid;
                r.setupDraggable({ ...o.opts.draggable,
                    start: t.start,
                    stop: t.stop,
                    drag: t.drag
                })
            }
        }), this
    }
    dragIn(e, t) {
        return this._getDDElements(e).forEach(i => i.setupDraggable(t)), this
    }
    droppable(e, t, i, s) {
        return typeof t.accept == "function" && !t._accept && (t._accept = t.accept, t.accept = r => t._accept(r)), this._getDDElements(e).forEach(r => {
            t === "disable" || t === "enable" ? r.ddDroppable && r.ddDroppable[t]() : t === "destroy" ? r.ddDroppable && r.cleanDroppable() : t === "option" ? r.setupDroppable({
                [i]: s
            }) : r.setupDroppable(t)
        }), this
    }
    isDroppable(e) {
        return !!(e && e.ddElement && e.ddElement.ddDroppable && !e.ddElement.ddDroppable.disabled)
    }
    isDraggable(e) {
        return !!(e && e.ddElement && e.ddElement.ddDraggable && !e.ddElement.ddDraggable.disabled)
    }
    isResizable(e) {
        return !!(e && e.ddElement && e.ddElement.ddResizable && !e.ddElement.ddResizable.disabled)
    }
    on(e, t, i) {
        return this._getDDElements(e).forEach(s => s.on(t, r => {
            i(r, g.dragElement ? g.dragElement.el : r.target, g.dragElement ? g.dragElement.helper : null)
        })), this
    }
    off(e, t) {
        return this._getDDElements(e).forEach(i => i.off(t)), this
    }
    _getDDElements(e, t = !0) {
        let i = l.getElements(e);
        if (!i.length) return [];
        let s = i.map(r => r.ddElement || (t ? B.init(r) : null));
        return t || s.filter(r => r), s
    }
}
/*!
 * GridStack 10.3.1
 * https://gridstackjs.com/
 *
 * Copyright (c) 2021-2022 Alain Dumesny
 * see root license https://github.com/gridstack/gridstack.js/tree/master/LICENSE
 */
const E = new q;
class c {
    static init(e = {}, t = ".grid-stack") {
        if (typeof document > "u") return null;
        let i = c.getGridElement(t);
        return i ? (i.gridstack || (i.gridstack = new c(i, l.cloneDeep(e))), i.gridstack) : (console.error(typeof t == "string" ? 'GridStack.initAll() no grid was found with selector "' + t + `" - element missing or wrong selector ?
Note: ".grid-stack" is required for proper CSS styling and drag/drop, and is the default selector.` : "GridStack.init() no grid element was passed."), null)
    }
    static initAll(e = {}, t = ".grid-stack") {
        let i = [];
        return typeof document > "u" || (c.getGridElements(t).forEach(s => {
            s.gridstack || (s.gridstack = new c(s, l.cloneDeep(e))), i.push(s.gridstack)
        }), i.length === 0 && console.error('GridStack.initAll() no grid was found with selector "' + t + `" - element missing or wrong selector ?
Note: ".grid-stack" is required for proper CSS styling and drag/drop, and is the default selector.`)), i
    }
    static addGrid(e, t = {}) {
        if (!e) return null;
        let i = e;
        if (i.gridstack) {
            const o = i.gridstack;
            return t && (o.opts = { ...o.opts,
                ...t
            }), t.children !== void 0 && o.load(t.children), o
        }
        if (!e.classList.contains("grid-stack") || c.addRemoveCB)
            if (c.addRemoveCB) i = c.addRemoveCB(e, t, !0, !0);
            else {
                let o = document.implementation.createHTMLDocument("");
                o.body.innerHTML = `<div class="grid-stack ${t.class||""}"></div>`, i = o.body.children[0], e.appendChild(i)
            }
        return c.init(t, i)
    }
    static registerEngine(e) {
        c.engineClass = e
    }
    get placeholder() {
        if (!this._placeholder) {
            let e = document.createElement("div");
            e.className = "placeholder-content", this.opts.placeholderText && (e.innerHTML = this.opts.placeholderText), this._placeholder = document.createElement("div"), this._placeholder.classList.add(this.opts.placeholderClass, b.itemClass, this.opts.itemClass), this.placeholder.appendChild(e)
        }
        return this._placeholder
    }
    constructor(e, t = {}) {
        var d, f, p, v;
        this.el = e, this.opts = t, this._gsEventHandler = {}, this._extraDragRow = 0, this.dragTransform = {
            xScale: 1,
            yScale: 1,
            xOffset: 0,
            yOffset: 0
        }, e.gridstack = this, t = t || {}, e.classList.contains("grid-stack") || this.el.classList.add("grid-stack"), t.row && (t.minRow = t.maxRow = t.row, delete t.row);
        let i = l.toNumber(e.getAttribute("gs-row"));
        t.column === "auto" && delete t.column, t.alwaysShowResizeHandle !== void 0 && (t._alwaysShowResizeHandle = t.alwaysShowResizeHandle);
        let s = (d = t.columnOpts) == null ? void 0 : d.breakpoints;
        const r = t;
        if (r.oneColumnModeDomSort && (delete r.oneColumnModeDomSort, console.log("warning: Gridstack oneColumnModeDomSort no longer supported. Use GridStackOptions.columnOpts instead.")), r.oneColumnSize || r.disableOneColumnMode === !1) {
            const y = r.oneColumnSize || 768;
            delete r.oneColumnSize, delete r.disableOneColumnMode, t.columnOpts = t.columnOpts || {}, s = t.columnOpts.breakpoints = t.columnOpts.breakpoints || [];
            let _ = s.find(w => w.c === 1);
            _ ? _.w = y : (_ = {
                c: 1,
                w: y
            }, s.push(_, {
                c: 12,
                w: y + 1
            }))
        }
        const o = t.columnOpts;
        o && (!o.columnWidth && !((f = o.breakpoints) != null && f.length) ? (delete t.columnOpts, s = void 0) : o.columnMax = o.columnMax || 12), (s == null ? void 0 : s.length) > 1 && s.sort((y, _) => (_.w || 0) - (y.w || 0));
        let n = { ...l.cloneDeep(b),
            column: l.toNumber(e.getAttribute("gs-column")) || b.column,
            minRow: i || l.toNumber(e.getAttribute("gs-min-row")) || b.minRow,
            maxRow: i || l.toNumber(e.getAttribute("gs-max-row")) || b.maxRow,
            staticGrid: l.toBool(e.getAttribute("gs-static")) || b.staticGrid,
            draggable: {
                handle: (t.handleClass ? "." + t.handleClass : t.handle ? t.handle : "") || b.draggable.handle
            },
            removableOptions: {
                accept: t.itemClass || b.removableOptions.accept,
                decline: b.removableOptions.decline
            }
        };
        e.getAttribute("gs-animate") && (n.animate = l.toBool(e.getAttribute("gs-animate"))), t = l.defaults(t, n), this._initMargin(), this.checkDynamicColumn(), this.el.classList.add("gs-" + t.column), t.rtl === "auto" && (t.rtl = e.style.direction === "rtl"), t.rtl && this.el.classList.add("grid-stack-rtl");
        const a = (p = this.el.parentElement) == null ? void 0 : p.parentElement;
        let u = a != null && a.classList.contains(b.itemClass) ? a.gridstackNode : void 0;
        u && (u.subGrid = this, this.parentGridItem = u, this.el.classList.add("grid-stack-nested"), u.el.classList.add("grid-stack-sub-grid")), this._isAutoCellHeight = t.cellHeight === "auto", this._isAutoCellHeight || t.cellHeight === "initial" ? this.cellHeight(void 0, !1) : (typeof t.cellHeight == "number" && t.cellHeightUnit && t.cellHeightUnit !== b.cellHeightUnit && (t.cellHeight = t.cellHeight + t.cellHeightUnit, delete t.cellHeightUnit), this.cellHeight(t.cellHeight, !1)), t.alwaysShowResizeHandle === "mobile" && (t.alwaysShowResizeHandle = x), this._styleSheetClass = "gs-id-" + C._idSeq++, this.el.classList.add(this._styleSheetClass), this._setStaticClass();
        let h = t.engineClass || c.engineClass || C;
        if (this.engine = new h({
                column: this.getColumn(),
                float: t.float,
                maxRow: t.maxRow,
                onChange: y => {
                    let _ = 0;
                    this.engine.nodes.forEach(w => {
                        _ = Math.max(_, w.y + w.h)
                    }), y.forEach(w => {
                        let z = w.el;
                        z && (w._removeDOM ? (z && z.remove(), delete w._removeDOM) : this._writePosAttr(z, w))
                    }), this._updateStyles(!1, _)
                }
            }), this._updateStyles(!1, 0), t.auto && (this.batchUpdate(), this.engine._loading = !0, this.getGridItems().forEach(y => this._prepareElement(y)), delete this.engine._loading, this.batchUpdate(!1)), t.children) {
            const y = t.children;
            delete t.children, y.length && this.load(y)
        }
        this.setAnimation(), t.subGridDynamic && !g.pauseDrag && (g.pauseDrag = !0), ((v = t.draggable) == null ? void 0 : v.pause) !== void 0 && (g.pauseDrag = t.draggable.pause), this._setupRemoveDrop(), this._setupAcceptWidget(), this._updateResizeEvent()
    }
    addWidget(e, t) {
        function i(n) {
            return n.el !== void 0 || n.x !== void 0 || n.y !== void 0 || n.w !== void 0 || n.h !== void 0 || n.content !== void 0
        }
        let s, r;
        if (typeof e == "string") {
            let n = document.implementation.createHTMLDocument("");
            n.body.innerHTML = e, s = n.body.children[0]
        } else if (arguments.length === 0 || arguments.length === 1 && i(e))
            if (r = t = e, r != null && r.el) s = r.el;
            else if (c.addRemoveCB) s = c.addRemoveCB(this.el, t, !0, !1);
        else {
            let n = (t == null ? void 0 : t.content) || "",
                a = document.implementation.createHTMLDocument("");
            a.body.innerHTML = `<div class="grid-stack-item ${this.opts.itemClass||""}"><div class="grid-stack-item-content">${n}</div></div>`, s = a.body.children[0]
        } else s = e;
        if (!s) return;
        if (r = s.gridstackNode, r && s.parentElement === this.el && this.engine.nodes.find(n => n._id === r._id)) return s;
        let o = this._readAttr(s);
        return t = l.cloneDeep(t) || {}, l.defaults(t, o), r = this.engine.prepareNode(t), this._writeAttr(s, t), this.el.appendChild(s), this.makeWidget(s, t), s
    }
    makeSubGrid(e, t, i, s = !0) {
        var p, v, y;
        let r = e.gridstackNode;
        if (r || (r = this.makeWidget(e).gridstackNode), (p = r.subGrid) != null && p.el) return r.subGrid;
        let o, n = this;
        for (; n && !o;) o = (v = n.opts) == null ? void 0 : v.subGridOpts, n = (y = n.parentGridItem) == null ? void 0 : y.grid;
        t = l.cloneDeep({ ...o || {},
            children: void 0,
            ...t || r.subGridOpts || {}
        }), r.subGridOpts = t;
        let a;
        t.column === "auto" && (a = !0, t.column = Math.max(r.w || 1, (i == null ? void 0 : i.w) || 1), delete t.columnOpts);
        let u = r.el.querySelector(".grid-stack-item-content"),
            h, d;
        if (s) {
            if (this._removeDD(r.el), d = { ...r,
                    x: 0,
                    y: 0
                }, l.removeInternalForSave(d), delete d.subGridOpts, r.content && (d.content = r.content, delete r.content), c.addRemoveCB) h = c.addRemoveCB(this.el, d, !0, !1);
            else {
                let _ = document.implementation.createHTMLDocument("");
                _.body.innerHTML = '<div class="grid-stack-item"></div>', h = _.body.children[0], h.appendChild(u), _.body.innerHTML = '<div class="grid-stack-item-content"></div>', u = _.body.children[0], r.el.appendChild(u)
            }
            this._prepareDragDropByNode(r)
        }
        if (i) {
            let _ = a ? t.column : r.w,
                w = r.h + i.h,
                z = r.el.style;
            z.transition = "none", this.update(r.el, {
                w: _,
                h: w
            }), setTimeout(() => z.transition = null)
        }
        let f = r.subGrid = c.addGrid(u, t);
        return i != null && i._moving && (f._isTemp = !0), a && (f._autoColumn = !0), s && f.addWidget(h, d), i && (i._moving ? window.setTimeout(() => l.simulateMouseEvent(i._event, "mouseenter", f.el), 0) : f.addWidget(r.el, r)), f
    }
    removeAsSubGrid(e) {
        var i;
        let t = (i = this.parentGridItem) == null ? void 0 : i.grid;
        t && (t.batchUpdate(), t.removeWidget(this.parentGridItem.el, !0, !0), this.engine.nodes.forEach(s => {
            s.x += this.parentGridItem.x, s.y += this.parentGridItem.y, t.addWidget(s.el, s)
        }), t.batchUpdate(!1), this.parentGridItem && delete this.parentGridItem.subGrid, delete this.parentGridItem, e && window.setTimeout(() => l.simulateMouseEvent(e._event, "mouseenter", t.el), 0))
    }
    save(e = !0, t = !1, i = c.saveCB) {
        let s = this.engine.save(e, i);
        if (s.forEach(r => {
                var o;
                if (e && r.el && !r.subGrid && !i) {
                    let n = r.el.querySelector(".grid-stack-item-content");
                    r.content = n ? n.innerHTML : void 0, r.content || delete r.content
                } else if (!e && !i && delete r.content, (o = r.subGrid) != null && o.el) {
                    const n = r.subGrid.save(e, t, i);
                    r.subGridOpts = t ? n : {
                        children: n
                    }, delete r.subGrid
                }
                delete r.el
            }), t) {
            let r = l.cloneDeep(this.opts);
            r.marginBottom === r.marginTop && r.marginRight === r.marginLeft && r.marginTop === r.marginRight && (r.margin = r.marginTop, delete r.marginTop, delete r.marginRight, delete r.marginBottom, delete r.marginLeft), r.rtl === (this.el.style.direction === "rtl") && (r.rtl = "auto"), this._isAutoCellHeight && (r.cellHeight = "auto"), this._autoColumn && (r.column = "auto");
            const o = r._alwaysShowResizeHandle;
            return delete r._alwaysShowResizeHandle, o !== void 0 ? r.alwaysShowResizeHandle = o : delete r.alwaysShowResizeHandle, l.removeInternalAndSame(r, b), r.children = s, r
        }
        return s
    }
    load(e, t = c.addRemoveCB || !0) {
        var u;
        e = l.cloneDeep(e);
        const i = this.getColumn();
        e.forEach(h => {
            h.w = h.w || 1, h.h = h.h || 1
        }), e = l.sort(e);
        let s = 0;
        e.forEach(h => {
            s = Math.max(s, (h.x || 0) + h.w)
        }), s > i && (this._ignoreLayoutsNodeChange = !0, this.engine.cacheLayout(e, s, !0));
        const r = c.addRemoveCB;
        typeof t == "function" && (c.addRemoveCB = t);
        let o = [];
        this.batchUpdate();
        const n = !this.engine.nodes.length;
        n && this.setAnimation(!1), !n && t && [...this.engine.nodes].forEach(d => {
            if (!d.id) return;
            l.find(e, d.id) || (c.addRemoveCB && c.addRemoveCB(this.el, d, !1, !1), o.push(d), this.removeWidget(d.el, !0, !1))
        }), this.engine._loading = !0;
        let a = [];
        return this.engine.nodes = this.engine.nodes.filter(h => l.find(e, h.id) ? (a.push(h), !1) : !0), e.forEach(h => {
            var f;
            let d = l.find(a, h.id);
            if (d) {
                if (l.shouldSizeToContent(d) && (h.h = d.h), this.engine.nodeBoundFix(h), (h.autoPosition || h.x === void 0 || h.y === void 0) && (h.w = h.w || d.w, h.h = h.h || d.h, this.engine.findEmptyPosition(h)), this.engine.nodes.push(d), l.samePos(d, h) && this.moveNode(d, { ...h,
                        forceCollide: !0
                    }), this.update(d.el, h), (f = h.subGridOpts) != null && f.children) {
                    let p = d.el.querySelector(".grid-stack");
                    p && p.gridstack && p.gridstack.load(h.subGridOpts.children)
                }
            } else t && this.addWidget(h)
        }), delete this.engine._loading, this.engine.removedNodes = o, this.batchUpdate(!1), delete this._ignoreLayoutsNodeChange, r ? c.addRemoveCB = r : delete c.addRemoveCB, n && ((u = this.opts) != null && u.animate) && this.setAnimation(this.opts.animate, !0), this
    }
    batchUpdate(e = !0) {
        return this.engine.batchUpdate(e), e || (this._updateContainerHeight(), this._triggerRemoveEvent(), this._triggerAddEvent(), this._triggerChangeEvent()), this
    }
    getCellHeight(e = !1) {
        if (this.opts.cellHeight && this.opts.cellHeight !== "auto" && (!e || !this.opts.cellHeightUnit || this.opts.cellHeightUnit === "px")) return this.opts.cellHeight;
        if (this.opts.cellHeightUnit === "rem") return this.opts.cellHeight * parseFloat(getComputedStyle(document.documentElement).fontSize);
        if (this.opts.cellHeightUnit === "em") return this.opts.cellHeight * parseFloat(getComputedStyle(this.el).fontSize);
        if (this.opts.cellHeightUnit === "cm") return this.opts.cellHeight * (96 / 2.54);
        if (this.opts.cellHeightUnit === "mm") return this.opts.cellHeight * (96 / 2.54) / 10;
        let t = this.el.querySelector("." + this.opts.itemClass);
        if (t) {
            let s = l.toNumber(t.getAttribute("gs-h")) || 1;
            return Math.round(t.offsetHeight / s)
        }
        let i = parseInt(this.el.getAttribute("gs-current-row"));
        return i ? Math.round(this.el.getBoundingClientRect().height / i) : this.opts.cellHeight
    }
    cellHeight(e, t = !0) {
        if (t && e !== void 0 && this._isAutoCellHeight !== (e === "auto") && (this._isAutoCellHeight = e === "auto", this._updateResizeEvent()), (e === "initial" || e === "auto") && (e = void 0), e === void 0) {
            let s = -this.opts.marginRight - this.opts.marginLeft + this.opts.marginTop + this.opts.marginBottom;
            e = this.cellWidth() + s
        }
        let i = l.parseHeight(e);
        return this.opts.cellHeightUnit === i.unit && this.opts.cellHeight === i.h ? this : (this.opts.cellHeightUnit = i.unit, this.opts.cellHeight = i.h, this.resizeToContentCheck(), t && this._updateStyles(!0), this)
    }
    cellWidth() {
        return this._widthOrContainer() / this.getColumn()
    }
    _widthOrContainer(e = !1) {
        var t;
        return e && ((t = this.opts.columnOpts) != null && t.breakpointForWindow) ? window.innerWidth : this.el.clientWidth || this.el.parentElement.clientWidth || window.innerWidth
    }
    checkDynamicColumn() {
        var r, o;
        const e = this.opts.columnOpts;
        if (!e || !e.columnWidth && !((r = e.breakpoints) != null && r.length)) return !1;
        const t = this.getColumn();
        let i = t;
        const s = this._widthOrContainer(!0);
        if (e.columnWidth) i = Math.min(Math.round(s / e.columnWidth) || 1, e.columnMax);
        else {
            i = e.columnMax;
            let n = 0;
            for (; n < e.breakpoints.length && s <= e.breakpoints[n].w;) i = e.breakpoints[n++].c || t
        }
        if (i !== t) {
            const n = (o = e.breakpoints) == null ? void 0 : o.find(a => a.c === i);
            return this.column(i, (n == null ? void 0 : n.layout) || e.layout), !0
        }
        return !1
    }
    compact(e = "compact", t = !0) {
        return this.engine.compact(e, t), this._triggerChangeEvent(), this
    }
    column(e, t = "moveScale") {
        if (!e || e < 1 || this.opts.column === e) return this;
        let i = this.getColumn();
        return this.opts.column = e, this.engine ? (this.engine.column = e, this.el.classList.remove("gs-" + i), this.el.classList.add("gs-" + e), this.engine.columnChanged(i, e, t), this._isAutoCellHeight && this.cellHeight(), this.resizeToContentCheck(!0), this._ignoreLayoutsNodeChange = !0, this._triggerChangeEvent(), delete this._ignoreLayoutsNodeChange, this) : this
    }
    getColumn() {
        return this.opts.column
    }
    getGridItems() {
        return Array.from(this.el.children).filter(e => e.matches("." + this.opts.itemClass) && !e.matches("." + this.opts.placeholderClass))
    }
    destroy(e = !0) {
        if (this.el) return this.offAll(), this._updateResizeEvent(!0), this.setStatic(!0, !1), this.setAnimation(!1), e ? this.el.parentNode.removeChild(this.el) : (this.removeAll(e), this.el.classList.remove(this._styleSheetClass), this.el.removeAttribute("gs-current-row")), this._removeStylesheet(), this.parentGridItem && delete this.parentGridItem.subGrid, delete this.parentGridItem, delete this.opts, delete this._placeholder, delete this.engine, delete this.el.gridstack, delete this.el, this
    }
    float(e) {
        return this.opts.float !== e && (this.opts.float = this.engine.float = e, this._triggerChangeEvent()), this
    }
    getFloat() {
        return this.engine.float
    }
    getCellFromPixel(e, t = !1) {
        let i = this.el.getBoundingClientRect(),
            s;
        t ? s = {
            top: i.top + document.documentElement.scrollTop,
            left: i.left
        } : s = {
            top: this.el.offsetTop,
            left: this.el.offsetLeft
        };
        let r = e.left - s.left,
            o = e.top - s.top,
            n = i.width / this.getColumn(),
            a = i.height / parseInt(this.el.getAttribute("gs-current-row"));
        return {
            x: Math.floor(r / n),
            y: Math.floor(o / a)
        }
    }
    getRow() {
        return Math.max(this.engine.getRow(), this.opts.minRow)
    }
    isAreaEmpty(e, t, i, s) {
        return this.engine.isAreaEmpty(e, t, i, s)
    }
    makeWidget(e, t) {
        let i = c.getElement(e);
        this._prepareElement(i, !0, t);
        const s = i.gridstackNode;
        return this._updateContainerHeight(), s.subGridOpts && this.makeSubGrid(i, s.subGridOpts, void 0, !1), this.opts.column === 1 && (this._ignoreLayoutsNodeChange = !0), this._triggerAddEvent(), this._triggerChangeEvent(), delete this._ignoreLayoutsNodeChange, i
    }
    on(e, t) {
        return e.indexOf(" ") !== -1 ? (e.split(" ").forEach(s => this.on(s, t)), this) : (e === "change" || e === "added" || e === "removed" || e === "enable" || e === "disable" ? (e === "enable" || e === "disable" ? this._gsEventHandler[e] = s => t(s) : this._gsEventHandler[e] = s => t(s, s.detail), this.el.addEventListener(e, this._gsEventHandler[e])) : e === "drag" || e === "dragstart" || e === "dragstop" || e === "resizestart" || e === "resize" || e === "resizestop" || e === "dropped" || e === "resizecontent" ? this._gsEventHandler[e] = t : console.error("GridStack.on(" + e + ") event not supported"), this)
    }
    off(e) {
        return e.indexOf(" ") !== -1 ? (e.split(" ").forEach(i => this.off(i)), this) : ((e === "change" || e === "added" || e === "removed" || e === "enable" || e === "disable") && this._gsEventHandler[e] && this.el.removeEventListener(e, this._gsEventHandler[e]), delete this._gsEventHandler[e], this)
    }
    offAll() {
        return Object.keys(this._gsEventHandler).forEach(e => this.off(e)), this
    }
    removeWidget(e, t = !0, i = !0) {
        return c.getElements(e).forEach(s => {
            if (s.parentElement && s.parentElement !== this.el) return;
            let r = s.gridstackNode;
            r || (r = this.engine.nodes.find(o => s === o.el)), r && (t && c.addRemoveCB && c.addRemoveCB(this.el, r, !1, !1), delete s.gridstackNode, this._removeDD(s), this.engine.removeNode(r, t, i), t && s.parentElement && s.remove())
        }), i && (this._triggerRemoveEvent(), this._triggerChangeEvent()), this
    }
    removeAll(e = !0, t = !0) {
        return this.engine.nodes.forEach(i => {
            e && c.addRemoveCB && c.addRemoveCB(this.el, i, !1, !1), delete i.el.gridstackNode, this.opts.staticGrid || this._removeDD(i.el)
        }), this.engine.removeAll(e, t), t && this._triggerRemoveEvent(), this
    }
    setAnimation(e = this.opts.animate, t) {
        return t ? setTimeout(() => {
            this.opts && this.setAnimation(e)
        }) : e ? this.el.classList.add("grid-stack-animate") : this.el.classList.remove("grid-stack-animate"), this
    }
    hasAnimationCSS() {
        return this.el.classList.contains("grid-stack-animate")
    }
    setStatic(e, t = !0, i = !0) {
        return !!this.opts.staticGrid === e ? this : (e ? this.opts.staticGrid = !0 : delete this.opts.staticGrid, this._setupRemoveDrop(), this._setupAcceptWidget(), this.engine.nodes.forEach(s => {
            this._prepareDragDropByNode(s), s.subGrid && i && s.subGrid.setStatic(e, t, i)
        }), t && this._setStaticClass(), this)
    }
    update(e, t) {
        if (arguments.length > 2) {
            console.warn("gridstack.ts: `update(el, x, y, w, h)` is deprecated. Use `update(el, {x, w, content, ...})`. It will be removed soon");
            let i = arguments,
                s = 1;
            return t = {
                x: i[s++],
                y: i[s++],
                w: i[s++],
                h: i[s++]
            }, this.update(e, t)
        }
        return c.getElements(e).forEach(i => {
            var h;
            let s = i == null ? void 0 : i.gridstackNode;
            if (!s) return;
            let r = l.cloneDeep(t);
            this.engine.nodeBoundFix(r), delete r.autoPosition, delete r.id;
            let o = ["x", "y", "w", "h"],
                n;
            if (o.some(d => r[d] !== void 0 && r[d] !== s[d]) && (n = {}, o.forEach(d => {
                    n[d] = r[d] !== void 0 ? r[d] : s[d], delete r[d]
                })), !n && (r.minW || r.minH || r.maxW || r.maxH) && (n = {}), r.content !== void 0) {
                const d = i.querySelector(".grid-stack-item-content");
                d && d.innerHTML !== r.content && (d.innerHTML = r.content, (h = s.subGrid) != null && h.el && (d.appendChild(s.subGrid.el), s.subGrid.opts.styleInHead || s.subGrid._updateStyles(!0))), delete r.content
            }
            let a = !1,
                u = !1;
            for (const d in r) d[0] !== "_" && s[d] !== r[d] && (s[d] = r[d], a = !0, u = u || !this.opts.staticGrid && (d === "noResize" || d === "noMove" || d === "locked"));
            if (l.sanitizeMinMax(s), n) {
                const d = n.w !== void 0 && n.w !== s.w;
                this.moveNode(s, n), this.resizeToContentCheck(d, s), delete s._orig
            }(n || a) && this._writeAttr(i, s), u && this._prepareDragDropByNode(s)
        }), this
    }
    moveNode(e, t) {
        const i = e._updating;
        i || this.engine.cleanNodes().beginUpdate(e), this.engine.moveNode(e, t), this._updateContainerHeight(), i || (this._triggerChangeEvent(), this.engine.endUpdate())
    }
    resizeToContent(e) {
        var f, p;
        if (!e || (e.classList.remove("size-to-content-max"), !e.clientHeight)) return;
        const t = e.gridstackNode;
        if (!t) return;
        const i = t.grid;
        if (!i || e.parentElement !== i.el) return;
        const s = i.getCellHeight(!0);
        if (!s) return;
        let r = t.h ? t.h * s : e.clientHeight,
            o;
        if (t.resizeToContentParent && (o = e.querySelector(t.resizeToContentParent)), o || (o = e.querySelector(c.resizeToContentParent)), !o) return;
        const n = e.clientHeight - o.clientHeight,
            a = t.h ? t.h * s - n : o.clientHeight;
        let u;
        if (t.subGrid) u = t.subGrid.getRow() * t.subGrid.getCellHeight(!0);
        else {
            if ((p = (f = t.subGridOpts) == null ? void 0 : f.children) != null && p.length) return; {
                const v = o.firstElementChild;
                if (!v) {
                    console.error(`Error: GridStack.resizeToContent() widget id:${t.id} '${c.resizeToContentParent}'.firstElementChild is null, make sure to have a div like container. Skipping sizing.`);
                    return
                }
                u = v.getBoundingClientRect().height || a
            }
        }
        if (a === u) return;
        r += u - a;
        let h = Math.ceil(r / s);
        const d = Number.isInteger(t.sizeToContent) ? t.sizeToContent : 0;
        d && h > d && (h = d, e.classList.add("size-to-content-max")), t.minH && h < t.minH ? h = t.minH : t.maxH && h > t.maxH && (h = t.maxH), h !== t.h && (i._ignoreLayoutsNodeChange = !0, i.moveNode(t, {
            h
        }), delete i._ignoreLayoutsNodeChange)
    }
    resizeToContentCBCheck(e) {
        c.resizeToContentCB ? c.resizeToContentCB(e) : this.resizeToContent(e)
    }
    rotate(e, t) {
        return c.getElements(e).forEach(i => {
            let s = i.gridstackNode;
            if (!l.canBeRotated(s)) return;
            const r = {
                w: s.h,
                h: s.w,
                minH: s.minW,
                minW: s.minH,
                maxH: s.maxW,
                maxW: s.maxH
            };
            if (t) {
                let n = t.left > 0 ? Math.floor(t.left / this.cellWidth()) : 0,
                    a = t.top > 0 ? Math.floor(t.top / this.opts.cellHeight) : 0;
                r.x = s.x + n - (s.h - (a + 1)), r.y = s.y + a - n
            }
            Object.keys(r).forEach(n => {
                r[n] === void 0 && delete r[n]
            });
            const o = s._orig;
            this.update(i, r), s._orig = o
        }), this
    }
    margin(e) {
        if (!(typeof e == "string" && e.split(" ").length > 1)) {
            let i = l.parseHeight(e);
            if (this.opts.marginUnit === i.unit && this.opts.margin === i.h) return
        }
        return this.opts.margin = e, this.opts.marginTop = this.opts.marginBottom = this.opts.marginLeft = this.opts.marginRight = void 0, this._initMargin(), this._updateStyles(!0), this
    }
    getMargin() {
        return this.opts.margin
    }
    willItFit(e) {
        if (arguments.length > 1) {
            console.warn("gridstack.ts: `willItFit(x,y,w,h,autoPosition)` is deprecated. Use `willItFit({x, y,...})`. It will be removed soon");
            let t = arguments,
                i = 0,
                s = {
                    x: t[i++],
                    y: t[i++],
                    w: t[i++],
                    h: t[i++],
                    autoPosition: t[i++]
                };
            return this.willItFit(s)
        }
        return this.engine.willItFit(e)
    }
    _triggerChangeEvent() {
        if (this.engine.batchMode) return this;
        let e = this.engine.getDirtyNodes(!0);
        return e && e.length && (this._ignoreLayoutsNodeChange || this.engine.layoutsNodesChange(e), this._triggerEvent("change", e)), this.engine.saveInitial(), this
    }
    _triggerAddEvent() {
        var e;
        if (this.engine.batchMode) return this;
        if ((e = this.engine.addedNodes) != null && e.length) {
            this._ignoreLayoutsNodeChange || this.engine.layoutsNodesChange(this.engine.addedNodes), this.engine.addedNodes.forEach(i => {
                delete i._dirty
            });
            const t = [...this.engine.addedNodes];
            this.engine.addedNodes = [], this._triggerEvent("added", t)
        }
        return this
    }
    _triggerRemoveEvent() {
        var e;
        if (this.engine.batchMode) return this;
        if ((e = this.engine.removedNodes) != null && e.length) {
            const t = [...this.engine.removedNodes];
            this.engine.removedNodes = [], this._triggerEvent("removed", t)
        }
        return this
    }
    _triggerEvent(e, t) {
        let i = t ? new CustomEvent(e, {
            bubbles: !1,
            detail: t
        }) : new Event(e);
        return this.el.dispatchEvent(i), this
    }
    _removeStylesheet() {
        if (this._styles) {
            const e = this.opts.styleInHead ? void 0 : this.el.parentNode;
            l.removeStylesheet(this._styleSheetClass, e), delete this._styles
        }
        return this
    }
    _updateStyles(e = !1, t) {
        if (e && this._removeStylesheet(), t === void 0 && (t = this.getRow()), this._updateContainerHeight(), this.opts.cellHeight === 0) return this;
        let i = this.opts.cellHeight,
            s = this.opts.cellHeightUnit,
            r = `.${this._styleSheetClass} > .${this.opts.itemClass}`;
        if (!this._styles) {
            const o = this.opts.styleInHead ? void 0 : this.el.parentNode;
            if (this._styles = l.createStylesheet(this._styleSheetClass, o, {
                    nonce: this.opts.nonce
                }), !this._styles) return this;
            this._styles._max = 0, l.addCSSRule(this._styles, r, `height: ${i}${s}`);
            let n = this.opts.marginTop + this.opts.marginUnit,
                a = this.opts.marginBottom + this.opts.marginUnit,
                u = this.opts.marginRight + this.opts.marginUnit,
                h = this.opts.marginLeft + this.opts.marginUnit,
                d = `${r} > .grid-stack-item-content`,
                f = `.${this._styleSheetClass} > .grid-stack-placeholder > .placeholder-content`;
            l.addCSSRule(this._styles, d, `top: ${n}; right: ${u}; bottom: ${a}; left: ${h};`), l.addCSSRule(this._styles, f, `top: ${n}; right: ${u}; bottom: ${a}; left: ${h};`), l.addCSSRule(this._styles, `${r} > .ui-resizable-n`, `top: ${n};`), l.addCSSRule(this._styles, `${r} > .ui-resizable-s`, `bottom: ${a}`), l.addCSSRule(this._styles, `${r} > .ui-resizable-ne`, `right: ${u}`), l.addCSSRule(this._styles, `${r} > .ui-resizable-e`, `right: ${u}`), l.addCSSRule(this._styles, `${r} > .ui-resizable-se`, `right: ${u}; bottom: ${a}`), l.addCSSRule(this._styles, `${r} > .ui-resizable-nw`, `left: ${h}`), l.addCSSRule(this._styles, `${r} > .ui-resizable-w`, `left: ${h}`), l.addCSSRule(this._styles, `${r} > .ui-resizable-sw`, `left: ${h}; bottom: ${a}`)
        }
        if (t = t || this._styles._max, t > this._styles._max) {
            let o = n => i * n + s;
            for (let n = this._styles._max + 1; n <= t; n++) l.addCSSRule(this._styles, `${r}[gs-y="${n}"]`, `top: ${o(n)}`), l.addCSSRule(this._styles, `${r}[gs-h="${n+1}"]`, `height: ${o(n+1)}`);
            this._styles._max = t
        }
        return this
    }
    _updateContainerHeight() {
        if (!this.engine || this.engine.batchMode) return this;
        const e = this.parentGridItem;
        let t = this.getRow() + this._extraDragRow;
        const i = this.opts.cellHeight,
            s = this.opts.cellHeightUnit;
        if (!i) return this;
        if (!e) {
            const r = l.parseHeight(getComputedStyle(this.el).minHeight);
            if (r.h > 0 && r.unit === s) {
                const o = Math.floor(r.h / i);
                t < o && (t = o)
            }
        }
        return this.el.setAttribute("gs-current-row", String(t)), this.el.style.removeProperty("min-height"), this.el.style.removeProperty("height"), t && (this.el.style[e ? "minHeight" : "height"] = t * i + s), e && !e.grid.engine.batchMode && l.shouldSizeToContent(e) && e.grid.resizeToContentCBCheck(e.el), this
    }
    _prepareElement(e, t = !1, i) {
        i = i || this._readAttr(e), e.gridstackNode = i, i.el = e, i.grid = this, i = this.engine.addNode(i, t), this._writeAttr(e, i), e.classList.add(b.itemClass, this.opts.itemClass);
        const s = l.shouldSizeToContent(i);
        return s ? e.classList.add("size-to-content") : e.classList.remove("size-to-content"), s && this.resizeToContentCheck(!1, i), this._prepareDragDropByNode(i), this
    }
    _writePosAttr(e, t) {
        return t.x !== void 0 && t.x !== null && e.setAttribute("gs-x", String(t.x)), t.y !== void 0 && t.y !== null && e.setAttribute("gs-y", String(t.y)), t.w > 1 ? e.setAttribute("gs-w", String(t.w)) : e.removeAttribute("gs-w"), t.h > 1 ? e.setAttribute("gs-h", String(t.h)) : e.removeAttribute("gs-h"), this
    }
    _writeAttr(e, t) {
        if (!t) return this;
        this._writePosAttr(e, t);
        let i = {
            autoPosition: "gs-auto-position",
            noResize: "gs-no-resize",
            noMove: "gs-no-move",
            locked: "gs-locked",
            id: "gs-id"
        };
        for (const s in i) t[s] ? e.setAttribute(i[s], String(t[s])) : e.removeAttribute(i[s]);
        return this
    }
    _readAttr(e, t = !0) {
        let i = {};
        i.x = l.toNumber(e.getAttribute("gs-x")), i.y = l.toNumber(e.getAttribute("gs-y")), i.w = l.toNumber(e.getAttribute("gs-w")), i.h = l.toNumber(e.getAttribute("gs-h")), i.autoPosition = l.toBool(e.getAttribute("gs-auto-position")), i.noResize = l.toBool(e.getAttribute("gs-no-resize")), i.noMove = l.toBool(e.getAttribute("gs-no-move")), i.locked = l.toBool(e.getAttribute("gs-locked")), i.id = e.getAttribute("gs-id"), i.maxW = l.toNumber(e.getAttribute("gs-max-w")), i.minW = l.toNumber(e.getAttribute("gs-min-w")), i.maxH = l.toNumber(e.getAttribute("gs-max-h")), i.minH = l.toNumber(e.getAttribute("gs-min-h")), t && (i.w === 1 && e.removeAttribute("gs-w"), i.h === 1 && e.removeAttribute("gs-h"), i.maxW && e.removeAttribute("gs-max-w"), i.minW && e.removeAttribute("gs-min-w"), i.maxH && e.removeAttribute("gs-max-h"), i.minH && e.removeAttribute("gs-min-h"));
        for (const s in i) {
            if (!i.hasOwnProperty(s)) return;
            !i[s] && i[s] !== 0 && delete i[s]
        }
        return i
    }
    _setStaticClass() {
        let e = ["grid-stack-static"];
        return this.opts.staticGrid ? (this.el.classList.add(...e), this.el.setAttribute("gs-static", "true")) : (this.el.classList.remove(...e), this.el.removeAttribute("gs-static")), this
    }
    onResize() {
        var t;
        if (!((t = this.el) != null && t.clientWidth) || this.prevWidth === this.el.clientWidth) return;
        this.prevWidth = this.el.clientWidth, this.batchUpdate();
        let e = !1;
        return this._autoColumn && this.parentGridItem ? this.opts.column !== this.parentGridItem.w && (this.column(this.parentGridItem.w, "none"), e = !0) : e = this.checkDynamicColumn(), this._isAutoCellHeight && this.cellHeight(), this.engine.nodes.forEach(i => {
            i.subGrid && i.subGrid.onResize()
        }), this._skipInitialResize || this.resizeToContentCheck(e), delete this._skipInitialResize, this.batchUpdate(!1), this
    }
    resizeToContentCheck(e = !1, t = void 0) {
        if (this.engine) {
            if (e && this.hasAnimationCSS()) return setTimeout(() => this.resizeToContentCheck(!1, t), 310);
            if (t) l.shouldSizeToContent(t) && this.resizeToContentCBCheck(t.el);
            else if (this.engine.nodes.some(i => l.shouldSizeToContent(i))) {
                const i = [...this.engine.nodes];
                this.batchUpdate(), i.forEach(s => {
                    l.shouldSizeToContent(s) && this.resizeToContentCBCheck(s.el)
                }), this.batchUpdate(!1)
            }
            this._gsEventHandler.resizecontent && this._gsEventHandler.resizecontent(null, t ? [t] : this.engine.nodes)
        }
    }
    _updateResizeEvent(e = !1) {
        const t = !this.parentGridItem && (this._isAutoCellHeight || this.opts.sizeToContent || this.opts.columnOpts || this.engine.nodes.find(i => i.sizeToContent));
        return !e && t && !this.resizeObserver ? (this._sizeThrottle = l.throttle(() => this.onResize(), this.opts.cellHeightThrottle), this.resizeObserver = new ResizeObserver(() => this._sizeThrottle()), this.resizeObserver.observe(this.el), this._skipInitialResize = !0) : (e || !t) && this.resizeObserver && (this.resizeObserver.disconnect(), delete this.resizeObserver, delete this._sizeThrottle), this
    }
    static getElement(e = ".grid-stack-item") {
        return l.getElement(e)
    }
    static getElements(e = ".grid-stack-item") {
        return l.getElements(e)
    }
    static getGridElement(e) {
        return c.getElement(e)
    }
    static getGridElements(e) {
        return l.getElements(e)
    }
    _initMargin() {
        let e, t = 0,
            i = [];
        return typeof this.opts.margin == "string" && (i = this.opts.margin.split(" ")), i.length === 2 ? (this.opts.marginTop = this.opts.marginBottom = i[0], this.opts.marginLeft = this.opts.marginRight = i[1]) : i.length === 4 ? (this.opts.marginTop = i[0], this.opts.marginRight = i[1], this.opts.marginBottom = i[2], this.opts.marginLeft = i[3]) : (e = l.parseHeight(this.opts.margin), this.opts.marginUnit = e.unit, t = this.opts.margin = e.h), this.opts.marginTop === void 0 ? this.opts.marginTop = t : (e = l.parseHeight(this.opts.marginTop), this.opts.marginTop = e.h, delete this.opts.margin), this.opts.marginBottom === void 0 ? this.opts.marginBottom = t : (e = l.parseHeight(this.opts.marginBottom), this.opts.marginBottom = e.h, delete this.opts.margin), this.opts.marginRight === void 0 ? this.opts.marginRight = t : (e = l.parseHeight(this.opts.marginRight), this.opts.marginRight = e.h, delete this.opts.margin), this.opts.marginLeft === void 0 ? this.opts.marginLeft = t : (e = l.parseHeight(this.opts.marginLeft), this.opts.marginLeft = e.h, delete this.opts.margin), this.opts.marginUnit = e.unit, this.opts.marginTop === this.opts.marginBottom && this.opts.marginLeft === this.opts.marginRight && this.opts.marginTop === this.opts.marginRight && (this.opts.margin = this.opts.marginTop), this
    }
    static getDD() {
        return E
    }
    static setupDragIn(e, t, i = document) {
        (t == null ? void 0 : t.pause) !== void 0 && (g.pauseDrag = t.pause), t = { ...$,
            ...t || {}
        };
        let s = typeof e == "string" ? l.getElements(e, i) : e;
        s.length && (s == null || s.forEach(r => {
            E.isDraggable(r) || E.dragIn(r, t)
        }))
    }
    movable(e, t) {
        return this.opts.staticGrid ? this : (c.getElements(e).forEach(i => {
            const s = i.gridstackNode;
            s && (t ? delete s.noMove : s.noMove = !0, this._prepareDragDropByNode(s))
        }), this)
    }
    resizable(e, t) {
        return this.opts.staticGrid ? this : (c.getElements(e).forEach(i => {
            let s = i.gridstackNode;
            s && (t ? delete s.noResize : s.noResize = !0, this._prepareDragDropByNode(s))
        }), this)
    }
    disable(e = !0) {
        if (!this.opts.staticGrid) return this.enableMove(!1, e), this.enableResize(!1, e), this._triggerEvent("disable"), this
    }
    enable(e = !0) {
        if (!this.opts.staticGrid) return this.enableMove(!0, e), this.enableResize(!0, e), this._triggerEvent("enable"), this
    }
    enableMove(e, t = !0) {
        return this.opts.staticGrid ? this : (e ? delete this.opts.disableDrag : this.opts.disableDrag = !0, this.engine.nodes.forEach(i => {
            this._prepareDragDropByNode(i), i.subGrid && t && i.subGrid.enableMove(e, t)
        }), this)
    }
    enableResize(e, t = !0) {
        return this.opts.staticGrid ? this : (e ? delete this.opts.disableResize : this.opts.disableResize = !0, this.engine.nodes.forEach(i => {
            this._prepareDragDropByNode(i), i.subGrid && t && i.subGrid.enableResize(e, t)
        }), this)
    }
    _removeDD(e) {
        return E.draggable(e, "destroy").resizable(e, "destroy"), e.gridstackNode && delete e.gridstackNode._initDD, delete e.ddElement, this
    }
    _setupAcceptWidget() {
        if (this.opts.staticGrid || !this.opts.acceptWidgets && !this.opts.removable) return E.droppable(this.el, "destroy"), this;
        let e, t, i = (s, r, o) => {
            var f;
            let n = r.gridstackNode;
            if (!n) return;
            if (o = o || r, !((f = n.grid) != null && f.el)) {
                o.style.transform = `scale(${1/this.dragTransform.xScale},${1/this.dragTransform.yScale})`;
                const p = o.getBoundingClientRect();
                o.style.left = p.x + (this.dragTransform.xScale - 1) * (s.clientX - p.x) / this.dragTransform.xScale + "px", o.style.top = p.y + (this.dragTransform.yScale - 1) * (s.clientY - p.y) / this.dragTransform.yScale + "px", o.style.transformOrigin = "0px 0px"
            }
            let a = this.el.getBoundingClientRect(),
                {
                    top: u,
                    left: h
                } = o.getBoundingClientRect();
            h -= a.left, u -= a.top;
            let d = {
                position: {
                    top: u * this.dragTransform.xScale,
                    left: h * this.dragTransform.yScale
                }
            };
            if (n._temporaryRemoved) {
                if (n.x = Math.max(0, Math.round(h / t)), n.y = Math.max(0, Math.round(u / e)), delete n.autoPosition, this.engine.nodeBoundFix(n), !this.engine.willItFit(n)) {
                    if (n.autoPosition = !0, !this.engine.willItFit(n)) {
                        E.off(r, "drag");
                        return
                    }
                    n._willFitPos && (l.copyPos(n, n._willFitPos), delete n._willFitPos)
                }
                this._onStartMoving(o, s, d, n, t, e)
            } else this._dragOrResize(o, s, d, n, t, e)
        };
        return E.droppable(this.el, {
            accept: s => {
                let r = s.gridstackNode || this._readAttr(s, !1);
                if ((r == null ? void 0 : r.grid) === this) return !0;
                if (!this.opts.acceptWidgets) return !1;
                let o = !0;
                if (typeof this.opts.acceptWidgets == "function") o = this.opts.acceptWidgets(s);
                else {
                    let n = this.opts.acceptWidgets === !0 ? ".grid-stack-item" : this.opts.acceptWidgets;
                    o = s.matches(n)
                }
                if (o && r && this.opts.maxRow) {
                    let n = {
                        w: r.w,
                        h: r.h,
                        minW: r.minW,
                        minH: r.minH
                    };
                    o = this.engine.willItFit(n)
                }
                return o
            }
        }).on(this.el, "dropover", (s, r, o) => {
            let n = r.gridstackNode;
            if ((n == null ? void 0 : n.grid) === this && !n._temporaryRemoved) return !1;
            n != null && n.grid && n.grid !== this && !n._temporaryRemoved && n.grid._leave(r, o), t = this.cellWidth(), e = this.getCellHeight(!0), n || (n = this._readAttr(r, !1)), n.grid || (n._isExternal = !0, r.gridstackNode = n), o = o || r;
            let a = n.w || Math.round(o.offsetWidth / t) || 1,
                u = n.h || Math.round(o.offsetHeight / e) || 1;
            return n.grid && n.grid !== this ? (r._gridstackNodeOrig || (r._gridstackNodeOrig = n), r.gridstackNode = n = { ...n,
                w: a,
                h: u,
                grid: this
            }, delete n.x, delete n.y, this.engine.cleanupNode(n).nodeBoundFix(n), n._initDD = n._isExternal = n._temporaryRemoved = !0) : (n.w = a, n.h = u, n._temporaryRemoved = !0), c._itemRemoving(n.el, !1), E.on(r, "drag", i), i(s, r, o), !1
        }).on(this.el, "dropout", (s, r, o) => {
            let n = r.gridstackNode;
            return n && (!n.grid || n.grid === this) && (this._leave(r, o), this._isTemp && this.removeAsSubGrid(n)), !1
        }).on(this.el, "drop", (s, r, o) => {
            var f, p, v;
            let n = r.gridstackNode;
            if ((n == null ? void 0 : n.grid) === this && !n._isExternal) return !1;
            const a = !!this.placeholder.parentElement;
            this.placeholder.remove();
            const u = a && this.opts.animate;
            u && this.setAnimation(!1);
            let h = r._gridstackNodeOrig;
            if (delete r._gridstackNodeOrig, a && (h != null && h.grid) && h.grid !== this) {
                let y = h.grid;
                y.engine.removeNodeFromLayoutCache(h), y.engine.removedNodes.push(h), y._triggerRemoveEvent()._triggerChangeEvent(), y.parentGridItem && !y.engine.nodes.length && y.opts.subGridDynamic && y.removeAsSubGrid()
            }
            if (!n || (a && (this.engine.cleanupNode(n), n.grid = this), (f = n.grid) == null || delete f._isTemp, E.off(r, "drag"), o !== r ? (o.remove(), r.gridstackNode = h, a && (r = r.cloneNode(!0))) : (r.remove(), this._removeDD(r)), !a)) return !1;
            r.gridstackNode = n, n.el = r;
            let d = (v = (p = n.subGrid) == null ? void 0 : p.el) == null ? void 0 : v.gridstack;
            return l.copyPos(n, this._readAttr(this.placeholder)), l.removePositioningStyles(r), this.el.appendChild(r), this._prepareElement(r, !0, n), d && (d.parentGridItem = n, d.opts.styleInHead || d._updateStyles(!0)), this._updateContainerHeight(), this.engine.addedNodes.push(n), this._triggerAddEvent(), this._triggerChangeEvent(), this.engine.endUpdate(), this._gsEventHandler.dropped && this._gsEventHandler.dropped({ ...s,
                type: "dropped"
            }, h && h.grid ? h : void 0, n), u && this.setAnimation(this.opts.animate, !0), !1
        }), this
    }
    static _itemRemoving(e, t) {
        const i = e ? e.gridstackNode : void 0;
        !(i != null && i.grid) || e.classList.contains(i.grid.opts.removableOptions.decline) || (t ? i._isAboutToRemove = !0 : delete i._isAboutToRemove, t ? e.classList.add("grid-stack-item-removing") : e.classList.remove("grid-stack-item-removing"))
    }
    _setupRemoveDrop() {
        if (typeof this.opts.removable != "string") return this;
        let e = document.querySelector(this.opts.removable);
        return e ? (!this.opts.staticGrid && !E.isDroppable(e) && E.droppable(e, this.opts.removableOptions).on(e, "dropover", (t, i) => c._itemRemoving(i, !0)).on(e, "dropout", (t, i) => c._itemRemoving(i, !1)), this) : this
    }
    _prepareDragDropByNode(e) {
        let t = e.el;
        const i = e.noMove || this.opts.disableDrag,
            s = e.noResize || this.opts.disableResize;
        if (this.opts.staticGrid || i && s) return e._initDD && (this._removeDD(t), delete e._initDD), t.classList.add("ui-draggable-disabled", "ui-resizable-disabled"), this;
        if (!e._initDD) {
            let r, o, n = (h, d) => {
                    this._gsEventHandler[h.type] && this._gsEventHandler[h.type](h, h.target), r = this.cellWidth(), o = this.getCellHeight(!0), this._onStartMoving(t, h, d, e, r, o)
                },
                a = (h, d) => {
                    this._dragOrResize(t, h, d, e, r, o)
                },
                u = h => {
                    this.placeholder.remove(), delete e._moving, delete e._event, delete e._lastTried;
                    const d = e.w !== e._orig.w;
                    let f = h.target;
                    if (!(!f.gridstackNode || f.gridstackNode.grid !== this)) {
                        if (e.el = f, e._isAboutToRemove) {
                            let p = t.gridstackNode.grid;
                            p._gsEventHandler[h.type] && p._gsEventHandler[h.type](h, f), p.engine.nodes.push(e), p.removeWidget(t, !0, !0)
                        } else l.removePositioningStyles(f), e._temporaryRemoved ? (l.copyPos(e, e._orig), this._writePosAttr(f, e), this.engine.addNode(e)) : this._writePosAttr(f, e), this._gsEventHandler[h.type] && this._gsEventHandler[h.type](h, f);
                        this._extraDragRow = 0, this._updateContainerHeight(), this._triggerChangeEvent(), this.engine.endUpdate(), h.type === "resizestop" && (Number.isInteger(e.sizeToContent) && (e.sizeToContent = e.h), this.resizeToContentCheck(d, e))
                    }
                };
            E.draggable(t, {
                start: n,
                stop: u,
                drag: a
            }).resizable(t, {
                start: n,
                stop: u,
                resize: a
            }), e._initDD = !0
        }
        return E.draggable(t, i ? "disable" : "enable").resizable(t, s ? "disable" : "enable"), this
    }
    _onStartMoving(e, t, i, s, r, o) {
        var n;
        if (this.engine.cleanNodes().beginUpdate(s), this._writePosAttr(this.placeholder, s), this.el.appendChild(this.placeholder), this.placeholder.gridstackNode = s, (n = s.grid) != null && n.el) this.dragTransform = l.getValuesFromTransformedElement(e);
        else if (this.placeholder && this.placeholder.closest(".grid-stack")) {
            const a = this.placeholder.closest(".grid-stack");
            this.dragTransform = l.getValuesFromTransformedElement(a)
        } else this.dragTransform = {
            xScale: 1,
            xOffset: 0,
            yScale: 1,
            yOffset: 0
        };
        if (s.el = this.placeholder, s._lastUiPosition = i.position, s._prevYPix = i.position.top, s._moving = t.type === "dragstart", delete s._lastTried, t.type === "dropover" && s._temporaryRemoved && (this.engine.addNode(s), s._moving = !0), this.engine.cacheRects(r, o, this.opts.marginTop, this.opts.marginRight, this.opts.marginBottom, this.opts.marginLeft), t.type === "resizestart") {
            const a = this.getColumn() - s.x,
                u = (this.opts.maxRow || Number.MAX_SAFE_INTEGER) - s.y;
            E.resizable(e, "option", "minWidth", r * Math.min(s.minW || 1, a)).resizable(e, "option", "minHeight", o * Math.min(s.minH || 1, u)).resizable(e, "option", "maxWidth", r * Math.min(s.maxW || Number.MAX_SAFE_INTEGER, a)).resizable(e, "option", "maxWidthMoveLeft", r * Math.min(s.maxW || Number.MAX_SAFE_INTEGER, s.x + s.w)).resizable(e, "option", "maxHeight", o * Math.min(s.maxH || Number.MAX_SAFE_INTEGER, u)).resizable(e, "option", "maxHeightMoveUp", o * Math.min(s.maxH || Number.MAX_SAFE_INTEGER, s.y + s.h))
        }
    }
    _dragOrResize(e, t, i, s, r, o) {
        let n = { ...s._orig
            },
            a, u = this.opts.marginLeft,
            h = this.opts.marginRight,
            d = this.opts.marginTop,
            f = this.opts.marginBottom,
            p = Math.round(o * .1),
            v = Math.round(r * .1);
        if (u = Math.min(u, v), h = Math.min(h, v), d = Math.min(d, p), f = Math.min(f, p), t.type === "drag") {
            if (s._temporaryRemoved) return;
            let _ = i.position.top - s._prevYPix;
            s._prevYPix = i.position.top, this.opts.draggable.scroll !== !1 && l.updateScrollPosition(e, i.position, _);
            let w = i.position.left + (i.position.left > s._lastUiPosition.left ? -h : u),
                z = i.position.top + (i.position.top > s._lastUiPosition.top ? -f : d);
            n.x = Math.round(w / r), n.y = Math.round(z / o);
            let G = this._extraDragRow;
            if (this.engine.collide(s, n)) {
                let A = this.getRow(),
                    O = Math.max(0, n.y + s.h - A);
                this.opts.maxRow && A + O > this.opts.maxRow && (O = Math.max(0, this.opts.maxRow - A)), this._extraDragRow = O
            } else this._extraDragRow = 0;
            if (this._extraDragRow !== G && this._updateContainerHeight(), s.x === n.x && s.y === n.y) return
        } else if (t.type === "resize") {
            if (n.x < 0 || (l.updateScrollResize(t, e, o), n.w = Math.round((i.size.width - u) / r), n.h = Math.round((i.size.height - d) / o), s.w === n.w && s.h === n.h) || s._lastTried && s._lastTried.w === n.w && s._lastTried.h === n.h) return;
            let _ = i.position.left + u,
                w = i.position.top + d;
            n.x = Math.round(_ / r), n.y = Math.round(w / o), a = !0
        }
        s._event = t, s._lastTried = n;
        let y = {
            x: i.position.left + u,
            y: i.position.top + d,
            w: (i.size ? i.size.width : s.w * r) - u - h,
            h: (i.size ? i.size.height : s.h * o) - d - f
        };
        if (this.engine.moveNodeCheck(s, { ...n,
                cellWidth: r,
                cellHeight: o,
                rect: y,
                resizing: a
            })) {
            s._lastUiPosition = i.position, this.engine.cacheRects(r, o, d, h, f, u), delete s._skipDown, a && s.subGrid && s.subGrid.onResize(), this._extraDragRow = 0, this._updateContainerHeight();
            let _ = t.target;
            this._writePosAttr(_, s), this._gsEventHandler[t.type] && this._gsEventHandler[t.type](t, _)
        }
    }
    _leave(e, t) {
        let i = e.gridstackNode;
        i && (t = t || e, t.style.transform = "scale(1)", E.off(e, "drag"), !i._temporaryRemoved && (i._temporaryRemoved = !0, this.engine.removeNode(i), i.el = i._isExternal && t ? t : e, this.opts.removable === !0 && c._itemRemoving(e, !0), e._gridstackNodeOrig ? (e.gridstackNode = e._gridstackNodeOrig, delete e._gridstackNodeOrig) : i._isExternal && (delete i.el, delete e.gridstackNode, this.engine.restoreInitial())))
    }
    commit() {
        return F(this, this.batchUpdate(!1), "commit", "batchUpdate", "5.2"), this
    }
}
c.resizeToContentParent = ".grid-stack-item-content";
c.Utils = l;
c.Engine = C;
c.GDRev = "10.3.1";
export {
    c as G
};