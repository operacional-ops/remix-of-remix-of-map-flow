import {
    S as a
} from "./DwsiLpv2.js";
const r = a.createStore("tracking", null);

function o(n) {
    r.update(t => ({ ...t ? ? {},
        ...n
    }))
}
export {
    r as l, o as s
};