import {
    U as e
} from "./B5WePDbK.js";
class o {
    static async execute(a) {
        var s;
        const t = await e.get("/users/waiting-list-reason", {
            token: ((s = a.authData) == null ? void 0 : s.token) ? ? ""
        });
        return t.statusCode === 401 ? {
            status: "UNAUTHORIZED"
        } : t.statusCode === 200 ? {
            status: "SUCCESS",
            reason: t.data.reason
        } : {
            status: "UNKNOWN"
        }
    }
}
export {
    o as G
};