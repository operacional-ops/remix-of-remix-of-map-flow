var j = Object.defineProperty;
var U = (s, n, e) => n in s ? j(s, n, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: e
}) : s[n] = e;
var i = (s, n, e) => U(s, typeof n != "symbol" ? n + "" : n, e);
import {
    e as J,
    s as H,
    h as F,
    i as S,
    j as ee,
    g as re,
    k as te,
    l as G,
    m as se,
    w as X,
    n as ne
} from "./dEV4iLZ3.js";
import {
    t as g,
    c as D,
    d as ae,
    e as ie,
    h as oe
} from "./DwsiLpv2.js";
import {
    g as ce
} from "./Dd0nEcXu.js";
import {
    b as A
} from "./FnqUtadX.js";
import {
    g as z
} from "./BCpwIhRd.js";

function ue(s, n) {
    const e = g(s, n == null ? void 0 : n.in).getDay();
    return e === 0 ? 7 : e
}

function le(s, n) {
    const e = de(n) ? new n(0) : D(n, 0);
    return e.setFullYear(s.getFullYear(), s.getMonth(), s.getDate()), e.setHours(s.getHours(), s.getMinutes(), s.getSeconds(), s.getMilliseconds()), e
}

function de(s) {
    var n;
    return typeof s == "function" && ((n = s.prototype) == null ? void 0 : n.constructor) === s
}
const we = 10;
class Z {
    constructor() {
        i(this, "subPriority", 0)
    }
    validate(n, e) {
        return !0
    }
}
class fe extends Z {
    constructor(n, e, t, r, a) {
        super(), this.value = n, this.validateValue = e, this.setValue = t, this.priority = r, a && (this.subPriority = a)
    }
    validate(n, e) {
        return this.validateValue(n, this.value, e)
    }
    set(n, e, t) {
        return this.setValue(n, e, this.value, t)
    }
}
class he extends Z {
    constructor(e, t) {
        super();
        i(this, "priority", we);
        i(this, "subPriority", -1);
        this.context = e || (r => D(t, r))
    }
    set(e, t) {
        return t.timestampIsSet ? e : D(e, le(e, this.context))
    }
}
class u {
    run(n, e, t, r) {
        const a = this.parse(n, e, t, r);
        return a ? {
            setter: new fe(a.value, this.validate, this.set, this.priority, this.subPriority),
            rest: a.rest
        } : null
    }
    validate(n, e, t) {
        return !0
    }
}
class ye extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 140);
        i(this, "incompatibleTokens", ["R", "u", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "G":
            case "GG":
            case "GGG":
                return r.era(e, {
                    width: "abbreviated"
                }) || r.era(e, {
                    width: "narrow"
                });
            case "GGGGG":
                return r.era(e, {
                    width: "narrow"
                });
            case "GGGG":
            default:
                return r.era(e, {
                    width: "wide"
                }) || r.era(e, {
                    width: "abbreviated"
                }) || r.era(e, {
                    width: "narrow"
                })
        }
    }
    set(e, t, r) {
        return t.era = r, e.setFullYear(r, 0, 1), e.setHours(0, 0, 0, 0), e
    }
}
const f = {
        month: /^(1[0-2]|0?\d)/,
        date: /^(3[0-1]|[0-2]?\d)/,
        dayOfYear: /^(36[0-6]|3[0-5]\d|[0-2]?\d?\d)/,
        week: /^(5[0-3]|[0-4]?\d)/,
        hour23h: /^(2[0-3]|[0-1]?\d)/,
        hour24h: /^(2[0-4]|[0-1]?\d)/,
        hour11h: /^(1[0-1]|0?\d)/,
        hour12h: /^(1[0-2]|0?\d)/,
        minute: /^[0-5]?\d/,
        second: /^[0-5]?\d/,
        singleDigit: /^\d/,
        twoDigits: /^\d{1,2}/,
        threeDigits: /^\d{1,3}/,
        fourDigits: /^\d{1,4}/,
        anyDigitsSigned: /^-?\d+/,
        singleDigitSigned: /^-?\d/,
        twoDigitsSigned: /^-?\d{1,2}/,
        threeDigitsSigned: /^-?\d{1,3}/,
        fourDigitsSigned: /^-?\d{1,4}/
    },
    b = {
        basicOptionalMinutes: /^([+-])(\d{2})(\d{2})?|Z/,
        basic: /^([+-])(\d{2})(\d{2})|Z/,
        basicOptionalSeconds: /^([+-])(\d{2})(\d{2})((\d{2}))?|Z/,
        extended: /^([+-])(\d{2}):(\d{2})|Z/,
        extendedOptionalSeconds: /^([+-])(\d{2}):(\d{2})(:(\d{2}))?|Z/
    };

function h(s, n) {
    return s && {
        value: n(s.value),
        rest: s.rest
    }
}

function l(s, n) {
    const e = n.match(s);
    return e ? {
        value: parseInt(e[0], 10),
        rest: n.slice(e[0].length)
    } : null
}

function m(s, n) {
    const e = n.match(s);
    if (!e) return null;
    if (e[0] === "Z") return {
        value: 0,
        rest: n.slice(1)
    };
    const t = e[1] === "+" ? 1 : -1,
        r = e[2] ? parseInt(e[2], 10) : 0,
        a = e[3] ? parseInt(e[3], 10) : 0,
        o = e[5] ? parseInt(e[5], 10) : 0;
    return {
        value: t * (r * ae + a * ie + o * oe),
        rest: n.slice(e[0].length)
    }
}

function K(s) {
    return l(f.anyDigitsSigned, s)
}

function w(s, n) {
    switch (s) {
        case 1:
            return l(f.singleDigit, n);
        case 2:
            return l(f.twoDigits, n);
        case 3:
            return l(f.threeDigits, n);
        case 4:
            return l(f.fourDigits, n);
        default:
            return l(new RegExp("^\\d{1," + s + "}"), n)
    }
}

function O(s, n) {
    switch (s) {
        case 1:
            return l(f.singleDigitSigned, n);
        case 2:
            return l(f.twoDigitsSigned, n);
        case 3:
            return l(f.threeDigitsSigned, n);
        case 4:
            return l(f.fourDigitsSigned, n);
        default:
            return l(new RegExp("^-?\\d{1," + s + "}"), n)
    }
}

function I(s) {
    switch (s) {
        case "morning":
            return 4;
        case "evening":
            return 17;
        case "pm":
        case "noon":
        case "afternoon":
            return 12;
        case "am":
        case "midnight":
        case "night":
        default:
            return 0
    }
}

function $(s, n) {
    const e = n > 0,
        t = e ? n : 1 - n;
    let r;
    if (t <= 50) r = s || 100;
    else {
        const a = t + 50,
            o = Math.trunc(a / 100) * 100,
            y = s >= a % 100;
        r = s + o - (y ? 100 : 0)
    }
    return e ? r : 1 - r
}

function V(s) {
    return s % 400 === 0 || s % 4 === 0 && s % 100 !== 0
}
class xe extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 130);
        i(this, "incompatibleTokens", ["Y", "R", "u", "w", "I", "i", "e", "c", "t", "T"])
    }
    parse(e, t, r) {
        const a = o => ({
            year: o,
            isTwoDigitYear: t === "yy"
        });
        switch (t) {
            case "y":
                return h(w(4, e), a);
            case "yo":
                return h(r.ordinalNumber(e, {
                    unit: "year"
                }), a);
            default:
                return h(w(t.length, e), a)
        }
    }
    validate(e, t) {
        return t.isTwoDigitYear || t.year > 0
    }
    set(e, t, r) {
        const a = e.getFullYear();
        if (r.isTwoDigitYear) {
            const y = $(r.year, a);
            return e.setFullYear(y, 0, 1), e.setHours(0, 0, 0, 0), e
        }
        const o = !("era" in t) || t.era === 1 ? r.year : 1 - r.year;
        return e.setFullYear(o, 0, 1), e.setHours(0, 0, 0, 0), e
    }
}
class be extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 130);
        i(this, "incompatibleTokens", ["y", "R", "u", "Q", "q", "M", "L", "I", "d", "D", "i", "t", "T"])
    }
    parse(e, t, r) {
        const a = o => ({
            year: o,
            isTwoDigitYear: t === "YY"
        });
        switch (t) {
            case "Y":
                return h(w(4, e), a);
            case "Yo":
                return h(r.ordinalNumber(e, {
                    unit: "year"
                }), a);
            default:
                return h(w(t.length, e), a)
        }
    }
    validate(e, t) {
        return t.isTwoDigitYear || t.year > 0
    }
    set(e, t, r, a) {
        const o = J(e, a);
        if (r.isTwoDigitYear) {
            const p = $(r.year, o);
            return e.setFullYear(p, 0, a.firstWeekContainsDate), e.setHours(0, 0, 0, 0), H(e, a)
        }
        const y = !("era" in t) || t.era === 1 ? r.year : 1 - r.year;
        return e.setFullYear(y, 0, a.firstWeekContainsDate), e.setHours(0, 0, 0, 0), H(e, a)
    }
}
class me extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 130);
        i(this, "incompatibleTokens", ["G", "y", "Y", "u", "Q", "q", "M", "L", "w", "d", "D", "e", "c", "t", "T"])
    }
    parse(e, t) {
        return O(t === "R" ? 4 : t.length, e)
    }
    set(e, t, r) {
        const a = D(e, 0);
        return a.setFullYear(r, 0, 4), a.setHours(0, 0, 0, 0), F(a)
    }
}
class pe extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 130);
        i(this, "incompatibleTokens", ["G", "y", "Y", "R", "w", "I", "i", "e", "c", "t", "T"])
    }
    parse(e, t) {
        return O(t === "u" ? 4 : t.length, e)
    }
    set(e, t, r) {
        return e.setFullYear(r, 0, 1), e.setHours(0, 0, 0, 0), e
    }
}
class Te extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 120);
        i(this, "incompatibleTokens", ["Y", "R", "q", "M", "L", "w", "I", "d", "D", "i", "e", "c", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "Q":
            case "QQ":
                return w(t.length, e);
            case "Qo":
                return r.ordinalNumber(e, {
                    unit: "quarter"
                });
            case "QQQ":
                return r.quarter(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.quarter(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "QQQQQ":
                return r.quarter(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "QQQQ":
            default:
                return r.quarter(e, {
                    width: "wide",
                    context: "formatting"
                }) || r.quarter(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.quarter(e, {
                    width: "narrow",
                    context: "formatting"
                })
        }
    }
    validate(e, t) {
        return t >= 1 && t <= 4
    }
    set(e, t, r) {
        return e.setMonth((r - 1) * 3, 1), e.setHours(0, 0, 0, 0), e
    }
}
class De extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 120);
        i(this, "incompatibleTokens", ["Y", "R", "Q", "M", "L", "w", "I", "d", "D", "i", "e", "c", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "q":
            case "qq":
                return w(t.length, e);
            case "qo":
                return r.ordinalNumber(e, {
                    unit: "quarter"
                });
            case "qqq":
                return r.quarter(e, {
                    width: "abbreviated",
                    context: "standalone"
                }) || r.quarter(e, {
                    width: "narrow",
                    context: "standalone"
                });
            case "qqqqq":
                return r.quarter(e, {
                    width: "narrow",
                    context: "standalone"
                });
            case "qqqq":
            default:
                return r.quarter(e, {
                    width: "wide",
                    context: "standalone"
                }) || r.quarter(e, {
                    width: "abbreviated",
                    context: "standalone"
                }) || r.quarter(e, {
                    width: "narrow",
                    context: "standalone"
                })
        }
    }
    validate(e, t) {
        return t >= 1 && t <= 4
    }
    set(e, t, r) {
        return e.setMonth((r - 1) * 3, 1), e.setHours(0, 0, 0, 0), e
    }
}
class ge extends u {
    constructor() {
        super(...arguments);
        i(this, "incompatibleTokens", ["Y", "R", "q", "Q", "L", "w", "I", "D", "i", "e", "c", "t", "T"]);
        i(this, "priority", 110)
    }
    parse(e, t, r) {
        const a = o => o - 1;
        switch (t) {
            case "M":
                return h(l(f.month, e), a);
            case "MM":
                return h(w(2, e), a);
            case "Mo":
                return h(r.ordinalNumber(e, {
                    unit: "month"
                }), a);
            case "MMM":
                return r.month(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.month(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "MMMMM":
                return r.month(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "MMMM":
            default:
                return r.month(e, {
                    width: "wide",
                    context: "formatting"
                }) || r.month(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.month(e, {
                    width: "narrow",
                    context: "formatting"
                })
        }
    }
    validate(e, t) {
        return t >= 0 && t <= 11
    }
    set(e, t, r) {
        return e.setMonth(r, 1), e.setHours(0, 0, 0, 0), e
    }
}
class ke extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 110);
        i(this, "incompatibleTokens", ["Y", "R", "q", "Q", "M", "w", "I", "D", "i", "e", "c", "t", "T"])
    }
    parse(e, t, r) {
        const a = o => o - 1;
        switch (t) {
            case "L":
                return h(l(f.month, e), a);
            case "LL":
                return h(w(2, e), a);
            case "Lo":
                return h(r.ordinalNumber(e, {
                    unit: "month"
                }), a);
            case "LLL":
                return r.month(e, {
                    width: "abbreviated",
                    context: "standalone"
                }) || r.month(e, {
                    width: "narrow",
                    context: "standalone"
                });
            case "LLLLL":
                return r.month(e, {
                    width: "narrow",
                    context: "standalone"
                });
            case "LLLL":
            default:
                return r.month(e, {
                    width: "wide",
                    context: "standalone"
                }) || r.month(e, {
                    width: "abbreviated",
                    context: "standalone"
                }) || r.month(e, {
                    width: "narrow",
                    context: "standalone"
                })
        }
    }
    validate(e, t) {
        return t >= 0 && t <= 11
    }
    set(e, t, r) {
        return e.setMonth(r, 1), e.setHours(0, 0, 0, 0), e
    }
}

function Pe(s, n, e) {
    const t = g(s, e == null ? void 0 : e.in),
        r = S(t, e) - n;
    return t.setDate(t.getDate() - r * 7), g(t, e == null ? void 0 : e.in)
}
class Me extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 100);
        i(this, "incompatibleTokens", ["y", "R", "u", "q", "Q", "M", "L", "I", "d", "D", "i", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "w":
                return l(f.week, e);
            case "wo":
                return r.ordinalNumber(e, {
                    unit: "week"
                });
            default:
                return w(t.length, e)
        }
    }
    validate(e, t) {
        return t >= 1 && t <= 53
    }
    set(e, t, r, a) {
        return H(Pe(e, r, a), a)
    }
}

function _e(s, n, e) {
    const t = g(s, e == null ? void 0 : e.in),
        r = ee(t, e) - n;
    return t.setDate(t.getDate() - r * 7), t
}
class Ye extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 100);
        i(this, "incompatibleTokens", ["y", "Y", "u", "q", "Q", "M", "L", "w", "d", "D", "e", "c", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "I":
                return l(f.week, e);
            case "Io":
                return r.ordinalNumber(e, {
                    unit: "week"
                });
            default:
                return w(t.length, e)
        }
    }
    validate(e, t) {
        return t >= 1 && t <= 53
    }
    set(e, t, r) {
        return F(_e(e, r))
    }
}
const Oe = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
    Ee = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
class He extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 90);
        i(this, "subPriority", 1);
        i(this, "incompatibleTokens", ["Y", "R", "q", "Q", "w", "I", "D", "i", "e", "c", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "d":
                return l(f.date, e);
            case "do":
                return r.ordinalNumber(e, {
                    unit: "date"
                });
            default:
                return w(t.length, e)
        }
    }
    validate(e, t) {
        const r = e.getFullYear(),
            a = V(r),
            o = e.getMonth();
        return a ? t >= 1 && t <= Ee[o] : t >= 1 && t <= Oe[o]
    }
    set(e, t, r) {
        return e.setDate(r), e.setHours(0, 0, 0, 0), e
    }
}
class Ie extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 90);
        i(this, "subpriority", 1);
        i(this, "incompatibleTokens", ["Y", "R", "q", "Q", "M", "L", "w", "I", "d", "E", "i", "e", "c", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "D":
            case "DD":
                return l(f.dayOfYear, e);
            case "Do":
                return r.ordinalNumber(e, {
                    unit: "date"
                });
            default:
                return w(t.length, e)
        }
    }
    validate(e, t) {
        const r = e.getFullYear();
        return V(r) ? t >= 1 && t <= 366 : t >= 1 && t <= 365
    }
    set(e, t, r) {
        return e.setMonth(0, r), e.setHours(0, 0, 0, 0), e
    }
}

function q(s, n, e) {
    var _, P, Y, T;
    const t = re(),
        r = (e == null ? void 0 : e.weekStartsOn) ? ? ((P = (_ = e == null ? void 0 : e.locale) == null ? void 0 : _.options) == null ? void 0 : P.weekStartsOn) ? ? t.weekStartsOn ? ? ((T = (Y = t.locale) == null ? void 0 : Y.options) == null ? void 0 : T.weekStartsOn) ? ? 0,
        a = g(s, e == null ? void 0 : e.in),
        o = a.getDay(),
        p = (n % 7 + 7) % 7,
        k = 7 - r,
        M = n < 0 || n > 6 ? n - (o + k) % 7 : (p + k) % 7 - (o + k) % 7;
    return A(a, M, e)
}
class qe extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 90);
        i(this, "incompatibleTokens", ["D", "i", "e", "c", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "E":
            case "EE":
            case "EEE":
                return r.day(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.day(e, {
                    width: "short",
                    context: "formatting"
                }) || r.day(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "EEEEE":
                return r.day(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "EEEEEE":
                return r.day(e, {
                    width: "short",
                    context: "formatting"
                }) || r.day(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "EEEE":
            default:
                return r.day(e, {
                    width: "wide",
                    context: "formatting"
                }) || r.day(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.day(e, {
                    width: "short",
                    context: "formatting"
                }) || r.day(e, {
                    width: "narrow",
                    context: "formatting"
                })
        }
    }
    validate(e, t) {
        return t >= 0 && t <= 6
    }
    set(e, t, r, a) {
        return e = q(e, r, a), e.setHours(0, 0, 0, 0), e
    }
}
class Le extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 90);
        i(this, "incompatibleTokens", ["y", "R", "u", "q", "Q", "M", "L", "I", "d", "D", "E", "i", "c", "t", "T"])
    }
    parse(e, t, r, a) {
        const o = y => {
            const p = Math.floor((y - 1) / 7) * 7;
            return (y + a.weekStartsOn + 6) % 7 + p
        };
        switch (t) {
            case "e":
            case "ee":
                return h(w(t.length, e), o);
            case "eo":
                return h(r.ordinalNumber(e, {
                    unit: "day"
                }), o);
            case "eee":
                return r.day(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.day(e, {
                    width: "short",
                    context: "formatting"
                }) || r.day(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "eeeee":
                return r.day(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "eeeeee":
                return r.day(e, {
                    width: "short",
                    context: "formatting"
                }) || r.day(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "eeee":
            default:
                return r.day(e, {
                    width: "wide",
                    context: "formatting"
                }) || r.day(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.day(e, {
                    width: "short",
                    context: "formatting"
                }) || r.day(e, {
                    width: "narrow",
                    context: "formatting"
                })
        }
    }
    validate(e, t) {
        return t >= 0 && t <= 6
    }
    set(e, t, r, a) {
        return e = q(e, r, a), e.setHours(0, 0, 0, 0), e
    }
}
class Qe extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 90);
        i(this, "incompatibleTokens", ["y", "R", "u", "q", "Q", "M", "L", "I", "d", "D", "E", "i", "e", "t", "T"])
    }
    parse(e, t, r, a) {
        const o = y => {
            const p = Math.floor((y - 1) / 7) * 7;
            return (y + a.weekStartsOn + 6) % 7 + p
        };
        switch (t) {
            case "c":
            case "cc":
                return h(w(t.length, e), o);
            case "co":
                return h(r.ordinalNumber(e, {
                    unit: "day"
                }), o);
            case "ccc":
                return r.day(e, {
                    width: "abbreviated",
                    context: "standalone"
                }) || r.day(e, {
                    width: "short",
                    context: "standalone"
                }) || r.day(e, {
                    width: "narrow",
                    context: "standalone"
                });
            case "ccccc":
                return r.day(e, {
                    width: "narrow",
                    context: "standalone"
                });
            case "cccccc":
                return r.day(e, {
                    width: "short",
                    context: "standalone"
                }) || r.day(e, {
                    width: "narrow",
                    context: "standalone"
                });
            case "cccc":
            default:
                return r.day(e, {
                    width: "wide",
                    context: "standalone"
                }) || r.day(e, {
                    width: "abbreviated",
                    context: "standalone"
                }) || r.day(e, {
                    width: "short",
                    context: "standalone"
                }) || r.day(e, {
                    width: "narrow",
                    context: "standalone"
                })
        }
    }
    validate(e, t) {
        return t >= 0 && t <= 6
    }
    set(e, t, r, a) {
        return e = q(e, r, a), e.setHours(0, 0, 0, 0), e
    }
}

function Ne(s, n, e) {
    const t = g(s, e == null ? void 0 : e.in),
        r = ue(t, e),
        a = n - r;
    return A(t, a, e)
}
class ve extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 90);
        i(this, "incompatibleTokens", ["y", "Y", "u", "q", "Q", "M", "L", "w", "d", "D", "E", "e", "c", "t", "T"])
    }
    parse(e, t, r) {
        const a = o => o === 0 ? 7 : o;
        switch (t) {
            case "i":
            case "ii":
                return w(t.length, e);
            case "io":
                return r.ordinalNumber(e, {
                    unit: "day"
                });
            case "iii":
                return h(r.day(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.day(e, {
                    width: "short",
                    context: "formatting"
                }) || r.day(e, {
                    width: "narrow",
                    context: "formatting"
                }), a);
            case "iiiii":
                return h(r.day(e, {
                    width: "narrow",
                    context: "formatting"
                }), a);
            case "iiiiii":
                return h(r.day(e, {
                    width: "short",
                    context: "formatting"
                }) || r.day(e, {
                    width: "narrow",
                    context: "formatting"
                }), a);
            case "iiii":
            default:
                return h(r.day(e, {
                    width: "wide",
                    context: "formatting"
                }) || r.day(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.day(e, {
                    width: "short",
                    context: "formatting"
                }) || r.day(e, {
                    width: "narrow",
                    context: "formatting"
                }), a)
        }
    }
    validate(e, t) {
        return t >= 1 && t <= 7
    }
    set(e, t, r) {
        return e = Ne(e, r), e.setHours(0, 0, 0, 0), e
    }
}
class Re extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 80);
        i(this, "incompatibleTokens", ["b", "B", "H", "k", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "a":
            case "aa":
            case "aaa":
                return r.dayPeriod(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.dayPeriod(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "aaaaa":
                return r.dayPeriod(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "aaaa":
            default:
                return r.dayPeriod(e, {
                    width: "wide",
                    context: "formatting"
                }) || r.dayPeriod(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.dayPeriod(e, {
                    width: "narrow",
                    context: "formatting"
                })
        }
    }
    set(e, t, r) {
        return e.setHours(I(r), 0, 0, 0), e
    }
}
class We extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 80);
        i(this, "incompatibleTokens", ["a", "B", "H", "k", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "b":
            case "bb":
            case "bbb":
                return r.dayPeriod(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.dayPeriod(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "bbbbb":
                return r.dayPeriod(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "bbbb":
            default:
                return r.dayPeriod(e, {
                    width: "wide",
                    context: "formatting"
                }) || r.dayPeriod(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.dayPeriod(e, {
                    width: "narrow",
                    context: "formatting"
                })
        }
    }
    set(e, t, r) {
        return e.setHours(I(r), 0, 0, 0), e
    }
}
class Ce extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 80);
        i(this, "incompatibleTokens", ["a", "b", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "B":
            case "BB":
            case "BBB":
                return r.dayPeriod(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.dayPeriod(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "BBBBB":
                return r.dayPeriod(e, {
                    width: "narrow",
                    context: "formatting"
                });
            case "BBBB":
            default:
                return r.dayPeriod(e, {
                    width: "wide",
                    context: "formatting"
                }) || r.dayPeriod(e, {
                    width: "abbreviated",
                    context: "formatting"
                }) || r.dayPeriod(e, {
                    width: "narrow",
                    context: "formatting"
                })
        }
    }
    set(e, t, r) {
        return e.setHours(I(r), 0, 0, 0), e
    }
}
class Be extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 70);
        i(this, "incompatibleTokens", ["H", "K", "k", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "h":
                return l(f.hour12h, e);
            case "ho":
                return r.ordinalNumber(e, {
                    unit: "hour"
                });
            default:
                return w(t.length, e)
        }
    }
    validate(e, t) {
        return t >= 1 && t <= 12
    }
    set(e, t, r) {
        const a = e.getHours() >= 12;
        return a && r < 12 ? e.setHours(r + 12, 0, 0, 0) : !a && r === 12 ? e.setHours(0, 0, 0, 0) : e.setHours(r, 0, 0, 0), e
    }
}
class Ge extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 70);
        i(this, "incompatibleTokens", ["a", "b", "h", "K", "k", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "H":
                return l(f.hour23h, e);
            case "Ho":
                return r.ordinalNumber(e, {
                    unit: "hour"
                });
            default:
                return w(t.length, e)
        }
    }
    validate(e, t) {
        return t >= 0 && t <= 23
    }
    set(e, t, r) {
        return e.setHours(r, 0, 0, 0), e
    }
}
class Xe extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 70);
        i(this, "incompatibleTokens", ["h", "H", "k", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "K":
                return l(f.hour11h, e);
            case "Ko":
                return r.ordinalNumber(e, {
                    unit: "hour"
                });
            default:
                return w(t.length, e)
        }
    }
    validate(e, t) {
        return t >= 0 && t <= 11
    }
    set(e, t, r) {
        return e.getHours() >= 12 && r < 12 ? e.setHours(r + 12, 0, 0, 0) : e.setHours(r, 0, 0, 0), e
    }
}
class Fe extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 70);
        i(this, "incompatibleTokens", ["a", "b", "h", "H", "K", "t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "k":
                return l(f.hour24h, e);
            case "ko":
                return r.ordinalNumber(e, {
                    unit: "hour"
                });
            default:
                return w(t.length, e)
        }
    }
    validate(e, t) {
        return t >= 1 && t <= 24
    }
    set(e, t, r) {
        const a = r <= 24 ? r % 24 : r;
        return e.setHours(a, 0, 0, 0), e
    }
}
class Ae extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 60);
        i(this, "incompatibleTokens", ["t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "m":
                return l(f.minute, e);
            case "mo":
                return r.ordinalNumber(e, {
                    unit: "minute"
                });
            default:
                return w(t.length, e)
        }
    }
    validate(e, t) {
        return t >= 0 && t <= 59
    }
    set(e, t, r) {
        return e.setMinutes(r, 0, 0), e
    }
}
class ze extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 50);
        i(this, "incompatibleTokens", ["t", "T"])
    }
    parse(e, t, r) {
        switch (t) {
            case "s":
                return l(f.second, e);
            case "so":
                return r.ordinalNumber(e, {
                    unit: "second"
                });
            default:
                return w(t.length, e)
        }
    }
    validate(e, t) {
        return t >= 0 && t <= 59
    }
    set(e, t, r) {
        return e.setSeconds(r, 0), e
    }
}
class Ze extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 30);
        i(this, "incompatibleTokens", ["t", "T"])
    }
    parse(e, t) {
        const r = a => Math.trunc(a * Math.pow(10, -t.length + 3));
        return h(w(t.length, e), r)
    }
    set(e, t, r) {
        return e.setMilliseconds(r), e
    }
}
class Ke extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 10);
        i(this, "incompatibleTokens", ["t", "T", "x"])
    }
    parse(e, t) {
        switch (t) {
            case "X":
                return m(b.basicOptionalMinutes, e);
            case "XX":
                return m(b.basic, e);
            case "XXXX":
                return m(b.basicOptionalSeconds, e);
            case "XXXXX":
                return m(b.extendedOptionalSeconds, e);
            case "XXX":
            default:
                return m(b.extended, e)
        }
    }
    set(e, t, r) {
        return t.timestampIsSet ? e : D(e, e.getTime() - z(e) - r)
    }
}
class $e extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 10);
        i(this, "incompatibleTokens", ["t", "T", "X"])
    }
    parse(e, t) {
        switch (t) {
            case "x":
                return m(b.basicOptionalMinutes, e);
            case "xx":
                return m(b.basic, e);
            case "xxxx":
                return m(b.basicOptionalSeconds, e);
            case "xxxxx":
                return m(b.extendedOptionalSeconds, e);
            case "xxx":
            default:
                return m(b.extended, e)
        }
    }
    set(e, t, r) {
        return t.timestampIsSet ? e : D(e, e.getTime() - z(e) - r)
    }
}
class Ve extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 40);
        i(this, "incompatibleTokens", "*")
    }
    parse(e) {
        return K(e)
    }
    set(e, t, r) {
        return [D(e, r * 1e3), {
            timestampIsSet: !0
        }]
    }
}
class je extends u {
    constructor() {
        super(...arguments);
        i(this, "priority", 20);
        i(this, "incompatibleTokens", "*")
    }
    parse(e) {
        return K(e)
    }
    set(e, t, r) {
        return [D(e, r), {
            timestampIsSet: !0
        }]
    }
}
const Ue = {
        G: new ye,
        y: new xe,
        Y: new be,
        R: new me,
        u: new pe,
        Q: new Te,
        q: new De,
        M: new ge,
        L: new ke,
        w: new Me,
        I: new Ye,
        d: new He,
        D: new Ie,
        E: new qe,
        e: new Le,
        c: new Qe,
        i: new ve,
        a: new Re,
        b: new We,
        B: new Ce,
        h: new Be,
        H: new Ge,
        K: new Xe,
        k: new Fe,
        m: new Ae,
        s: new ze,
        S: new Ze,
        X: new Ke,
        x: new $e,
        t: new Ve,
        T: new je
    },
    Je = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g,
    Se = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g,
    er = /^'([^]*?)'?$/,
    rr = /''/g,
    tr = /\S/,
    sr = /[a-zA-Z]/;

function dr(s, n, e, t) {
    var Q, N, v, R;
    const r = () => D(e, NaN),
        a = ce(),
        o = a.locale ? ? te,
        y = a.firstWeekContainsDate ? ? ((N = (Q = a.locale) == null ? void 0 : Q.options) == null ? void 0 : N.firstWeekContainsDate) ? ? 1,
        p = a.weekStartsOn ? ? ((R = (v = a.locale) == null ? void 0 : v.options) == null ? void 0 : R.weekStartsOn) ? ? 0;
    if (!n) return s ? r() : g(e, t == null ? void 0 : t.in);
    const k = {
            firstWeekContainsDate: y,
            weekStartsOn: p,
            locale: o
        },
        M = [new he(t == null ? void 0 : t.in, e)],
        _ = n.match(Se).map(c => {
            const d = c[0];
            if (d in G) {
                const x = G[d];
                return x(c, o.formatLong)
            }
            return c
        }).join("").match(Je),
        P = [];
    for (let c of _) {
        se(c) && X(c, n, s), ne(c) && X(c, n, s);
        const d = c[0],
            x = Ue[d];
        if (x) {
            const {
                incompatibleTokens: W
            } = x;
            if (Array.isArray(W)) {
                const C = P.find(B => W.includes(B.token) || B.token === d);
                if (C) throw new RangeError(`The format string mustn't contain \`${C.fullToken}\` and \`${c}\` at the same time`)
            } else if (x.incompatibleTokens === "*" && P.length > 0) throw new RangeError(`The format string mustn't contain \`${c}\` and any other token at the same time`);
            P.push({
                token: d,
                fullToken: c
            });
            const E = x.run(s, c, o.match, k);
            if (!E) return r();
            M.push(E.setter), s = E.rest
        } else {
            if (d.match(sr)) throw new RangeError("Format string contains an unescaped latin alphabet character `" + d + "`");
            if (c === "''" ? c = "'" : d === "'" && (c = nr(c)), s.indexOf(c) === 0) s = s.slice(c.length);
            else return r()
        }
    }
    if (s.length > 0 && tr.test(s)) return r();
    const Y = M.map(c => c.priority).sort((c, d) => d - c).filter((c, d, x) => x.indexOf(c) === d).map(c => M.filter(d => d.priority === c).sort((d, x) => x.subPriority - d.subPriority)).map(c => c[0]);
    let T = g(e, t == null ? void 0 : t.in);
    if (isNaN(+T)) return r();
    const L = {};
    for (const c of Y) {
        if (!c.validate(T, k)) return r();
        const d = c.set(T, L, k);
        Array.isArray(d) ? (T = d[0], Object.assign(L, d[1])) : T = d
    }
    return T
}

function nr(s) {
    return s.match(er)[1].replace(rr, "'")
}
export {
    dr as p
};