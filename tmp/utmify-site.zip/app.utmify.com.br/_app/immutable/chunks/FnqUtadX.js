var D = Object.defineProperty;
var y = (a, t, e) => t in a ? D(a, t, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: e
}) : a[t] = e;
var h = (a, t, e) => y(a, typeof t != "symbol" ? t + "" : t, e);
import {
    D as o
} from "./Dd0nEcXu.js";
import {
    t as l,
    c as u,
    a as M
} from "./DwsiLpv2.js";

function m(a, t, e) {
    const s = l(a, e == null ? void 0 : e.in);
    return isNaN(t) ? u((e == null ? void 0 : e.in) || a, NaN) : (t && s.setDate(s.getDate() + t), s)
}

function T(a, t, e) {
    const s = l(a, e == null ? void 0 : e.in);
    if (isNaN(t)) return u(a, NaN);
    if (!t) return s;
    const r = s.getDate(),
        n = u(a, s.getTime());
    n.setMonth(s.getMonth() + t + 1, 0);
    const c = n.getDate();
    return r >= c ? n : (s.setFullYear(n.getFullYear(), n.getMonth(), r), s)
}

function d(a, t, e) {
    return m(a, -t, e)
}

function f(a, t, e) {
    return M(a, -1)
}
class i {
    constructor(t, e, s) {
        h(this, "from");
        h(this, "to");
        const r = (s == null ? void 0 : s.resetTime) ? ? !0,
            n = s == null ? void 0 : s.timeZone;
        this.from = t, this.to = e, r && (this.from = o.resetedTimeDate(this.from), this.to = f(o.resetedTimeDate(m(this.to, 1)))), n && (this.from = o.inTimeZone(this.from, n), this.to = o.inTimeZone(this.to, n))
    }
    static custom(t, e, s) {
        return s ? new i(t, e, {
            resetTime: !1,
            timeZone: s
        }) : new i(t, e)
    }
    static todayWithOffset(t) {
        const e = o.resetedTimeFromHoursOffset(new Date, t),
            s = m(e, 1),
            r = f(s);
        return new i(e, r, {
            resetTime: !1
        })
    }
    static yesterdayWithOffset(t) {
        const e = o.resetedTimeFromHoursOffset(d(new Date, 1), t),
            s = m(e, 1),
            r = f(s);
        return new i(e, r, {
            resetTime: !1
        })
    }
    static lastSevenDaysWithOffset(t) {
        const e = o.resetedTimeFromHoursOffset(d(new Date, 6), t),
            s = m(e, 7),
            r = f(s);
        return new i(e, r, {
            resetTime: !1
        })
    }
    static thisMonthWithOffset(t) {
        const e = o.resetedTimeFromHoursOffset(new Date, t),
            s = o.setDateForHoursOffset(e, t, {
                date: 1
            }),
            r = T(s, 1),
            n = f(r);
        return new i(s, n, {
            resetTime: !1
        })
    }
    static lastMonthWithOffset(t) {
        const e = o.getDateInfoForHoursOffset(new Date, t).date,
            s = o.resetedTimeFromHoursOffset(d(new Date, e), t),
            r = o.setDateForHoursOffset(s, t, {
                date: 1
            }),
            n = T(r, 1),
            c = f(n);
        return new i(r, c, {
            resetTime: !1
        })
    }
    static thisWeekWithOffset(t) {
        const e = o.getDateInfoForHoursOffset(new Date, t).day,
            s = d(new Date, e),
            r = o.resetedTimeFromHoursOffset(s, t),
            n = m(r, 7),
            c = f(n);
        return new i(r, c, {
            resetTime: !1
        })
    }
    static lastWeekWithOffset(t) {
        const e = o.getDateInfoForHoursOffset(new Date, t).day,
            s = d(new Date, 7 + e),
            r = o.resetedTimeFromHoursOffset(s, t),
            n = m(r, 7),
            c = f(n);
        return new i(r, c, {
            resetTime: !1
        })
    }
    daysInRange() {
        const t = Math.abs(this.to.getTime() - this.from.getTime());
        return Math.ceil(t / (1e3 * 60 * 60 * 24))
    }
    toMapISO() {
        return {
            from: this.from.toISOString(),
            to: this.to.toISOString()
        }
    }
}
export {
    i as D, T as a, m as b, d as s
};