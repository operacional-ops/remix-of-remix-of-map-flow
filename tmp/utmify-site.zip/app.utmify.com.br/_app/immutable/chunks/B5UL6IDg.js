import {
    U as e
} from "./B5WePDbK.js";
class u {
    static async execute(s) {
        var a;
        const t = await e.post("/orders/filters", {
            dashboardId: s.dashboardId
        }, {
            token: ((a = s.authData) == null ? void 0 : a.token) ? ? ""
        });
        if (t.statusCode === 401) return {
            status: "UNAUTHORIZED"
        };
        if (t.statusCode === 200) {
            const r = t.data;
            return {
                status: "SUCCESS",
                data: {
                    productNames: r.productNames,
                    platforms: r.platforms
                }
            }
        }
        return {
            status: "UNKNOWN"
        }
    }
}
export {
    u as G
};