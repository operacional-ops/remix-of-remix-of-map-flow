import {
    U as e
} from "./B5WePDbK.js";
class u {
    static async execute(s) {
        var a;
        const t = await e.put("/dashboards/resumo-items/set", {
            dashboardId: s.dashboardId,
            resumoItems: s.resumoItems
        }, {
            token: ((a = s.authData) == null ? void 0 : a.token) ? ? ""
        });
        return t.statusCode === 401 ? {
            status: "UNAUTHORIZED"
        } : t.statusCode === 200 ? {
            status: "SUCCESS",
            resumoItems: t.data
        } : {
            status: "UNKNOWN"
        }
    }
}
export {
    u as S
};