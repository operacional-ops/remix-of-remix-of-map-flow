import {
    S as t
} from "./DwsiLpv2.js";
const g = t.createStore("theme", null),
    e = o => (o == null ? void 0 : o.theme) === "Light" ? "/logo/logo-white.png" : "/logo/logo-dark.png";
export {
    e as g, g as t
};