import {
    N as v,
    O as k,
    P as b,
    B as S
} from "./DDNnt9XD.js";

function x(a) {
    const r = a - 1;
    return r * r * r + 1
}

function U(a, {
    delay: r = 0,
    duration: i = 400,
    easing: c = k
} = {}) {
    const d = +getComputedStyle(a).opacity;
    return {
        delay: r,
        duration: i,
        easing: c,
        css: n => `opacity: ${n*d}`
    }
}

function q(a, {
    delay: r = 0,
    duration: i = 400,
    easing: c = x,
    x: d = 0,
    y: n = 0,
    opacity: p = 0
} = {}) {
    const e = getComputedStyle(a),
        l = +e.opacity,
        o = e.transform === "none" ? "" : e.transform,
        t = l * (1 - p),
        [f, y] = v(d),
        [u, g] = v(n);
    return {
        delay: r,
        duration: i,
        easing: c,
        css: ($, h) => `
			transform: ${o} translate(${(1-$)*f}${y}, ${(1-$)*u}${g});
			opacity: ${l-t*h}`
    }
}

function O(a, {
    delay: r = 0,
    duration: i = 400,
    easing: c = x,
    axis: d = "y"
} = {}) {
    const n = getComputedStyle(a),
        p = +n.opacity,
        e = d === "y" ? "height" : "width",
        l = parseFloat(n[e]),
        o = d === "y" ? ["top", "bottom"] : ["left", "right"],
        t = o.map(s => `${s[0].toUpperCase()}${s.slice(1)}`),
        f = parseFloat(n[`padding${t[0]}`]),
        y = parseFloat(n[`padding${t[1]}`]),
        u = parseFloat(n[`margin${t[0]}`]),
        g = parseFloat(n[`margin${t[1]}`]),
        $ = parseFloat(n[`border${t[0]}Width`]),
        h = parseFloat(n[`border${t[1]}Width`]);
    return {
        delay: r,
        duration: i,
        easing: c,
        css: s => `overflow: hidden;opacity: ${Math.min(s*20,1)*p};${e}: ${s*l}px;padding-${o[0]}: ${s*f}px;padding-${o[1]}: ${s*y}px;margin-${o[0]}: ${s*u}px;margin-${o[1]}: ${s*g}px;border-${o[0]}-width: ${s*$}px;border-${o[1]}-width: ${s*h}px;`
    }
}

function R({
    fallback: a,
    ...r
}) {
    const i = new Map,
        c = new Map;

    function d(p, e, l) {
        const {
            delay: o = 0,
            duration: t = _ => Math.sqrt(_) * 30,
            easing: f = x
        } = b(b({}, r), l), y = p.getBoundingClientRect(), u = e.getBoundingClientRect(), g = y.left - u.left, $ = y.top - u.top, h = y.width / u.width, s = y.height / u.height, C = Math.sqrt(g * g + $ * $), m = getComputedStyle(e), F = m.transform === "none" ? "" : m.transform, M = +m.opacity;
        return {
            delay: o,
            duration: S(t) ? t(C) : t,
            easing: f,
            css: (_, w) => `
				opacity: ${_*M};
				transform-origin: top left;
				transform: ${F} translate(${w*g}px,${w*$}px) scale(${_+(1-_)*h}, ${_+(1-_)*s});
			`
        }
    }

    function n(p, e, l) {
        return (o, t) => (p.set(t.key, o), () => {
            if (e.has(t.key)) {
                const f = e.get(t.key);
                return e.delete(t.key), d(f, o, t)
            }
            return p.delete(t.key), a && a(o, t, l)
        })
    }
    return [n(c, i, !1), n(i, c, !0)]
}
export {
    q as a, x as b, R as c, U as f, O as s
};