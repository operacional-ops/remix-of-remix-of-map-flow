import {
    n as i
} from "./CPi_hQE5.js";
import {
    d as r
} from "./BCpwIhRd.js";

function l(n, s, t) {
    const [e, c] = i(t == null ? void 0 : t.in, n, s), o = f(e, c), g = Math.abs(r(e, c));
    e.setDate(e.getDate() - o * g);
    const d = +(f(e, c) === -o),
        u = o * (g - d);
    return u === 0 ? 0 : u
}

function f(n, s) {
    const t = n.getFullYear() - s.getFullYear() || n.getMonth() - s.getMonth() || n.getDate() - s.getDate() || n.getHours() - s.getHours() || n.getMinutes() - s.getMinutes() || n.getSeconds() - s.getSeconds() || n.getMilliseconds() - s.getMilliseconds();
    return t < 0 ? -1 : t > 0 ? 1 : t
}
export {
    l as d
};