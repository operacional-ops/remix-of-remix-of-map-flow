import {
    s as T,
    n as k,
    d,
    y as v,
    m as s,
    i as y,
    b as S,
    q as w,
    c as f,
    e as D,
    h as _,
    k as L,
    x as z
} from "./DDNnt9XD.js";
import {
    S as B,
    i as E
} from "./qWASNxYk.js";
import {
    E as q,
    u as I
} from "./B5WePDbK.js";
import {
    t as M
} from "./BszCcFfc.js";

function A(t) {
    let l, a, r, n, g, m, h, i, c;
    return {
        c() {
            l = _("div"), a = _("a"), r = _("img"), this.h()
        },
        l(o) {
            l = f(o, "DIV", {
                class: !0
            });
            var e = D(l);
            a = f(e, "A", {
                class: !0,
                id: !0
            });
            var u = D(a);
            r = f(u, "IMG", {
                src: !0,
                alt: !0
            }), u.forEach(d), e.forEach(d), this.h()
        },
        h() {
            var o, e;
            v(r.src, n = t[3] === "Dark" || ((o = t[4]) == null ? void 0 : o.theme) === "Dark" ? "/logo/logo-dark.png" : "/logo/logo-white.png") || s(r, "src", n), s(r, "alt", "UTMify logo"), s(a, "class", g = t[2] ? "navbar-brand" : ""), s(a, "id", m = ((e = t[4]) == null ? void 0 : e.theme) === "Dark" ? "brandLogo-dark" : "brandLogo-light"), s(l, "class", h = t[1] === "small" ? "w-[50%] mx-auto" : "")
        },
        m(o, e) {
            y(o, l, e), S(l, a), S(a, r), t[7](a), i || (c = w(a, "click", t[6]), i = !0)
        },
        p(o, [e]) {
            var u, b;
            e & 24 && !v(r.src, n = o[3] === "Dark" || ((u = o[4]) == null ? void 0 : u.theme) === "Dark" ? "/logo/logo-dark.png" : "/logo/logo-white.png") && s(r, "src", n), e & 4 && g !== (g = o[2] ? "navbar-brand" : "") && s(a, "class", g), e & 16 && m !== (m = ((b = o[4]) == null ? void 0 : b.theme) === "Dark" ? "brandLogo-dark" : "brandLogo-light") && s(a, "id", m), e & 2 && h !== (h = o[1] === "small" ? "w-[50%] mx-auto" : "") && s(l, "class", h)
        },
        i: k,
        o: k,
        d(o) {
            o && d(l), t[7](null), i = !1, c()
        }
    }
}

function C(t, l, a) {
    let r, n;
    L(t, M, e => a(4, r = e)), L(t, I, e => a(5, n = e));
    let {
        size: g = "large"
    } = l, {
        navbarBrandStyle: m = !1
    } = l, {
        logoTheme: h = "Light"
    } = l, {
        logo: i = null
    } = l;
    const c = () => q.navigateToStart(n);

    function o(e) {
        z[e ? "unshift" : "push"](() => {
            i = e, a(0, i)
        })
    }
    return t.$$set = e => {
        "size" in e && a(1, g = e.size), "navbarBrandStyle" in e && a(2, m = e.navbarBrandStyle), "logoTheme" in e && a(3, h = e.logoTheme), "logo" in e && a(0, i = e.logo)
    }, [i, g, m, h, r, n, c, o]
}
class F extends B {
    constructor(l) {
        super(), E(this, l, C, A, T, {
            size: 1,
            navbarBrandStyle: 2,
            logoTheme: 3,
            logo: 0
        })
    }
}
export {
    F as L
};