import {
    t as c,
    m
} from "./DwsiLpv2.js";
import {
    n as o
} from "./CPi_hQE5.js";

function s(a) {
    const e = c(a),
        t = new Date(Date.UTC(e.getFullYear(), e.getMonth(), e.getDate(), e.getHours(), e.getMinutes(), e.getSeconds(), e.getMilliseconds()));
    return t.setUTCFullYear(e.getFullYear()), +a - +t
}

function l(a, e) {
    const t = c(a, e == null ? void 0 : e.in);
    return t.setHours(0, 0, 0, 0), t
}

function y(a, e, t) {
    const [i, u] = o(t == null ? void 0 : t.in, a, e), r = l(i), n = l(u), D = +r - s(r), f = +n - s(n);
    return Math.round((D - f) / m)
}
export {
    y as d, s as g, l as s
};