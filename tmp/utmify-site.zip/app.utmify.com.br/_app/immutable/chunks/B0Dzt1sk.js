var he = Object.defineProperty;
var pe = (t, e, n) => e in t ? he(t, e, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: n
}) : t[e] = n;
var U = (t, e, n) => pe(t, typeof e != "symbol" ? e + "" : e, n);
import {
    v as jt,
    W as Q
} from "./DDNnt9XD.js";
import {
    w as bt
} from "./BKn_unzl.js";
class kt {
    constructor(e, n) {
        this.status = e, typeof n == "string" ? this.body = {
            message: n
        } : n ? this.body = n : this.body = {
            message: `Error: ${e}`
        }
    }
    toString() {
        return JSON.stringify(this.body)
    }
}
class Et {
    constructor(e, n) {
        this.status = e, this.location = n
    }
}
class St extends Error {
    constructor(e, n, r) {
        super(r), this.status = e, this.text = n
    }
}
new URL("sveltekit-internal://");

function ge(t, e) {
    return t === "/" || e === "ignore" ? t : e === "never" ? t.endsWith("/") ? t.slice(0, -1) : t : e === "always" && !t.endsWith("/") ? t + "/" : t
}

function me(t) {
    return t.split("%25").map(decodeURI).join("%25")
}

function _e(t) {
    for (const e in t) t[e] = decodeURIComponent(t[e]);
    return t
}

function dt({
    href: t
}) {
    return t.split("#")[0]
}

function we(...t) {
    let e = 5381;
    for (const n of t)
        if (typeof n == "string") {
            let r = n.length;
            for (; r;) e = e * 33 ^ n.charCodeAt(--r)
        } else if (ArrayBuffer.isView(n)) {
        const r = new Uint8Array(n.buffer, n.byteOffset, n.byteLength);
        let a = r.length;
        for (; a;) e = e * 33 ^ r[--a]
    } else throw new TypeError("value must be a string or TypedArray");
    return (e >>> 0).toString(36)
}
new TextEncoder;
new TextDecoder;

function ve(t) {
    const e = atob(t),
        n = new Uint8Array(e.length);
    for (let r = 0; r < e.length; r++) n[r] = e.charCodeAt(r);
    return n
}
const ye = window.fetch;
window.fetch = (t, e) => ((t instanceof Request ? t.method : (e == null ? void 0 : e.method) || "GET") !== "GET" && K.delete(Rt(t)), ye(t, e));
const K = new Map;

function be(t, e) {
    const n = Rt(t, e),
        r = document.querySelector(n);
    if (r != null && r.textContent) {
        r.remove();
        let {
            body: a,
            ...s
        } = JSON.parse(r.textContent);
        const o = r.getAttribute("data-ttl");
        return o && K.set(n, {
            body: a,
            init: s,
            ttl: 1e3 * Number(o)
        }), r.getAttribute("data-b64") !== null && (a = ve(a)), Promise.resolve(new Response(a, s))
    }
    return window.fetch(t, e)
}

function ke(t, e, n) {
    if (K.size > 0) {
        const r = Rt(t, n),
            a = K.get(r);
        if (a) {
            if (performance.now() < a.ttl && ["default", "force-cache", "only-if-cached", void 0].includes(n == null ? void 0 : n.cache)) return new Response(a.body, a.init);
            K.delete(r)
        }
    }
    return window.fetch(e, n)
}

function Rt(t, e) {
    let r = `script[data-sveltekit-fetched][data-url=${JSON.stringify(t instanceof Request?t.url:t)}]`;
    if (e != null && e.headers || e != null && e.body) {
        const a = [];
        e.headers && a.push([...new Headers(e.headers)].join(",")), e.body && (typeof e.body == "string" || ArrayBuffer.isView(e.body)) && a.push(e.body), r += `[data-hash="${we(...a)}"]`
    }
    return r
}
const Ee = /^(\[)?(\.\.\.)?(\w+)(?:=(\w+))?(\])?$/;

function Se(t) {
    const e = [];
    return {
        pattern: t === "/" ? /^\/$/ : new RegExp(`^${xe(t).map(r=>{const a=/^\[\.\.\.(\w+)(?:=(\w+))?\]$/.exec(r);if(a)return e.push({name:a[1],matcher:a[2],optional:!1,rest:!0,chained:!0}),"(?:/([^]*))?";const s=/^\[\[(\w+)(?:=(\w+))?\]\]$/.exec(r);if(s)return e.push({name:s[1],matcher:s[2],optional:!0,rest:!1,chained:!0}),"(?:/([^/]+))?";if(!r)return;const o=r.split(/\[(.+?)\](?!\])/);return"/"+o.map((c,l)=>{if(l%2){if(c.startsWith("x+"))return ht(String.fromCharCode(parseInt(c.slice(2),16)));if(c.startsWith("u+"))return ht(String.fromCharCode(...c.slice(2).split("-").map(_=>parseInt(_,16))));const d=Ee.exec(c),[,u,v,f,h]=d;return e.push({name:f,matcher:h,optional:!!u,rest:!!v,chained:v?l===1&&o[0]==="":!1}),v?"([^]*?)":u?"([^/]*)?":"([^/]+?)"}return ht(c)}).join("")}).join("")}/?$`),
        params: e
    }
}

function Re(t) {
    return t !== "" && !/^\([^)]+\)$/.test(t)
}

function xe(t) {
    return t.slice(1).split("/").filter(Re)
}

function Le(t, e, n) {
    const r = {},
        a = t.slice(1),
        s = a.filter(i => i !== void 0);
    let o = 0;
    for (let i = 0; i < e.length; i += 1) {
        const c = e[i];
        let l = a[i - o];
        if (c.chained && c.rest && o && (l = a.slice(i - o, i + 1).filter(d => d).join("/"), o = 0), l === void 0) {
            c.rest && (r[c.name] = "");
            continue
        }
        if (!c.matcher || n[c.matcher](l)) {
            r[c.name] = l;
            const d = e[i + 1],
                u = a[i + 1];
            d && !d.rest && d.optional && u && c.chained && (o = 0), !d && !u && Object.keys(r).length === s.length && (o = 0);
            continue
        }
        if (c.optional && c.chained) {
            o++;
            continue
        }
        return
    }
    if (!o) return r
}

function ht(t) {
    return t.normalize().replace(/[[\]]/g, "\\$&").replace(/%/g, "%25").replace(/\//g, "%2[Ff]").replace(/\?/g, "%3[Ff]").replace(/#/g, "%23").replace(/[.*+?^${}()|\\]/g, "\\$&")
}

function Ue({
    nodes: t,
    server_loads: e,
    dictionary: n,
    matchers: r
}) {
    const a = new Set(e);
    return Object.entries(n).map(([i, [c, l, d]]) => {
        const {
            pattern: u,
            params: v
        } = Se(i), f = {
            id: i,
            exec: h => {
                const _ = u.exec(h);
                if (_) return Le(_, v, r)
            },
            errors: [1, ...d || []].map(h => t[h]),
            layouts: [0, ...l || []].map(o),
            leaf: s(c)
        };
        return f.errors.length = f.layouts.length = Math.max(f.errors.length, f.layouts.length), f
    });

    function s(i) {
        const c = i < 0;
        return c && (i = ~i), [c, t[i]]
    }

    function o(i) {
        return i === void 0 ? i : [a.has(i), t[i]]
    }
}

function Gt(t, e = JSON.parse) {
    try {
        return e(sessionStorage[t])
    } catch {}
}

function Nt(t, e, n = JSON.stringify) {
    const r = n(e);
    try {
        sessionStorage[t] = r
    } catch {}
}
var Wt;
const L = ((Wt = globalThis.__sveltekit_8ycbvg) == null ? void 0 : Wt.base) ? ? "";
var Ft;
const Ae = ((Ft = globalThis.__sveltekit_8ycbvg) == null ? void 0 : Ft.assets) ? ? L ? ? "",
    Te = "1771276923299",
    Yt = "sveltekit:snapshot",
    zt = "sveltekit:scroll",
    Ht = "sveltekit:states",
    $e = "sveltekit:pageurl",
    V = "sveltekit:history",
    W = "sveltekit:navigation",
    P = {
        tap: 1,
        hover: 2,
        viewport: 3,
        eager: 4,
        off: -1,
        false: -1
    },
    it = location.origin;

function xt(t) {
    if (t instanceof URL) return t;
    let e = document.baseURI;
    if (!e) {
        const n = document.getElementsByTagName("base");
        e = n.length ? n[0].href : document.URL
    }
    return new URL(t, e)
}

function ct() {
    return {
        x: pageXOffset,
        y: pageYOffset
    }
}

function D(t, e) {
    return t.getAttribute(`data-sveltekit-${e}`)
}
const Dt = { ...P,
    "": P.hover
};

function Jt(t) {
    let e = t.assignedSlot ? ? t.parentNode;
    return (e == null ? void 0 : e.nodeType) === 11 && (e = e.host), e
}

function Xt(t, e) {
    for (; t && t !== e;) {
        if (t.nodeName.toUpperCase() === "A" && t.hasAttribute("href")) return t;
        t = Jt(t)
    }
}

function mt(t, e, n) {
    let r;
    try {
        if (r = new URL(t instanceof SVGAElement ? t.href.baseVal : t.href, document.baseURI), n && r.hash.match(/^#[^/]/)) {
            const i = location.hash.split("#")[1] || "/";
            r.hash = `#${i}${r.hash}`
        }
    } catch {}
    const a = t instanceof SVGAElement ? t.target.baseVal : t.target,
        s = !r || !!a || lt(r, e, n) || (t.getAttribute("rel") || "").split(/\s+/).includes("external"),
        o = (r == null ? void 0 : r.origin) === it && t.hasAttribute("download");
    return {
        url: r,
        external: s,
        target: a,
        download: o
    }
}

function Z(t) {
    let e = null,
        n = null,
        r = null,
        a = null,
        s = null,
        o = null,
        i = t;
    for (; i && i !== document.documentElement;) r === null && (r = D(i, "preload-code")), a === null && (a = D(i, "preload-data")), e === null && (e = D(i, "keepfocus")), n === null && (n = D(i, "noscroll")), s === null && (s = D(i, "reload")), o === null && (o = D(i, "replacestate")), i = Jt(i);

    function c(l) {
        switch (l) {
            case "":
            case "true":
                return !0;
            case "off":
            case "false":
                return !1;
            default:
                return
        }
    }
    return {
        preload_code: Dt[r ? ? "off"],
        preload_data: Dt[a ? ? "off"],
        keepfocus: c(e),
        noscroll: c(n),
        reload: c(s),
        replace_state: c(o)
    }
}

function Vt(t) {
    const e = bt(t);
    let n = !0;

    function r() {
        n = !0, e.update(o => o)
    }

    function a(o) {
        n = !1, e.set(o)
    }

    function s(o) {
        let i;
        return e.subscribe(c => {
            (i === void 0 || n && c !== i) && o(i = c)
        })
    }
    return {
        notify: r,
        set: a,
        subscribe: s
    }
}
const Qt = {
    v: () => {}
};

function Ie() {
    const {
        set: t,
        subscribe: e
    } = bt(!1);
    let n;
    async function r() {
        clearTimeout(n);
        try {
            const a = await fetch(`${Ae}/_app/version.json`, {
                headers: {
                    pragma: "no-cache",
                    "cache-control": "no-cache"
                }
            });
            if (!a.ok) return !1;
            const o = (await a.json()).version !== Te;
            return o && (t(!0), Qt.v(), clearTimeout(n)), o
        } catch {
            return !1
        }
    }
    return {
        subscribe: e,
        check: r
    }
}

function lt(t, e, n) {
    return t.origin !== it || !t.pathname.startsWith(e) ? !0 : n ? t.pathname !== location.pathname : !1
}

function sn(t) {}
const Zt = new Set(["load", "prerender", "csr", "ssr", "trailingSlash", "config"]);
[...Zt];
const Oe = new Set([...Zt]);
[...Oe];

function Pe(t) {
    return t.filter(e => e != null)
}

function Lt(t) {
    return t instanceof kt || t instanceof St ? t.status : 500
}

function Ce(t) {
    return t instanceof St ? t.text : "Internal Error"
}
let S, F, pt;
const je = jt.toString().includes("$$") || /function \w+\(\) \{\}/.test(jt.toString());
je ? (S = {
    data: {},
    form: null,
    error: null,
    params: {},
    route: {
        id: null
    },
    state: {},
    status: -1,
    url: new URL("https://example.com")
}, F = {
    current: null
}, pt = {
    current: !1
}) : (S = new class {
    constructor() {
        U(this, "data", $state.raw({}));
        U(this, "form", $state.raw(null));
        U(this, "error", $state.raw(null));
        U(this, "params", $state.raw({}));
        U(this, "route", $state.raw({
            id: null
        }));
        U(this, "state", $state.raw({}));
        U(this, "status", $state.raw(-1));
        U(this, "url", $state.raw(new URL("https://example.com")))
    }
}, F = new class {
    constructor() {
        U(this, "current", $state.raw(null))
    }
}, pt = new class {
    constructor() {
        U(this, "current", $state.raw(!1))
    }
}, Qt.v = () => pt.current = !0);

function Ne(t) {
    Object.assign(S, t)
}
const De = new Set(["icon", "shortcut icon", "apple-touch-icon"]),
    j = Gt(zt) ? ? {},
    G = Gt(Yt) ? ? {},
    O = {
        url: Vt({}),
        page: Vt({}),
        navigating: bt(null),
        updated: Ie()
    };

function Ut(t) {
    j[t] = ct()
}

function Ve(t, e) {
    let n = t + 1;
    for (; j[n];) delete j[n], n += 1;
    for (n = e + 1; G[n];) delete G[n], n += 1
}

function Y(t, e = !1) {
    return e ? location.replace(t.href) : location.href = t.href, new Promise(() => {})
}
async function te() {
    if ("serviceWorker" in navigator) {
        const t = await navigator.serviceWorker.getRegistration(L || "/");
        t && await t.update()
    }
}

function qt() {}
let At, _t, tt, T, wt, b;
const et = [],
    nt = [];
let w = null;

function vt() {
    var t;
    (t = w == null ? void 0 : w.fork) == null || t.then(e => e == null ? void 0 : e.discard()), w = null
}
const X = new Map,
    ee = new Set,
    qe = new Set,
    M = new Set;
let m = {
        branch: [],
        error: null,
        url: null
    },
    ne = !1,
    at = !1,
    Bt = !0,
    z = !1,
    B = !1,
    ae = !1,
    Tt = !1,
    re, E, x, C;
const rt = new Set,
    Kt = new Map;
async function un(t, e, n) {
    var s, o, i, c, l;
    (s = globalThis.__sveltekit_8ycbvg) != null && s.data && globalThis.__sveltekit_8ycbvg.data, document.URL !== location.href && (location.href = location.href), b = t, await ((i = (o = t.hooks).init) == null ? void 0 : i.call(o)), At = Ue(t), T = document.documentElement, wt = e, _t = t.nodes[0], tt = t.nodes[1], _t(), tt(), E = (c = history.state) == null ? void 0 : c[V], x = (l = history.state) == null ? void 0 : l[W], E || (E = x = Date.now(), history.replaceState({ ...history.state,
        [V]: E,
        [W]: x
    }, ""));
    const r = j[E];

    function a() {
        r && (history.scrollRestoration = "manual", scrollTo(r.x, r.y))
    }
    n ? (a(), await Ze(wt, n)) : (await q({
        type: "enter",
        url: xt(b.hash ? nn(new URL(location.href)) : location.href),
        replace_state: !0
    }), a()), Qe()
}

function Be() {
    et.length = 0, Tt = !1
}

function oe(t) {
    nt.some(e => e == null ? void 0 : e.snapshot) && (G[t] = nt.map(e => {
        var n;
        return (n = e == null ? void 0 : e.snapshot) == null ? void 0 : n.capture()
    }))
}

function se(t) {
    var e;
    (e = G[t]) == null || e.forEach((n, r) => {
        var a, s;
        (s = (a = nt[r]) == null ? void 0 : a.snapshot) == null || s.restore(n)
    })
}

function Mt() {
    Ut(E), Nt(zt, j), oe(x), Nt(Yt, G)
}
async function ie(t, e, n, r) {
    let a;
    e.invalidateAll && vt(), await q({
        type: "goto",
        url: xt(t),
        keepfocus: e.keepFocus,
        noscroll: e.noScroll,
        replace_state: e.replaceState,
        state: e.state,
        redirect_count: n,
        nav_token: r,
        accept: () => {
            e.invalidateAll && (Tt = !0, a = [...Kt.keys()]), e.invalidate && e.invalidate.forEach(Xe)
        }
    }), e.invalidateAll && Q().then(Q).then(() => {
        Kt.forEach(({
            resource: s
        }, o) => {
            var i;
            a != null && a.includes(o) && ((i = s.refresh) == null || i.call(s))
        })
    })
}
async function Ke(t) {
    if (t.id !== (w == null ? void 0 : w.id)) {
        vt();
        const e = {};
        rt.add(e), w = {
            id: t.id,
            token: e,
            promise: le({ ...t,
                preload: e
            }).then(n => (rt.delete(e), n.type === "loaded" && n.state.error && vt(), n)),
            fork: null
        }
    }
    return w.promise
}
async function gt(t) {
    var n;
    const e = (n = await ft(t, !1)) == null ? void 0 : n.route;
    e && await Promise.all([...e.layouts, e.leaf].map(r => r == null ? void 0 : r[1]()))
}
async function ce(t, e, n) {
    var a;
    m = t.state;
    const r = document.querySelector("style[data-sveltekit]");
    if (r && r.remove(), Object.assign(S, t.props.page), re = new b.root({
            target: e,
            props: { ...t.props,
                stores: O,
                components: nt
            },
            hydrate: n,
            sync: !1
        }), await Promise.resolve(), se(x), n) {
        const s = {
            from: null,
            to: {
                params: m.params,
                route: {
                    id: ((a = m.route) == null ? void 0 : a.id) ? ? null
                },
                url: new URL(location.href)
            },
            willUnload: !1,
            type: "enter",
            complete: Promise.resolve()
        };
        M.forEach(o => o(s))
    }
    at = !0
}

function ot({
    url: t,
    params: e,
    branch: n,
    status: r,
    error: a,
    route: s,
    form: o
}) {
    let i = "never";
    if (L && (t.pathname === L || t.pathname === L + "/")) i = "always";
    else
        for (const f of n)(f == null ? void 0 : f.slash) !== void 0 && (i = f.slash);
    t.pathname = ge(t.pathname, i), t.search = t.search;
    const c = {
        type: "loaded",
        state: {
            url: t,
            params: e,
            branch: n,
            error: a,
            route: s
        },
        props: {
            constructors: Pe(n).map(f => f.node.component),
            page: Ct(S)
        }
    };
    o !== void 0 && (c.props.form = o);
    let l = {},
        d = !S,
        u = 0;
    for (let f = 0; f < Math.max(n.length, m.branch.length); f += 1) {
        const h = n[f],
            _ = m.branch[f];
        (h == null ? void 0 : h.data) !== (_ == null ? void 0 : _.data) && (d = !0), h && (l = { ...l,
            ...h.data
        }, d && (c.props[`data_${u}`] = l), u += 1)
    }
    return (!m.url || t.href !== m.url.href || m.error !== a || o !== void 0 && o !== S.form || d) && (c.props.page = {
        error: a,
        params: e,
        route: {
            id: (s == null ? void 0 : s.id) ? ? null
        },
        state: {},
        status: r,
        url: new URL(t),
        form: o ? ? null,
        data: d ? l : S.data
    }), c
}
async function $t({
    loader: t,
    parent: e,
    url: n,
    params: r,
    route: a,
    server_data_node: s
}) {
    var l, d;
    let o = null;
    const i = {
            dependencies: new Set,
            params: new Set,
            parent: !1,
            route: !1,
            url: !1,
            search_params: new Set
        },
        c = await t();
    return {
        node: c,
        loader: t,
        server: s,
        universal: (l = c.universal) != null && l.load ? {
            type: "data",
            data: o,
            uses: i
        } : null,
        data: o ? ? (s == null ? void 0 : s.data) ? ? null,
        slash: ((d = c.universal) == null ? void 0 : d.trailingSlash) ? ? (s == null ? void 0 : s.slash)
    }
}

function Me(t, e, n) {
    let r = t instanceof Request ? t.url : t;
    const a = new URL(r, n);
    a.origin === n.origin && (r = a.href.slice(n.origin.length));
    const s = at ? ke(r, a.href, e) : be(r, e);
    return {
        resolved: a,
        promise: s
    }
}

function We(t, e, n, r, a, s) {
    if (Tt) return !0;
    if (!a) return !1;
    if (a.parent && t || a.route && e || a.url && n) return !0;
    for (const o of a.search_params)
        if (r.has(o)) return !0;
    for (const o of a.params)
        if (s[o] !== m.params[o]) return !0;
    for (const o of a.dependencies)
        if (et.some(i => i(new URL(o)))) return !0;
    return !1
}

function It(t, e) {
    return (t == null ? void 0 : t.type) === "data" ? t : (t == null ? void 0 : t.type) === "skip" ? e ? ? null : null
}

function Fe(t, e) {
    if (!t) return new Set(e.searchParams.keys());
    const n = new Set([...t.searchParams.keys(), ...e.searchParams.keys()]);
    for (const r of n) {
        const a = t.searchParams.getAll(r),
            s = e.searchParams.getAll(r);
        a.every(o => s.includes(o)) && s.every(o => a.includes(o)) && n.delete(r)
    }
    return n
}

function Ge({
    error: t,
    url: e,
    route: n,
    params: r
}) {
    return {
        type: "loaded",
        state: {
            error: t,
            url: e,
            route: n,
            params: r,
            branch: []
        },
        props: {
            page: Ct(S),
            constructors: []
        }
    }
}
async function le({
    id: t,
    invalidating: e,
    url: n,
    params: r,
    route: a,
    preload: s
}) {
    if ((w == null ? void 0 : w.id) === t) return rt.delete(w.token), w.promise;
    const {
        errors: o,
        layouts: i,
        leaf: c
    } = a, l = [...i, c];
    o.forEach(g => g == null ? void 0 : g().catch(() => {})), l.forEach(g => g == null ? void 0 : g[1]().catch(() => {}));
    const d = m.url ? t !== st(m.url) : !1,
        u = m.route ? a.id !== m.route.id : !1,
        v = Fe(m.url, n);
    let f = !1;
    const h = l.map(async (g, p) => {
        var $;
        if (!g) return;
        const k = m.branch[p];
        return g[1] === (k == null ? void 0 : k.loader) && !We(f, u, d, v, ($ = k.universal) == null ? void 0 : $.uses, r) ? k : (f = !0, $t({
            loader: g[1],
            url: n,
            params: r,
            route: a,
            parent: async () => {
                var J;
                const A = {};
                for (let y = 0; y < p; y += 1) Object.assign(A, (J = await h[y]) == null ? void 0 : J.data);
                return A
            },
            server_data_node: It(g[0] ? {
                type: "skip"
            } : null, g[0] ? k == null ? void 0 : k.server : void 0)
        }))
    });
    for (const g of h) g.catch(() => {});
    const _ = [];
    for (let g = 0; g < l.length; g += 1)
        if (l[g]) try {
            _.push(await h[g])
        } catch (p) {
            if (p instanceof Et) return {
                type: "redirect",
                location: p.location
            };
            if (rt.has(s)) return Ge({
                error: await H(p, {
                    params: r,
                    url: n,
                    route: {
                        id: a.id
                    }
                }),
                url: n,
                params: r,
                route: a
            });
            let k = Lt(p),
                R;
            if (p instanceof kt) R = p.body;
            else {
                if (await O.updated.check()) return await te(), await Y(n);
                R = await H(p, {
                    params: r,
                    url: n,
                    route: {
                        id: a.id
                    }
                })
            }
            const $ = await Ye(g, _, o);
            return $ ? ot({
                url: n,
                params: r,
                branch: _.slice(0, $.idx).concat($.node),
                status: k,
                error: R,
                route: a
            }) : await ue(n, {
                id: a.id
            }, R, k)
        } else _.push(void 0);
    return ot({
        url: n,
        params: r,
        branch: _,
        status: 200,
        error: null,
        route: a,
        form: e ? void 0 : null
    })
}
async function Ye(t, e, n) {
    for (; t--;)
        if (n[t]) {
            let r = t;
            for (; !e[r];) r -= 1;
            try {
                return {
                    idx: r + 1,
                    node: {
                        node: await n[t](),
                        loader: n[t],
                        data: {},
                        server: null,
                        universal: null
                    }
                }
            } catch {
                continue
            }
        }
}
async function Ot({
    status: t,
    error: e,
    url: n,
    route: r
}) {
    const a = {};
    let s = null;
    try {
        const o = await $t({
                loader: _t,
                url: n,
                params: a,
                route: r,
                parent: () => Promise.resolve({}),
                server_data_node: It(s)
            }),
            i = {
                node: await tt(),
                loader: tt,
                universal: null,
                server: null,
                data: null
            };
        return ot({
            url: n,
            params: a,
            branch: [o, i],
            status: t,
            error: e,
            route: null
        })
    } catch (o) {
        if (o instanceof Et) return ie(new URL(o.location, location.href), {}, 0);
        throw o
    }
}
async function ze(t) {
    const e = t.href;
    if (X.has(e)) return X.get(e);
    let n;
    try {
        const r = (async () => {
            let a = await b.hooks.reroute({
                url: new URL(t),
                fetch: async (s, o) => Me(s, o, t).promise
            }) ? ? t;
            if (typeof a == "string") {
                const s = new URL(t);
                b.hash ? s.hash = a : s.pathname = a, a = s
            }
            return a
        })();
        X.set(e, r), n = await r
    } catch {
        X.delete(e);
        return
    }
    return n
}
async function ft(t, e) {
    if (t && !lt(t, L, b.hash)) {
        const n = await ze(t);
        if (!n) return;
        const r = He(n);
        for (const a of At) {
            const s = a.exec(r);
            if (s) return {
                id: st(t),
                invalidating: e,
                route: a,
                params: _e(s),
                url: t
            }
        }
    }
}

function He(t) {
    return me(b.hash ? t.hash.replace(/^#/, "").replace(/[?#].+/, "") : t.pathname.slice(L.length)) || "/"
}

function st(t) {
    return (b.hash ? t.hash.replace(/^#/, "") : t.pathname) + t.search
}

function fe({
    url: t,
    type: e,
    intent: n,
    delta: r,
    event: a
}) {
    let s = !1;
    const o = Pt(m, n, t, e);
    r !== void 0 && (o.navigation.delta = r), a !== void 0 && (o.navigation.event = a);
    const i = { ...o.navigation,
        cancel: () => {
            s = !0, o.reject(new Error("navigation cancelled"))
        }
    };
    return z || ee.forEach(c => c(i)), s ? null : o
}
async function q({
    type: t,
    url: e,
    popped: n,
    keepfocus: r,
    noscroll: a,
    replace_state: s,
    state: o = {},
    redirect_count: i = 0,
    nav_token: c = {},
    accept: l = qt,
    block: d = qt,
    event: u
}) {
    const v = C;
    C = c;
    const f = await ft(e, !1),
        h = t === "enter" ? Pt(m, f, e, t) : fe({
            url: e,
            type: t,
            delta: n == null ? void 0 : n.delta,
            intent: f,
            event: u
        });
    if (!h) {
        d(), C === c && (C = v);
        return
    }
    const _ = E,
        g = x;
    l(), z = !0, at && h.navigation.type !== "enter" && O.navigating.set(F.current = h.navigation);
    let p = f && await le(f);
    if (!p) {
        if (lt(e, L, b.hash)) return await Y(e, s);
        p = await ue(e, {
            id: null
        }, await H(new St(404, "Not Found", `Not found: ${e.pathname}`), {
            url: e,
            params: {},
            route: {
                id: null
            }
        }), 404, s)
    }
    if (e = (f == null ? void 0 : f.url) || e, C !== c) return h.reject(new Error("navigation aborted")), !1;
    if (p.type === "redirect") {
        if (i < 20) {
            await q({
                type: t,
                url: new URL(p.location, e),
                popped: n,
                keepfocus: r,
                noscroll: a,
                replace_state: s,
                state: o,
                redirect_count: i + 1,
                nav_token: c
            }), h.fulfil(void 0);
            return
        }
        p = await Ot({
            status: 500,
            error: await H(new Error("Redirect loop"), {
                url: e,
                params: {},
                route: {
                    id: null
                }
            }),
            url: e,
            route: {
                id: null
            }
        })
    } else p.props.page.status >= 400 && await O.updated.check() && (await te(), await Y(e, s));
    if (Be(), Ut(_), oe(g), p.props.page.url.pathname !== e.pathname && (e.pathname = p.props.page.url.pathname), o = n ? n.state : o, !n) {
        const y = s ? 0 : 1,
            N = {
                [V]: E += y,
                [W]: x += y,
                [Ht]: o
            };
        (s ? history.replaceState : history.pushState).call(history, N, "", e), s || Ve(E, x)
    }
    const k = f && (w == null ? void 0 : w.id) === f.id ? w.fork : null;
    w = null, p.props.page.state = o;
    let R;
    if (at) {
        const y = (await Promise.all(Array.from(qe, I => I(h.navigation)))).filter(I => typeof I == "function");
        if (y.length > 0) {
            let I = function() {
                y.forEach(ut => {
                    M.delete(ut)
                })
            };
            y.push(I), y.forEach(ut => {
                M.add(ut)
            })
        }
        m = p.state, p.props.page && (p.props.page.url = e);
        const N = k && await k;
        N ? R = N.commit() : (re.$set(p.props), Ne(p.props.page), R = void 0), ae = !0
    } else await ce(p, wt, !1);
    const {
        activeElement: $
    } = document;
    await R, await Q(), await Q();
    let A = n ? n.scroll : a ? ct() : null;
    if (Bt) {
        const y = e.hash && document.getElementById(de(e));
        if (A) scrollTo(A.x, A.y);
        else if (y) {
            y.scrollIntoView();
            const {
                top: N,
                left: I
            } = y.getBoundingClientRect();
            A = {
                x: pageXOffset + I,
                y: pageYOffset + N
            }
        } else scrollTo(0, 0)
    }
    const J = document.activeElement !== $ && document.activeElement !== document.body;
    !r && !J && en(e, A), Bt = !0, p.props.page && Object.assign(S, p.props.page), z = !1, t === "popstate" && se(x), h.fulfil(void 0), M.forEach(y => y(h.navigation)), O.navigating.set(F.current = null)
}
async function ue(t, e, n, r, a) {
    return t.origin === it && t.pathname === location.pathname && !ne ? await Ot({
        status: r,
        error: n,
        url: t,
        route: e
    }) : await Y(t, a)
}

function Je() {
    let t, e, n;
    T.addEventListener("mousemove", i => {
        const c = i.target;
        clearTimeout(t), t = setTimeout(() => {
            s(c, P.hover)
        }, 20)
    });

    function r(i) {
        i.defaultPrevented || s(i.composedPath()[0], P.tap)
    }
    T.addEventListener("mousedown", r), T.addEventListener("touchstart", r, {
        passive: !0
    });
    const a = new IntersectionObserver(i => {
        for (const c of i) c.isIntersecting && (gt(new URL(c.target.href)), a.unobserve(c.target))
    }, {
        threshold: 0
    });
    async function s(i, c) {
        const l = Xt(i, T),
            d = l === e && c >= n;
        if (!l || d) return;
        const {
            url: u,
            external: v,
            download: f
        } = mt(l, L, b.hash);
        if (v || f) return;
        const h = Z(l),
            _ = u && st(m.url) === st(u);
        if (!(h.reload || _))
            if (c <= h.preload_data) {
                e = l, n = P.tap;
                const g = await ft(u, !1);
                if (!g) return;
                Ke(g)
            } else c <= h.preload_code && (e = l, n = c, gt(u))
    }

    function o() {
        a.disconnect();
        for (const i of T.querySelectorAll("a")) {
            const {
                url: c,
                external: l,
                download: d
            } = mt(i, L, b.hash);
            if (l || d) continue;
            const u = Z(i);
            u.reload || (u.preload_code === P.viewport && a.observe(i), u.preload_code === P.eager && gt(c))
        }
    }
    M.add(o), o()
}

function H(t, e) {
    if (t instanceof kt) return t.body;
    const n = Lt(t),
        r = Ce(t);
    return b.hooks.handleError({
        error: t,
        event: e,
        status: n,
        message: r
    }) ? ? {
        message: r
    }
}

function dn(t, e = {}) {
    return t = new URL(xt(t)), t.origin !== it ? Promise.reject(new Error("goto: invalid URL")) : ie(t, e, 0)
}

function Xe(t) {
    if (typeof t == "function") et.push(t);
    else {
        const {
            href: e
        } = new URL(t, location.href);
        et.push(n => n.href === e)
    }
}

function Qe() {
    var e;
    history.scrollRestoration = "manual", addEventListener("beforeunload", n => {
        let r = !1;
        if (Mt(), !z) {
            const a = Pt(m, void 0, null, "leave"),
                s = { ...a.navigation,
                    cancel: () => {
                        r = !0, a.reject(new Error("navigation cancelled"))
                    }
                };
            ee.forEach(o => o(s))
        }
        r ? (n.preventDefault(), n.returnValue = "") : history.scrollRestoration = "auto"
    }), addEventListener("visibilitychange", () => {
        document.visibilityState === "hidden" && Mt()
    }), (e = navigator.connection) != null && e.saveData || Je(), T.addEventListener("click", async n => {
        if (n.button || n.which !== 1 || n.metaKey || n.ctrlKey || n.shiftKey || n.altKey || n.defaultPrevented) return;
        const r = Xt(n.composedPath()[0], T);
        if (!r) return;
        const {
            url: a,
            external: s,
            target: o,
            download: i
        } = mt(r, L, b.hash);
        if (!a) return;
        if (o === "_parent" || o === "_top") {
            if (window.parent !== window) return
        } else if (o && o !== "_self") return;
        const c = Z(r);
        if (!(r instanceof SVGAElement) && a.protocol !== location.protocol && !(a.protocol === "https:" || a.protocol === "http:") || i) return;
        const [d, u] = (b.hash ? a.hash.replace(/^#/, "") : a.href).split("#"), v = d === dt(location);
        if (s || c.reload && (!v || !u)) {
            fe({
                url: a,
                type: "link",
                event: n
            }) ? z = !0 : n.preventDefault();
            return
        }
        if (u !== void 0 && v) {
            const [, f] = m.url.href.split("#");
            if (f === u) {
                if (n.preventDefault(), u === "" || u === "top" && r.ownerDocument.getElementById("top") === null) scrollTo({
                    top: 0
                });
                else {
                    const h = r.ownerDocument.getElementById(decodeURIComponent(u));
                    h && (h.scrollIntoView(), h.focus())
                }
                return
            }
            if (B = !0, Ut(E), t(a), !c.replace_state) return;
            B = !1
        }
        n.preventDefault(), await new Promise(f => {
            requestAnimationFrame(() => {
                setTimeout(f, 0)
            }), setTimeout(f, 100)
        }), await q({
            type: "link",
            url: a,
            keepfocus: c.keepfocus,
            noscroll: c.noscroll,
            replace_state: c.replace_state ? ? a.href === location.href,
            event: n
        })
    }), T.addEventListener("submit", n => {
        if (n.defaultPrevented) return;
        const r = HTMLFormElement.prototype.cloneNode.call(n.target),
            a = n.submitter;
        if (((a == null ? void 0 : a.formTarget) || r.target) === "_blank" || ((a == null ? void 0 : a.formMethod) || r.method) !== "get") return;
        const i = new URL((a == null ? void 0 : a.hasAttribute("formaction")) && (a == null ? void 0 : a.formAction) || r.action);
        if (lt(i, L, !1)) return;
        const c = n.target,
            l = Z(c);
        if (l.reload) return;
        n.preventDefault(), n.stopPropagation();
        const d = new FormData(c, a);
        i.search = new URLSearchParams(d).toString(), q({
            type: "form",
            url: i,
            keepfocus: l.keepfocus,
            noscroll: l.noscroll,
            replace_state: l.replace_state ? ? i.href === location.href,
            event: n
        })
    }), addEventListener("popstate", async n => {
        var r;
        if (!yt) {
            if ((r = n.state) != null && r[V]) {
                const a = n.state[V];
                if (C = {}, a === E) return;
                const s = j[a],
                    o = n.state[Ht] ? ? {},
                    i = new URL(n.state[$e] ? ? location.href),
                    c = n.state[W],
                    l = m.url ? dt(location) === dt(m.url) : !1;
                if (c === x && (ae || l)) {
                    o !== S.state && (S.state = o), t(i), j[E] = ct(), s && scrollTo(s.x, s.y), E = a;
                    return
                }
                const u = a - E;
                await q({
                    type: "popstate",
                    url: i,
                    popped: {
                        state: o,
                        scroll: s,
                        delta: u
                    },
                    accept: () => {
                        E = a, x = c
                    },
                    block: () => {
                        history.go(-u)
                    },
                    nav_token: C,
                    event: n
                })
            } else if (!B) {
                const a = new URL(location.href);
                t(a), b.hash && location.reload()
            }
        }
    }), addEventListener("hashchange", () => {
        B && (B = !1, history.replaceState({ ...history.state,
            [V]: ++E,
            [W]: x
        }, "", location.href))
    });
    for (const n of document.querySelectorAll("link")) De.has(n.rel) && (n.href = n.href);
    addEventListener("pageshow", n => {
        n.persisted && O.navigating.set(F.current = null)
    });

    function t(n) {
        m.url = S.url = n, O.page.set(Ct(S)), O.page.notify()
    }
}
async function Ze(t, {
    status: e = 200,
    error: n,
    node_ids: r,
    params: a,
    route: s,
    server_route: o,
    data: i,
    form: c
}) {
    ne = !0;
    const l = new URL(location.href);
    let d;
    ({
        params: a = {},
        route: s = {
            id: null
        }
    } = await ft(l, !1) || {}), d = At.find(({
        id: f
    }) => f === s.id);
    let u, v = !0;
    try {
        const f = r.map(async (_, g) => {
                const p = i[g];
                return p != null && p.uses && (p.uses = tn(p.uses)), $t({
                    loader: b.nodes[_],
                    url: l,
                    params: a,
                    route: s,
                    parent: async () => {
                        const k = {};
                        for (let R = 0; R < g; R += 1) Object.assign(k, (await f[R]).data);
                        return k
                    },
                    server_data_node: It(p)
                })
            }),
            h = await Promise.all(f);
        if (d) {
            const _ = d.layouts;
            for (let g = 0; g < _.length; g++) _[g] || h.splice(g, 0, void 0)
        }
        u = ot({
            url: l,
            params: a,
            branch: h,
            status: e,
            error: n,
            form: c,
            route: d ? ? null
        })
    } catch (f) {
        if (f instanceof Et) {
            await Y(new URL(f.location, location.href));
            return
        }
        u = await Ot({
            status: Lt(f),
            error: await H(f, {
                url: l,
                params: a,
                route: s
            }),
            url: l,
            route: s
        }), t.textContent = "", v = !1
    }
    u.props.page && (u.props.page.state = {}), await ce(u, t, v)
}

function tn(t) {
    return {
        dependencies: new Set((t == null ? void 0 : t.dependencies) ? ? []),
        params: new Set((t == null ? void 0 : t.params) ? ? []),
        parent: !!(t != null && t.parent),
        route: !!(t != null && t.route),
        url: !!(t != null && t.url),
        search_params: new Set((t == null ? void 0 : t.search_params) ? ? [])
    }
}
let yt = !1;

function en(t, e = null) {
    const n = document.querySelector("[autofocus]");
    if (n) n.focus();
    else {
        const r = de(t);
        if (r && document.getElementById(r)) {
            const {
                x: s,
                y: o
            } = e ? ? ct();
            setTimeout(() => {
                const i = history.state;
                yt = !0, location.replace(`#${r}`), b.hash && location.replace(t.hash), history.replaceState(i, "", t.hash), scrollTo(s, o), yt = !1
            })
        } else {
            const s = document.body,
                o = s.getAttribute("tabindex");
            s.tabIndex = -1, s.focus({
                preventScroll: !0,
                focusVisible: !1
            }), o !== null ? s.setAttribute("tabindex", o) : s.removeAttribute("tabindex")
        }
        const a = getSelection();
        if (a && a.type !== "None") {
            const s = [];
            for (let o = 0; o < a.rangeCount; o += 1) s.push(a.getRangeAt(o));
            setTimeout(() => {
                if (a.rangeCount === s.length) {
                    for (let o = 0; o < a.rangeCount; o += 1) {
                        const i = s[o],
                            c = a.getRangeAt(o);
                        if (i.commonAncestorContainer !== c.commonAncestorContainer || i.startContainer !== c.startContainer || i.endContainer !== c.endContainer || i.startOffset !== c.startOffset || i.endOffset !== c.endOffset) return
                    }
                    a.removeAllRanges()
                }
            })
        }
    }
}

function Pt(t, e, n, r) {
    var c, l;
    let a, s;
    const o = new Promise((d, u) => {
        a = d, s = u
    });
    return o.catch(() => {}), {
        navigation: {
            from: {
                params: t.params,
                route: {
                    id: ((c = t.route) == null ? void 0 : c.id) ? ? null
                },
                url: t.url
            },
            to: n && {
                params: (e == null ? void 0 : e.params) ? ? null,
                route: {
                    id: ((l = e == null ? void 0 : e.route) == null ? void 0 : l.id) ? ? null
                },
                url: n
            },
            willUnload: !e,
            type: r,
            complete: o
        },
        fulfil: a,
        reject: s
    }
}

function Ct(t) {
    return {
        data: t.data,
        error: t.error,
        form: t.form,
        params: t.params,
        route: t.route,
        state: t.state,
        status: t.status,
        url: t.url
    }
}

function nn(t) {
    const e = new URL(t);
    return e.hash = decodeURIComponent(t.hash), e
}

function de(t) {
    let e;
    if (b.hash) {
        const [, , n] = t.hash.split("#", 3);
        e = n ? ? ""
    } else e = t.hash.slice(1);
    return decodeURIComponent(e)
}
export {
    un as a, dn as g, sn as l, O as s
};