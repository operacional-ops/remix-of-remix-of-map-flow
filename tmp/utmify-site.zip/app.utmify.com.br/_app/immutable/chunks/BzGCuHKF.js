import {
    s as r,
    n as o,
    d,
    i as n,
    c,
    o as m,
    h as l
} from "./DDNnt9XD.js";
import {
    S as u,
    i as p
} from "./qWASNxYk.js";

function f(i) {
    let e, s = `<h2 class="text-3xl font-bold my-2 text-center">POLÍTICA DE PRIVACIDADE DA UTMIFY</h2> <p class="mb-2 text-justify text-md">Esta Política de Privacidade (“Política”) é disponibilizada e mantida pela
    UTMIFY TECNOLOGIA LTDA, pessoa jurídica de direito privado, regularmente
    registrada sob o CNPJ n° 44.105.337/0001-39, com sede à Rua Moyses Braga
    Lima, n° 271, Bairro Goiabal, Barra Mansa – RJ, CEP 27.340-110.</p> <p class="mb-2 text-justify text-md">Na UTMIFY, privacidade e segurança são prioridades e nos comprometemos com a
    transparência do tratamento de dados pessoais dos nossos Usuários e de
    terceiros. Esta Política de Privacidade estabelece como é feita a coleta,
    uso e transferência de informações de Usuários que utilizam a Plataforma
    UTMify, bem como dados de terceiros por estes coletados e adicionados à
    Plataforma.</p> <h3 class="text-xl font-bold mb-2">CONCEITOS E DEFINIÇÕES</h3> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md"><strong>DADO PESSOAL:</strong> Qualquer informação relacionada a uma pessoa
      física identificada ou identificável;</li> <li class="mb-2 text-justify text-md"><strong>DADO SENSÍVEL:</strong> dado pessoal sobre origem racial ou étnica,
      convicção religiosa, opinião política, filiação a sindicato ou a organização
      de caráter religioso, filosófico ou político, dado referente à saúde ou à vida
      sexual, dado genético ou biométrico, quando vinculado a uma pessoa natural;</li> <li class="mb-2 text-justify text-md"><strong>ANONIMIZAÇÃO:</strong> Utilização de meios técnicos razoáveis e disponíveis
      no momento do Tratamento para que um Dado Pessoal não mais possa ser associado,
      direta ou indiretamente, a um indivíduo;</li> <li class="mb-2 text-justify text-md"><strong>USO COMPARTILHADO DE DADOS:</strong> comunicação, difusão, transferência
      internacional, interconexão de dados pessoais ou tratamento compartilhado de
      bancos de dados pessoais por órgãos e entidades públicos no cumprimento de
      suas competências legais, ou entre esses e entes privados, reciprocamente,
      com autorização específica, para uma ou mais modalidades de tratamento permitidas
      por esses entes públicos, ou entre entes privados;</li> <li class="mb-2 text-justify text-md"><strong>BANCO DE DADOS:</strong> Conjunto estruturado de dados pessoais, estabelecido
      em um ou em vários locais, em suporte eletrônico ou físico.</li> <li class="mb-2 text-justify text-md"><strong>BASE LEGAL:</strong> Hipóteses previstas nos artigos 7º e 11 da LGPD
      que autorizam a UTMIFY a Tratar os Dados Pessoais dos Titulares;</li> <li class="mb-2 text-justify text-md"><strong>CONSENTIMENTO:</strong> Manifestação livre, informada e inequívoca
      pela qual o Titular concorda com o Tratamento de seus Dados Pessoais para uma
      finalidade determinada;</li> <li class="mb-2 text-justify text-md"><strong>CONTROLADOR:</strong> É a pessoa física ou jurídica, de direito público
      ou privado, a quem competem as decisões referentes ao Tratamento de Dados Pessoais;</li> <li class="mb-2 text-justify text-md"><strong>COOKIES:</strong> Os cookies são uma tecnologia que pode ser usada
      para ajudar a personalizar o uso de um site. Um cookie é uma pequena quantidade
      de dados que geralmente inclui um identificador exclusivo que é enviado para
      seu dispositivo a partir do site e é armazenado no navegador ou disco rígido
      do seu dispositivo;</li> <li class="mb-2 text-justify text-md"><strong>ENCARREGADO:</strong> pessoa indicada pela UTMIFY, responsável por
      garantir o atendimento dos direitos dos Titulares e esclarecer dúvidas sobre
      o Tratamento de seus Dados Pessoais, podendo também ser conhecido como Data
      Protection Office - DPO;</li> <li class="mb-2 text-justify text-md"><strong>FINALIDADE:</strong> motivo pelo qual o Dado Pessoal será Tratado,
      ou objetivo que se pretende atingir com o Tratamento dos Dados;</li> <li class="mb-2 text-justify text-md"><strong>LGPD:</strong> Trata-se da Lei Geral de Proteção de Dados (Lei n°
      13.709/2018);</li> <li class="mb-2 text-justify text-md"><strong>ANDP:</strong> Autoridade Nacional de Proteção de Dados, órgão da
      administração pública responsável por zelar, implementar e fiscalizar o cumprimento
      da Lei Geral de Proteção de Dados em todo o território nacional.</li> <li class="mb-2 text-justify text-md"><strong>OPERADOR:</strong> É a pessoa física ou jurídica, de direito público
      ou privado, que realiza o Tratamento de Dados Pessoais em nome do Controlador;</li> <li class="mb-2 text-justify text-md"><strong>CONTROLADOR:</strong> pessoa natural ou jurídica, de direito público
      ou privado, a quem competem as decisões referentes ao tratamento de dados pessoais</li> <li class="mb-2 text-justify text-md"><strong>TERCEIRO:</strong> Refere-se, mas não está limitado, a toda e qualquer
      pessoa física ou jurídica, cujos dados a UTMIFY venha a ter acesso direta ou
      indiretamente, no âmbito do software UTMIFY, como por exemplo, fornecedores,
      clientes dos nossos clientes, colaboradores ou representantes dos nossos clientes;</li> <li class="mb-2 text-justify text-md"><strong>TITULAR:</strong> Pessoa física a quem se referem os Dados Pessoais,
      tais como clientes e usuários;</li> <li class="mb-2 text-justify text-md"><strong>TRATAMENTO:</strong> Qualquer operação, ou conjunto de operações,
      realizada com Dados Pessoais.</li></ul> <h2 class="text-2xl font-bold mb-2">1. DADOS COLETADOS E FORMA DE COLETA</h2> <p class="mb-2 text-justify text-md">1.1. Enquanto Controladora de dados, a UTMify poderá coletar dados pessoais
    necessários para a prestação de seus respectivos serviços, destinada à
    criação e gestão da conta, incluindo, mas não se limitando a, nome, endereço
    de e-mail, informações de contato e número de documento. A coleta ocorre
    através do cadastro na plataforma, interações com nossos serviços, podendo
    também ocorrer através de cookies e tecnologias similares, ou ainda, por
    autorização especificamente coletado de outro modo.</p> <div class="overflow-x-auto mb-2"><table class="table-auto border-collapse w-full"><thead><tr><th class="border px-1 py-2">FINALIDADE</th> <th class="border px-1 py-2">DADOS COLETADOS</th> <th class="border px-1 py-2">FUNDAMENTO LEGAL</th></tr></thead> <tbody><tr><td class="border px-1 py-2">(a) Cadastro de Conta e contratação de serviços; (b) Permitir a
            execução das obrigações contratuais estabelecidas pela UTMIFY em
            face do Usuário; (c) Processar o faturamento e outros assuntos
            relacionados à gestão do contrato; (d) Enviar Notificações e avisos
            sobre os serviços;</td> <td class="border px-1 py-2">Nome, e-mail, contato telefônico, endereço, tipo de plano
            contratado e dados financeiros, credenciais de acesso</td> <td class="border px-1 py-2">Quando necessário para a execução de contrato ou de procedimentos
            preliminares relacionados a contrato - art. 7°, V, da LGPD.</td></tr> <tr><td class="border px-1 py-2">(a) Fornecer, personalizar e melhorar a experiência do Usuário com
            os serviços oferecidos pela Plataforma, e com outros serviços e
            produtos fornecidos pela UTMIFY; (b) Compreender de que forma o
            Usuário acessa e utiliza os serviços, a fim de garantir sua
            funcionalidade técnica, desenvolver novos produtos e serviços; (c)
            Prover a autenticação do Usuário e outras medidas para vitar a
            ocorrência de fraudes contra o Usuário, a Plataforma e Terceiros;
            (d) Fornecer ao Usuário funcionalidades, atualizações, políticas de
            preços e de contratação, publicidade ou outro conteúdo baseado na
            localização e nos interesses específicos do Usuário; Atendimento ao
            art. 15 do Marco Civil da Internet (Lei n° 12.965/2014)</td> <td class="border px-1 py-2">Dados de acesso e utilização: tipo de plano contratado; informações
            sobre as interações do usuário com os serviços, data e hora de
            qualquer acesso, inclusive os serviços utilizados, o conteúdo
            publicado na conta do cliente, a configuração e alterações na
            configuração dos serviços, informações relacionadas ou resultantes
            da utilização de software de terceiros, dados técnicos; informações
            de URL, dados de Cookies, o endereço IP do Usuário geolocalização, o
            tipo de dispositivo utilizado para acessar o conectar-se à
            plataforma, identificação do dispositivo, atributos do dispositivo,
            tipo de ligação à rede, e fornecedor de rede, desempenho da rede e
            do dispositivo, tipo de navegador, idioma, informações que permitam
            a gestão dos direitos digitais, sistema operativo e versão da
            UTMIFY. Dados de log (data e hora de acesso ao site) e endereço IP
            do seu dispositivo (IP).</td> <td class="border px-1 py-2">Legítimo Interesse do Controlador - art. 7°, IX, da LGPD;
            Cumprimento de Obrigação Legal - art. 7°, Inciso II da LGPD;</td></tr> <tr><td class="border px-1 py-2">Enviar comunicações ao Usuário, diretamente ou através de parceiros
            para fins de: marketing, pesquisa, participação em concursos, quis,
            promoções através de e-mails, notificações ou outras mensagens, de
            acordo com quaisquer autorizações eventualmente transmitidas pelo
            usuário</td> <td class="border px-1 py-2">Nome, e-mail, telefone</td> <td class="border px-1 py-2">Consentimento do Titular - art. 7°, I da LGPD;</td></tr></tbody></table></div> <p class="mb-2 text-justify text-md">1.2. Para usuários que optam por realizar a assinatura de planos pagos, os
    dados requeridos relacionados à cobrança (dados de cartão de crédito e
    endereço de cobrança) não são armazenados pela UTMIFY.</p> <p class="mb-2 text-justify text-md">1.3. A Plataforma armazena dados de métricas vitais para a análise e
    otimização do desempenho das campanhas de seus respectivos Usuários, isso
    inclui, mas não se limita a, dados e gastos com anúncios em Plataformas de
    Gerenciadores de Anúncios, bem como nas vendas realizadas nas plataformas de
    vendas onde o compartilhamento de dados e realizado pelo Usuário.</p> <p class="mb-2 text-justify text-md">1.4. Em virtude de sua atividade, a UTMIFY atua como Operadora de Dados, no
    que toca aos Dados de Terceiros coletados pelo Usuário (através de outras
    plataformas, tais como Meta e/ou Google), sendo referidos dados comunicados
    à Plataforma UTMify automaticamente pelos sistemas de webhooks e API’s de
    sistema vinculados pelo próprio Usuário. Isso significa que a UTMIFY tratará
    referidos Dados Pessoais por conta e ordem do Usuário, ou seja, do titular
    da conta na UTMIFY, o qual figurará neste caso como o Controlador de Dados,
    responsável por tais operações de tratamento. Desse modo, é de
    responsabilidade do Usuário, em conformidade com o disposto na Lei n°
    13.709/18, estipular os objetivos que justificam a realização do Tratamento,
    sua respectiva base legal, bem como obter autorizações aplicáveis, cabendo
    ao mesmo atender às solicitações dos Titulares de Dados Pessoais.</p> <p class="mb-2 text-justify text-md">1.5. Em atenção a segurança e privacidade dos dados, a UTMIFY não coleta,
    recebe ou mantém em guarda dados sensíveis dos Usuários ou de terceiros.
    Caso tais dados sejam recebidos inadvertidamente de plataformas terceiras,
    eles são imediatamente excluídos, tão logo sejam identificados, assegurando
    que não sejam armazenados ou compartilhados com terceiros.</p> <p class="mb-2 text-justify text-md">1.6. Para aprimorar e otimizar suas campanhas publicitárias, a UTMIFY coleta
    dados dos anúncios veiculados a gerenciadores de anúncios vinculados e/ou
    integração à Plataforma pelo Usuário, permitindo à UTMIFY acessar as
    métricas relevantes das suas respectivas campanhas.</p> <p class="mb-2 text-justify text-md">1.7. A UTMIFY não é responsável pela precisão, veracidade ou falta dela nas
    informações que o Usuário ou plataforma por ele vinculada imputar na
    Plataforma UTMIFY, ou por sua desatualização, sendo responsabilidade do
    Usuário ou da plataforma terceira prestá-las com exatidão ou atualizá-las.</p> <p class="mb-2 text-justify text-md">1.8. Quando uma venda é realizada e comunicada à UTMIFY por meio de webhook
    de plataformas de vendas parceiras, recebemos uma série de dados sobre o
    cliente final. Isso inclui CPF/CNPJ, e-mail, telefone, IP, data de
    nascimento e endereço. Destas informações, apenas o e-mail do cliente final
    é armazenado em nosso banco de dados. As demais informações podem ser
    utilizadas para reenvio ao Facebook, com o objetivo de otimizar as campanhas
    publicitárias, conforme as preferências de uso da nossa plataforma.</p> <p class="mb-2 text-justify text-md">1.9. A UTMIFY se compromete a utilizar os dados coletados exclusivamente
    para os fins especificados, respeitando a privacidade e a segurança das
    informações dos Usuários e de Terceiros. A plataforma está em conformidade
    com as legislações vigentes de proteção de dados, garantindo que os usuários
    tenham controle sobre suas informações pessoais e possam exercer seus
    direitos de acesso, retificação e exclusão conforme necessário.</p> <p class="mb-2 text-justify text-md">1.10. Conforme exigência do art. 15 do Marco Civil da Internet (Lei n°
    12.965/14) a UTMIFY todos os logs de ações do Usuário são mantidos em guarda
    pelo período mínimo de 6 (seis) meses, sendo automaticamente excluídos
    posteriormente ao período indicado, salvo por obrigação legal, solicitação
    judicial, ou indicação de ou necessidade de preservação de evidências em
    investigações de atividades ilícitas, suspeita de fraude, violações de
    termos ou políticas de uso, ou para proteger os direitos e a segurança da
    UTMIFY, de seus usuários ou de terceiros.</p> <p class="mb-2 text-justify text-md">1.11. Para vincular essas ações a um usuário específico, é criado um
    identificador único (ID) no momento do registro do usuário. Esse ID é então
    associado a todas as atividades registradas nos logs, permitindo uma
    correlação direta entre as ações e o usuário responsável por elas. Os tipos
    de logs registrados incluem: erros de aplicação, que nos ajudam a
    identificar e corrigir falhas; e dados de atividades, tais como alterações
    em campanhas, desativações e alterações de configurações, além de dados de
    vendas. Esses registros são classificados como temporários e mantidos por um
    período de segurança, sendo automaticamente excluídos no tempo devido.</p> <h2 class="text-2xl font-bold mb-2">2. DIREITOS DO USUÁRIO</h2> <p class="mb-2 text-justify text-md">2.1. Conforme dispõe o art. 18 da Lei Geral de Proteção de Dados (LGPD),
    pessoas físicas, enquanto titulares de dados pessoais, possuem o direito de
    (a) confirmação da existência de tratamento de seus dados pessoais; (b)
    acesso aos seus respectivos dados; (c) solicitar e receber a correção de
    dados incompletos, inexatos ou desatualizados; (d) anonimização, bloqueio ou
    eliminação de dados desnecessários, excessivos ou tratados em
    desconformidade com o disposto nesta Lei; (d) portabilidade dos dados a
    outro fornecedor de serviço ou produto, mediante requisição expressa, de
    acordo com a regulamentação da autoridade nacional, observados os segredos
    comercial e industrial; (e) eliminação dos dados pessoais tratados com o
    consentimento do titular, exceto nas hipóteses previstas no art. 16 da Lei
    Geral de Proteção de Dados; (f) informação das entidades públicas e privadas
    com as quais o controlador realizou uso compartilhado de dados; (g)
    informação sobre a possibilidade de não fornecer consentimento e sobre as
    consequências da negativa; (h) revogação do consentimento dado para o
    tratamento de dados, nos termos do § 5º do art. 8º da Lei Geral de Proteção
    de Dados; (i) peticionar em relação aos seus dados contra o controlador
    perante a autoridade nacional de proteção de dados; (j) opor-se a tratamento
    realizado com fundamento em uma das hipóteses de dispensa de consentimento,
    em caso de descumprimento ao disposto na Lei Geral de Proteção de Dados; (k)
    exercer seus direitos mediante requerimento expresso do titular ou de
    representante legalmente constituído, a agente de tratamento, sendo atendido
    sem custos, nos prazos e nos termos previstos em regulamento.</p> <p class="mb-2 text-justify text-md">2.2. Caso o Titular procure exercer qualquer de seus direitos frente à
    UTMIFY, deverá comunica-la, por meio do Encarregado de Proteção de Dados,
    conforme disposto nesta Política de Privacidade, a respeito de sua
    requisição.</p> <p class="mb-2 text-justify text-md">2.3. A UTMIFY compromete-se a responder, em até 2 (dois) dias úteis, o
    Titular de Dados, quanto à sua requisição, atendendo-a solicitação sempre
    que possível de maneira imediata, ou informando o prazo para atendimento da
    solicitação.</p> <h2 class="text-2xl font-bold mb-2">3. FORMA E PRAZO DE ARMAZENAMENTO DOS DADOS</h2> <p class="mb-2 text-justify text-md">3.1. Salvo nas condições expressamente estabelecidas, a UTMIFY, atuando como
    Controladora dos dados, assegura que os dados coletados através da
    Plataforma UTMify serão removidos de forma automática após sua utilização
    para os propósitos identificados nesta Política de Privacidade.</p> <p class="mb-2 text-justify text-md">3.2. Os Usuários devem estar cientes de que a remoção de dados
    indispensáveis para a administração de suas contas na Plataforma UTMify
    resultará na desativação de seu registro e na consequente interrupção dos
    serviços prestados pela plataforma.</p> <p class="mb-2 text-justify text-md">3.3. Em situações onde a conta seja finalizada, decorrente da rescisão do
    Termo de Condições de Uso da Plataforma UTMify, a UTMIFY se compromete a
    excluir do seu Banco de Dados os Dados associados à conta encerrada, bem
    como quaisquer Dados fornecidos pelo cliente na Plataforma, isso ocorrerá
    após um período de 60 dias contados a partir do término do contrato.
    Contudo, reteremos somente aqueles dados que forem imprescindíveis para
    cumprir obrigações jurídicas da UTMIFY, cumprir regulamentações, resolver
    desacordos com o Usuário, prevenir fraudes ou mau uso da Plataforma e dos
    Dados, e assegurar a aderência às disposições desta Política de Privacidade
    e do Termo de Condições de Uso da Plataforma UTMify.</p> <h2 class="text-2xl font-bold mb-2">4. SEGURANÇA DE DADOS E COMPARTILHAMENTO</h2> <p class="mb-2 text-justify text-md">4.1. Todos os dados tratados pela UTMIFY são assegurados com a implementação
    de protocolos de segurança e criptografia padrão, em servidores próprios ou
    por ela contratados. Essas medidas constituem a base da abordagem de
    segurança, visando proteger a integridade e a confidencialidade das
    informações de Usuários e de Terceiros.</p> <p class="mb-2 text-justify text-md">4.2. A UTMIFY se compromete a implementar medidas tecnológicas avançadas que
    atendem aos requisitos legais para a proteção da privacidade dos dados
    armazenados em sua Plataforma. Isso inclui: (a) mecanismos robustos de
    segurança para impedir acessos não autorizados aos seus sistemas; (b)
    gerenciamento rigoroso do acesso às informações recolhidas, assegurado pela
    adesão estrita dos funcionários e colaboradores externos aos termos de
    confidencialidade, com ações guiadas pelos princípios de proporcionalidade,
    necessidade e relevância, sempre com o intuito de salvaguardar a privacidade
    conforme estabelecido nesta Política; (c) treinamentos periódicos e
    contínuos de seus colaboradores, destinados a identificar, avaliar e mitigar
    riscos relacionados à privacidade de dados e sobre as melhores práticas de
    proteção de dados e privacidade.</p> <p class="mb-2 text-justify text-md">4.3. A UTMIFY operará com uso compartilhado de dados, podendo compartilhar
    ou receber dados: (a) com plataformas de redes sociais e serviços de
    publicidade, para otimização de campanhas publicitárias e aprimoramento da
    segmentação de anúncios; (b) com fornecedores e parceiros de serviços que
    oferecem soluções tecnológicas e operacionais necessárias para a execução e
    melhoria contínua dos serviços oferecidos pela plataforma; (c) em resposta a
    obrigações legais ou regulatórias, quando necessário compartilhar dados com
    autoridades governamentais ou outras entidades reguladoras; (e) durante
    auditorias externas e processos de conformidade para assegurar e demonstrar
    a adesão aos requisitos regulatórios e padrões da indústria, garantindo que
    a empresa auditora cumpre os requisitos legais de conformidade de dados; e
    (f) com outras entidades, quando houver necessidade de colaborar com
    investigações para prevenir fraudes ou atividades ilegais, assegurando a
    integridade e segurança tanto da plataforma quanto dos dados de seus
    usuários.</p> <p class="mb-2 text-justify text-md">4.4. A UTMIFY não compartilhará os Dados do Usuário com terceiros sem
    anuência do Usuário, exceto: (a) conforme necessário para atender a
    instruções e requerimentos do Usuário; (b) na medida necessária para
    viabilizar a funcionalidade dos serviços UTMIFY contratados; (c) para
    atender a ordens judiciais nos termos da legislação em vigor, ou em
    processos judiciais para estabelecer ou exercer seus direitos legais ou
    empreender defesa contra ações judiciais; (d) quando acreditar de boa-fé ser
    necessário compartilhar as Informações com o objetivo de investigar, impedir
    ou adotar medidas relativas a atividades ilegais, suspeitas de fraude,
    situações envolvendo possíveis ameaças à segurança física de qualquer
    pessoa, ou violações aos Termos e Condições de Uso da UTMIFY; (e) em caso de
    venda dos ativos da UTMIFY, em função de mudança em seu controle, em eventos
    relacionados a mutações societárias ou em preparação para qualquer desses
    eventos (sendo que os adquirentes terão o direito de continuar a utilizar as
    Informações conforme esta Política de Privacidade); (f) com outros
    objetivos, através de procedimentos especificados e autorizados pela lei ou
    pelo Usuário.</p> <p class="mb-2 text-justify text-md">4.5. A UTMIFY reserva-se o direito de dividir as informações que coleta com
    os prestadores de serviço que a auxiliam em suas operações, incluindo
    entidades encarregadas do processamento de dados (operadores), provedores de
    serviços de cloud computing, consultores de tecnologia da informação,
    fornecedores de telecomunicações, agentes de entrega, agências de
    publicidade e marketing, organizadores de eventos e empresas envolvidas na
    gestão de créditos financeiros.</p> <p class="mb-2 text-justify text-md">4.6. O Usuário e Terceiros poderão, a qualquer tempo, realizar comunicação à
    Autoridade Nacional de Proteção de Dados – ANDP, em caso de incidentes de
    segurança que possam acarretar risco ou dano relevante.</p> <h2 class="text-2xl font-bold mb-2">5. POLÍTICA DE COOKIES E DADOS DE NAVEGAÇÃO</h2> <p class="mb-2 text-justify text-md">5.1. Utilizamos as informações coletadas automaticamente e outras
    informações coletadas no Serviço por meio de cookies e tecnologias
    semelhantes para: (i) personalizar nosso Serviço, como lembrar as
    informações de um Usuário ou Visitante, para que o Usuário ou Visitante não
    precise digitá-lo novamente durante uma visita ou em visitas subsequentes;
    (ii) fornecer anúncios, conteúdo e informações personalizados; (iii)
    monitorar e analisar a eficácia das atividades de Serviço e de marketing de
    terceiros; (iv) monitorar métricas agregadas de uso do site, como número
    total de visitantes e páginas visualizadas; e (v) rastrear suas entradas,
    envios e status em quaisquer promoções ou outras atividades no Serviço. Você
    pode obter mais informações sobre cookies visitando a nossa <strong>Política de Cookies</strong>.</p> <h2 class="text-2xl font-bold mb-2">6. ALTERAÇÃO DA POLÍTICA DE PRIVACIDADE</h2> <p class="mb-2 text-justify text-md">6.1. Esta Política de Privacidade é a vigente para regular os serviços
    disponibilizados pela plataforma UTMify desde 08/05/2024.</p> <p class="mb-2 text-justify text-md">6.2. A UTMIFY reserva-se ao direito de modificar esta Política de
    Privacidade a qualquer tempo, por mera liberalidade, desde de que
    identificada a necessidade e/ou conveniência da empresa para a adequação à
    legislação vigente, em especial à Lei Geral de Proteção de Dados, e às
    normas regulamentares da Autoridade Nacional de Proteção de Dados – ANDP.</p> <p class="mb-2 text-justify text-md">6.3. A UTMIFY informará aos Usuários sobre futuras alterações da Política de
    Privacidades por meio de upload da mesma na plataforma de acesso, cujo
    aceite será condição indispensável para prosseguimento na utilização do
    serviço contratado, bem como via informativo via e-mail, no e-mail
    registrado pelo Usuário na plataforma. O uso da Plataforma UTMify pelo
    Usuário importará em aceite integral do Usuário à nova Política de
    Privacidade.</p> <h2 class="text-2xl font-bold mb-2">7. DA PRIVACIDADE DE MENORES</h2> <p class="mb-2 text-justify text-md">7.1. A preservação da privacidade infantil é de suma importância para a
    UTMIFY. Nosso Serviço não é projetado para indivíduos menores de 18 anos, e
    não coletamos propositalmente informações pessoais de menores sem o
    consentimento de seus pais ou responsáveis legais.</p> <p class="mb-2 text-justify text-md">7.2. Pedimos que menores de 18 anos não utilizem nem acessem o Serviço em
    nenhuma circunstância. Caso a UTMIFY seja notificada ou detecte dados
    pessoais recolhidos de menor de 18 anos sem a autorização devida, a mesma
    adotará medidas para excluir referidas informações dos registros.</p> <p class="mb-2 text-justify text-md">7.3. Se você é pai, mãe ou responsável legal e percebe que menor obteve
    acesso e criou uma conta na UTMIFY, entre em contato conosco imediatamente
    através do e-mail contato@utmify.com.br para que possamos excluir as
    informações pessoais do menor de nossos sistemas.</p> <h2 class="text-2xl font-bold mb-2">8. ENCARREGADO DE DADOS</h2> <p class="mb-2 text-justify text-md">8.1. O responsável pelo tratamento de dados pessoais, conforme estabelecido
    nesta Política de Privacidade, é o Sr. Marcio Gabriel de Souza Valim. Para
    esclarecer dúvidas, realizar consultas ou fazer requerimentos relacionados a
    esta Política ou ao tratamento de dados, o mesmo poderá ser contatado
    através do e-mail contato@utmify.com.br.</p> <h2 class="text-2xl font-bold mb-2">9. LEGISLAÇÃO APLICÁVEL</h2> <p class="mb-2 text-justify text-md">9.1. Esta Política de Privacidade deverá ser interpretada de acordo com as
    leis vigentes na República Federativa do Brasil, sendo regida
    especificamente pelo Marco Civil da Internet (Lei n° 12.965/14), bem como
    pela Lei Geral de Proteção de Dados (Lei n° 13.709/18).</p>`;
    return {
        c() {
            e = l("div"), e.innerHTML = s
        },
        l(a) {
            e = c(a, "DIV", {
                "data-svelte-h": !0
            }), m(e) !== "svelte-vkol50" && (e.innerHTML = s)
        },
        m(a, t) {
            n(a, e, t)
        },
        p: o,
        i: o,
        o,
        d(a) {
            a && d(e)
        }
    }
}
class g extends u {
    constructor(e) {
        super(), p(this, e, null, f, r, {})
    }
}
export {
    g as P
};