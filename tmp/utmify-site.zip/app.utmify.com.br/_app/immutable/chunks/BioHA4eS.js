import "./qWASNxYk.js";
import {
    w as p
} from "./BKn_unzl.js";
import {
    t as T
} from "./BszCcFfc.js";
const w = {
    duration: 4e3,
    initial: 1,
    next: 0,
    pausable: !1,
    dismissable: !0,
    reversed: !1,
    intro: {
        x: 256
    }
};

function B() {
    const {
        subscribe: n,
        update: e
    } = p(new Array), a = {};
    let i = 0;

    function f(t) {
        return t instanceof Object
    }

    function h(t = "default", s = {}) {
        return a[t] = s, a
    }

    function g(t, s) {
        const o = {
                target: "default",
                ...f(t) ? t : { ...s,
                    msg: t
                }
            },
            r = a[o.target] || {},
            c = { ...w,
                ...r,
                ...o,
                theme: { ...r.theme,
                    ...o.theme
                },
                classes: [...r.classes || [], ...o.classes || []],
                id: ++i
            };
        return e(u => c.reversed ? [...u, c] : [c, ...u]), i
    }

    function k(t) {
        e(s => {
            if (!s.length || t === 0) return [];
            if (typeof t == "function") return s.filter(r => t(r));
            if (f(t)) return s.filter(r => r.target !== t.target);
            const o = t || Math.max(...s.map(r => r.id));
            return s.filter(r => r.id !== o)
        })
    }

    function m(t, s) {
        const o = f(t) ? t : { ...s,
            id: t
        };
        e(r => {
            const c = r.findIndex(u => u.id === o.id);
            return c > -1 && (r[c] = { ...r[c],
                ...o
            }), r
        })
    }
    return {
        subscribe: n,
        push: g,
        pop: k,
        set: m,
        _init: h
    }
}
const _ = B();
let d = !1,
    l;
const b = () => {
    l = T.subscribe(n => {
        d = (n == null ? void 0 : n.theme) === "Dark"
    })
};
class v {
    static primary(e, a) {
        this._themedToast(e, {
            background: "#005AE3",
            color: "white",
            barBackground: "#364eb5"
        }, a)
    }
    static success(e, a) {
        b(), this._themedToast(e, {
            background: d ? "rgb(32, 163, 105)" : "#29C76F",
            color: "white",
            barBackground: d ? "#1d834b" : "#229c59"
        }, a), l()
    }
    static warning(e, a) {
        b(), this._themedToast(e, {
            background: d ? "rgb(227, 142, 55)" : "#C78F2A",
            color: "white",
            barBackground: "#a67721"
        }, a), l()
    }
    static error(e, a) {
        this._themedToast(e, {
            background: "#ee4542",
            color: "white",
            barBackground: "#ba3634"
        }, a)
    }
    static _themedToast(e, a, i) {
        _.push(e, {
            theme: {
                "--toastBackground": a.background,
                "--toastColor": a.color,
                "--toastBarBackground": a.barBackground
            },
            duration: (i == null ? void 0 : i.duration) ? ? 3500
        })
    }
}
export {
    v as T, _ as t
};