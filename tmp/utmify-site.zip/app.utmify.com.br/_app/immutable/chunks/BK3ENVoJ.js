import {
    t
} from "./DwsiLpv2.js";

function i(r, o) {
    return +t(r) > +t(o)
}
export {
    i
};