import {
    U as t
} from "./B5WePDbK.js";
class n {
    static async execute(o) {
        var s;
        const e = await t.post("/users/notAlertInfo", {
            notAlertInfo: o.notAlertInfo
        }, {
            token: ((s = o.authData) == null ? void 0 : s.token) ? ? ""
        });
        return e.statusCode === 401 ? {
            status: "UNAUTHORIZED"
        } : e.statusCode === 200 ? {
            status: "SUCCESS"
        } : {
            status: "UNKNOWN"
        }
    }
}
var i = (a => (a.ProductSync = "ProductSync", a.ViewPeriod = "ViewPeriod", a.ViewOnlyFrontend = "ViewOnlyFrontend", a.WhiteLabelCommissions = "WhiteLabelCommissions", a.TictoCommission = "TictoCommission", a.TwoFactorReminder = "TwoFactorReminder", a.Maintenance2025_01_14 = "Maintenance2025_01_14", a.SupportWhatsAppTempChanged = "SupportWhatsAppTempChanged", a.SupportWhatsAppRemoved = "SupportWhatsAppRemoved", a.SupportWhatsAppReturned = "SupportWhatsAppReturned", a.PaginationCampaignsReminder = "PaginationCampaignsReminder", a.DiagnosticAds = "DiagnosticAds", a.KirvanoCommissions = "KirvanoCommissions", a.WhatsApp1Discontinued = "WhatsApp1Discontinued", a.MetaAdsTax = "MetaAdsTax", a))(i || {});
const m = {
    ProductSync: {
        title: "Sincronização dos produtos",
        text: "Para que os produtos apareçam para seleção, é necessário que pelo menos uma venda ou processamento de pedido tenha sido realizado com o devido produto.",
        confirmBeforeClose: !0
    },
    ViewPeriod: {
        title: "Filtro de Período de Visualização",
        text: "Exibimos apenas campanhas com gastos ou criadas no período selecionado. Se não encontrar alguma campanha, ajuste o intervalo de datas.",
        confirmBeforeClose: !1
    },
    ViewOnlyFrontend: {
        title: "Visualizar apenas front-end",
        text: 'Para ver apenas as vendas do produto principal (front-end), use o filtro de produtos. Deixe em "Qualquer" para ver todas as vendas.',
        confirmBeforeClose: !1
    },
    WhiteLabelCommissions: {
        title: "Ocorreu uma atualização nos Webhooks das plataformas: Zippify, Tribo Pay, Mund Pay, Striv Pay, Disrupty e Pantherfy",
        text: "As plataformas acima passaram a enviar a comissão da venda. Não será mais necessário utilizar as taxas no dashboard da UTMify para calcular a sua comissão.",
        confirmBeforeClose: !1
    },
    TictoCommission: {
        title: "Atualizamos a nossa integração com a Ticto",
        text: "As novas vendas irão contabilizar a comissão do usuário. Não será mais necessário utilizar as taxas no dashboard da UTMify para calcular a sua comissão.",
        confirmBeforeClose: !1
    },
    TwoFactorReminder: {
        title: "Configurar a autenticação em dois fatores",
        text: "Para aumentar a segurança da sua conta, recomendamos a ativação da autenticação em dois fatores (2FA). Com essa opção, seu login estará mais protegido contra acessos não autorizados. Embora seja uma recomendação, a ativação não é obrigatória.",
        confirmBeforeClose: !0
    },
    Maintenance2025_01_14: {
        title: "Manutenção programada - 14/01/2025 21:00",
        text: "Nesta terça-feira, 14/01/2025, às 21:00, realizaremos uma manutenção em nossa plataforma para trazer melhorias e implementações nos nossos servidores. Devido a essa atualização, a plataforma poderá ficar fora do ar por algumas horas.",
        confirmBeforeClose: !1
    },
    SupportWhatsAppTempChanged: {
        title: "Problema temporário no WhatsApp do suporte",
        text: "Nosso número de suporte oficial está enfrentando instabilidades. Se você enviou uma mensagem pelo WhatsApp, pedimos que a reenvie para nosso número temporário para que possamos atendê-lo. Clique no ícone do WhatsApp ou envie uma mensagem para: 24992795837",
        confirmBeforeClose: !1
    },
    SupportWhatsAppRemoved: {
        title: "Problemas em nossos números do WhatsApp",
        text: "Nosso número de suporte oficial está passando por uma instabiliadade. Quem já enviou mensagens solicitando ajuda pelo número antigo, pedimos desculpas pelo transtorno. Para atendermos cada um de vocês com prontidão, adicionamos um chat interno no canto inferior direito dentro da Utmify, basta clicar em cima e informar/reenviar a sua dúvida ou problema e iremos prosseguir com o seu atendimento.",
        confirmBeforeClose: !1
    },
    SupportWhatsAppReturned: {
        title: "Suporte via WhatsApp",
        text: "Estamos retornando as atividades do suporte via WhatsApp. Para entrar em contato conosco, clique no ícone do WhatsApp no canto inferior direito da tela, ou entre em contato através do número: 24992281288",
        confirmBeforeClose: !0
    },
    PaginationCampaignsReminder: {
        title: "Suas campanhas estão divididas em mais de uma página",
        text: "Você pode navegar entre as páginas para ver todas as suas campanhas. Use o botão de navegação para avançar ou retroceder entre as páginas.",
        confirmBeforeClose: !1
    },
    DiagnosticAds: {
        title: "Diagnóstico de Anúncios",
        text: "Através deste botão é possível verificar se suas campanhas estão configuradas corretamente com os parâmetros necessários.",
        confirmBeforeClose: !1
    },
    KirvanoCommissions: {
        title: "Comissões da Kirvano",
        text: "Atualizamos a nossa integração com a Kirvano. Agora os valores salvos já consideram a comissão, não sendo mais necessário adicionar taxas para igualar os valores entre Utmify e Kirvano.",
        confirmBeforeClose: !0
    },
    WhatsApp1Discontinued: {
        title: "Tracking WhatsApp 2.0",
        text: "Com a implementação do Tracking WhatsApp 2.0, que traz melhorias importantes de desempenho e estabilidade, a versão 1.0 está sendo descontinuada. Caso algum dos seus números tenha sido desconectado, basta reconectá-lo para aproveitar a nova versão.",
        confirmBeforeClose: !1
    },
    MetaAdsTax: {
        title: "Imposto do anúncio (Meta)",
        text: "Configure a alíquota do imposto aplicado aos anúncios da Meta na aba “Taxas” para que os resultados e o lucro fiquem mais precisos.",
        confirmBeforeClose: !1
    }
};
export {
    m as A, n as S, i as a
};