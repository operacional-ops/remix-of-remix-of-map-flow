import {
    s as r,
    n as s,
    d as p,
    i,
    c,
    o as l,
    h as n
} from "./DDNnt9XD.js";
import {
    S as b,
    i as m
} from "./qWASNxYk.js";

function x(t) {
    let e, d = `<h1 class="text-3xl font-bold my-2 text-center">POLÍTICA DE COOKIES UTMIFY</h1> <p class="mb-2 text-justify text-md">Esta Política de Cookies é disponibilizada e mantida pela UTMIFY TECNOLOGIA
    LTDA, pessoa jurídica de direito privado, regularmente registrada sob o CNPJ
    n° 44.105.337/0001-39, com sede à Rua Moyses Braga Lima, n° 271, Bairro
    Goiabal, Barra Mansa – RJ, CEP 27.340-110. Na UTMIFY, privacidade e
    segurança são prioridades e nos comprometemos com a transparência do
    tratamento de dados pessoais dos nossos Usuários e de terceiros. Esta
    Política de Cookies é um documento complementar à Política de Privacidade da
    UTMIFY, acessível através https://app.utmify.com.br/politica-de-privacidade.
    Neste documento, apresentamos informações claras e precisas sobre o que são
    Cookies, os tipos que utilizamos em nossa plataforma, suas funcionalidades e
    como você pode gerenciá-los.</p> <h2 class="text-2xl font-bold mb-2">1. O QUE SÃO COOKIES?</h2> <p class="mb-2 text-justify text-md">Cookies são pequenos arquivos de texto enviados ao seu computador ou
    dispositivo móvel quando você visita nosso site. Eles armazenam dados que
    são essenciais para oferecer uma navegação mais eficiente e personalizada.
    Os Cookies não armazenam informações pessoais identificáveis diretamente,
    mas são capazes de identificar seu dispositivo de maneira indireta.</p> <h2 class="text-xl font-bold mb-2">1.1. Tipos de Cookies</h2> <p class="mb-2 text-justify text-md"><strong>Cookies próprios:</strong> São aqueles definidos pelo próprio site que
    você está visitando, e apenas esse site pode ler as informações.</p> <p class="mb-2 text-justify text-md"><strong>Cookies de terceiros:</strong> São configurados por um domínio diferente
    do site que está sendo visitado. Isso acontece, por exemplo, com elementos incorporados
    que pertencem a outro domínio, como anúncios ou imagens.</p> <p class="mb-2 text-justify text-md"><strong>Cookies de sessão:</strong> São temporários e são excluídos assim que
    você fecha o navegador ou termina a sessão no website.</p> <p class="mb-2 text-justify text-md"><strong>Cookies persistentes:</strong> Permanecem no dispositivo do usuário por
    um tempo predeterminado ou até que sejam excluídos manualmente, permitindo que
    as preferências ou ações do usuário sejam lembradas em visitas futuras ao site.</p> <p class="mb-2 text-justify text-md"><strong>Cookies necessários:</strong> São essenciais para navegar no site/plataforma
    e usar suas funcionalidades, como acessar áreas seguras. Sem esses cookies, serviços
    essenciais da plataforma não podem ser fornecidos.</p> <p class="mb-2 text-justify text-md"><strong>Cookies de desempenho:</strong> Coletam informações sobre como você usa
    o site, como quais páginas você visita com mais frequência. Eles não coletam
    informações que identificam o usuário e são usados apenas para melhorar o desempenho
    do site.</p> <p class="mb-2 text-justify text-md"><strong>Cookies de funcionalidade:</strong> Permitem que o site lembre as escolhas
    que você faz (como seu nome de usuário, idioma ou a região em que está) e forneçam
    recursos aprimorados e mais pessoais.</p> <p class="mb-2 text-justify text-md"><strong>Cookies de publicidade:</strong> São usados para entregar anúncios mais
    relevantes para você e seus interesses. Eles também são usados para limitar o
    número de vezes que você vê um anúncio, bem como ajudar a medir a eficácia da
    campanha publicitária.</p> <h2 class="text-2xl font-bold mb-2">2. POR QUE USAMOS COOKIES?</h2> <p class="mb-2 text-justify text-md">A UTMIFY utiliza Cookies para aprimorar a funcionalidade de nosso site e
    plataforma, facilitando serviços como autenticação de usuários, preferências
    de idioma, análise de desempenho do site, entre outros. Eles nos permitem
    ajustar o conteúdo às suas necessidades e preferências, melhorando
    continuamente a sua experiência.</p> <h2 class="text-2xl font-bold mb-2">3. QUE TIPO DE COOKIES UTILIZAMOS?</h2> <p class="mb-2 text-justify text-md">Listaremos todos os Cookies que podem ser utilizados pela UTMIFY, detalhando
    sua função e necessidade. É importante lembrar que você pode controlar a
    permissão concedida para cada Cookie diretamente no seu navegador. Logo
    abaixo segue uma lista com todos os cookies utilizados:</p> <div class="overflow-x-auto mb-2"><table class="table-auto border-collapse w-full"><thead><tr><th class="border px-1 py-2">PROVEDOR</th> <th class="border px-1 py-2">NOME</th> <th class="border px-1 py-2">TIPO DE COOKIE</th> <th class="border px-1 py-2">VENCIMENTO</th> <th class="border px-1 py-2">FINALIDADE</th></tr></thead> <tbody><tr><td class="border px-1 py-2">Google Analytics</td> <td class="border px-1 py-2">_ga</td> <td class="border px-1 py-2">Cookie de Desempenho</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Armazena e conta as visualizações da página.</td></tr> <tr><td class="border px-1 py-2">Google Adsense</td> <td class="border px-1 py-2">_ga_EMB1BST8V9</td> <td class="border px-1 py-2">Cookie de Desempenho</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Ajuda os proprietários de sites a entender melhor como os
            visitantes interagem com seus sites, permitindo-lhes melhorar a
            experiência do usuário e otimizar o conteúdo do site.</td></tr> <tr><td class="border px-1 py-2">Google Analytics</td> <td class="border px-1 py-2">_ga_H30R9PNQFN</td> <td class="border px-1 py-2">Cookie de Desempenho</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Ajuda os proprietários de sites a entender melhor como os
            visitantes interagem com seus sites, permitindo-lhes melhorar a
            experiência do usuário e otimizar o conteúdo do site.</td></tr> <tr><td class="border px-1 py-2">Google Analytics</td> <td class="border px-1 py-2">_ga_J1P6G0T9W9</td> <td class="border px-1 py-2">Cookie de Desempenho</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Ajuda os proprietários de sites a entender melhor como os
            visitantes interagem com seus sites, permitindo-lhes melhorar a
            experiência do usuário e otimizar o conteúdo do site.</td></tr> <tr><td class="border px-1 py-2">Google Adsense</td> <td class="border px-1 py-2">_gcl_au</td> <td class="border px-1 py-2">Cookie de Desempenho</td> <td class="border px-1 py-2">Persistente</td> <td class="border px-1 py-2">Armazena e rastreia conversões.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">ACCOUNT_CHOOSER</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Permite que o Google colete informações do usuário para vídeos
            hospedados no Youtube.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">APISID</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Permite que o Google colete informações do usuário para vídeos
            hospedados no Youtube.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">1P_JAR</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">31 dias</td> <td class="border px-1 py-2">Fornece entrega de anúncios ou retargeting.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">AEC</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">183 dias</td> <td class="border px-1 py-2">São usados para detectar spam, fraude e abuso para ajudar a
            garantir que os anunciantes não sejam cobrados incorretamente por
            impressões ou interações fraudulentas ou inválidas com anúncios, e
            que os criadores de conteúdo do Programa de Parcerias do YouTube
            sejam remunerados de modo justo.</td></tr> <tr><td class="border px-1 py-2">Google</td> <td class="border px-1 py-2">COMPASS</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">10 dias</td> <td class="border px-1 py-2">Necessário para o uso das opções e serviços do Gmail, Google Drive,
            Google Agenda e Google Docs.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">GMAIL_AT</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">Ao fim da sessão</td> <td class="border px-1 py-2">Necessário para o uso das opções e serviços do Gmail, Google Drive,
            Google Agenda e Google Docs.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">GMAIL_LF</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">365 dias</td> <td class="border px-1 py-2">Necessário para o uso das opções e serviços do Gmail, Google Drive,
            Google Agenda e Google Docs.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">HSID</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Fornece prevenção à fraudes.</td></tr> <tr><td class="border px-1 py-2">Google DoubleClick</td> <td class="border px-1 py-2">IDE</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Fornece entrega de anúncios ou retargeting.</td></tr> <tr><td class="border px-1 py-2">Google Analytics</td> <td class="border px-1 py-2">LSID</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Verifica se o usuário está conectado ao navegador Google Crhome.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">NID</td> <td class="border px-1 py-2">Cookie de Marketing e Funcionalidade</td> <td class="border px-1 py-2">183 dias</td> <td class="border px-1 py-2">Fornece entrega de anúncios ou retargeting, armazena preferências
            do usuário.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">OSID</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">183 dias</td> <td class="border px-1 py-2">Fornece anúncios relevantes em sites externos.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">OTZ</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">183 dias</td> <td class="border px-1 py-2">Fornece anúncios relevantes em sites externos.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">SMSV</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">183 dias</td> <td class="border px-1 py-2">Fornece anúncios relevantes em sites externos.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">SAPISID</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Permite que você compartilhe informações publicamente, como parte
            do seu Perfil do Google.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">SID</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Fornece entrega de anúncios ou retargeting, fornece prevenção à
            fraudes.</td></tr> <tr><td class="border px-1 py-2">Google Maps</td> <td class="border px-1 py-2">SIDCC</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">365 dias</td> <td class="border px-1 py-2">Fornece a identificação de tráfego da web confiável.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">SNID</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Permite que você compartilhe informações publicamente, como parte
            do seu Perfil do Google.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">__Host-GMAIL_SCH</td> <td class="border px-1 py-2">Cookie Necessário</td> <td class="border px-1 py-2">Ao fim da sessão</td> <td class="border px-1 py-2">Necessário para o uso das opções e serviços do Gmail.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">__Host-GMAIL_SCH_GML</td> <td class="border px-1 py-2">Cookie Necessário</td> <td class="border px-1 py-2">19 dias</td> <td class="border px-1 py-2">Necessário para o uso das opções e serviços do Gmail.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">__Host-1PLSID</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Usado para fazer login em nosso site com sua conta do Google.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">__Host-3PLSID</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Usado para fazer login em nosso site com sua conta do Google.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">__Host-GAPS</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Usado para fazer login em nosso site com sua conta do Google.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">__Secure-1PAPISID</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Usado para fazer login em nosso site com sua conta do Google.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">__Secure-1PSID</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Usado para fazer login em nosso site com sua conta do Google.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">__Secure-1PSIDCC</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">365 dias</td> <td class="border px-1 py-2">Usado para fazer login em nosso site com sua conta do Google.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">__Secure-1PSIDTS</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">365 dias</td> <td class="border px-1 py-2">Coleta informações sobre suas interações com serviços e anúncios do
            Google.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">__Secure-3PAPISID</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Usado para fazer login em nosso site com sua conta do Google.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">__Secure-3PSID</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Usado para fazer login em nosso site com sua conta do Google.</td></tr> <tr><td class="border px-1 py-2">Google Accounts</td> <td class="border px-1 py-2">__Secure-3PSIDCC</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">365 dias</td> <td class="border px-1 py-2">Usado para fazer login em nosso site com sua conta do Google.</td></tr> <tr><td class="border px-1 py-2">Google Ads Optimization</td> <td class="border px-1 py-2">__Secure-3PSIDTS</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">365 dias</td> <td class="border px-1 py-2">Coleta informações sobre suas interações com serviços e anúncios do
            Google.</td></tr> <tr><td class="border px-1 py-2">Google</td> <td class="border px-1 py-2">__Secure-OSID</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">214 dias</td> <td class="border px-1 py-2">Necessário para o uso das opções e serviços do Gmail, Google Agenda
            e Google Meet.</td></tr> <tr><td class="border px-1 py-2">Facebook</td> <td class="border px-1 py-2">_fbp</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">91 dias</td> <td class="border px-1 py-2">Armazena e rastreia visitas em sites.</td></tr> <tr><td class="border px-1 py-2">Facebook</td> <td class="border px-1 py-2">c_user</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">30 dias</td> <td class="border px-1 py-2">Armazena um ID único de sessão.</td></tr> <tr><td class="border px-1 py-2">Facebook</td> <td class="border px-1 py-2">datr</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Fornece prenvenção à fraudes.</td></tr> <tr><td class="border px-1 py-2">Facebook</td> <td class="border px-1 py-2">fr</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">91 dias</td> <td class="border px-1 py-2">Fornece entrega de anúncios ou retargeting.</td></tr> <tr><td class="border px-1 py-2">Facebook</td> <td class="border px-1 py-2">ps_l</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">365 dias</td> <td class="border px-1 py-2">Um cookie de publicidade do Facebook.</td></tr> <tr><td class="border px-1 py-2">Facebook</td> <td class="border px-1 py-2">ps_n</td> <td class="border px-1 py-2">Cookie de Marketing</td> <td class="border px-1 py-2">365 dias</td> <td class="border px-1 py-2">Um cookie de publicidade do Facebook.</td></tr> <tr><td class="border px-1 py-2">Facebook</td> <td class="border px-1 py-2">sb</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">730 dias</td> <td class="border px-1 py-2">Armazena informações sobre o dispositivo de navegação do usuário.</td></tr> <tr><td class="border px-1 py-2">Facebook</td> <td class="border px-1 py-2">xs</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">91 dias</td> <td class="border px-1 py-2">Armazena um ID único de sessão.</td></tr> <tr><td class="border px-1 py-2">Facebook</td> <td class="border px-1 py-2">wd</td> <td class="border px-1 py-2">Cookie de Funcionalidade</td> <td class="border px-1 py-2">7 dias</td> <td class="border px-1 py-2">Armazena informações sobre a resolução de tela do usuário.</td></tr></tbody></table></div> <h2 class="text-2xl font-bold mb-2">4. GERENCIAMENTO DOS COOKIES</h2> <p class="mb-2 text-justify text-md">Você pode controlar e gerenciar os Cookies através das configurações do seu
    navegador, decidindo bloquear ou aceitar parcial ou totalmente os Cookies.
    Ao acessar nossas aplicações pela primeira vez, um sistema de consentimento
    (como um banner informativo) solicitará sua permissão para ativar os
    Cookies. Sua aceitação implicará em consentimento para a sua ativação.</p> <p class="mb-2 text-justify text-md">Se você usa o Internet Explorer;</p> <p class="mb-2 text-justify text-md">Se você usa o Firefox;</p> <p class="mb-2 text-justify text-md">Se você usa o Google Chrome;</p> <p class="mb-2 text-justify text-md">Se você usa o Safari;</p> <p class="mb-2 text-justify text-md">Se você usa o Microsoft Edge;</p> <p class="mb-2 text-justify text-md">Se você usa o Opera;</p> <h2 class="text-2xl font-bold mb-2">5. DISPOSIÇÕES FINAIS</h2> <p class="mb-2 text-justify text-md">Estamos comprometidos com a segurança e a privacidade de seus dados.
    Portanto, a UTMIFY se reserva o direito de fazer alterações nesta Política
    de Cookies, as quais serão efetivadas imediatamente após sua publicação em
    nosso site.</p> <p class="mb-2 text-justify text-md">Em caso de dúvidas sobre esta Política de Cookies, você pode entrar em
    contato conosco através dos seguintes meios:</p> <p class="mb-2 text-justify text-md">Meio de contato: contato@utmify.com.br</p> <p class="mb-2 text-justify text-md">Esta Política de Cookies foi atualizada pela última vez em: 08/05/2024.</p> <p class="mb-2 text-justify text-md">Continuar a navegação em nosso site após as mudanças na Política será
    considerado como aceitação dessas modificações.</p>`;
    return {
        c() {
            e = n("div"), e.innerHTML = d
        },
        l(o) {
            e = c(o, "DIV", {
                "data-svelte-h": !0
            }), l(e) !== "svelte-tl4hiw" && (e.innerHTML = d)
        },
        m(o, a) {
            i(o, e, a)
        },
        p: s,
        i: s,
        o: s,
        d(o) {
            o && p(e)
        }
    }
}
class g extends b {
    constructor(e) {
        super(), m(this, e, null, x, r, {})
    }
}
export {
    g as P
};