var jn = Object.defineProperty;
var zn = (t, e, r) => e in t ? jn(t, e, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: r
}) : t[e] = r;
var b = (t, e, r) => zn(t, typeof e != "symbol" ? e + "" : e, r);
import {
    g as Vn
} from "./B0Dzt1sk.js";
import {
    s as Ye,
    n as ye,
    d as _,
    m as T,
    i as et,
    b as me,
    C as ee,
    e as te,
    D as ne,
    W as ht
} from "./DDNnt9XD.js";
import {
    S as tt,
    i as nt
} from "./qWASNxYk.js";
import {
    S as _n
} from "./DwsiLpv2.js";

function $n(t) {
    let e, r, a, o;
    return {
        c() {
            e = ne("svg"), r = ne("path"), a = ne("polygon"), this.h()
        },
        l(u) {
            e = ee(u, "svg", {
                xmlns: !0,
                width: !0,
                height: !0,
                fill: !0,
                viewBox: !0,
                stroke: !0,
                "stroke-width": !0,
                "stroke-linecap": !0,
                "stroke-linejoin": !0,
                class: !0
            });
            var l = te(e);
            r = ee(l, "path", {
                d: !0
            }), te(r).forEach(_), a = ee(l, "polygon", {
                points: !0
            }), te(a).forEach(_), l.forEach(_), this.h()
        },
        h() {
            T(r, "d", "M5 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-1"), T(a, "points", "12 15 17 21 7 21 12 15"), T(e, "xmlns", "http://www.w3.org/2000/svg"), T(e, "width", t[0]), T(e, "height", t[0]), T(e, "fill", "none"), T(e, "viewBox", "0 0 24 24"), T(e, "stroke", "currentColor"), T(e, "stroke-width", t[1]), T(e, "stroke-linecap", "round"), T(e, "stroke-linejoin", "round"), T(e, "class", o = "feather feather-airplay " + t[2])
        },
        m(u, l) {
            et(u, e, l), me(e, r), me(e, a)
        },
        p(u, [l]) {
            l & 1 && T(e, "width", u[0]), l & 1 && T(e, "height", u[0]), l & 2 && T(e, "stroke-width", u[1]), l & 4 && o !== (o = "feather feather-airplay " + u[2]) && T(e, "class", o)
        },
        i: ye,
        o: ye,
        d(u) {
            u && _(e)
        }
    }
}

function Gn(t, e, r) {
    let {
        size: a = "24"
    } = e, {
        strokeWidth: o = 2
    } = e, {
        class: u = ""
    } = e;
    return a !== "100%" && (a = a.slice(-1) === "x" ? a.slice(0, a.length - 1) + "em" : parseInt(a) + "px"), t.$$set = l => {
        "size" in l && r(0, a = l.size), "strokeWidth" in l && r(1, o = l.strokeWidth), "class" in l && r(2, u = l.class)
    }, [a, o, u]
}
class Jn extends tt {
    constructor(e) {
        super(), nt(this, e, Gn, $n, Ye, {
            size: 0,
            strokeWidth: 1,
            class: 2
        })
    }
}

function Kn(t) {
    let e, r, a, o, u;
    return {
        c() {
            e = ne("svg"), r = ne("rect"), a = ne("line"), o = ne("line"), this.h()
        },
        l(l) {
            e = ee(l, "svg", {
                xmlns: !0,
                width: !0,
                height: !0,
                fill: !0,
                viewBox: !0,
                stroke: !0,
                "stroke-width": !0,
                "stroke-linecap": !0,
                "stroke-linejoin": !0,
                class: !0
            });
            var d = te(e);
            r = ee(d, "rect", {
                x: !0,
                y: !0,
                width: !0,
                height: !0,
                rx: !0,
                ry: !0
            }), te(r).forEach(_), a = ee(d, "line", {
                x1: !0,
                y1: !0,
                x2: !0,
                y2: !0
            }), te(a).forEach(_), o = ee(d, "line", {
                x1: !0,
                y1: !0,
                x2: !0,
                y2: !0
            }), te(o).forEach(_), d.forEach(_), this.h()
        },
        h() {
            T(r, "x", "2"), T(r, "y", "3"), T(r, "width", "20"), T(r, "height", "14"), T(r, "rx", "2"), T(r, "ry", "2"), T(a, "x1", "8"), T(a, "y1", "21"), T(a, "x2", "16"), T(a, "y2", "21"), T(o, "x1", "12"), T(o, "y1", "17"), T(o, "x2", "12"), T(o, "y2", "21"), T(e, "xmlns", "http://www.w3.org/2000/svg"), T(e, "width", t[0]), T(e, "height", t[0]), T(e, "fill", "none"), T(e, "viewBox", "0 0 24 24"), T(e, "stroke", "currentColor"), T(e, "stroke-width", t[1]), T(e, "stroke-linecap", "round"), T(e, "stroke-linejoin", "round"), T(e, "class", u = "feather feather-monitor " + t[2])
        },
        m(l, d) {
            et(l, e, d), me(e, r), me(e, a), me(e, o)
        },
        p(l, [d]) {
            d & 1 && T(e, "width", l[0]), d & 1 && T(e, "height", l[0]), d & 2 && T(e, "stroke-width", l[1]), d & 4 && u !== (u = "feather feather-monitor " + l[2]) && T(e, "class", u)
        },
        i: ye,
        o: ye,
        d(l) {
            l && _(e)
        }
    }
}

function Qn(t, e, r) {
    let {
        size: a = "24"
    } = e, {
        strokeWidth: o = 2
    } = e, {
        class: u = ""
    } = e;
    return a !== "100%" && (a = a.slice(-1) === "x" ? a.slice(0, a.length - 1) + "em" : parseInt(a) + "px"), t.$$set = l => {
        "size" in l && r(0, a = l.size), "strokeWidth" in l && r(1, o = l.strokeWidth), "class" in l && r(2, u = l.class)
    }, [a, o, u]
}
class Xn extends tt {
    constructor(e) {
        super(), nt(this, e, Qn, Kn, Ye, {
            size: 0,
            strokeWidth: 1,
            class: 2
        })
    }
}

function Zn(t) {
    let e, r, a, o;
    return {
        c() {
            e = ne("svg"), r = ne("rect"), a = ne("line"), this.h()
        },
        l(u) {
            e = ee(u, "svg", {
                xmlns: !0,
                width: !0,
                height: !0,
                fill: !0,
                viewBox: !0,
                stroke: !0,
                "stroke-width": !0,
                "stroke-linecap": !0,
                "stroke-linejoin": !0,
                class: !0
            });
            var l = te(e);
            r = ee(l, "rect", {
                x: !0,
                y: !0,
                width: !0,
                height: !0,
                rx: !0,
                ry: !0
            }), te(r).forEach(_), a = ee(l, "line", {
                x1: !0,
                y1: !0,
                x2: !0,
                y2: !0
            }), te(a).forEach(_), l.forEach(_), this.h()
        },
        h() {
            T(r, "x", "5"), T(r, "y", "2"), T(r, "width", "14"), T(r, "height", "20"), T(r, "rx", "2"), T(r, "ry", "2"), T(a, "x1", "12"), T(a, "y1", "18"), T(a, "x2", "12.01"), T(a, "y2", "18"), T(e, "xmlns", "http://www.w3.org/2000/svg"), T(e, "width", t[0]), T(e, "height", t[0]), T(e, "fill", "none"), T(e, "viewBox", "0 0 24 24"), T(e, "stroke", "currentColor"), T(e, "stroke-width", t[1]), T(e, "stroke-linecap", "round"), T(e, "stroke-linejoin", "round"), T(e, "class", o = "feather feather-smartphone " + t[2])
        },
        m(u, l) {
            et(u, e, l), me(e, r), me(e, a)
        },
        p(u, [l]) {
            l & 1 && T(e, "width", u[0]), l & 1 && T(e, "height", u[0]), l & 2 && T(e, "stroke-width", u[1]), l & 4 && o !== (o = "feather feather-smartphone " + u[2]) && T(e, "class", o)
        },
        i: ye,
        o: ye,
        d(u) {
            u && _(e)
        }
    }
}

function Yn(t, e, r) {
    let {
        size: a = "24"
    } = e, {
        strokeWidth: o = 2
    } = e, {
        class: u = ""
    } = e;
    return a !== "100%" && (a = a.slice(-1) === "x" ? a.slice(0, a.length - 1) + "em" : parseInt(a) + "px"), t.$$set = l => {
        "size" in l && r(0, a = l.size), "strokeWidth" in l && r(1, o = l.strokeWidth), "class" in l && r(2, u = l.class)
    }, [a, o, u]
}
class er extends tt {
    constructor(e) {
        super(), nt(this, e, Yn, Zn, Ye, {
            size: 0,
            strokeWidth: 1,
            class: 2
        })
    }
}

function tr(t) {
    let e, r, a, o;
    return {
        c() {
            e = ne("svg"), r = ne("rect"), a = ne("line"), this.h()
        },
        l(u) {
            e = ee(u, "svg", {
                xmlns: !0,
                width: !0,
                height: !0,
                fill: !0,
                viewBox: !0,
                stroke: !0,
                "stroke-width": !0,
                "stroke-linecap": !0,
                "stroke-linejoin": !0,
                class: !0
            });
            var l = te(e);
            r = ee(l, "rect", {
                x: !0,
                y: !0,
                width: !0,
                height: !0,
                rx: !0,
                ry: !0
            }), te(r).forEach(_), a = ee(l, "line", {
                x1: !0,
                y1: !0,
                x2: !0,
                y2: !0
            }), te(a).forEach(_), l.forEach(_), this.h()
        },
        h() {
            T(r, "x", "4"), T(r, "y", "2"), T(r, "width", "16"), T(r, "height", "20"), T(r, "rx", "2"), T(r, "ry", "2"), T(a, "x1", "12"), T(a, "y1", "18"), T(a, "x2", "12.01"), T(a, "y2", "18"), T(e, "xmlns", "http://www.w3.org/2000/svg"), T(e, "width", t[0]), T(e, "height", t[0]), T(e, "fill", "none"), T(e, "viewBox", "0 0 24 24"), T(e, "stroke", "currentColor"), T(e, "stroke-width", t[1]), T(e, "stroke-linecap", "round"), T(e, "stroke-linejoin", "round"), T(e, "class", o = "feather feather-tablet " + t[2])
        },
        m(u, l) {
            et(u, e, l), me(e, r), me(e, a)
        },
        p(u, [l]) {
            l & 1 && T(e, "width", u[0]), l & 1 && T(e, "height", u[0]), l & 2 && T(e, "stroke-width", u[1]), l & 4 && o !== (o = "feather feather-tablet " + u[2]) && T(e, "class", o)
        },
        i: ye,
        o: ye,
        d(u) {
            u && _(e)
        }
    }
}

function nr(t, e, r) {
    let {
        size: a = "24"
    } = e, {
        strokeWidth: o = 2
    } = e, {
        class: u = ""
    } = e;
    return a !== "100%" && (a = a.slice(-1) === "x" ? a.slice(0, a.length - 1) + "em" : parseInt(a) + "px"), t.$$set = l => {
        "size" in l && r(0, a = l.size), "strokeWidth" in l && r(1, o = l.strokeWidth), "class" in l && r(2, u = l.class)
    }, [a, o, u]
}
class rr extends tt {
    constructor(e) {
        super(), nt(this, e, nr, tr, Ye, {
            size: 0,
            strokeWidth: 1,
            class: 2
        })
    }
}
const Q = class Q {
    static get size() {
        return window.innerWidth < Q.smallPixels ? "small" : window.innerWidth < Q.mediumPixels ? "medium" : window.innerWidth < Q.largePixels ? "large" : "extraLarge"
    }
    static get sizeInPixels() {
        return window.innerWidth
    }
    static isGreaterThanOrEqual(e) {
        return Q.sizeInPixels >= Q.sizeToPixels(e)
    }
    static sizeToPixels(e) {
        switch (e) {
            case "small":
                return Q.smallPixels;
            case "medium":
                return Q.mediumPixels;
            case "large":
                return Q.largePixels;
            case "extraLarge":
                return Q.extraLargePixels;
            default:
                return 0
        }
    }
};
b(Q, "smallPixels", 640), b(Q, "mediumPixels", 840), b(Q, "largePixels", 1024), b(Q, "extraLargePixels", 1280);
let gt = Q;
const ia = t => {
        switch (t) {
            case "small":
                return "Celular";
            case "medium":
                return "Tablet";
            case "large":
                return "Mini Laptop";
            case "extraLarge":
                return "Desktop";
            default:
                return ""
        }
    },
    aa = t => {
        switch (t) {
            case "small":
                return er;
            case "medium":
                return rr;
            case "large":
                return Jn;
            case "extraLarge":
                return Xn;
            default:
                return ""
        }
    };
class R {
    static visualizationPeriodTooltip(e) {
        return e === "Google" ? "Este é o período de visualização dos dados. <br/>Por exemplo, se você escolher 'Hoje', vamos listar suas campanhas e mostrar os gastos de hoje.<br/><br/>Note também que o filtro por horário só se refere a pedidos, mas não a gastos do Google." : e === "Kwai" ? "Este é o período de visualização dos dados. <br/>Por exemplo, se você escolher 'Hoje', vamos listar as campanhas que foram criadas ou tiveram gastos hoje." : e === "TikTok" ? "Este é o período de visualização dos dados. <br/>Por exemplo, se você escolher 'Hoje', vamos listar suas campanhas e mostrar os gastos de hoje.<br/><br/>Note também que o filtro por horário só se refere a pedidos, mas não a gastos do TikTok." : "Este é o período de visualização dos dados. <br/>Por exemplo, se você escolher 'Hoje', vamos listar as campanhas que foram criadas ou tiveram gastos hoje. <br/><br/>Note também que o filtro por horário só se refere a pedidos, mas não a gastos do Facebook."
    }
}
b(R, "summary", "Resumo"), b(R, "campaigns", "Meta"), b(R, "google", "Google"), b(R, "kwai", "Kwai"), b(R, "tikTok", "TikTok"), b(R, "integrations", "Integrações"), b(R, "additionalValues", "Taxas"), b(R, "customSpendings", "Despesas"), b(R, "rules", "Regras"), b(R, "reports", "Relatórios"), b(R, "utms", "UTMs"), b(R, "subscription", "Assinatura"), b(R, "account", "Minha conta"), b(R, "advanced", "Avançado"), b(R, "queue", "Filas"), b(R, "help", "Suporte"), b(R, "app", "Aplicativo"), b(R, "affiliate", "Indique e Ganhe 10%"), b(R, "notifications", "Notificações"), b(R, "news", "Novidades"), b(R, "untrackedTooltip", `Uma venda não trackeada é uma venda que é contabilizada na página de Resumo,
	mas que não é possível identificar de qual campanha veio.`), b(R, "utmDiagnosticAdsTooltip", "Verifique se suas campanhas estão corretamente configuradas com os parâmetros necessários."), b(R, "rulesTooltip", "Atualize campanhas, conjuntos de anúncios ou anúncios em massa automaticamente criando regras automatizadas"), b(R, "customSpendingsToolTip", "Adicione ou edite os gastos adicionais da sua operação"), b(R, "customSpendingsDescriptionFilterToolTip", "Filtre seus gastos por descrição."), b(R, "customSpendingsCategoryFilterToolTip", "Filtre seus gastos por categoria."), b(R, "customSpendingsDateFilterToolTip", "Filtre seus gastos por período."), b(R, "dashboardViewTooltip", `
	  Escolha se quer ver o faturamento total ou normal no dashboard.
	  <br/>
	  <br/>
	  Faturamento Total: Valor total, sem descontar taxas de gateway, co-produção ou afiliação.
	  <br/>
	  Faturamento Normal: Valor da venda, descontando taxas de gateway, co-produção e afiliação sempre que possível.
	`), b(R, "dashboardTimeZoneTooltip", "Escolha o fuso horário de visualização das suas métricas."), b(R, "dashboardCurrencyTooltip", "Escolha a moeda que deseja usar para suas métricas, regras e taxas."), b(R, "visualizationPeriodReportsTooltip", "Este é o período de visualização dos dados diários. <br/>Por exemplo, se você escolher 'Essa semana', vamos listar os dados que foram criados essa semana."), b(R, "extraFeesPaymentMethodTooltip", "Escolha as formas de pagamento em que a taxa deve ser aplicada."), b(R, "calcShippingTooltip", "Se habilitado, o valor do frete será somado ao valor da venda."), b(R, "calcInterestTooltip", "Se habilitado, o faturamento padrão incluirá juros de parcelamento."), b(R, "prizeProgressTooltip", "Progresso para receber prêmios. <br></br> Baseado no faturamento trackeado com a Utmify.<br></br> (atualizado semanalmente)<br> [apenas para assinantes]"), b(R, "timeZoneIana", "Fuso horário considerado ao buscar dados do Kwai.");
var ve = (t => (t.Total = "Total", t.Normal = "Normal", t))(ve || {});
const oa = () => [{
        value: "Total",
        label: Lt("Total")
    }, {
        value: "Normal",
        label: Lt("Normal")
    }],
    Lt = t => {
        switch (t) {
            case "Total":
                return "Faturamento Total";
            case "Normal":
                return "Faturamento Normal";
            default:
                return t
        }
    },
    B = class B {
        static approvalRateTooltip() {
            return "Porcentagem de pagamentos aprovados para cada meio de pagamento"
        }
        static netRevenueLabel(e) {
            return (e == null ? void 0 : e.viewType) === ve.Total ? "Faturamento Líquido Total" : "Faturamento Líquido"
        }
        static grossRevenueLabel(e) {
            return (e == null ? void 0 : e.viewType) === ve.Total ? "Faturamento Bruto Total" : "Faturamento Bruto"
        }
        static adSpentTooltip() {
            return "Valor gasto em anúncios"
        }
        static netRevenueTooltip(e) {
            return (e == null ? void 0 : e.viewType) === ve.Total ? `Faturamento líquido total das vendas aprovadas <br/><br/> Fat. Líq. Total = Venda - ${B.feesLabel} - ${B.totalTaxWithMetaAdsTaxLabel} - ${B.productsCostLabel}<br/><br/> (Essa métrica não desconta as taxas de coprodutores e afiliados)` : `Faturamento líquido das vendas aprovadas <br/><br/> Fat. Líq. = Venda - Taxa do gateway de pagamentos - Taxas de coprodutores e afiliados - ${B.feesLabel} - ${B.totalTaxWithMetaAdsTaxLabel} - ${B.productsCostLabel}`
        }
        static netArpuTooltip(e) {
            return (e == null ? void 0 : e.viewType) === ve.Total ? "Faturamento líquido total das vendas aprovadas / Clientes distintos" : "Faturamento líquido / Clientes distintos"
        }
        static grossRevenueTooltip(e) {
            return (e == null ? void 0 : e.viewType) === ve.Total ? "Faturamento Bruto total das vendas aprovadas <br/><br/> Fat. Bruto. Total = Valor da Venda <br/><br/> (Essa métrica não desconta as taxas de coprodutores e afiliados)" : "Faturamento Bruto das vendas aprovadas <br/><br/> Fat. Bruto. = Venda - Taxa do gateway de pagamentos - Taxas de coprodutores e afiliados"
        }
        static roasTooltip(e) {
            return `Retorno sobre o investimento em anúncios <br/><br/> ${B.roasLabel} = ${B.grossRevenueLabel(e)} / ${B.adSpentLabel}`
        }
        static profitMarginTooltip(e) {
            return `Equivale ao percentual do faturamento que é lucro <br/><br/> ${B.profitMarginLabel} = ${B.profitLabel} / ${B.netRevenueLabel(e)}`
        }
        static salesByPaymentTooltip() {
            return "Quantidade de vendas aprovadas por tipo de pagamento"
        }
        static salesByProductTooltip() {
            return "Total de unidades vendidas.<br/><br/>Uma venda pode incluir várias unidades."
        }
        static revenueByProductTooltip() {
            return "Faturamento gerado por cada produto."
        }
        static salesByUtmSourceTooltip() {
            return "Quantidade de vendas por cada 'utm_source' <br/><br/> 'MetaAds' = vendas da Meta identificáveis <br/> 'N/A' = vendas com parâmetro vazio <br/> Outros = vendas pelo nome do parâmetro <br/><br/> Se suas vendas da Meta não estão corretas, tente revisar sua configuração de UTMs"
        }
        static salesBySrcTooltip() {
            return "Quantidade de vendas por cada 'src' <br/><br/> 'N/A' = vendas com parâmetro vazio <br/> Outros = vendas pelo nome do parâmetro"
        }
        static salesByUtmTermTooltip() {
            return "Quantidade de vendas por cada Posicionamento de anúncio. <br/>Para esse gráfico funcionar corretamente, é importante que as UTMs estejam configuradas da forma correta.<br/><br/> 'N/A' = vendas com parâmetro de posicionamento vazio <br/> Outros = vendas pelo nome do posicionamento"
        }
        static salesByCustomerCountryTooltip() {
            return "Quantidade de vendas por cada país <br/><br/> 'N/A' = vendas com parâmetro vazio <br/> Outros = vendas pelo nome do país"
        }
        static salesByHourTooltip() {
            return "Percentual de vendas para cada hora do dia"
        }
        static profitByHourTooltip() {
            return "Lucro por hora no período selecionado (máx. 31 dias).<br/><br/><b>Bruto</b> = Receita − Gastos com anúncios<br/><br/> <b>Líquido</b> = Bruto − Impostos − Taxas de pagamento − Custo dos produtos"
        }
        static salesByDayOfWeekTooltip() {
            return "Percentual de vendas para cada dia da semana"
        }
        static conversionFunnelTooltip() {
            return "O funil de conversão analisa as métricas<br/>de cada etapa do seu funil. Sendo elas:<br/><br/>- Cliques;<br/>- Visualizações de Página;<br/>- Início de Finalização de Compra;<br/>- Vendas Iniciadas;<br/>- Vendas Aprovadas.<br/><br/>As métricas de cliques, vis. de página e<br/>ICs são advindas do Meta. Para maior<br/>assertividade, é necessário que o pixel<br/>esteja configurado corretamente. <br/><br/> Esse gráfico considera apenas os dados<br/> da Meta."
        }
        static revenueInvestmentProfitByHourTooltip() {
            return "Comparação acumulativa de faturamento, investimento e lucro ao longo de cada hora do dia."
        }
        static roiTooltip(e) {
            return `Retorno sobre o investimento <br/><br/> ${B.roiLabel} = ${B.netRevenueLabel(e)} / Gastos Totais`
        }
        static icTooltip() {
            return "Finalizações de compra iniciadas. <br/><br/> Diferente das vendas, essa métrica é estimada e pode não ser 100% precisa."
        }
        static addToCartTooltip() {
            return "Adições ao carrinho.<br/><br/>Quantidade total de adições ao carrinho na sua conta, campanha, conjunto ou anúncio."
        }
        static leadTooltip() {
            return "Cadastros registrados. <br/><br/> Ative o Pixel da Utmify para essa métrica funcionar corretamente."
        }
        static costPerIcTooltip() {
            return "Custo por finalização de compra iniciada. <br/><br/> Diferente das vendas, essa métrica é estimada e pode não ser 100% precisa."
        }
        static costPerAddToCartTooltip() {
            return "Custo por adições ao carrinho.<br/><br/>Custo por adições ao carrinho = Gastos / Adições ao carrinho"
        }
        static costPerLeadTooltip() {
            return "Custo por Lead/Cadastro. <br/><br/> Diferente das vendas, essa métrica é estimada e pode não ser 100% precisa."
        }
        static taxTooltip() {
            return `Imposto sobre o Faturamento Líquido ou Bruto. <br/><br/> Pode ser configurado na aba ${R.additionalValues}.`
        }
        static metaAdsTaxTooltip() {
            return `Imposto específico aplicado sobre o Faturamento Líquido ou Bruto proveniente de anúncios da Meta. <br/><br/> Pode ser configurado na aba ${R.additionalValues}.`
        }
        static totalTaxWithMetaAdsTaxTooltip() {
            return `Imposto total aplicado sobre o Faturamento Líquido ou Bruto, incluindo o imposto específico da Meta Ads. <br/><br/> Pode ser configurado na aba ${R.additionalValues}.`
        }
        static feesTooltip() {
            return `Taxas sobre o Faturamento Líquido ou Bruto. <br/><br/> Pode ser configurado na aba ${R.additionalValues}.`
        }
        static productsCostTooltip() {
            return `Custo total dos produtos. <br/><br/> Pode ser configurado na aba ${R.additionalValues}.`
        }
        static pendingCommissionTooltip() {
            return "Valor das vendas pendentes"
        }
        static refundedCommissionTooltip() {
            return "Valor das vendas reembolsadas"
        }
        static profitTooltip(e) {
            return `Lucro calculado. <br/><br/> ${B.profitLabel} = ${B.netRevenueLabel(e)} - ${B.adSpentLabel} - ${B.customSpendings}`
        }
        static arpuTooltip(e) {
            return `Receita gerada por usuário. <br/><br/> ${B.arpuLabel} = ${B.netRevenueLabel(e)} / Clientes distintos`
        }
        static icrToolTip() {
            return "Taxa de ICs<br/><br/>ICR = Finalizações de Compra Iniciadas / Vis. de Pág. (%)"
        }
        static conToolTip() {
            return "Taxa de conexão<br/><br/>CON = Vis. de Pág. / Cliques (%)"
        }
        static conversionToolTip() {
            return "Conversão<br/><br/>Conversão = Vendas / Vis. de Pág. (%)"
        }
        static retentionToolTip() {
            return "Retenção<br/><br/>Retenção = Vídeos Assistidos por 3 Segundos / Vídeos Reproduzidos (%)"
        }
        static hookToolTip() {
            return "Hook<br/><br/>Hook = Vídeos Assistidos por 3 Segundos / Impressões (%)"
        }
        static bodyConversionToolTip() {
            return "Conversão do Body<br/><br/>Conversão do Body = (Compras / Vídeos assistidos 75%) (%)"
        }
        static bodyRetentionToolTip() {
            return "Retenção do Body<br/><br/>Retenção do Body = Vídeos assistidos 75% / Vídeos iniciados (%)"
        }
        static ctaToolTip() {
            return "Retenção para Clique | Medidor de CTA<br/><br/>Retenção para Clique | Medidor de CTA = (Cliques no Link / Vídeos assistidos 75%) (%)"
        }
        static hookPlayRateToolTip() {
            return "Play Rate do Hook<br/><br/>Play Rate do Hook = Vídeos iniciados / Impressões (%)"
        }
        static video75WatchedToolTip() {
            return "Retenção de Vídeo (75%)<br/><br/>Retenção de Vídeo (75%) = Quantidade de vezes que o vídeo foi reproduzido até 75%"
        }
        static holdRateToolTip() {
            return "Hold Rate<br/><br/>Hold Rate = Vídeos assistidos 75% / impressões (%)"
        }
        static conversationsToolTip() {
            return "Conversas Iniciadas em apps de mensagem"
        }
        static costPerConversationToolTip() {
            return "Custo por Conversa Iniciada em apps de mensagem"
        }
        static frequencyToolTip() {
            return "A frequência do anúncio no Facebook Ads refere-se ao número médio de vezes que um anúncio foi exibido para cada pessoa dentro de um público-alvo específico durante um determinado período."
        }
        static clickConversionToolTip() {
            return "A conversão de cliques representa a porcentagem de cliques que resultaram em vendas em uma campanha. <br/><br/> Fórmula: vendas  / cliques (%)"
        }
        static checkoutConversionToolTip() {
            return "Conversão do Checkout representa a porcentagem de conversão de um checkout. <br/><br/> Fórmula: (Vendas Aprovadas + Vendas Pendentes) / ICs"
        }
        static salesCountTooltip() {
            return "Quantidade de vendas aprovadas."
        }
        static chargebackTooltip() {
            return "Taxa de chargeback <br/><br/> (Calculada sobre o faturamento)"
        }
        static refundRateTooltip() {
            return "Taxa de reembolso <br/><br/> (Calculada sobre a quantidade de pedidos)"
        }
        static salesChargebackTooltip() {
            return "Valor das vendas que sofreram chargeback"
        }
        static salesReturnedGrossTooltip(e) {
            return "Valor bruto das vendas devolvidas <br/><br/> Vendas reembolsadas + Vendas chargeback"
        }
        static customSpendingsTooltip() {
            return 'Valor total dos gastos personalizados.<br/><br/>Pode ser configurado na aba "Despesas"'
        }
        static cpaTooltip() {
            return "Custo por Aquisição Médio.<br/><br/>Gastos Totais / Vendas"
        }
        static conversationsTooltip() {
            return "Conversas Iniciadas"
        }
        static costPerConversationTooltip() {
            return "Custo por Conversa Iniciada.<br/><br/>Gastos Totais / Conversas Iniciadas"
        }
        static createdTimeTooltip() {
            return "Data em que a campanha, conjunto de anúncios ou anúncio foi criado."
        }
        static effectiveStatusToolTip() {
            return "O status de veiculação pode ajudar você a entender se a sua campanha de anúncios está sendo veiculada normalmente ou se há algum problema que requer sua atenção. Campanhas, conjuntos de anúncios e anúncios podem ter diferentes status de veiculação."
        }
        static leadCountTooltip() {
            return "Quantidade de Leads captados.<br/><br/>Somente referente aos resultados do Facebook."
        }
        static refundedOrdersCountToolTip() {
            return "Quantidade de vendas que foram reembolsadas."
        }
        static refundedRevenueToolTip() {
            return "Valor total reembolsado das vendas."
        }
    };
b(B, "adSpentLabel", "Gastos com anúncios"), b(B, "profitLabel", "Lucro"), b(B, "taxLabel", "Imposto sobre vendas"), b(B, "metaAdsTaxLabel", "Imposto Meta Ads"), b(B, "totalTaxWithMetaAdsTaxLabel", "Imposto total"), b(B, "feesLabel", "Taxas"), b(B, "productsCostLabel", "Custos de Produto"), b(B, "profitMarginLabel", "Margem"), b(B, "arpuLabel", "ARPU"), b(B, "roasLabel", "ROAS"), b(B, "roiLabel", "ROI"), b(B, "icLabel", "IC"), b(B, "addToCartLabel", "Add To Cart"), b(B, "leadLabel", "Cadastros"), b(B, "costPerIcLabel", "CPI"), b(B, "costPerAddToCartLabel", "CPAC"), b(B, "costPerLeadLabel", "CPL"), b(B, "salesCountMinLabel", "Vendas"), b(B, "salesCountLabel", "Quantidade de Vendas"), b(B, "approvalRateLabel", "Taxa de Aprovação"), b(B, "salesByHour", "Vendas por Horário"), b(B, "profitByHour", "Lucro por Horário"), b(B, "salesByDayOfWeek", "Vendas por Dia da Semana"), b(B, "conversionFunnel", "Funil de Conversão"), b(B, "customSpendings", "Despesas adicionais"), b(B, "cpa", "CPA"), b(B, "conversations", "Conversas"), b(B, "costPerConversation", "Custo por Conversa"), b(B, "leads", "Leads"), b(B, "costPerLead", "Custo por Lead"), b(B, "revenueInvestmentProfitByHour", "Faturamento x Investimento x Lucro por Hora (acumulado).");
let A = B;
class v {
    constructor(e) {
        b(this, "type");
        b(this, "sm");
        b(this, "md");
        b(this, "lg");
        b(this, "xl");
        this.type = e.type, this.sm = e.sm, this.md = e.md, this.lg = e.lg, this.xl = e.xl
    }
}
var ir = (t => (t.Sm = "sm", t.Md = "md", t.Lg = "lg", t.Xl = "xl", t))(ir || {}),
    ar = (t => (t.NetRevenue = "NetRevenue", t.GrossRevenue = "GrossRevenue", t.Spend = "Spend", t.Roas = "Roas", t.ProductCosts = "ProductCosts", t.Profit = "Profit", t.SalesByPayment = "SalesByPayment", t.PendingCommission = "PendingCommission", t.Roi = "Roi", t.ProfitMargin = "ProfitMargin", t.RefundedCommission = "RefundedCommission", t.RefundRate = "RefundRate", t.Arpu = "Arpu", t.Tax = "Tax", t.ChargebackRate = "ChargebackRate", t.Fees = "Fees", t.SalesByProduct = "SalesByProduct", t.RevenueByProduct = "RevenueByProduct", t.SalesByUtmSource = "SalesByUtmSource", t.SalesBySrc = "SalesBySrc", t.SalesByUtmTerm = "SalesByUtmTerm", t.SalesByCustomerCountry = "SalesByCustomerCountry", t.ApprovalRate = "ApprovalRate", t.SalesByHour = "SalesByHour", t.SalesByDayOfWeek = "SalesByDayOfWeek", t.ConversionFunnel = "ConversionFunnel", t.SalesChargeback = "SalesChargeback", t.SalesReturnedGross = "SalesReturnedGross", t.CustomSpendings = "CustomSpendings", t.Cpa = "Cpa", t.Conversations = "Conversations", t.CostPerConversation = "CostPerConversation", t.LeadCount = "LeadCount", t.CostPerLead = "CostPerLead", t.ProfitByHour = "ProfitByHour", t.RevenueInvestmentProfitByHour = "RevenueInvestmentProfitByHour", t.MetaAdsTax = "MetaAdsTax", t.TotalTaxWithMetaAdsTax = "TotalTaxWithMetaAdsTax", t))(ar || {});
const on = [new v({
        type: "GrossRevenue",
        xl: {
            index: 0,
            w: 4,
            h: 1,
            x: 0,
            y: 0,
            enabled: !1
        },
        lg: {
            index: 0,
            w: 4,
            h: 1,
            x: 0,
            y: 0,
            enabled: !1
        },
        md: {
            index: 0,
            w: 6,
            h: 1,
            x: 0,
            y: 0,
            enabled: !1
        },
        sm: {
            index: 0,
            w: 12,
            h: 1,
            x: 0,
            y: 0,
            enabled: !1
        }
    }), new v({
        type: "Spend",
        xl: {
            index: 1,
            w: 3,
            h: 1,
            x: 4,
            y: 0,
            enabled: !0
        },
        lg: {
            index: 1,
            w: 3,
            h: 1,
            x: 4,
            y: 0,
            enabled: !0
        },
        md: {
            index: 1,
            w: 6,
            h: 1,
            x: 6,
            y: 0,
            enabled: !0
        },
        sm: {
            index: 1,
            w: 12,
            h: 1,
            x: 0,
            y: 1,
            enabled: !0
        }
    }), new v({
        type: "Roas",
        xl: {
            index: 2,
            w: 2,
            h: 1,
            x: 7,
            y: 0,
            enabled: !0
        },
        lg: {
            index: 2,
            w: 2,
            h: 1,
            x: 7,
            y: 0,
            enabled: !0
        },
        md: {
            index: 2,
            w: 6,
            h: 1,
            x: 0,
            y: 1,
            enabled: !0
        },
        sm: {
            index: 2,
            w: 12,
            h: 1,
            x: 0,
            y: 2,
            enabled: !0
        }
    }), new v({
        type: "Profit",
        xl: {
            index: 3,
            w: 3,
            h: 1,
            x: 9,
            y: 0,
            enabled: !0
        },
        lg: {
            index: 3,
            w: 3,
            h: 1,
            x: 9,
            y: 0,
            enabled: !0
        },
        md: {
            index: 3,
            w: 6,
            h: 1,
            x: 6,
            y: 1,
            enabled: !0
        },
        sm: {
            index: 3,
            w: 12,
            h: 1,
            x: 0,
            y: 3,
            enabled: !0
        }
    }), new v({
        type: "NetRevenue",
        xl: {
            index: 4,
            w: 4,
            h: 1,
            x: 0,
            y: 0,
            enabled: !0
        },
        lg: {
            index: 4,
            w: 4,
            h: 1,
            x: 0,
            y: 0,
            enabled: !0
        },
        md: {
            index: 4,
            w: 6,
            h: 1,
            x: 0,
            y: 0,
            enabled: !0
        },
        sm: {
            index: 4,
            w: 12,
            h: 1,
            x: 0,
            y: 0,
            enabled: !0
        }
    }), new v({
        type: "SalesByPayment",
        xl: {
            index: 4,
            w: 4,
            h: 3,
            x: 0,
            y: 1,
            enabled: !0
        },
        lg: {
            index: 4,
            w: 4,
            h: 3,
            x: 0,
            y: 1,
            enabled: !0
        },
        md: {
            index: 4,
            w: 12,
            h: 4,
            x: 0,
            y: 2,
            enabled: !0
        },
        sm: {
            index: 4,
            w: 12,
            h: 4,
            x: 0,
            y: 4,
            enabled: !0
        }
    }), new v({
        type: "PendingCommission",
        xl: {
            index: 5,
            w: 3,
            h: 1,
            x: 4,
            y: 1,
            enabled: !0
        },
        lg: {
            index: 5,
            w: 3,
            h: 1,
            x: 4,
            y: 1,
            enabled: !0
        },
        md: {
            index: 5,
            w: 6,
            h: 1,
            x: 0,
            y: 6,
            enabled: !0
        },
        sm: {
            index: 5,
            w: 12,
            h: 1,
            x: 0,
            y: 8,
            enabled: !0
        }
    }), new v({
        type: "Roi",
        xl: {
            index: 6,
            w: 2,
            h: 1,
            x: 7,
            y: 1,
            enabled: !0
        },
        lg: {
            index: 6,
            w: 2,
            h: 1,
            x: 7,
            y: 1,
            enabled: !0
        },
        md: {
            index: 6,
            w: 6,
            h: 1,
            x: 6,
            y: 6,
            enabled: !0
        },
        sm: {
            index: 6,
            w: 12,
            h: 1,
            x: 0,
            y: 9,
            enabled: !0
        }
    }), new v({
        type: "ProfitMargin",
        xl: {
            index: 7,
            w: 2,
            h: 1,
            x: 7,
            y: 2,
            enabled: !0
        },
        lg: {
            index: 7,
            w: 2,
            h: 1,
            x: 7,
            y: 2,
            enabled: !0
        },
        md: {
            index: 7,
            w: 6,
            h: 1,
            x: 0,
            y: 7,
            enabled: !0
        },
        sm: {
            index: 7,
            w: 12,
            h: 1,
            x: 0,
            y: 10,
            enabled: !0
        }
    }), new v({
        type: "RefundedCommission",
        xl: {
            index: 8,
            w: 3,
            h: 1,
            x: 4,
            y: 2,
            enabled: !0
        },
        lg: {
            index: 8,
            w: 3,
            h: 1,
            x: 4,
            y: 2,
            enabled: !0
        },
        md: {
            index: 8,
            w: 6,
            h: 1,
            x: 6,
            y: 7,
            enabled: !0
        },
        sm: {
            index: 8,
            w: 12,
            h: 1,
            x: 0,
            y: 11,
            enabled: !0
        }
    }), new v({
        type: "SalesChargeback",
        xl: {
            index: 8,
            w: 3,
            h: 1,
            x: 9,
            y: 4,
            enabled: !1
        },
        lg: {
            index: 8,
            w: 3,
            h: 1,
            x: 9,
            y: 4,
            enabled: !1
        },
        md: {
            index: 8,
            w: 6,
            h: 1,
            x: 6,
            y: 7,
            enabled: !1
        },
        sm: {
            index: 8,
            w: 12,
            h: 1,
            x: 0,
            y: 11,
            enabled: !1
        }
    }), new v({
        type: "SalesReturnedGross",
        xl: {
            index: 8,
            w: 3,
            h: 1,
            x: 4,
            y: 2,
            enabled: !1
        },
        lg: {
            index: 8,
            w: 3,
            h: 1,
            x: 4,
            y: 2,
            enabled: !1
        },
        md: {
            index: 8,
            w: 6,
            h: 1,
            x: 6,
            y: 7,
            enabled: !1
        },
        sm: {
            index: 8,
            w: 12,
            h: 1,
            x: 0,
            y: 11,
            enabled: !1
        }
    }), new v({
        type: "RefundRate",
        xl: {
            index: 9,
            w: 2,
            h: 1,
            x: 7,
            y: 3,
            enabled: !1
        },
        lg: {
            index: 9,
            w: 2,
            h: 1,
            x: 7,
            y: 3,
            enabled: !1
        },
        md: {
            index: 9,
            w: 6,
            h: 1,
            x: 0,
            y: 8,
            enabled: !1
        },
        sm: {
            index: 9,
            w: 12,
            h: 1,
            x: 0,
            y: 12,
            enabled: !1
        }
    }), new v({
        type: "ChargebackRate",
        xl: {
            index: 0,
            w: 2,
            h: 1,
            x: 7,
            y: 4,
            enabled: !0
        },
        lg: {
            index: 0,
            w: 2,
            h: 1,
            x: 7,
            y: 4,
            enabled: !0
        },
        md: {
            index: 0,
            w: 6,
            h: 1,
            x: 6,
            y: 9,
            enabled: !0
        },
        sm: {
            index: 0,
            w: 12,
            h: 1,
            x: 0,
            y: 15,
            enabled: !0
        }
    }), new v({
        type: "Arpu",
        xl: {
            index: 10,
            w: 3,
            h: 1,
            x: 9,
            y: 2,
            enabled: !1
        },
        lg: {
            index: 10,
            w: 3,
            h: 1,
            x: 9,
            y: 2,
            enabled: !1
        },
        md: {
            index: 10,
            w: 6,
            h: 1,
            x: 6,
            y: 8,
            enabled: !1
        },
        sm: {
            index: 10,
            w: 12,
            h: 1,
            x: 0,
            y: 13,
            enabled: !1
        }
    }), new v({
        type: "Tax",
        xl: {
            index: 11,
            w: 3,
            h: 1,
            x: 4,
            y: 3,
            enabled: !0
        },
        lg: {
            index: 11,
            w: 3,
            h: 1,
            x: 4,
            y: 3,
            enabled: !0
        },
        md: {
            index: 11,
            w: 6,
            h: 1,
            x: 0,
            y: 9,
            enabled: !0
        },
        sm: {
            index: 11,
            w: 12,
            h: 1,
            x: 0,
            y: 14,
            enabled: !0
        }
    }), new v({
        type: "MetaAdsTax",
        xl: {
            index: 11,
            w: 3,
            h: 1,
            x: 4,
            y: 3,
            enabled: !0
        },
        lg: {
            index: 11,
            w: 3,
            h: 1,
            x: 4,
            y: 3,
            enabled: !0
        },
        md: {
            index: 11,
            w: 6,
            h: 1,
            x: 0,
            y: 9,
            enabled: !0
        },
        sm: {
            index: 11,
            w: 12,
            h: 1,
            x: 0,
            y: 14,
            enabled: !0
        }
    }), new v({
        type: "TotalTaxWithMetaAdsTax",
        xl: {
            index: 11,
            w: 3,
            h: 1,
            x: 4,
            y: 3,
            enabled: !0
        },
        lg: {
            index: 11,
            w: 3,
            h: 1,
            x: 4,
            y: 3,
            enabled: !0
        },
        md: {
            index: 11,
            w: 6,
            h: 1,
            x: 0,
            y: 9,
            enabled: !0
        },
        sm: {
            index: 11,
            w: 12,
            h: 1,
            x: 0,
            y: 14,
            enabled: !0
        }
    }), new v({
        type: "ProductCosts",
        xl: {
            index: 13,
            w: 3,
            h: 1,
            x: 9,
            y: 2,
            enabled: !0
        },
        lg: {
            index: 13,
            w: 3,
            h: 1,
            x: 9,
            y: 2,
            enabled: !0
        },
        md: {
            index: 13,
            w: 6,
            h: 1,
            x: 0,
            y: 10,
            enabled: !0
        },
        sm: {
            index: 13,
            w: 12,
            h: 1,
            x: 0,
            y: 16,
            enabled: !0
        }
    }), new v({
        type: "Fees",
        xl: {
            index: 13,
            w: 3,
            h: 1,
            x: 9,
            y: 4,
            enabled: !0
        },
        lg: {
            index: 13,
            w: 3,
            h: 1,
            x: 9,
            y: 4,
            enabled: !0
        },
        md: {
            index: 13,
            w: 6,
            h: 1,
            x: 0,
            y: 10,
            enabled: !0
        },
        sm: {
            index: 13,
            w: 12,
            h: 1,
            x: 0,
            y: 16,
            enabled: !0
        }
    }), new v({
        type: "SalesByProduct",
        xl: {
            index: 14,
            w: 4,
            h: 2,
            x: 0,
            y: 5,
            enabled: !0
        },
        lg: {
            index: 14,
            w: 4,
            h: 2,
            x: 0,
            y: 5,
            enabled: !0
        },
        md: {
            index: 14,
            w: 12,
            h: 2,
            x: 0,
            y: 11,
            enabled: !0
        },
        sm: {
            index: 14,
            w: 12,
            h: 2,
            x: 0,
            y: 17,
            enabled: !0
        }
    }), new v({
        type: "RevenueByProduct",
        xl: {
            index: 14,
            w: 4,
            h: 2,
            x: 0,
            y: 5,
            enabled: !1
        },
        lg: {
            index: 14,
            w: 4,
            h: 2,
            x: 0,
            y: 5,
            enabled: !1
        },
        md: {
            index: 14,
            w: 12,
            h: 2,
            x: 0,
            y: 11,
            enabled: !1
        },
        sm: {
            index: 14,
            w: 12,
            h: 2,
            x: 0,
            y: 17,
            enabled: !1
        }
    }), new v({
        type: "SalesByUtmSource",
        xl: {
            index: 15,
            w: 5,
            h: 2,
            x: 4,
            y: 5,
            enabled: !0
        },
        lg: {
            index: 15,
            w: 5,
            h: 2,
            x: 4,
            y: 5,
            enabled: !0
        },
        md: {
            index: 15,
            w: 12,
            h: 2,
            x: 0,
            y: 12,
            enabled: !0
        },
        sm: {
            index: 15,
            w: 12,
            h: 2,
            x: 0,
            y: 18,
            enabled: !0
        }
    }), new v({
        type: "SalesBySrc",
        xl: {
            index: 0,
            w: 5,
            h: 2,
            x: 4,
            y: 4,
            enabled: !1
        },
        lg: {
            index: 0,
            w: 5,
            h: 2,
            x: 4,
            y: 4,
            enabled: !1
        },
        md: {
            index: 0,
            w: 12,
            h: 2,
            x: 0,
            y: 12,
            enabled: !1
        },
        sm: {
            index: 0,
            w: 12,
            h: 2,
            x: 0,
            y: 18,
            enabled: !1
        }
    }), new v({
        type: "SalesByUtmTerm",
        xl: {
            index: 14,
            w: 4,
            h: 2,
            x: 0,
            y: 5,
            enabled: !1
        },
        lg: {
            index: 14,
            w: 4,
            h: 2,
            x: 0,
            y: 6,
            enabled: !1
        },
        md: {
            index: 14,
            w: 12,
            h: 2,
            x: 0,
            y: 11,
            enabled: !1
        },
        sm: {
            index: 14,
            w: 12,
            h: 2,
            x: 0,
            y: 17,
            enabled: !1
        }
    }), new v({
        type: "SalesByCustomerCountry",
        xl: {
            index: 0,
            w: 5,
            h: 2,
            x: 4,
            y: 4,
            enabled: !1
        },
        lg: {
            index: 0,
            w: 5,
            h: 2,
            x: 4,
            y: 4,
            enabled: !1
        },
        md: {
            index: 0,
            w: 12,
            h: 2,
            x: 0,
            y: 12,
            enabled: !1
        },
        sm: {
            index: 0,
            w: 12,
            h: 2,
            x: 0,
            y: 18,
            enabled: !1
        }
    }), new v({
        type: "ApprovalRate",
        xl: {
            index: 16,
            w: 3,
            h: 2,
            x: 9,
            y: 5,
            enabled: !0
        },
        lg: {
            index: 16,
            w: 3,
            h: 2,
            x: 9,
            y: 5,
            enabled: !0
        },
        md: {
            index: 16,
            w: 12,
            h: 2,
            x: 0,
            y: 13,
            enabled: !0
        },
        sm: {
            index: 16,
            w: 12,
            h: 2,
            x: 0,
            y: 19,
            enabled: !0
        }
    }), new v({
        type: "SalesByHour",
        xl: {
            index: 0,
            w: 12,
            h: 3,
            x: 0,
            y: 1,
            enabled: !1
        },
        lg: {
            index: 0,
            w: 12,
            h: 3,
            x: 0,
            y: 1,
            enabled: !1
        },
        md: {
            index: 0,
            w: 12,
            h: 4,
            x: 0,
            y: 2,
            enabled: !1
        },
        sm: {
            index: 0,
            w: 12,
            h: 4,
            x: 0,
            y: 4,
            enabled: !1
        }
    }), new v({
        type: "ProfitByHour",
        xl: {
            index: 0,
            w: 12,
            h: 3,
            x: 0,
            y: 1,
            enabled: !1
        },
        lg: {
            index: 0,
            w: 12,
            h: 3,
            x: 0,
            y: 1,
            enabled: !1
        },
        md: {
            index: 0,
            w: 12,
            h: 4,
            x: 0,
            y: 2,
            enabled: !1
        },
        sm: {
            index: 0,
            w: 12,
            h: 4,
            x: 0,
            y: 4,
            enabled: !1
        }
    }), new v({
        type: "SalesByDayOfWeek",
        xl: {
            index: 0,
            w: 4,
            h: 3,
            x: 0,
            y: 1,
            enabled: !1
        },
        lg: {
            index: 0,
            w: 4,
            h: 3,
            x: 0,
            y: 1,
            enabled: !1
        },
        md: {
            index: 0,
            w: 4,
            h: 4,
            x: 0,
            y: 2,
            enabled: !1
        },
        sm: {
            index: 0,
            w: 4,
            h: 4,
            x: 0,
            y: 4,
            enabled: !1
        }
    }), new v({
        type: "ConversionFunnel",
        xl: {
            index: 0,
            w: 7,
            h: 4,
            x: 0,
            y: 1,
            enabled: !1
        },
        lg: {
            index: 0,
            w: 7,
            h: 4,
            x: 0,
            y: 1,
            enabled: !1
        },
        md: {
            index: 0,
            w: 12,
            h: 4,
            x: 0,
            y: 2,
            enabled: !1
        },
        sm: {
            index: 0,
            w: 12,
            h: 4,
            x: 0,
            y: 4,
            enabled: !1
        }
    }), new v({
        type: "CustomSpendings",
        xl: {
            index: 2,
            w: 3,
            h: 1,
            x: 9,
            y: 3,
            enabled: !0
        },
        lg: {
            index: 2,
            w: 3,
            h: 1,
            x: 9,
            y: 3,
            enabled: !0
        },
        md: {
            index: 2,
            w: 6,
            h: 1,
            x: 0,
            y: 1,
            enabled: !0
        },
        sm: {
            index: 2,
            w: 12,
            h: 1,
            x: 0,
            y: 2,
            enabled: !0
        }
    }), new v({
        type: "Cpa",
        xl: {
            index: 2,
            w: 3,
            h: 1,
            x: 9,
            y: 3,
            enabled: !1
        },
        lg: {
            index: 2,
            w: 3,
            h: 1,
            x: 9,
            y: 3,
            enabled: !1
        },
        md: {
            index: 2,
            w: 6,
            h: 1,
            x: 0,
            y: 1,
            enabled: !1
        },
        sm: {
            index: 2,
            w: 12,
            h: 1,
            x: 0,
            y: 2,
            enabled: !1
        }
    }), new v({
        type: "Conversations",
        xl: {
            index: 2,
            w: 2,
            h: 1,
            x: 9,
            y: 3,
            enabled: !1
        },
        lg: {
            index: 2,
            w: 2,
            h: 1,
            x: 9,
            y: 3,
            enabled: !1
        },
        md: {
            index: 2,
            w: 6,
            h: 1,
            x: 0,
            y: 1,
            enabled: !1
        },
        sm: {
            index: 2,
            w: 12,
            h: 1,
            x: 0,
            y: 2,
            enabled: !1
        }
    }), new v({
        type: "CostPerConversation",
        xl: {
            index: 2,
            w: 3,
            h: 1,
            x: 9,
            y: 3,
            enabled: !1
        },
        lg: {
            index: 2,
            w: 3,
            h: 1,
            x: 9,
            y: 3,
            enabled: !1
        },
        md: {
            index: 2,
            w: 6,
            h: 1,
            x: 0,
            y: 1,
            enabled: !1
        },
        sm: {
            index: 2,
            w: 12,
            h: 1,
            x: 0,
            y: 2,
            enabled: !1
        }
    }), new v({
        type: "LeadCount",
        xl: {
            index: 2,
            w: 3,
            h: 1,
            x: 9,
            y: 3,
            enabled: !1
        },
        lg: {
            index: 2,
            w: 3,
            h: 1,
            x: 9,
            y: 3,
            enabled: !1
        },
        md: {
            index: 2,
            w: 6,
            h: 1,
            x: 0,
            y: 1,
            enabled: !1
        },
        sm: {
            index: 2,
            w: 12,
            h: 1,
            x: 0,
            y: 2,
            enabled: !1
        }
    }), new v({
        type: "CostPerLead",
        xl: {
            index: 2,
            w: 3,
            h: 1,
            x: 9,
            y: 3,
            enabled: !1
        },
        lg: {
            index: 2,
            w: 3,
            h: 1,
            x: 9,
            y: 3,
            enabled: !1
        },
        md: {
            index: 2,
            w: 6,
            h: 1,
            x: 0,
            y: 1,
            enabled: !1
        },
        sm: {
            index: 2,
            w: 12,
            h: 1,
            x: 0,
            y: 2,
            enabled: !1
        }
    }), new v({
        type: "RevenueInvestmentProfitByHour",
        xl: {
            index: 0,
            w: 12,
            h: 4,
            x: 0,
            y: 1,
            enabled: !1
        },
        lg: {
            index: 0,
            w: 12,
            h: 4,
            x: 0,
            y: 1,
            enabled: !1
        },
        md: {
            index: 0,
            w: 12,
            h: 4,
            x: 0,
            y: 2,
            enabled: !1
        },
        sm: {
            index: 0,
            w: 12,
            h: 4,
            x: 0,
            y: 4,
            enabled: !1
        }
    })],
    sa = () => {
        const t = [{
                type: "NetRevenue",
                sm: {
                    index: 0,
                    enabled: !0,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: 0,
                    enabled: !0,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: 0,
                    enabled: !0,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: 0,
                    enabled: !0,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "Spend",
                sm: {
                    index: 1,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 0
                },
                md: {
                    index: 1,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 0
                },
                lg: {
                    index: 1,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 0
                },
                xl: {
                    index: 1,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 0
                }
            }, {
                type: "Roas",
                sm: {
                    index: 2,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 0
                },
                md: {
                    index: 2,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 0
                },
                lg: {
                    index: 2,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 0
                },
                xl: {
                    index: 2,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 0
                }
            }, {
                type: "Profit",
                sm: {
                    index: 3,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 0
                },
                md: {
                    index: 3,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 0
                },
                lg: {
                    index: 3,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 0
                },
                xl: {
                    index: 3,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 0
                }
            }, {
                type: "SalesByPayment",
                sm: {
                    index: 4,
                    enabled: !0,
                    w: 4,
                    h: 3,
                    x: 0,
                    y: 1
                },
                md: {
                    index: 4,
                    enabled: !0,
                    w: 4,
                    h: 3,
                    x: 0,
                    y: 1
                },
                lg: {
                    index: 4,
                    enabled: !0,
                    w: 4,
                    h: 3,
                    x: 0,
                    y: 1
                },
                xl: {
                    index: 4,
                    enabled: !0,
                    w: 4,
                    h: 3,
                    x: 0,
                    y: 1
                }
            }, {
                type: "PendingCommission",
                sm: {
                    index: 5,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 1
                },
                md: {
                    index: 5,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 1
                },
                lg: {
                    index: 5,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 1
                },
                xl: {
                    index: 5,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 1
                }
            }, {
                type: "Roi",
                sm: {
                    index: 6,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 1
                },
                md: {
                    index: 6,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 1
                },
                lg: {
                    index: 6,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 1
                },
                xl: {
                    index: 6,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 1
                }
            }, {
                type: "ProductCosts",
                sm: {
                    index: 7,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 1
                },
                md: {
                    index: 7,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 1
                },
                lg: {
                    index: 7,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 1
                },
                xl: {
                    index: 7,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 1
                }
            }, {
                type: "RefundedCommission",
                sm: {
                    index: 8,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 2
                },
                md: {
                    index: 8,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 2
                },
                lg: {
                    index: 8,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 2
                },
                xl: {
                    index: 8,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 2
                }
            }, {
                type: "ProfitMargin",
                sm: {
                    index: 9,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 2
                },
                md: {
                    index: 9,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 2
                },
                lg: {
                    index: 9,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 2
                },
                xl: {
                    index: 9,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 2
                }
            }, {
                type: "CustomSpendings",
                sm: {
                    index: 10,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 2
                },
                md: {
                    index: 10,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 2
                },
                lg: {
                    index: 10,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 2
                },
                xl: {
                    index: 10,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 2
                }
            }, {
                type: "Tax",
                sm: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                },
                md: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                },
                lg: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                },
                xl: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                }
            }, {
                type: "MetaAdsTax",
                sm: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                },
                md: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                },
                lg: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                },
                xl: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                }
            }, {
                type: "TotalTaxWithMetaAdsTax",
                sm: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                },
                md: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                },
                lg: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                },
                xl: {
                    index: 11,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 3
                }
            }, {
                type: "ChargebackRate",
                sm: {
                    index: 12,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 3
                },
                md: {
                    index: 12,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 3
                },
                lg: {
                    index: 12,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 3
                },
                xl: {
                    index: 12,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 3
                }
            }, {
                type: "Fees",
                sm: {
                    index: 13,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 3
                },
                md: {
                    index: 13,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 3
                },
                lg: {
                    index: 13,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 3
                },
                xl: {
                    index: 13,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 3
                }
            }, {
                type: "Cpa",
                sm: {
                    index: 14,
                    enabled: !0,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                },
                md: {
                    index: 14,
                    enabled: !0,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                },
                lg: {
                    index: 14,
                    enabled: !0,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                },
                xl: {
                    index: 14,
                    enabled: !0,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                }
            }, {
                type: "CostPerConversation",
                sm: {
                    index: 15,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 4
                },
                md: {
                    index: 15,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 4
                },
                lg: {
                    index: 15,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 4
                },
                xl: {
                    index: 15,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 4,
                    y: 4
                }
            }, {
                type: "Conversations",
                sm: {
                    index: 16,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 4
                },
                md: {
                    index: 16,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 4
                },
                lg: {
                    index: 16,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 4
                },
                xl: {
                    index: 16,
                    enabled: !0,
                    w: 2,
                    h: 1,
                    x: 7,
                    y: 4
                }
            }, {
                type: "Arpu",
                sm: {
                    index: 17,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 4
                },
                md: {
                    index: 17,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 4
                },
                lg: {
                    index: 17,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 4
                },
                xl: {
                    index: 17,
                    enabled: !0,
                    w: 3,
                    h: 1,
                    x: 9,
                    y: 4
                }
            }, {
                type: "SalesByProduct",
                sm: {
                    index: 18,
                    enabled: !0,
                    w: 4,
                    h: 2,
                    x: 0,
                    y: 5
                },
                md: {
                    index: 18,
                    enabled: !0,
                    w: 4,
                    h: 2,
                    x: 0,
                    y: 5
                },
                lg: {
                    index: 18,
                    enabled: !0,
                    w: 4,
                    h: 2,
                    x: 0,
                    y: 5
                },
                xl: {
                    index: 18,
                    enabled: !0,
                    w: 4,
                    h: 2,
                    x: 0,
                    y: 5
                }
            }, {
                type: "SalesByUtmSource",
                sm: {
                    index: 19,
                    enabled: !0,
                    w: 5,
                    h: 2,
                    x: 4,
                    y: 5
                },
                md: {
                    index: 19,
                    enabled: !0,
                    w: 5,
                    h: 2,
                    x: 4,
                    y: 5
                },
                lg: {
                    index: 19,
                    enabled: !0,
                    w: 5,
                    h: 2,
                    x: 4,
                    y: 5
                },
                xl: {
                    index: 19,
                    enabled: !0,
                    w: 5,
                    h: 2,
                    x: 4,
                    y: 5
                }
            }, {
                type: "ApprovalRate",
                sm: {
                    index: 20,
                    enabled: !0,
                    w: 3,
                    h: 2,
                    x: 9,
                    y: 5
                },
                md: {
                    index: 20,
                    enabled: !0,
                    w: 3,
                    h: 2,
                    x: 9,
                    y: 5
                },
                lg: {
                    index: 20,
                    enabled: !0,
                    w: 3,
                    h: 2,
                    x: 9,
                    y: 5
                },
                xl: {
                    index: 20,
                    enabled: !0,
                    w: 3,
                    h: 2,
                    x: 9,
                    y: 5
                }
            }, {
                type: "GrossRevenue",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "SalesChargeback",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "SalesReturnedGross",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "RefundRate",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "SalesBySrc",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "SalesByUtmTerm",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "SalesByCustomerCountry",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "SalesByHour",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "ProfitByHour",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "SalesByDayOfWeek",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "ConversionFunnel",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }, {
                type: "LeadCount",
                sm: {
                    index: 14,
                    enabled: !1,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                },
                md: {
                    index: 14,
                    enabled: !1,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                },
                lg: {
                    index: 14,
                    enabled: !1,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                },
                xl: {
                    index: 14,
                    enabled: !1,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                }
            }, {
                type: "CostPerLead",
                sm: {
                    index: 14,
                    enabled: !1,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                },
                md: {
                    index: 14,
                    enabled: !1,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                },
                lg: {
                    index: 14,
                    enabled: !1,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                },
                xl: {
                    index: 14,
                    enabled: !1,
                    w: 4,
                    h: 1,
                    x: 0,
                    y: 4
                }
            }, {
                type: "RevenueInvestmentProfitByHour",
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }],
            r = on.filter(a => !t.some(o => o.type === a.type)).map(a => ({
                type: a.type,
                sm: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                md: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                lg: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                },
                xl: {
                    index: -1,
                    enabled: !1,
                    w: 1,
                    h: 1,
                    x: 0,
                    y: 0
                }
            }));
        return [...t, ...r]
    },
    la = t => on.find(e => e.type === t),
    ua = t => {
        switch (t) {
            case "NetRevenue":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "GrossRevenue":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "Spend":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "Roas":
                return {
                    xl: {
                        minW: 2,
                        maxW: 3,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 2,
                        maxW: 3,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "Profit":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "SalesByPayment":
                return {
                    xl: {
                        minW: 4,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    lg: {
                        minW: 4,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    }
                };
            case "PendingCommission":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "Roi":
                return {
                    xl: {
                        minW: 2,
                        maxW: 3,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 2,
                        maxW: 3,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "ProfitMargin":
                return {
                    xl: {
                        minW: 2,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 2,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 4,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "RefundedCommission":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "RefundRate":
                return {
                    xl: {
                        minW: 2,
                        maxW: 3,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 2,
                        maxW: 3,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "Arpu":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "Tax":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "MetaAdsTax":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "TotalTaxWithMetaAdsTax":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "ChargebackRate":
                return {
                    xl: {
                        minW: 2,
                        maxW: 3,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 2,
                        maxW: 3,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "Fees":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "ProductCosts":
                return {
                    xl: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "SalesByProduct":
                return {
                    xl: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    lg: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    }
                };
            case "RevenueByProduct":
                return {
                    xl: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    lg: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    }
                };
            case "SalesByUtmSource":
                return {
                    xl: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    lg: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    }
                };
            case "SalesBySrc":
                return {
                    xl: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    lg: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    }
                };
            case "SalesByUtmTerm":
                return {
                    xl: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    lg: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    }
                };
            case "SalesByCustomerCountry":
                return {
                    xl: {
                        minW: 3,
                        maxW: 12,
                        minH: 4,
                        maxH: 6
                    },
                    lg: {
                        minW: 3,
                        maxW: 12,
                        minH: 4,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 4,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 4,
                        maxH: 6
                    }
                };
            case "ApprovalRate":
                return {
                    xl: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    lg: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 1,
                        maxH: 6
                    }
                };
            case "SalesByHour":
                return {
                    xl: {
                        minW: 4,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    lg: {
                        minW: 4,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    }
                };
            case "ProfitByHour":
                return {
                    xl: {
                        minW: 4,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    lg: {
                        minW: 4,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    }
                };
            case "SalesByDayOfWeek":
                return {
                    xl: {
                        minW: 4,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    lg: {
                        minW: 4,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    }
                };
            case "ConversionFunnel":
                return {
                    xl: {
                        minW: 4,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    lg: {
                        minW: 4,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 3,
                        maxH: 6
                    }
                };
            case "SalesChargeback":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "SalesReturnedGross":
                return {
                    xl: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 3,
                        maxW: 4,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "CustomSpendings":
                return {
                    xl: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "Cpa":
                return {
                    xl: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "Conversations":
                return {
                    xl: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "CostPerConversation":
                return {
                    xl: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "LeadCount":
                return {
                    xl: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "CostPerLead":
                return {
                    xl: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 2,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 6,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                };
            case "RevenueInvestmentProfitByHour":
                return {
                    xl: {
                        minW: 4,
                        maxW: 12,
                        minH: 4,
                        maxH: 6
                    },
                    lg: {
                        minW: 4,
                        maxW: 12,
                        minH: 4,
                        maxH: 6
                    },
                    md: {
                        minW: 6,
                        maxW: 12,
                        minH: 4,
                        maxH: 6
                    },
                    sm: {
                        minW: 12,
                        maxW: 12,
                        minH: 4,
                        maxH: 6
                    }
                };
            default:
                return {
                    xl: {
                        minW: 1,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    },
                    lg: {
                        minW: 1,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    },
                    md: {
                        minW: 3,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    },
                    sm: {
                        minW: 6,
                        maxW: 12,
                        minH: 1,
                        maxH: 1
                    }
                }
        }
    },
    xt = (t, e) => {
        switch (e) {
            case "extraLarge":
                return t.xl;
            case "large":
                return t.lg;
            case "medium":
                return t.md;
            case "small":
                return t.sm;
            default:
                return t.sm
        }
    },
    da = t => {
        const e = a => `(Gráfico)<br/><br/>${a}`;
        return {
            ApprovalRate: {
                title: "Taxa de Aprovação",
                tooltip: e(A.approvalRateTooltip()),
                symbol: "%"
            },
            Arpu: {
                title: "ARPU",
                tooltip: A.arpuTooltip(null),
                symbol: "R$"
            },
            ChargebackRate: {
                title: "Chargeback",
                tooltip: A.chargebackTooltip(),
                symbol: "%"
            },
            Fees: {
                title: "Taxas",
                tooltip: A.feesTooltip(),
                symbol: "R$"
            },
            ProductCosts: {
                title: "Custos de Produto",
                tooltip: A.productsCostTooltip(),
                symbol: "R$"
            },
            PendingCommission: {
                title: "Vendas Pendentes",
                tooltip: A.pendingCommissionTooltip(),
                symbol: "R$"
            },
            Profit: {
                title: "Lucro",
                tooltip: A.profitTooltip(null),
                symbol: "R$"
            },
            ProfitMargin: {
                title: "Margem de Lucro",
                tooltip: A.profitMarginTooltip(null),
                symbol: "%"
            },
            RefundedCommission: {
                title: "Vendas Reembolsadas",
                tooltip: A.refundedCommissionTooltip(),
                symbol: "R$"
            },
            RefundRate: {
                title: "Taxa de Reembolso",
                tooltip: A.refundRateTooltip(),
                symbol: "%"
            },
            NetRevenue: {
                title: "Faturamento Líquido",
                tooltip: A.netRevenueTooltip(null),
                symbol: "R$"
            },
            GrossRevenue: {
                title: "Faturamento Bruto",
                tooltip: A.grossRevenueTooltip(null),
                symbol: "R$"
            },
            Roas: {
                title: "ROAS",
                tooltip: A.roasTooltip(null),
                symbol: "."
            },
            Roi: {
                title: "ROI",
                tooltip: A.roiTooltip(null),
                symbol: "%"
            },
            SalesByPayment: {
                title: "Vendas / Pagamento",
                tooltip: e(A.salesByPaymentTooltip()),
                symbol: ""
            },
            SalesByProduct: {
                title: "Vendas / Produto",
                tooltip: e(A.salesByProductTooltip()),
                symbol: ""
            },
            RevenueByProduct: {
                title: "Faturamento / Produto",
                tooltip: e(A.revenueByProductTooltip()),
                symbol: ""
            },
            SalesByUtmSource: {
                title: "Vendas / Fonte",
                tooltip: e(A.salesByUtmSourceTooltip()),
                symbol: ""
            },
            SalesBySrc: {
                title: "Vendas / Src",
                tooltip: e(A.salesBySrcTooltip()),
                symbol: ""
            },
            SalesByUtmTerm: {
                title: "Vendas / Posicionamento",
                tooltip: e(A.salesByUtmTermTooltip()),
                symbol: ""
            },
            SalesByCustomerCountry: {
                title: "Vendas / País",
                tooltip: e(A.salesByCustomerCountryTooltip()),
                symbol: ""
            },
            Spend: {
                title: "Gasto",
                tooltip: A.adSpentTooltip(),
                symbol: "R$"
            },
            Tax: {
                title: "Imposto",
                tooltip: A.taxTooltip(),
                symbol: "R$"
            },
            MetaAdsTax: {
                title: "Imposto Meta Ads",
                tooltip: A.metaAdsTaxTooltip(),
                symbol: "R$"
            },
            TotalTaxWithMetaAdsTax: {
                title: "Imposto Total",
                tooltip: A.totalTaxWithMetaAdsTaxTooltip(),
                symbol: "R$"
            },
            SalesByHour: {
                title: "Vendas / Horário",
                tooltip: e(A.salesByHourTooltip()),
                symbol: ""
            },
            ProfitByHour: {
                title: "Lucro / Horário",
                tooltip: e(A.profitByHourTooltip()),
                symbol: ""
            },
            SalesByDayOfWeek: {
                title: "Vendas / Dia",
                tooltip: e(A.salesByDayOfWeekTooltip()),
                symbol: ""
            },
            ConversionFunnel: {
                title: "Funil de Conversão",
                tooltip: e(A.conversionFunnelTooltip()),
                symbol: ""
            },
            SalesChargeback: {
                title: "Vendas chargeback",
                tooltip: A.salesChargebackTooltip(),
                symbol: "R$"
            },
            SalesReturnedGross: {
                title: "Vendas devolvidas",
                tooltip: A.salesReturnedGrossTooltip(null),
                symbol: "R$"
            },
            CustomSpendings: {
                title: "Gastos adicionais",
                tooltip: A.customSpendingsTooltip(),
                symbol: "R$"
            },
            Cpa: {
                title: "CPA",
                tooltip: A.cpaTooltip(),
                symbol: "R$"
            },
            Conversations: {
                title: "Conversas",
                tooltip: A.conversationsTooltip(),
                symbol: ""
            },
            CostPerConversation: {
                title: "Custo por Conversa",
                tooltip: A.costPerConversationTooltip(),
                symbol: "R$"
            },
            LeadCount: {
                title: "Leads",
                tooltip: A.leadCountTooltip(),
                symbol: ""
            },
            CostPerLead: {
                title: "Custo por Lead",
                tooltip: A.costPerLeadTooltip(),
                symbol: "R$"
            },
            RevenueInvestmentProfitByHour: {
                title: "Faturamento x Investimento x Lucro por Hora",
                tooltip: e(A.revenueInvestmentProfitByHourTooltip()),
                symbol: ""
            }
        }[t]
    },
    Tt = t => t ? t.adAccounts.filter(e => e.enabled) : [],
    ca = t => {
        const e = Tt(t).map(r => ({
            label: r.name,
            value: r.id
        }));
        return e.sort((r, a) => r.label.toLowerCase().localeCompare(a.label.toLowerCase())), e.unshift({
            label: "Todas",
            value: "all"
        }), e
    },
    Ct = t => {
        const e = [];
        for (const r of (t == null ? void 0 : t.googleProfiles) ? ? [])
            for (const a of r.adAccounts) a.enabled && e.push(a);
        return e
    },
    ma = t => {
        const e = Ct(t).map(r => ({
            label: r.name,
            value: r.id
        }));
        return e.sort((r, a) => r.label.toLowerCase().localeCompare(a.label.toLowerCase())), e.unshift({
            label: "Todas",
            value: "all"
        }), e
    },
    or = t => {
        const e = [];
        for (const r of (t == null ? void 0 : t.kwaiProfiles) ? ? [])
            for (const a of r.adAccounts) a.enabled && e.push(a);
        return e
    },
    fa = t => {
        const e = or(t).map(r => ({
            label: r.name,
            value: r.id.toString()
        }));
        return e.sort((r, a) => r.label.toLowerCase().localeCompare(a.label.toLowerCase())), e.unshift({
            label: "Todas",
            value: "all"
        }), e
    },
    ha = t => {
        const e = [];
        for (const r of (t == null ? void 0 : t.tikTokProfiles) ? ? [])
            for (const a of r.adAccounts) a.enabled && e.push(a);
        return e
    },
    Mt = t => {
        var e;
        return t ? ((e = t.metaProfiles) == null ? void 0 : e.length) > 0 : !1
    },
    qt = t => {
        var e;
        return t ? ((e = t.googleProfiles) == null ? void 0 : e.length) > 0 : !1
    },
    xa = t => {
        var e;
        return t ? ((e = t.kwaiProfiles) == null ? void 0 : e.length) > 0 : !1
    },
    pa = t => {
        var e;
        return t ? ((e = t.tikTokProfiles) == null ? void 0 : e.length) > 0 : !1
    },
    ya = (t, e) => {
        const r = gt.size;
        return t.filter(a => {
            const o = xt(a, r);
            return (o == null ? void 0 : o.enabled) !== !1
        }).sort((a, o) => {
            const u = xt(a, r),
                l = xt(o, r);
            return ((u == null ? void 0 : u.index) ? ? 0) - ((l == null ? void 0 : l.index) ? ? 0)
        })
    },
    sn = _n.createStore("user", null),
    wa = t => {
        var e, r;
        return ((r = (e = t == null ? void 0 : t.user) == null ? void 0 : e.newsPushes) == null ? void 0 : r.news) === "ENABLED"
    },
    ba = t => {
        var r;
        return ((r = t == null ? void 0 : t.plan.whatsAppBackupSeats) == null ? void 0 : r.find(a => {
            var o;
            return new Date().getTime() < (((o = new Date(a == null ? void 0 : a.expiresAt)) == null ? void 0 : o.getTime()) ? ? 0)
        })) ? ? null
    },
    ga = t => {
        var r;
        return ((r = t == null ? void 0 : t.plan.collaboratorBackupSeats) == null ? void 0 : r.find(a => {
            var o, u;
            return new Date().getTime() < (((u = new Date((o = a == null ? void 0 : a.props) == null ? void 0 : o.expiresAt)) == null ? void 0 : u.getTime()) ? ? 0)
        })) ? ? null
    },
    Ta = t => rt(t).reduce((r, a) => r + a.webhooks.length, 0) ? ? 0,
    Ca = t => rt(t).reduce((r, a) => r + a.adAccounts.filter(o => o.enabled).length, 0) ? ? 0,
    Ea = t => rt(t).reduce((r, a) => r + a.pixels.length, 0) ? ? 0,
    Ha = t => rt(t).reduce((r, a) => r + a.whatsApps.length, 0) ? ? 0,
    rt = t => (t == null ? void 0 : t.user.dashboards.filter(e => e.userId === t.user.id)) ? ? [],
    Ba = t => ((t == null ? void 0 : t.plan.increases) ? ? []).sort((r, a) => r.type.toString().localeCompare(a.type.toString())),
    Sa = t => {
        var a;
        const e = ((a = t == null ? void 0 : t.plan) == null ? void 0 : a.priceInCents) ? ? 0,
            r = (t == null ? void 0 : t.plan.increases.reduce((o, u) => o + u.valueInCents, 0)) ? ? 0;
        return e - r
    },
    Wa = t => t.map(e => ({ ...e.dashboard,
        downloadedUtmScript: e.dashboard.configuredUtms,
        copiedUtmCode: e.dashboard.configuredUtms,
        timeZone: {
            hoursOffset: e.dashboard.timeZoneHourOffset
        },
        preventFetchingFacebookDataOnUtmPage: e.dashboard.preventFetchingFacebookDataOnUtmPage
    })),
    sr = t => t.id ? ? "",
    lr = t => {
        var l;
        const {
            timeZone: e,
            copiedUtmCode: r,
            downloadedUtmScript: a,
            ...o
        } = t, u = ((l = t.timeZone) == null ? void 0 : l.hoursOffset) ? ? 0;
        return { ...o,
            timeZoneHourOffset: u
        }
    },
    jt = t => {
        if (!t) return [];
        const e = t.user.dashboards ? ? [],
            r = t.accessMap ? ? {};
        return e.map(a => {
            const o = sr(a),
                u = r[o] ? ? {};
            return {
                dashboard: lr(a),
                access: u
            }
        })
    },
    Ra = (t, e, r) => {
        var a, o, u, l, d, y;
        return Mt(t) === !1 && qt(t) === !1 ? "NOT_CONNECTED_WITH_AD_PLATFORM" : r === "Meta" && Mt(t) === !1 || r === "Google" && qt(t) === !1 || ((a = Tt(t)) == null ? void 0 : a.length) === 0 && ((o = Ct(t)) == null ? void 0 : o.length) === 0 || r === "Meta" && ((u = Tt(t)) == null ? void 0 : u.length) === 0 || r === "Google" && ((l = Ct(t)) == null ? void 0 : l.length) === 0 ? "NO_ENABLED_AD_ACCOUNTS" : ((d = t == null ? void 0 : t.webhooks) == null ? void 0 : d.length) === 0 && (((y = t == null ? void 0 : t.apiCredentials) == null ? void 0 : y.length) ? ? 0) <= 0 ? "NO_WEBHOOKS" : (e == null ? void 0 : e.user.dashboards.findIndex(x => x.configuredUtms)) === -1 ? "NOT_CONFIGURED_UTMS" : (t == null ? void 0 : t.pixels.length) === 0 ? "NO_PIXELS" : "READY"
    };
var ln = {},
    it = {};
it.byteLength = cr;
it.toByteArray = fr;
it.fromByteArray = pr;
var ce = [],
    ie = [],
    ur = typeof Uint8Array < "u" ? Uint8Array : Array,
    pt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (var Ae = 0, dr = pt.length; Ae < dr; ++Ae) ce[Ae] = pt[Ae], ie[pt.charCodeAt(Ae)] = Ae;
ie[45] = 62;
ie[95] = 63;

function un(t) {
    var e = t.length;
    if (e % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
    var r = t.indexOf("=");
    r === -1 && (r = e);
    var a = r === e ? 0 : 4 - r % 4;
    return [r, a]
}

function cr(t) {
    var e = un(t),
        r = e[0],
        a = e[1];
    return (r + a) * 3 / 4 - a
}

function mr(t, e, r) {
    return (e + r) * 3 / 4 - r
}

function fr(t) {
    var e, r = un(t),
        a = r[0],
        o = r[1],
        u = new ur(mr(t, a, o)),
        l = 0,
        d = o > 0 ? a - 4 : a,
        y;
    for (y = 0; y < d; y += 4) e = ie[t.charCodeAt(y)] << 18 | ie[t.charCodeAt(y + 1)] << 12 | ie[t.charCodeAt(y + 2)] << 6 | ie[t.charCodeAt(y + 3)], u[l++] = e >> 16 & 255, u[l++] = e >> 8 & 255, u[l++] = e & 255;
    return o === 2 && (e = ie[t.charCodeAt(y)] << 2 | ie[t.charCodeAt(y + 1)] >> 4, u[l++] = e & 255), o === 1 && (e = ie[t.charCodeAt(y)] << 10 | ie[t.charCodeAt(y + 1)] << 4 | ie[t.charCodeAt(y + 2)] >> 2, u[l++] = e >> 8 & 255, u[l++] = e & 255), u
}

function hr(t) {
    return ce[t >> 18 & 63] + ce[t >> 12 & 63] + ce[t >> 6 & 63] + ce[t & 63]
}

function xr(t, e, r) {
    for (var a, o = [], u = e; u < r; u += 3) a = (t[u] << 16 & 16711680) + (t[u + 1] << 8 & 65280) + (t[u + 2] & 255), o.push(hr(a));
    return o.join("")
}

function pr(t) {
    for (var e, r = t.length, a = r % 3, o = [], u = 16383, l = 0, d = r - a; l < d; l += u) o.push(xr(t, l, l + u > d ? d : l + u));
    return a === 1 ? (e = t[r - 1], o.push(ce[e >> 2] + ce[e << 4 & 63] + "==")) : a === 2 && (e = (t[r - 2] << 8) + t[r - 1], o.push(ce[e >> 10] + ce[e >> 4 & 63] + ce[e << 2 & 63] + "=")), o.join("")
}
var At = {}; /*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
At.read = function(t, e, r, a, o) {
    var u, l, d = o * 8 - a - 1,
        y = (1 << d) - 1,
        x = y >> 1,
        p = -7,
        C = r ? o - 1 : 0,
        S = r ? -1 : 1,
        F = t[e + C];
    for (C += S, u = F & (1 << -p) - 1, F >>= -p, p += d; p > 0; u = u * 256 + t[e + C], C += S, p -= 8);
    for (l = u & (1 << -p) - 1, u >>= -p, p += a; p > 0; l = l * 256 + t[e + C], C += S, p -= 8);
    if (u === 0) u = 1 - x;
    else {
        if (u === y) return l ? NaN : (F ? -1 : 1) * (1 / 0);
        l = l + Math.pow(2, a), u = u - x
    }
    return (F ? -1 : 1) * l * Math.pow(2, u - a)
};
At.write = function(t, e, r, a, o, u) {
    var l, d, y, x = u * 8 - o - 1,
        p = (1 << x) - 1,
        C = p >> 1,
        S = o === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0,
        F = a ? 0 : u - 1,
        g = a ? 1 : -1,
        H = e < 0 || e === 0 && 1 / e < 0 ? 1 : 0;
    for (e = Math.abs(e), isNaN(e) || e === 1 / 0 ? (d = isNaN(e) ? 1 : 0, l = p) : (l = Math.floor(Math.log(e) / Math.LN2), e * (y = Math.pow(2, -l)) < 1 && (l--, y *= 2), l + C >= 1 ? e += S / y : e += S * Math.pow(2, 1 - C), e * y >= 2 && (l++, y /= 2), l + C >= p ? (d = 0, l = p) : l + C >= 1 ? (d = (e * y - 1) * Math.pow(2, o), l = l + C) : (d = e * Math.pow(2, C - 1) * Math.pow(2, o), l = 0)); o >= 8; t[r + F] = d & 255, F += g, d /= 256, o -= 8);
    for (l = l << o | d, x += o; x > 0; t[r + F] = l & 255, F += g, l /= 256, x -= 8);
    t[r + F - g] |= H * 128
};
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
(function(t) {
    const e = it,
        r = At,
        a = typeof Symbol == "function" && typeof Symbol.for == "function" ? Symbol.for("nodejs.util.inspect.custom") : null;
    t.Buffer = d, t.SlowBuffer = X, t.INSPECT_MAX_BYTES = 50;
    const o = 2147483647;
    t.kMaxLength = o, d.TYPED_ARRAY_SUPPORT = u(), !d.TYPED_ARRAY_SUPPORT && typeof console < "u" && typeof console.error == "function" && console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support.");

    function u() {
        try {
            const s = new Uint8Array(1),
                n = {
                    foo: function() {
                        return 42
                    }
                };
            return Object.setPrototypeOf(n, Uint8Array.prototype), Object.setPrototypeOf(s, n), s.foo() === 42
        } catch {
            return !1
        }
    }
    Object.defineProperty(d.prototype, "parent", {
        enumerable: !0,
        get: function() {
            if (d.isBuffer(this)) return this.buffer
        }
    }), Object.defineProperty(d.prototype, "offset", {
        enumerable: !0,
        get: function() {
            if (d.isBuffer(this)) return this.byteOffset
        }
    });

    function l(s) {
        if (s > o) throw new RangeError('The value "' + s + '" is invalid for option "size"');
        const n = new Uint8Array(s);
        return Object.setPrototypeOf(n, d.prototype), n
    }

    function d(s, n, i) {
        if (typeof s == "number") {
            if (typeof n == "string") throw new TypeError('The "string" argument must be of type string. Received type number');
            return C(s)
        }
        return y(s, n, i)
    }
    d.poolSize = 8192;

    function y(s, n, i) {
        if (typeof s == "string") return S(s, n);
        if (ArrayBuffer.isView(s)) return g(s);
        if (s == null) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof s);
        if (ue(s, ArrayBuffer) || s && ue(s.buffer, ArrayBuffer) || typeof SharedArrayBuffer < "u" && (ue(s, SharedArrayBuffer) || s && ue(s.buffer, SharedArrayBuffer))) return H(s, n, i);
        if (typeof s == "number") throw new TypeError('The "value" argument must not be of type number. Received type number');
        const c = s.valueOf && s.valueOf();
        if (c != null && c !== s) return d.from(c, n, i);
        const m = E(s);
        if (m) return m;
        if (typeof Symbol < "u" && Symbol.toPrimitive != null && typeof s[Symbol.toPrimitive] == "function") return d.from(s[Symbol.toPrimitive]("string"), n, i);
        throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof s)
    }
    d.from = function(s, n, i) {
        return y(s, n, i)
    }, Object.setPrototypeOf(d.prototype, Uint8Array.prototype), Object.setPrototypeOf(d, Uint8Array);

    function x(s) {
        if (typeof s != "number") throw new TypeError('"size" argument must be of type number');
        if (s < 0) throw new RangeError('The value "' + s + '" is invalid for option "size"')
    }

    function p(s, n, i) {
        return x(s), s <= 0 ? l(s) : n !== void 0 ? typeof i == "string" ? l(s).fill(n, i) : l(s).fill(n) : l(s)
    }
    d.alloc = function(s, n, i) {
        return p(s, n, i)
    };

    function C(s) {
        return x(s), l(s < 0 ? 0 : N(s) | 0)
    }
    d.allocUnsafe = function(s) {
        return C(s)
    }, d.allocUnsafeSlow = function(s) {
        return C(s)
    };

    function S(s, n) {
        if ((typeof n != "string" || n === "") && (n = "utf8"), !d.isEncoding(n)) throw new TypeError("Unknown encoding: " + n);
        const i = q(s, n) | 0;
        let c = l(i);
        const m = c.write(s, n);
        return m !== i && (c = c.slice(0, m)), c
    }

    function F(s) {
        const n = s.length < 0 ? 0 : N(s.length) | 0,
            i = l(n);
        for (let c = 0; c < n; c += 1) i[c] = s[c] & 255;
        return i
    }

    function g(s) {
        if (ue(s, Uint8Array)) {
            const n = new Uint8Array(s);
            return H(n.buffer, n.byteOffset, n.byteLength)
        }
        return F(s)
    }

    function H(s, n, i) {
        if (n < 0 || s.byteLength < n) throw new RangeError('"offset" is outside of buffer bounds');
        if (s.byteLength < n + (i || 0)) throw new RangeError('"length" is outside of buffer bounds');
        let c;
        return n === void 0 && i === void 0 ? c = new Uint8Array(s) : i === void 0 ? c = new Uint8Array(s, n) : c = new Uint8Array(s, n, i), Object.setPrototypeOf(c, d.prototype), c
    }

    function E(s) {
        if (d.isBuffer(s)) {
            const n = N(s.length) | 0,
                i = l(n);
            return i.length === 0 || s.copy(i, 0, 0, n), i
        }
        if (s.length !== void 0) return typeof s.length != "number" || ft(s.length) ? l(0) : F(s);
        if (s.type === "Buffer" && Array.isArray(s.data)) return F(s.data)
    }

    function N(s) {
        if (s >= o) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + o.toString(16) + " bytes");
        return s | 0
    }

    function X(s) {
        return +s != s && (s = 0), d.alloc(+s)
    }
    d.isBuffer = function(n) {
        return n != null && n._isBuffer === !0 && n !== d.prototype
    }, d.compare = function(n, i) {
        if (ue(n, Uint8Array) && (n = d.from(n, n.offset, n.byteLength)), ue(i, Uint8Array) && (i = d.from(i, i.offset, i.byteLength)), !d.isBuffer(n) || !d.isBuffer(i)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
        if (n === i) return 0;
        let c = n.length,
            m = i.length;
        for (let h = 0, w = Math.min(c, m); h < w; ++h)
            if (n[h] !== i[h]) {
                c = n[h], m = i[h];
                break
            }
        return c < m ? -1 : m < c ? 1 : 0
    }, d.isEncoding = function(n) {
        switch (String(n).toLowerCase()) {
            case "hex":
            case "utf8":
            case "utf-8":
            case "ascii":
            case "latin1":
            case "binary":
            case "base64":
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return !0;
            default:
                return !1
        }
    }, d.concat = function(n, i) {
        if (!Array.isArray(n)) throw new TypeError('"list" argument must be an Array of Buffers');
        if (n.length === 0) return d.alloc(0);
        let c;
        if (i === void 0)
            for (i = 0, c = 0; c < n.length; ++c) i += n[c].length;
        const m = d.allocUnsafe(i);
        let h = 0;
        for (c = 0; c < n.length; ++c) {
            let w = n[c];
            if (ue(w, Uint8Array)) h + w.length > m.length ? (d.isBuffer(w) || (w = d.from(w)), w.copy(m, h)) : Uint8Array.prototype.set.call(m, w, h);
            else if (d.isBuffer(w)) w.copy(m, h);
            else throw new TypeError('"list" argument must be an Array of Buffers');
            h += w.length
        }
        return m
    };

    function q(s, n) {
        if (d.isBuffer(s)) return s.length;
        if (ArrayBuffer.isView(s) || ue(s, ArrayBuffer)) return s.byteLength;
        if (typeof s != "string") throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof s);
        const i = s.length,
            c = arguments.length > 2 && arguments[2] === !0;
        if (!c && i === 0) return 0;
        let m = !1;
        for (;;) switch (n) {
            case "ascii":
            case "latin1":
            case "binary":
                return i;
            case "utf8":
            case "utf-8":
                return mt(s).length;
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return i * 2;
            case "hex":
                return i >>> 1;
            case "base64":
                return Dt(s).length;
            default:
                if (m) return c ? -1 : mt(s).length;
                n = ("" + n).toLowerCase(), m = !0
        }
    }
    d.byteLength = q;

    function G(s, n, i) {
        let c = !1;
        if ((n === void 0 || n < 0) && (n = 0), n > this.length || ((i === void 0 || i > this.length) && (i = this.length), i <= 0) || (i >>>= 0, n >>>= 0, i <= n)) return "";
        for (s || (s = "utf8");;) switch (s) {
            case "hex":
                return $e(this, n, i);
            case "utf8":
            case "utf-8":
                return se(this, n, i);
            case "ascii":
                return _e(this, n, i);
            case "latin1":
            case "binary":
                return le(this, n, i);
            case "base64":
                return we(this, n, i);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return dt(this, n, i);
            default:
                if (c) throw new TypeError("Unknown encoding: " + s);
                s = (s + "").toLowerCase(), c = !0
        }
    }
    d.prototype._isBuffer = !0;

    function z(s, n, i) {
        const c = s[n];
        s[n] = s[i], s[i] = c
    }
    d.prototype.swap16 = function() {
        const n = this.length;
        if (n % 2 !== 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
        for (let i = 0; i < n; i += 2) z(this, i, i + 1);
        return this
    }, d.prototype.swap32 = function() {
        const n = this.length;
        if (n % 4 !== 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
        for (let i = 0; i < n; i += 4) z(this, i, i + 3), z(this, i + 1, i + 2);
        return this
    }, d.prototype.swap64 = function() {
        const n = this.length;
        if (n % 8 !== 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
        for (let i = 0; i < n; i += 8) z(this, i, i + 7), z(this, i + 1, i + 6), z(this, i + 2, i + 5), z(this, i + 3, i + 4);
        return this
    }, d.prototype.toString = function() {
        const n = this.length;
        return n === 0 ? "" : arguments.length === 0 ? se(this, 0, n) : G.apply(this, arguments)
    }, d.prototype.toLocaleString = d.prototype.toString, d.prototype.equals = function(n) {
        if (!d.isBuffer(n)) throw new TypeError("Argument must be a Buffer");
        return this === n ? !0 : d.compare(this, n) === 0
    }, d.prototype.inspect = function() {
        let n = "";
        const i = t.INSPECT_MAX_BYTES;
        return n = this.toString("hex", 0, i).replace(/(.{2})/g, "$1 ").trim(), this.length > i && (n += " ... "), "<Buffer " + n + ">"
    }, a && (d.prototype[a] = d.prototype.inspect), d.prototype.compare = function(n, i, c, m, h) {
        if (ue(n, Uint8Array) && (n = d.from(n, n.offset, n.byteLength)), !d.isBuffer(n)) throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof n);
        if (i === void 0 && (i = 0), c === void 0 && (c = n ? n.length : 0), m === void 0 && (m = 0), h === void 0 && (h = this.length), i < 0 || c > n.length || m < 0 || h > this.length) throw new RangeError("out of range index");
        if (m >= h && i >= c) return 0;
        if (m >= h) return -1;
        if (i >= c) return 1;
        if (i >>>= 0, c >>>= 0, m >>>= 0, h >>>= 0, this === n) return 0;
        let w = h - m,
            k = c - i;
        const D = Math.min(w, k),
            I = this.slice(m, h),
            L = n.slice(i, c);
        for (let O = 0; O < D; ++O)
            if (I[O] !== L[O]) {
                w = I[O], k = L[O];
                break
            }
        return w < k ? -1 : k < w ? 1 : 0
    };

    function oe(s, n, i, c, m) {
        if (s.length === 0) return -1;
        if (typeof i == "string" ? (c = i, i = 0) : i > 2147483647 ? i = 2147483647 : i < -2147483648 && (i = -2147483648), i = +i, ft(i) && (i = m ? 0 : s.length - 1), i < 0 && (i = s.length + i), i >= s.length) {
            if (m) return -1;
            i = s.length - 1
        } else if (i < 0)
            if (m) i = 0;
            else return -1;
        if (typeof n == "string" && (n = d.from(n, c)), d.isBuffer(n)) return n.length === 0 ? -1 : K(s, n, i, c, m);
        if (typeof n == "number") return n = n & 255, typeof Uint8Array.prototype.indexOf == "function" ? m ? Uint8Array.prototype.indexOf.call(s, n, i) : Uint8Array.prototype.lastIndexOf.call(s, n, i) : K(s, [n], i, c, m);
        throw new TypeError("val must be string, number or Buffer")
    }

    function K(s, n, i, c, m) {
        let h = 1,
            w = s.length,
            k = n.length;
        if (c !== void 0 && (c = String(c).toLowerCase(), c === "ucs2" || c === "ucs-2" || c === "utf16le" || c === "utf-16le")) {
            if (s.length < 2 || n.length < 2) return -1;
            h = 2, w /= 2, k /= 2, i /= 2
        }

        function D(L, O) {
            return h === 1 ? L[O] : L.readUInt16BE(O * h)
        }
        let I;
        if (m) {
            let L = -1;
            for (I = i; I < w; I++)
                if (D(s, I) === D(n, L === -1 ? 0 : I - L)) {
                    if (L === -1 && (L = I), I - L + 1 === k) return L * h
                } else L !== -1 && (I -= I - L), L = -1
        } else
            for (i + k > w && (i = w - k), I = i; I >= 0; I--) {
                let L = !0;
                for (let O = 0; O < k; O++)
                    if (D(s, I + O) !== D(n, O)) {
                        L = !1;
                        break
                    }
                if (L) return I
            }
        return -1
    }
    d.prototype.includes = function(n, i, c) {
        return this.indexOf(n, i, c) !== -1
    }, d.prototype.indexOf = function(n, i, c) {
        return oe(this, n, i, c, !0)
    }, d.prototype.lastIndexOf = function(n, i, c) {
        return oe(this, n, i, c, !1)
    };

    function Oe(s, n, i, c) {
        i = Number(i) || 0;
        const m = s.length - i;
        c ? (c = Number(c), c > m && (c = m)) : c = m;
        const h = n.length;
        c > h / 2 && (c = h / 2);
        let w;
        for (w = 0; w < c; ++w) {
            const k = parseInt(n.substr(w * 2, 2), 16);
            if (ft(k)) return w;
            s[i + w] = k
        }
        return w
    }

    function He(s, n, i, c) {
        return Ge(mt(n, s.length - i), s, i, c)
    }

    function ze(s, n, i, c) {
        return Ge(Dn(n), s, i, c)
    }

    function Ve(s, n, i, c) {
        return Ge(Dt(n), s, i, c)
    }

    function Be(s, n, i, c) {
        return Ge(Ln(n, s.length - i), s, i, c)
    }
    d.prototype.write = function(n, i, c, m) {
        if (i === void 0) m = "utf8", c = this.length, i = 0;
        else if (c === void 0 && typeof i == "string") m = i, c = this.length, i = 0;
        else if (isFinite(i)) i = i >>> 0, isFinite(c) ? (c = c >>> 0, m === void 0 && (m = "utf8")) : (m = c, c = void 0);
        else throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
        const h = this.length - i;
        if ((c === void 0 || c > h) && (c = h), n.length > 0 && (c < 0 || i < 0) || i > this.length) throw new RangeError("Attempt to write outside buffer bounds");
        m || (m = "utf8");
        let w = !1;
        for (;;) switch (m) {
            case "hex":
                return Oe(this, n, i, c);
            case "utf8":
            case "utf-8":
                return He(this, n, i, c);
            case "ascii":
            case "latin1":
            case "binary":
                return ze(this, n, i, c);
            case "base64":
                return Ve(this, n, i, c);
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return Be(this, n, i, c);
            default:
                if (w) throw new TypeError("Unknown encoding: " + m);
                m = ("" + m).toLowerCase(), w = !0
        }
    }, d.prototype.toJSON = function() {
        return {
            type: "Buffer",
            data: Array.prototype.slice.call(this._arr || this, 0)
        }
    };

    function we(s, n, i) {
        return n === 0 && i === s.length ? e.fromByteArray(s) : e.fromByteArray(s.slice(n, i))
    }

    function se(s, n, i) {
        i = Math.min(s.length, i);
        const c = [];
        let m = n;
        for (; m < i;) {
            const h = s[m];
            let w = null,
                k = h > 239 ? 4 : h > 223 ? 3 : h > 191 ? 2 : 1;
            if (m + k <= i) {
                let D, I, L, O;
                switch (k) {
                    case 1:
                        h < 128 && (w = h);
                        break;
                    case 2:
                        D = s[m + 1], (D & 192) === 128 && (O = (h & 31) << 6 | D & 63, O > 127 && (w = O));
                        break;
                    case 3:
                        D = s[m + 1], I = s[m + 2], (D & 192) === 128 && (I & 192) === 128 && (O = (h & 15) << 12 | (D & 63) << 6 | I & 63, O > 2047 && (O < 55296 || O > 57343) && (w = O));
                        break;
                    case 4:
                        D = s[m + 1], I = s[m + 2], L = s[m + 3], (D & 192) === 128 && (I & 192) === 128 && (L & 192) === 128 && (O = (h & 15) << 18 | (D & 63) << 12 | (I & 63) << 6 | L & 63, O > 65535 && O < 1114112 && (w = O))
                }
            }
            w === null ? (w = 65533, k = 1) : w > 65535 && (w -= 65536, c.push(w >>> 10 & 1023 | 55296), w = 56320 | w & 1023), c.push(w), m += k
        }
        return re(c)
    }
    const Ue = 4096;

    function re(s) {
        const n = s.length;
        if (n <= Ue) return String.fromCharCode.apply(String, s);
        let i = "",
            c = 0;
        for (; c < n;) i += String.fromCharCode.apply(String, s.slice(c, c += Ue));
        return i
    }

    function _e(s, n, i) {
        let c = "";
        i = Math.min(s.length, i);
        for (let m = n; m < i; ++m) c += String.fromCharCode(s[m] & 127);
        return c
    }

    function le(s, n, i) {
        let c = "";
        i = Math.min(s.length, i);
        for (let m = n; m < i; ++m) c += String.fromCharCode(s[m]);
        return c
    }

    function $e(s, n, i) {
        const c = s.length;
        (!n || n < 0) && (n = 0), (!i || i < 0 || i > c) && (i = c);
        let m = "";
        for (let h = n; h < i; ++h) m += Mn[s[h]];
        return m
    }

    function dt(s, n, i) {
        const c = s.slice(n, i);
        let m = "";
        for (let h = 0; h < c.length - 1; h += 2) m += String.fromCharCode(c[h] + c[h + 1] * 256);
        return m
    }
    d.prototype.slice = function(n, i) {
        const c = this.length;
        n = ~~n, i = i === void 0 ? c : ~~i, n < 0 ? (n += c, n < 0 && (n = 0)) : n > c && (n = c), i < 0 ? (i += c, i < 0 && (i = 0)) : i > c && (i = c), i < n && (i = n);
        const m = this.subarray(n, i);
        return Object.setPrototypeOf(m, d.prototype), m
    };

    function P(s, n, i) {
        if (s % 1 !== 0 || s < 0) throw new RangeError("offset is not uint");
        if (s + n > i) throw new RangeError("Trying to access beyond buffer length")
    }
    d.prototype.readUintLE = d.prototype.readUIntLE = function(n, i, c) {
        n = n >>> 0, i = i >>> 0, c || P(n, i, this.length);
        let m = this[n],
            h = 1,
            w = 0;
        for (; ++w < i && (h *= 256);) m += this[n + w] * h;
        return m
    }, d.prototype.readUintBE = d.prototype.readUIntBE = function(n, i, c) {
        n = n >>> 0, i = i >>> 0, c || P(n, i, this.length);
        let m = this[n + --i],
            h = 1;
        for (; i > 0 && (h *= 256);) m += this[n + --i] * h;
        return m
    }, d.prototype.readUint8 = d.prototype.readUInt8 = function(n, i) {
        return n = n >>> 0, i || P(n, 1, this.length), this[n]
    }, d.prototype.readUint16LE = d.prototype.readUInt16LE = function(n, i) {
        return n = n >>> 0, i || P(n, 2, this.length), this[n] | this[n + 1] << 8
    }, d.prototype.readUint16BE = d.prototype.readUInt16BE = function(n, i) {
        return n = n >>> 0, i || P(n, 2, this.length), this[n] << 8 | this[n + 1]
    }, d.prototype.readUint32LE = d.prototype.readUInt32LE = function(n, i) {
        return n = n >>> 0, i || P(n, 4, this.length), (this[n] | this[n + 1] << 8 | this[n + 2] << 16) + this[n + 3] * 16777216
    }, d.prototype.readUint32BE = d.prototype.readUInt32BE = function(n, i) {
        return n = n >>> 0, i || P(n, 4, this.length), this[n] * 16777216 + (this[n + 1] << 16 | this[n + 2] << 8 | this[n + 3])
    }, d.prototype.readBigUInt64LE = fe(function(n) {
        n = n >>> 0, Re(n, "offset");
        const i = this[n],
            c = this[n + 7];
        (i === void 0 || c === void 0) && Ne(n, this.length - 8);
        const m = i + this[++n] * 2 ** 8 + this[++n] * 2 ** 16 + this[++n] * 2 ** 24,
            h = this[++n] + this[++n] * 2 ** 8 + this[++n] * 2 ** 16 + c * 2 ** 24;
        return BigInt(m) + (BigInt(h) << BigInt(32))
    }), d.prototype.readBigUInt64BE = fe(function(n) {
        n = n >>> 0, Re(n, "offset");
        const i = this[n],
            c = this[n + 7];
        (i === void 0 || c === void 0) && Ne(n, this.length - 8);
        const m = i * 2 ** 24 + this[++n] * 2 ** 16 + this[++n] * 2 ** 8 + this[++n],
            h = this[++n] * 2 ** 24 + this[++n] * 2 ** 16 + this[++n] * 2 ** 8 + c;
        return (BigInt(m) << BigInt(32)) + BigInt(h)
    }), d.prototype.readIntLE = function(n, i, c) {
        n = n >>> 0, i = i >>> 0, c || P(n, i, this.length);
        let m = this[n],
            h = 1,
            w = 0;
        for (; ++w < i && (h *= 256);) m += this[n + w] * h;
        return h *= 128, m >= h && (m -= Math.pow(2, 8 * i)), m
    }, d.prototype.readIntBE = function(n, i, c) {
        n = n >>> 0, i = i >>> 0, c || P(n, i, this.length);
        let m = i,
            h = 1,
            w = this[n + --m];
        for (; m > 0 && (h *= 256);) w += this[n + --m] * h;
        return h *= 128, w >= h && (w -= Math.pow(2, 8 * i)), w
    }, d.prototype.readInt8 = function(n, i) {
        return n = n >>> 0, i || P(n, 1, this.length), this[n] & 128 ? (255 - this[n] + 1) * -1 : this[n]
    }, d.prototype.readInt16LE = function(n, i) {
        n = n >>> 0, i || P(n, 2, this.length);
        const c = this[n] | this[n + 1] << 8;
        return c & 32768 ? c | 4294901760 : c
    }, d.prototype.readInt16BE = function(n, i) {
        n = n >>> 0, i || P(n, 2, this.length);
        const c = this[n + 1] | this[n] << 8;
        return c & 32768 ? c | 4294901760 : c
    }, d.prototype.readInt32LE = function(n, i) {
        return n = n >>> 0, i || P(n, 4, this.length), this[n] | this[n + 1] << 8 | this[n + 2] << 16 | this[n + 3] << 24
    }, d.prototype.readInt32BE = function(n, i) {
        return n = n >>> 0, i || P(n, 4, this.length), this[n] << 24 | this[n + 1] << 16 | this[n + 2] << 8 | this[n + 3]
    }, d.prototype.readBigInt64LE = fe(function(n) {
        n = n >>> 0, Re(n, "offset");
        const i = this[n],
            c = this[n + 7];
        (i === void 0 || c === void 0) && Ne(n, this.length - 8);
        const m = this[n + 4] + this[n + 5] * 2 ** 8 + this[n + 6] * 2 ** 16 + (c << 24);
        return (BigInt(m) << BigInt(32)) + BigInt(i + this[++n] * 2 ** 8 + this[++n] * 2 ** 16 + this[++n] * 2 ** 24)
    }), d.prototype.readBigInt64BE = fe(function(n) {
        n = n >>> 0, Re(n, "offset");
        const i = this[n],
            c = this[n + 7];
        (i === void 0 || c === void 0) && Ne(n, this.length - 8);
        const m = (i << 24) + this[++n] * 2 ** 16 + this[++n] * 2 ** 8 + this[++n];
        return (BigInt(m) << BigInt(32)) + BigInt(this[++n] * 2 ** 24 + this[++n] * 2 ** 16 + this[++n] * 2 ** 8 + c)
    }), d.prototype.readFloatLE = function(n, i) {
        return n = n >>> 0, i || P(n, 4, this.length), r.read(this, n, !0, 23, 4)
    }, d.prototype.readFloatBE = function(n, i) {
        return n = n >>> 0, i || P(n, 4, this.length), r.read(this, n, !1, 23, 4)
    }, d.prototype.readDoubleLE = function(n, i) {
        return n = n >>> 0, i || P(n, 8, this.length), r.read(this, n, !0, 52, 8)
    }, d.prototype.readDoubleBE = function(n, i) {
        return n = n >>> 0, i || P(n, 8, this.length), r.read(this, n, !1, 52, 8)
    };

    function j(s, n, i, c, m, h) {
        if (!d.isBuffer(s)) throw new TypeError('"buffer" argument must be a Buffer instance');
        if (n > m || n < h) throw new RangeError('"value" argument is out of bounds');
        if (i + c > s.length) throw new RangeError("Index out of range")
    }
    d.prototype.writeUintLE = d.prototype.writeUIntLE = function(n, i, c, m) {
        if (n = +n, i = i >>> 0, c = c >>> 0, !m) {
            const k = Math.pow(2, 8 * c) - 1;
            j(this, n, i, c, k, 0)
        }
        let h = 1,
            w = 0;
        for (this[i] = n & 255; ++w < c && (h *= 256);) this[i + w] = n / h & 255;
        return i + c
    }, d.prototype.writeUintBE = d.prototype.writeUIntBE = function(n, i, c, m) {
        if (n = +n, i = i >>> 0, c = c >>> 0, !m) {
            const k = Math.pow(2, 8 * c) - 1;
            j(this, n, i, c, k, 0)
        }
        let h = c - 1,
            w = 1;
        for (this[i + h] = n & 255; --h >= 0 && (w *= 256);) this[i + h] = n / w & 255;
        return i + c
    }, d.prototype.writeUint8 = d.prototype.writeUInt8 = function(n, i, c) {
        return n = +n, i = i >>> 0, c || j(this, n, i, 1, 255, 0), this[i] = n & 255, i + 1
    }, d.prototype.writeUint16LE = d.prototype.writeUInt16LE = function(n, i, c) {
        return n = +n, i = i >>> 0, c || j(this, n, i, 2, 65535, 0), this[i] = n & 255, this[i + 1] = n >>> 8, i + 2
    }, d.prototype.writeUint16BE = d.prototype.writeUInt16BE = function(n, i, c) {
        return n = +n, i = i >>> 0, c || j(this, n, i, 2, 65535, 0), this[i] = n >>> 8, this[i + 1] = n & 255, i + 2
    }, d.prototype.writeUint32LE = d.prototype.writeUInt32LE = function(n, i, c) {
        return n = +n, i = i >>> 0, c || j(this, n, i, 4, 4294967295, 0), this[i + 3] = n >>> 24, this[i + 2] = n >>> 16, this[i + 1] = n >>> 8, this[i] = n & 255, i + 4
    }, d.prototype.writeUint32BE = d.prototype.writeUInt32BE = function(n, i, c) {
        return n = +n, i = i >>> 0, c || j(this, n, i, 4, 4294967295, 0), this[i] = n >>> 24, this[i + 1] = n >>> 16, this[i + 2] = n >>> 8, this[i + 3] = n & 255, i + 4
    };

    function Se(s, n, i, c, m) {
        Nt(n, c, m, s, i, 7);
        let h = Number(n & BigInt(4294967295));
        s[i++] = h, h = h >> 8, s[i++] = h, h = h >> 8, s[i++] = h, h = h >> 8, s[i++] = h;
        let w = Number(n >> BigInt(32) & BigInt(4294967295));
        return s[i++] = w, w = w >> 8, s[i++] = w, w = w >> 8, s[i++] = w, w = w >> 8, s[i++] = w, i
    }

    function be(s, n, i, c, m) {
        Nt(n, c, m, s, i, 7);
        let h = Number(n & BigInt(4294967295));
        s[i + 7] = h, h = h >> 8, s[i + 6] = h, h = h >> 8, s[i + 5] = h, h = h >> 8, s[i + 4] = h;
        let w = Number(n >> BigInt(32) & BigInt(4294967295));
        return s[i + 3] = w, w = w >> 8, s[i + 2] = w, w = w >> 8, s[i + 1] = w, w = w >> 8, s[i] = w, i + 8
    }
    d.prototype.writeBigUInt64LE = fe(function(n, i = 0) {
        return Se(this, n, i, BigInt(0), BigInt("0xffffffffffffffff"))
    }), d.prototype.writeBigUInt64BE = fe(function(n, i = 0) {
        return be(this, n, i, BigInt(0), BigInt("0xffffffffffffffff"))
    }), d.prototype.writeIntLE = function(n, i, c, m) {
        if (n = +n, i = i >>> 0, !m) {
            const D = Math.pow(2, 8 * c - 1);
            j(this, n, i, c, D - 1, -D)
        }
        let h = 0,
            w = 1,
            k = 0;
        for (this[i] = n & 255; ++h < c && (w *= 256);) n < 0 && k === 0 && this[i + h - 1] !== 0 && (k = 1), this[i + h] = (n / w >> 0) - k & 255;
        return i + c
    }, d.prototype.writeIntBE = function(n, i, c, m) {
        if (n = +n, i = i >>> 0, !m) {
            const D = Math.pow(2, 8 * c - 1);
            j(this, n, i, c, D - 1, -D)
        }
        let h = c - 1,
            w = 1,
            k = 0;
        for (this[i + h] = n & 255; --h >= 0 && (w *= 256);) n < 0 && k === 0 && this[i + h + 1] !== 0 && (k = 1), this[i + h] = (n / w >> 0) - k & 255;
        return i + c
    }, d.prototype.writeInt8 = function(n, i, c) {
        return n = +n, i = i >>> 0, c || j(this, n, i, 1, 127, -128), n < 0 && (n = 255 + n + 1), this[i] = n & 255, i + 1
    }, d.prototype.writeInt16LE = function(n, i, c) {
        return n = +n, i = i >>> 0, c || j(this, n, i, 2, 32767, -32768), this[i] = n & 255, this[i + 1] = n >>> 8, i + 2
    }, d.prototype.writeInt16BE = function(n, i, c) {
        return n = +n, i = i >>> 0, c || j(this, n, i, 2, 32767, -32768), this[i] = n >>> 8, this[i + 1] = n & 255, i + 2
    }, d.prototype.writeInt32LE = function(n, i, c) {
        return n = +n, i = i >>> 0, c || j(this, n, i, 4, 2147483647, -2147483648), this[i] = n & 255, this[i + 1] = n >>> 8, this[i + 2] = n >>> 16, this[i + 3] = n >>> 24, i + 4
    }, d.prototype.writeInt32BE = function(n, i, c) {
        return n = +n, i = i >>> 0, c || j(this, n, i, 4, 2147483647, -2147483648), n < 0 && (n = 4294967295 + n + 1), this[i] = n >>> 24, this[i + 1] = n >>> 16, this[i + 2] = n >>> 8, this[i + 3] = n & 255, i + 4
    }, d.prototype.writeBigInt64LE = fe(function(n, i = 0) {
        return Se(this, n, i, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"))
    }), d.prototype.writeBigInt64BE = fe(function(n, i = 0) {
        return be(this, n, i, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"))
    });

    function Ie(s, n, i, c, m, h) {
        if (i + c > s.length) throw new RangeError("Index out of range");
        if (i < 0) throw new RangeError("Index out of range")
    }

    function Ot(s, n, i, c, m) {
        return n = +n, i = i >>> 0, m || Ie(s, n, i, 4), r.write(s, n, i, c, 23, 4), i + 4
    }
    d.prototype.writeFloatLE = function(n, i, c) {
        return Ot(this, n, i, !0, c)
    }, d.prototype.writeFloatBE = function(n, i, c) {
        return Ot(this, n, i, !1, c)
    };

    function Ut(s, n, i, c, m) {
        return n = +n, i = i >>> 0, m || Ie(s, n, i, 8), r.write(s, n, i, c, 52, 8), i + 8
    }
    d.prototype.writeDoubleLE = function(n, i, c) {
        return Ut(this, n, i, !0, c)
    }, d.prototype.writeDoubleBE = function(n, i, c) {
        return Ut(this, n, i, !1, c)
    }, d.prototype.copy = function(n, i, c, m) {
        if (!d.isBuffer(n)) throw new TypeError("argument should be a Buffer");
        if (c || (c = 0), !m && m !== 0 && (m = this.length), i >= n.length && (i = n.length), i || (i = 0), m > 0 && m < c && (m = c), m === c || n.length === 0 || this.length === 0) return 0;
        if (i < 0) throw new RangeError("targetStart out of bounds");
        if (c < 0 || c >= this.length) throw new RangeError("Index out of range");
        if (m < 0) throw new RangeError("sourceEnd out of bounds");
        m > this.length && (m = this.length), n.length - i < m - c && (m = n.length - i + c);
        const h = m - c;
        return this === n && typeof Uint8Array.prototype.copyWithin == "function" ? this.copyWithin(i, c, m) : Uint8Array.prototype.set.call(n, this.subarray(c, m), i), h
    }, d.prototype.fill = function(n, i, c, m) {
        if (typeof n == "string") {
            if (typeof i == "string" ? (m = i, i = 0, c = this.length) : typeof c == "string" && (m = c, c = this.length), m !== void 0 && typeof m != "string") throw new TypeError("encoding must be a string");
            if (typeof m == "string" && !d.isEncoding(m)) throw new TypeError("Unknown encoding: " + m);
            if (n.length === 1) {
                const w = n.charCodeAt(0);
                (m === "utf8" && w < 128 || m === "latin1") && (n = w)
            }
        } else typeof n == "number" ? n = n & 255 : typeof n == "boolean" && (n = Number(n));
        if (i < 0 || this.length < i || this.length < c) throw new RangeError("Out of range index");
        if (c <= i) return this;
        i = i >>> 0, c = c === void 0 ? this.length : c >>> 0, n || (n = 0);
        let h;
        if (typeof n == "number")
            for (h = i; h < c; ++h) this[h] = n;
        else {
            const w = d.isBuffer(n) ? n : d.from(n, m),
                k = w.length;
            if (k === 0) throw new TypeError('The value "' + n + '" is invalid for argument "value"');
            for (h = 0; h < c - i; ++h) this[h + i] = w[h % k]
        }
        return this
    };
    const We = {};

    function ct(s, n, i) {
        We[s] = class extends i {
            constructor() {
                super(), Object.defineProperty(this, "message", {
                    value: n.apply(this, arguments),
                    writable: !0,
                    configurable: !0
                }), this.name = `${this.name} [${s}]`, this.stack, delete this.name
            }
            get code() {
                return s
            }
            set code(m) {
                Object.defineProperty(this, "code", {
                    configurable: !0,
                    enumerable: !0,
                    value: m,
                    writable: !0
                })
            }
            toString() {
                return `${this.name} [${s}]: ${this.message}`
            }
        }
    }
    ct("ERR_BUFFER_OUT_OF_BOUNDS", function(s) {
        return s ? `${s} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds"
    }, RangeError), ct("ERR_INVALID_ARG_TYPE", function(s, n) {
        return `The "${s}" argument must be of type number. Received type ${typeof n}`
    }, TypeError), ct("ERR_OUT_OF_RANGE", function(s, n, i) {
        let c = `The value of "${s}" is out of range.`,
            m = i;
        return Number.isInteger(i) && Math.abs(i) > 2 ** 32 ? m = It(String(i)) : typeof i == "bigint" && (m = String(i), (i > BigInt(2) ** BigInt(32) || i < -(BigInt(2) ** BigInt(32))) && (m = It(m)), m += "n"), c += ` It must be ${n}. Received ${m}`, c
    }, RangeError);

    function It(s) {
        let n = "",
            i = s.length;
        const c = s[0] === "-" ? 1 : 0;
        for (; i >= c + 4; i -= 3) n = `_${s.slice(i-3,i)}${n}`;
        return `${s.slice(0,i)}${n}`
    }

    function Un(s, n, i) {
        Re(n, "offset"), (s[n] === void 0 || s[n + i] === void 0) && Ne(n, s.length - (i + 1))
    }

    function Nt(s, n, i, c, m, h) {
        if (s > i || s < n) {
            const w = typeof n == "bigint" ? "n" : "";
            let k;
            throw n === 0 || n === BigInt(0) ? k = `>= 0${w} and < 2${w} ** ${(h+1)*8}${w}` : k = `>= -(2${w} ** ${(h+1)*8-1}${w}) and < 2 ** ${(h+1)*8-1}${w}`, new We.ERR_OUT_OF_RANGE("value", k, s)
        }
        Un(c, m, h)
    }

    function Re(s, n) {
        if (typeof s != "number") throw new We.ERR_INVALID_ARG_TYPE(n, "number", s)
    }

    function Ne(s, n, i) {
        throw Math.floor(s) !== s ? (Re(s, i), new We.ERR_OUT_OF_RANGE("offset", "an integer", s)) : n < 0 ? new We.ERR_BUFFER_OUT_OF_BOUNDS : new We.ERR_OUT_OF_RANGE("offset", `>= 0 and <= ${n}`, s)
    }
    const In = /[^+/0-9A-Za-z-_]/g;

    function Nn(s) {
        if (s = s.split("=")[0], s = s.trim().replace(In, ""), s.length < 2) return "";
        for (; s.length % 4 !== 0;) s = s + "=";
        return s
    }

    function mt(s, n) {
        n = n || 1 / 0;
        let i;
        const c = s.length;
        let m = null;
        const h = [];
        for (let w = 0; w < c; ++w) {
            if (i = s.charCodeAt(w), i > 55295 && i < 57344) {
                if (!m) {
                    if (i > 56319) {
                        (n -= 3) > -1 && h.push(239, 191, 189);
                        continue
                    } else if (w + 1 === c) {
                        (n -= 3) > -1 && h.push(239, 191, 189);
                        continue
                    }
                    m = i;
                    continue
                }
                if (i < 56320) {
                    (n -= 3) > -1 && h.push(239, 191, 189), m = i;
                    continue
                }
                i = (m - 55296 << 10 | i - 56320) + 65536
            } else m && (n -= 3) > -1 && h.push(239, 191, 189);
            if (m = null, i < 128) {
                if ((n -= 1) < 0) break;
                h.push(i)
            } else if (i < 2048) {
                if ((n -= 2) < 0) break;
                h.push(i >> 6 | 192, i & 63 | 128)
            } else if (i < 65536) {
                if ((n -= 3) < 0) break;
                h.push(i >> 12 | 224, i >> 6 & 63 | 128, i & 63 | 128)
            } else if (i < 1114112) {
                if ((n -= 4) < 0) break;
                h.push(i >> 18 | 240, i >> 12 & 63 | 128, i >> 6 & 63 | 128, i & 63 | 128)
            } else throw new Error("Invalid code point")
        }
        return h
    }

    function Dn(s) {
        const n = [];
        for (let i = 0; i < s.length; ++i) n.push(s.charCodeAt(i) & 255);
        return n
    }

    function Ln(s, n) {
        let i, c, m;
        const h = [];
        for (let w = 0; w < s.length && !((n -= 2) < 0); ++w) i = s.charCodeAt(w), c = i >> 8, m = i % 256, h.push(m), h.push(c);
        return h
    }

    function Dt(s) {
        return e.toByteArray(Nn(s))
    }

    function Ge(s, n, i, c) {
        let m;
        for (m = 0; m < c && !(m + i >= n.length || m >= s.length); ++m) n[m + i] = s[m];
        return m
    }

    function ue(s, n) {
        return s instanceof n || s != null && s.constructor != null && s.constructor.name != null && s.constructor.name === n.name
    }

    function ft(s) {
        return s !== s
    }
    const Mn = function() {
        const s = "0123456789abcdef",
            n = new Array(256);
        for (let i = 0; i < 16; ++i) {
            const c = i * 16;
            for (let m = 0; m < 16; ++m) n[c + m] = s[i] + s[m]
        }
        return n
    }();

    function fe(s) {
        return typeof BigInt > "u" ? qn : s
    }

    function qn() {
        throw new Error("BigInt not supported")
    }
})(ln);

function dn(t, e) {
    return function() {
        return t.apply(e, arguments)
    }
}
const {
    toString: yr
} = Object.prototype, {
    getPrototypeOf: vt
} = Object, {
    iterator: at,
    toStringTag: cn
} = Symbol, ot = (t => e => {
    const r = yr.call(e);
    return t[r] || (t[r] = r.slice(8, -1).toLowerCase())
})(Object.create(null)), ae = t => (t = t.toLowerCase(), e => ot(e) === t), st = t => e => typeof e === t, {
    isArray: Fe
} = Array, ke = st("undefined");

function Le(t) {
    return t !== null && !ke(t) && t.constructor !== null && !ke(t.constructor) && Z(t.constructor.isBuffer) && t.constructor.isBuffer(t)
}
const mn = ae("ArrayBuffer");

function wr(t) {
    let e;
    return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? e = ArrayBuffer.isView(t) : e = t && t.buffer && mn(t.buffer), e
}
const br = st("string"),
    Z = st("function"),
    fn = st("number"),
    Me = t => t !== null && typeof t == "object",
    gr = t => t === !0 || t === !1,
    Ke = t => {
        if (ot(t) !== "object") return !1;
        const e = vt(t);
        return (e === null || e === Object.prototype || Object.getPrototypeOf(e) === null) && !(cn in t) && !(at in t)
    },
    Tr = t => {
        if (!Me(t) || Le(t)) return !1;
        try {
            return Object.keys(t).length === 0 && Object.getPrototypeOf(t) === Object.prototype
        } catch {
            return !1
        }
    },
    Cr = ae("Date"),
    Er = ae("File"),
    Hr = ae("Blob"),
    Br = ae("FileList"),
    Sr = t => Me(t) && Z(t.pipe),
    Wr = t => {
        let e;
        return t && (typeof FormData == "function" && t instanceof FormData || Z(t.append) && ((e = ot(t)) === "formdata" || e === "object" && Z(t.toString) && t.toString() === "[object FormData]"))
    },
    Rr = ae("URLSearchParams"),
    [Ar, vr, kr, Fr] = ["ReadableStream", "Request", "Response", "Headers"].map(ae),
    Pr = t => t.trim ? t.trim() : t.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");

function qe(t, e, {
    allOwnKeys: r = !1
} = {}) {
    if (t === null || typeof t > "u") return;
    let a, o;
    if (typeof t != "object" && (t = [t]), Fe(t))
        for (a = 0, o = t.length; a < o; a++) e.call(null, t[a], a, t);
    else {
        if (Le(t)) return;
        const u = r ? Object.getOwnPropertyNames(t) : Object.keys(t),
            l = u.length;
        let d;
        for (a = 0; a < l; a++) d = u[a], e.call(null, t[d], d, t)
    }
}

function hn(t, e) {
    if (Le(t)) return null;
    e = e.toLowerCase();
    const r = Object.keys(t);
    let a = r.length,
        o;
    for (; a-- > 0;)
        if (o = r[a], e === o.toLowerCase()) return o;
    return null
}
const Te = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global,
    xn = t => !ke(t) && t !== Te;

function Et() {
    const {
        caseless: t,
        skipUndefined: e
    } = xn(this) && this || {}, r = {}, a = (o, u) => {
        const l = t && hn(r, u) || u;
        Ke(r[l]) && Ke(o) ? r[l] = Et(r[l], o) : Ke(o) ? r[l] = Et({}, o) : Fe(o) ? r[l] = o.slice() : (!e || !ke(o)) && (r[l] = o)
    };
    for (let o = 0, u = arguments.length; o < u; o++) arguments[o] && qe(arguments[o], a);
    return r
}
const Or = (t, e, r, {
        allOwnKeys: a
    } = {}) => (qe(e, (o, u) => {
        r && Z(o) ? t[u] = dn(o, r) : t[u] = o
    }, {
        allOwnKeys: a
    }), t),
    Ur = t => (t.charCodeAt(0) === 65279 && (t = t.slice(1)), t),
    Ir = (t, e, r, a) => {
        t.prototype = Object.create(e.prototype, a), t.prototype.constructor = t, Object.defineProperty(t, "super", {
            value: e.prototype
        }), r && Object.assign(t.prototype, r)
    },
    Nr = (t, e, r, a) => {
        let o, u, l;
        const d = {};
        if (e = e || {}, t == null) return e;
        do {
            for (o = Object.getOwnPropertyNames(t), u = o.length; u-- > 0;) l = o[u], (!a || a(l, t, e)) && !d[l] && (e[l] = t[l], d[l] = !0);
            t = r !== !1 && vt(t)
        } while (t && (!r || r(t, e)) && t !== Object.prototype);
        return e
    },
    Dr = (t, e, r) => {
        t = String(t), (r === void 0 || r > t.length) && (r = t.length), r -= e.length;
        const a = t.indexOf(e, r);
        return a !== -1 && a === r
    },
    Lr = t => {
        if (!t) return null;
        if (Fe(t)) return t;
        let e = t.length;
        if (!fn(e)) return null;
        const r = new Array(e);
        for (; e-- > 0;) r[e] = t[e];
        return r
    },
    Mr = (t => e => t && e instanceof t)(typeof Uint8Array < "u" && vt(Uint8Array)),
    qr = (t, e) => {
        const a = (t && t[at]).call(t);
        let o;
        for (;
            (o = a.next()) && !o.done;) {
            const u = o.value;
            e.call(t, u[0], u[1])
        }
    },
    jr = (t, e) => {
        let r;
        const a = [];
        for (;
            (r = t.exec(e)) !== null;) a.push(r);
        return a
    },
    zr = ae("HTMLFormElement"),
    Vr = t => t.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function(r, a, o) {
        return a.toUpperCase() + o
    }),
    zt = (({
        hasOwnProperty: t
    }) => (e, r) => t.call(e, r))(Object.prototype),
    _r = ae("RegExp"),
    pn = (t, e) => {
        const r = Object.getOwnPropertyDescriptors(t),
            a = {};
        qe(r, (o, u) => {
            let l;
            (l = e(o, u, t)) !== !1 && (a[u] = l || o)
        }), Object.defineProperties(t, a)
    },
    $r = t => {
        pn(t, (e, r) => {
            if (Z(t) && ["arguments", "caller", "callee"].indexOf(r) !== -1) return !1;
            const a = t[r];
            if (Z(a)) {
                if (e.enumerable = !1, "writable" in e) {
                    e.writable = !1;
                    return
                }
                e.set || (e.set = () => {
                    throw Error("Can not rewrite read-only method '" + r + "'")
                })
            }
        })
    },
    Gr = (t, e) => {
        const r = {},
            a = o => {
                o.forEach(u => {
                    r[u] = !0
                })
            };
        return Fe(t) ? a(t) : a(String(t).split(e)), r
    },
    Jr = () => {},
    Kr = (t, e) => t != null && Number.isFinite(t = +t) ? t : e;

function Qr(t) {
    return !!(t && Z(t.append) && t[cn] === "FormData" && t[at])
}
const Xr = t => {
        const e = new Array(10),
            r = (a, o) => {
                if (Me(a)) {
                    if (e.indexOf(a) >= 0) return;
                    if (Le(a)) return a;
                    if (!("toJSON" in a)) {
                        e[o] = a;
                        const u = Fe(a) ? [] : {};
                        return qe(a, (l, d) => {
                            const y = r(l, o + 1);
                            !ke(y) && (u[d] = y)
                        }), e[o] = void 0, u
                    }
                }
                return a
            };
        return r(t, 0)
    },
    Zr = ae("AsyncFunction"),
    Yr = t => t && (Me(t) || Z(t)) && Z(t.then) && Z(t.catch),
    yn = ((t, e) => t ? setImmediate : e ? ((r, a) => (Te.addEventListener("message", ({
        source: o,
        data: u
    }) => {
        o === Te && u === r && a.length && a.shift()()
    }, !1), o => {
        a.push(o), Te.postMessage(r, "*")
    }))(`axios@${Math.random()}`, []) : r => setTimeout(r))(typeof setImmediate == "function", Z(Te.postMessage)),
    ei = typeof queueMicrotask < "u" ? queueMicrotask.bind(Te) : typeof process < "u" && process.nextTick || yn,
    ti = t => t != null && Z(t[at]),
    f = {
        isArray: Fe,
        isArrayBuffer: mn,
        isBuffer: Le,
        isFormData: Wr,
        isArrayBufferView: wr,
        isString: br,
        isNumber: fn,
        isBoolean: gr,
        isObject: Me,
        isPlainObject: Ke,
        isEmptyObject: Tr,
        isReadableStream: Ar,
        isRequest: vr,
        isResponse: kr,
        isHeaders: Fr,
        isUndefined: ke,
        isDate: Cr,
        isFile: Er,
        isBlob: Hr,
        isRegExp: _r,
        isFunction: Z,
        isStream: Sr,
        isURLSearchParams: Rr,
        isTypedArray: Mr,
        isFileList: Br,
        forEach: qe,
        merge: Et,
        extend: Or,
        trim: Pr,
        stripBOM: Ur,
        inherits: Ir,
        toFlatObject: Nr,
        kindOf: ot,
        kindOfTest: ae,
        endsWith: Dr,
        toArray: Lr,
        forEachEntry: qr,
        matchAll: jr,
        isHTMLForm: zr,
        hasOwnProperty: zt,
        hasOwnProp: zt,
        reduceDescriptors: pn,
        freezeMethods: $r,
        toObjectSet: Gr,
        toCamelCase: Vr,
        noop: Jr,
        toFiniteNumber: Kr,
        findKey: hn,
        global: Te,
        isContextDefined: xn,
        isSpecCompliantForm: Qr,
        toJSONObject: Xr,
        isAsyncFn: Zr,
        isThenable: Yr,
        setImmediate: yn,
        asap: ei,
        isIterable: ti
    };

function W(t, e, r, a, o) {
    Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack, this.message = t, this.name = "AxiosError", e && (this.code = e), r && (this.config = r), a && (this.request = a), o && (this.response = o, this.status = o.status ? o.status : null)
}
f.inherits(W, Error, {
    toJSON: function() {
        return {
            message: this.message,
            name: this.name,
            description: this.description,
            number: this.number,
            fileName: this.fileName,
            lineNumber: this.lineNumber,
            columnNumber: this.columnNumber,
            stack: this.stack,
            config: f.toJSONObject(this.config),
            code: this.code,
            status: this.status
        }
    }
});
const wn = W.prototype,
    bn = {};
["ERR_BAD_OPTION_VALUE", "ERR_BAD_OPTION", "ECONNABORTED", "ETIMEDOUT", "ERR_NETWORK", "ERR_FR_TOO_MANY_REDIRECTS", "ERR_DEPRECATED", "ERR_BAD_RESPONSE", "ERR_BAD_REQUEST", "ERR_CANCELED", "ERR_NOT_SUPPORT", "ERR_INVALID_URL"].forEach(t => {
    bn[t] = {
        value: t
    }
});
Object.defineProperties(W, bn);
Object.defineProperty(wn, "isAxiosError", {
    value: !0
});
W.from = (t, e, r, a, o, u) => {
    const l = Object.create(wn);
    f.toFlatObject(t, l, function(p) {
        return p !== Error.prototype
    }, x => x !== "isAxiosError");
    const d = t && t.message ? t.message : "Error",
        y = e == null && t ? t.code : e;
    return W.call(l, d, y, r, a, o), t && l.cause == null && Object.defineProperty(l, "cause", {
        value: t,
        configurable: !0
    }), l.name = t && t.name || "Error", u && Object.assign(l, u), l
};
const ni = null;

function Ht(t) {
    return f.isPlainObject(t) || f.isArray(t)
}

function gn(t) {
    return f.endsWith(t, "[]") ? t.slice(0, -2) : t
}

function Vt(t, e, r) {
    return t ? t.concat(e).map(function(o, u) {
        return o = gn(o), !r && u ? "[" + o + "]" : o
    }).join(r ? "." : "") : e
}

function ri(t) {
    return f.isArray(t) && !t.some(Ht)
}
const ii = f.toFlatObject(f, {}, null, function(e) {
    return /^is[A-Z]/.test(e)
});

function lt(t, e, r) {
    if (!f.isObject(t)) throw new TypeError("target must be an object");
    e = e || new FormData, r = f.toFlatObject(r, {
        metaTokens: !0,
        dots: !1,
        indexes: !1
    }, !1, function(H, E) {
        return !f.isUndefined(E[H])
    });
    const a = r.metaTokens,
        o = r.visitor || p,
        u = r.dots,
        l = r.indexes,
        y = (r.Blob || typeof Blob < "u" && Blob) && f.isSpecCompliantForm(e);
    if (!f.isFunction(o)) throw new TypeError("visitor must be a function");

    function x(g) {
        if (g === null) return "";
        if (f.isDate(g)) return g.toISOString();
        if (f.isBoolean(g)) return g.toString();
        if (!y && f.isBlob(g)) throw new W("Blob is not supported. Use a Buffer instead.");
        return f.isArrayBuffer(g) || f.isTypedArray(g) ? y && typeof Blob == "function" ? new Blob([g]) : Buffer.from(g) : g
    }

    function p(g, H, E) {
        let N = g;
        if (g && !E && typeof g == "object") {
            if (f.endsWith(H, "{}")) H = a ? H : H.slice(0, -2), g = JSON.stringify(g);
            else if (f.isArray(g) && ri(g) || (f.isFileList(g) || f.endsWith(H, "[]")) && (N = f.toArray(g))) return H = gn(H), N.forEach(function(q, G) {
                !(f.isUndefined(q) || q === null) && e.append(l === !0 ? Vt([H], G, u) : l === null ? H : H + "[]", x(q))
            }), !1
        }
        return Ht(g) ? !0 : (e.append(Vt(E, H, u), x(g)), !1)
    }
    const C = [],
        S = Object.assign(ii, {
            defaultVisitor: p,
            convertValue: x,
            isVisitable: Ht
        });

    function F(g, H) {
        if (!f.isUndefined(g)) {
            if (C.indexOf(g) !== -1) throw Error("Circular reference detected in " + H.join("."));
            C.push(g), f.forEach(g, function(N, X) {
                (!(f.isUndefined(N) || N === null) && o.call(e, N, f.isString(X) ? X.trim() : X, H, S)) === !0 && F(N, H ? H.concat(X) : [X])
            }), C.pop()
        }
    }
    if (!f.isObject(t)) throw new TypeError("data must be an object");
    return F(t), e
}

function _t(t) {
    const e = {
        "!": "%21",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "~": "%7E",
        "%20": "+",
        "%00": "\0"
    };
    return encodeURIComponent(t).replace(/[!'()~]|%20|%00/g, function(a) {
        return e[a]
    })
}

function kt(t, e) {
    this._pairs = [], t && lt(t, this, e)
}
const Tn = kt.prototype;
Tn.append = function(e, r) {
    this._pairs.push([e, r])
};
Tn.toString = function(e) {
    const r = e ? function(a) {
        return e.call(this, a, _t)
    } : _t;
    return this._pairs.map(function(o) {
        return r(o[0]) + "=" + r(o[1])
    }, "").join("&")
};

function ai(t) {
    return encodeURIComponent(t).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+")
}

function Cn(t, e, r) {
    if (!e) return t;
    const a = r && r.encode || ai;
    f.isFunction(r) && (r = {
        serialize: r
    });
    const o = r && r.serialize;
    let u;
    if (o ? u = o(e, r) : u = f.isURLSearchParams(e) ? e.toString() : new kt(e, r).toString(a), u) {
        const l = t.indexOf("#");
        l !== -1 && (t = t.slice(0, l)), t += (t.indexOf("?") === -1 ? "?" : "&") + u
    }
    return t
}
class $t {
    constructor() {
        this.handlers = []
    }
    use(e, r, a) {
        return this.handlers.push({
            fulfilled: e,
            rejected: r,
            synchronous: a ? a.synchronous : !1,
            runWhen: a ? a.runWhen : null
        }), this.handlers.length - 1
    }
    eject(e) {
        this.handlers[e] && (this.handlers[e] = null)
    }
    clear() {
        this.handlers && (this.handlers = [])
    }
    forEach(e) {
        f.forEach(this.handlers, function(a) {
            a !== null && e(a)
        })
    }
}
const En = {
        silentJSONParsing: !0,
        forcedJSONParsing: !0,
        clarifyTimeoutError: !1
    },
    oi = typeof URLSearchParams < "u" ? URLSearchParams : kt,
    si = typeof FormData < "u" ? FormData : null,
    li = typeof Blob < "u" ? Blob : null,
    ui = {
        isBrowser: !0,
        classes: {
            URLSearchParams: oi,
            FormData: si,
            Blob: li
        },
        protocols: ["http", "https", "file", "blob", "url", "data"]
    },
    Ft = typeof window < "u" && typeof document < "u",
    Bt = typeof navigator == "object" && navigator || void 0,
    di = Ft && (!Bt || ["ReactNative", "NativeScript", "NS"].indexOf(Bt.product) < 0),
    ci = typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope && typeof self.importScripts == "function",
    mi = Ft && window.location.href || "http://localhost",
    fi = Object.freeze(Object.defineProperty({
        __proto__: null,
        hasBrowserEnv: Ft,
        hasStandardBrowserEnv: di,
        hasStandardBrowserWebWorkerEnv: ci,
        navigator: Bt,
        origin: mi
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    J = { ...fi,
        ...ui
    };

function hi(t, e) {
    return lt(t, new J.classes.URLSearchParams, {
        visitor: function(r, a, o, u) {
            return J.isNode && f.isBuffer(r) ? (this.append(a, r.toString("base64")), !1) : u.defaultVisitor.apply(this, arguments)
        },
        ...e
    })
}

function xi(t) {
    return f.matchAll(/\w+|\[(\w*)]/g, t).map(e => e[0] === "[]" ? "" : e[1] || e[0])
}

function pi(t) {
    const e = {},
        r = Object.keys(t);
    let a;
    const o = r.length;
    let u;
    for (a = 0; a < o; a++) u = r[a], e[u] = t[u];
    return e
}

function Hn(t) {
    function e(r, a, o, u) {
        let l = r[u++];
        if (l === "__proto__") return !0;
        const d = Number.isFinite(+l),
            y = u >= r.length;
        return l = !l && f.isArray(o) ? o.length : l, y ? (f.hasOwnProp(o, l) ? o[l] = [o[l], a] : o[l] = a, !d) : ((!o[l] || !f.isObject(o[l])) && (o[l] = []), e(r, a, o[l], u) && f.isArray(o[l]) && (o[l] = pi(o[l])), !d)
    }
    if (f.isFormData(t) && f.isFunction(t.entries)) {
        const r = {};
        return f.forEachEntry(t, (a, o) => {
            e(xi(a), o, r, 0)
        }), r
    }
    return null
}

function yi(t, e, r) {
    if (f.isString(t)) try {
        return (e || JSON.parse)(t), f.trim(t)
    } catch (a) {
        if (a.name !== "SyntaxError") throw a
    }
    return (r || JSON.stringify)(t)
}
const je = {
    transitional: En,
    adapter: ["xhr", "http", "fetch"],
    transformRequest: [function(e, r) {
        const a = r.getContentType() || "",
            o = a.indexOf("application/json") > -1,
            u = f.isObject(e);
        if (u && f.isHTMLForm(e) && (e = new FormData(e)), f.isFormData(e)) return o ? JSON.stringify(Hn(e)) : e;
        if (f.isArrayBuffer(e) || f.isBuffer(e) || f.isStream(e) || f.isFile(e) || f.isBlob(e) || f.isReadableStream(e)) return e;
        if (f.isArrayBufferView(e)) return e.buffer;
        if (f.isURLSearchParams(e)) return r.setContentType("application/x-www-form-urlencoded;charset=utf-8", !1), e.toString();
        let d;
        if (u) {
            if (a.indexOf("application/x-www-form-urlencoded") > -1) return hi(e, this.formSerializer).toString();
            if ((d = f.isFileList(e)) || a.indexOf("multipart/form-data") > -1) {
                const y = this.env && this.env.FormData;
                return lt(d ? {
                    "files[]": e
                } : e, y && new y, this.formSerializer)
            }
        }
        return u || o ? (r.setContentType("application/json", !1), yi(e)) : e
    }],
    transformResponse: [function(e) {
        const r = this.transitional || je.transitional,
            a = r && r.forcedJSONParsing,
            o = this.responseType === "json";
        if (f.isResponse(e) || f.isReadableStream(e)) return e;
        if (e && f.isString(e) && (a && !this.responseType || o)) {
            const l = !(r && r.silentJSONParsing) && o;
            try {
                return JSON.parse(e, this.parseReviver)
            } catch (d) {
                if (l) throw d.name === "SyntaxError" ? W.from(d, W.ERR_BAD_RESPONSE, this, null, this.response) : d
            }
        }
        return e
    }],
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
        FormData: J.classes.FormData,
        Blob: J.classes.Blob
    },
    validateStatus: function(e) {
        return e >= 200 && e < 300
    },
    headers: {
        common: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": void 0
        }
    }
};
f.forEach(["delete", "get", "head", "post", "put", "patch"], t => {
    je.headers[t] = {}
});
const wi = f.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]),
    bi = t => {
        const e = {};
        let r, a, o;
        return t && t.split(`
`).forEach(function(l) {
            o = l.indexOf(":"), r = l.substring(0, o).trim().toLowerCase(), a = l.substring(o + 1).trim(), !(!r || e[r] && wi[r]) && (r === "set-cookie" ? e[r] ? e[r].push(a) : e[r] = [a] : e[r] = e[r] ? e[r] + ", " + a : a)
        }), e
    },
    Gt = Symbol("internals");

function De(t) {
    return t && String(t).trim().toLowerCase()
}

function Qe(t) {
    return t === !1 || t == null ? t : f.isArray(t) ? t.map(Qe) : String(t)
}

function gi(t) {
    const e = Object.create(null),
        r = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let a;
    for (; a = r.exec(t);) e[a[1]] = a[2];
    return e
}
const Ti = t => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(t.trim());

function yt(t, e, r, a, o) {
    if (f.isFunction(a)) return a.call(this, e, r);
    if (o && (e = r), !!f.isString(e)) {
        if (f.isString(a)) return e.indexOf(a) !== -1;
        if (f.isRegExp(a)) return a.test(e)
    }
}

function Ci(t) {
    return t.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (e, r, a) => r.toUpperCase() + a)
}

function Ei(t, e) {
    const r = f.toCamelCase(" " + e);
    ["get", "set", "has"].forEach(a => {
        Object.defineProperty(t, a + r, {
            value: function(o, u, l) {
                return this[a].call(this, e, o, u, l)
            },
            configurable: !0
        })
    })
}
let Y = class {
    constructor(e) {
        e && this.set(e)
    }
    set(e, r, a) {
        const o = this;

        function u(d, y, x) {
            const p = De(y);
            if (!p) throw new Error("header name must be a non-empty string");
            const C = f.findKey(o, p);
            (!C || o[C] === void 0 || x === !0 || x === void 0 && o[C] !== !1) && (o[C || y] = Qe(d))
        }
        const l = (d, y) => f.forEach(d, (x, p) => u(x, p, y));
        if (f.isPlainObject(e) || e instanceof this.constructor) l(e, r);
        else if (f.isString(e) && (e = e.trim()) && !Ti(e)) l(bi(e), r);
        else if (f.isObject(e) && f.isIterable(e)) {
            let d = {},
                y, x;
            for (const p of e) {
                if (!f.isArray(p)) throw TypeError("Object iterator must return a key-value pair");
                d[x = p[0]] = (y = d[x]) ? f.isArray(y) ? [...y, p[1]] : [y, p[1]] : p[1]
            }
            l(d, r)
        } else e != null && u(r, e, a);
        return this
    }
    get(e, r) {
        if (e = De(e), e) {
            const a = f.findKey(this, e);
            if (a) {
                const o = this[a];
                if (!r) return o;
                if (r === !0) return gi(o);
                if (f.isFunction(r)) return r.call(this, o, a);
                if (f.isRegExp(r)) return r.exec(o);
                throw new TypeError("parser must be boolean|regexp|function")
            }
        }
    }
    has(e, r) {
        if (e = De(e), e) {
            const a = f.findKey(this, e);
            return !!(a && this[a] !== void 0 && (!r || yt(this, this[a], a, r)))
        }
        return !1
    }
    delete(e, r) {
        const a = this;
        let o = !1;

        function u(l) {
            if (l = De(l), l) {
                const d = f.findKey(a, l);
                d && (!r || yt(a, a[d], d, r)) && (delete a[d], o = !0)
            }
        }
        return f.isArray(e) ? e.forEach(u) : u(e), o
    }
    clear(e) {
        const r = Object.keys(this);
        let a = r.length,
            o = !1;
        for (; a--;) {
            const u = r[a];
            (!e || yt(this, this[u], u, e, !0)) && (delete this[u], o = !0)
        }
        return o
    }
    normalize(e) {
        const r = this,
            a = {};
        return f.forEach(this, (o, u) => {
            const l = f.findKey(a, u);
            if (l) {
                r[l] = Qe(o), delete r[u];
                return
            }
            const d = e ? Ci(u) : String(u).trim();
            d !== u && delete r[u], r[d] = Qe(o), a[d] = !0
        }), this
    }
    concat(...e) {
        return this.constructor.concat(this, ...e)
    }
    toJSON(e) {
        const r = Object.create(null);
        return f.forEach(this, (a, o) => {
            a != null && a !== !1 && (r[o] = e && f.isArray(a) ? a.join(", ") : a)
        }), r
    }[Symbol.iterator]() {
        return Object.entries(this.toJSON())[Symbol.iterator]()
    }
    toString() {
        return Object.entries(this.toJSON()).map(([e, r]) => e + ": " + r).join(`
`)
    }
    getSetCookie() {
        return this.get("set-cookie") || []
    }
    get[Symbol.toStringTag]() {
        return "AxiosHeaders"
    }
    static from(e) {
        return e instanceof this ? e : new this(e)
    }
    static concat(e, ...r) {
        const a = new this(e);
        return r.forEach(o => a.set(o)), a
    }
    static accessor(e) {
        const a = (this[Gt] = this[Gt] = {
                accessors: {}
            }).accessors,
            o = this.prototype;

        function u(l) {
            const d = De(l);
            a[d] || (Ei(o, l), a[d] = !0)
        }
        return f.isArray(e) ? e.forEach(u) : u(e), this
    }
};
Y.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
f.reduceDescriptors(Y.prototype, ({
    value: t
}, e) => {
    let r = e[0].toUpperCase() + e.slice(1);
    return {
        get: () => t,
        set(a) {
            this[r] = a
        }
    }
});
f.freezeMethods(Y);

function wt(t, e) {
    const r = this || je,
        a = e || r,
        o = Y.from(a.headers);
    let u = a.data;
    return f.forEach(t, function(d) {
        u = d.call(r, u, o.normalize(), e ? e.status : void 0)
    }), o.normalize(), u
}

function Bn(t) {
    return !!(t && t.__CANCEL__)
}

function Pe(t, e, r) {
    W.call(this, t ? ? "canceled", W.ERR_CANCELED, e, r), this.name = "CanceledError"
}
f.inherits(Pe, W, {
    __CANCEL__: !0
});

function Sn(t, e, r) {
    const a = r.config.validateStatus;
    !r.status || !a || a(r.status) ? t(r) : e(new W("Request failed with status code " + r.status, [W.ERR_BAD_REQUEST, W.ERR_BAD_RESPONSE][Math.floor(r.status / 100) - 4], r.config, r.request, r))
}

function Hi(t) {
    const e = /^([-+\w]{1,25})(:?\/\/|:)/.exec(t);
    return e && e[1] || ""
}

function Bi(t, e) {
    t = t || 10;
    const r = new Array(t),
        a = new Array(t);
    let o = 0,
        u = 0,
        l;
    return e = e !== void 0 ? e : 1e3,
        function(y) {
            const x = Date.now(),
                p = a[u];
            l || (l = x), r[o] = y, a[o] = x;
            let C = u,
                S = 0;
            for (; C !== o;) S += r[C++], C = C % t;
            if (o = (o + 1) % t, o === u && (u = (u + 1) % t), x - l < e) return;
            const F = p && x - p;
            return F ? Math.round(S * 1e3 / F) : void 0
        }
}

function Si(t, e) {
    let r = 0,
        a = 1e3 / e,
        o, u;
    const l = (x, p = Date.now()) => {
        r = p, o = null, u && (clearTimeout(u), u = null), t(...x)
    };
    return [(...x) => {
        const p = Date.now(),
            C = p - r;
        C >= a ? l(x, p) : (o = x, u || (u = setTimeout(() => {
            u = null, l(o)
        }, a - C)))
    }, () => o && l(o)]
}
const Ze = (t, e, r = 3) => {
        let a = 0;
        const o = Bi(50, 250);
        return Si(u => {
            const l = u.loaded,
                d = u.lengthComputable ? u.total : void 0,
                y = l - a,
                x = o(y),
                p = l <= d;
            a = l;
            const C = {
                loaded: l,
                total: d,
                progress: d ? l / d : void 0,
                bytes: y,
                rate: x || void 0,
                estimated: x && d && p ? (d - l) / x : void 0,
                event: u,
                lengthComputable: d != null,
                [e ? "download" : "upload"]: !0
            };
            t(C)
        }, r)
    },
    Jt = (t, e) => {
        const r = t != null;
        return [a => e[0]({
            lengthComputable: r,
            total: t,
            loaded: a
        }), e[1]]
    },
    Kt = t => (...e) => f.asap(() => t(...e)),
    Wi = J.hasStandardBrowserEnv ? ((t, e) => r => (r = new URL(r, J.origin), t.protocol === r.protocol && t.host === r.host && (e || t.port === r.port)))(new URL(J.origin), J.navigator && /(msie|trident)/i.test(J.navigator.userAgent)) : () => !0,
    Ri = J.hasStandardBrowserEnv ? {
        write(t, e, r, a, o, u, l) {
            if (typeof document > "u") return;
            const d = [`${t}=${encodeURIComponent(e)}`];
            f.isNumber(r) && d.push(`expires=${new Date(r).toUTCString()}`), f.isString(a) && d.push(`path=${a}`), f.isString(o) && d.push(`domain=${o}`), u === !0 && d.push("secure"), f.isString(l) && d.push(`SameSite=${l}`), document.cookie = d.join("; ")
        },
        read(t) {
            if (typeof document > "u") return null;
            const e = document.cookie.match(new RegExp("(?:^|; )" + t + "=([^;]*)"));
            return e ? decodeURIComponent(e[1]) : null
        },
        remove(t) {
            this.write(t, "", Date.now() - 864e5, "/")
        }
    } : {
        write() {},
        read() {
            return null
        },
        remove() {}
    };

function Ai(t) {
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(t)
}

function vi(t, e) {
    return e ? t.replace(/\/?\/$/, "") + "/" + e.replace(/^\/+/, "") : t
}

function Wn(t, e, r) {
    let a = !Ai(e);
    return t && (a || r == !1) ? vi(t, e) : e
}
const Qt = t => t instanceof Y ? { ...t
} : t;

function Ee(t, e) {
    e = e || {};
    const r = {};

    function a(x, p, C, S) {
        return f.isPlainObject(x) && f.isPlainObject(p) ? f.merge.call({
            caseless: S
        }, x, p) : f.isPlainObject(p) ? f.merge({}, p) : f.isArray(p) ? p.slice() : p
    }

    function o(x, p, C, S) {
        if (f.isUndefined(p)) {
            if (!f.isUndefined(x)) return a(void 0, x, C, S)
        } else return a(x, p, C, S)
    }

    function u(x, p) {
        if (!f.isUndefined(p)) return a(void 0, p)
    }

    function l(x, p) {
        if (f.isUndefined(p)) {
            if (!f.isUndefined(x)) return a(void 0, x)
        } else return a(void 0, p)
    }

    function d(x, p, C) {
        if (C in e) return a(x, p);
        if (C in t) return a(void 0, x)
    }
    const y = {
        url: u,
        method: u,
        data: u,
        baseURL: l,
        transformRequest: l,
        transformResponse: l,
        paramsSerializer: l,
        timeout: l,
        timeoutMessage: l,
        withCredentials: l,
        withXSRFToken: l,
        adapter: l,
        responseType: l,
        xsrfCookieName: l,
        xsrfHeaderName: l,
        onUploadProgress: l,
        onDownloadProgress: l,
        decompress: l,
        maxContentLength: l,
        maxBodyLength: l,
        beforeRedirect: l,
        transport: l,
        httpAgent: l,
        httpsAgent: l,
        cancelToken: l,
        socketPath: l,
        responseEncoding: l,
        validateStatus: d,
        headers: (x, p, C) => o(Qt(x), Qt(p), C, !0)
    };
    return f.forEach(Object.keys({ ...t,
        ...e
    }), function(p) {
        const C = y[p] || o,
            S = C(t[p], e[p], p);
        f.isUndefined(S) && C !== d || (r[p] = S)
    }), r
}
const Rn = t => {
        const e = Ee({}, t);
        let {
            data: r,
            withXSRFToken: a,
            xsrfHeaderName: o,
            xsrfCookieName: u,
            headers: l,
            auth: d
        } = e;
        if (e.headers = l = Y.from(l), e.url = Cn(Wn(e.baseURL, e.url, e.allowAbsoluteUrls), t.params, t.paramsSerializer), d && l.set("Authorization", "Basic " + btoa((d.username || "") + ":" + (d.password ? unescape(encodeURIComponent(d.password)) : ""))), f.isFormData(r)) {
            if (J.hasStandardBrowserEnv || J.hasStandardBrowserWebWorkerEnv) l.setContentType(void 0);
            else if (f.isFunction(r.getHeaders)) {
                const y = r.getHeaders(),
                    x = ["content-type", "content-length"];
                Object.entries(y).forEach(([p, C]) => {
                    x.includes(p.toLowerCase()) && l.set(p, C)
                })
            }
        }
        if (J.hasStandardBrowserEnv && (a && f.isFunction(a) && (a = a(e)), a || a !== !1 && Wi(e.url))) {
            const y = o && u && Ri.read(u);
            y && l.set(o, y)
        }
        return e
    },
    ki = typeof XMLHttpRequest < "u",
    Fi = ki && function(t) {
        return new Promise(function(r, a) {
            const o = Rn(t);
            let u = o.data;
            const l = Y.from(o.headers).normalize();
            let {
                responseType: d,
                onUploadProgress: y,
                onDownloadProgress: x
            } = o, p, C, S, F, g;

            function H() {
                F && F(), g && g(), o.cancelToken && o.cancelToken.unsubscribe(p), o.signal && o.signal.removeEventListener("abort", p)
            }
            let E = new XMLHttpRequest;
            E.open(o.method.toUpperCase(), o.url, !0), E.timeout = o.timeout;

            function N() {
                if (!E) return;
                const q = Y.from("getAllResponseHeaders" in E && E.getAllResponseHeaders()),
                    z = {
                        data: !d || d === "text" || d === "json" ? E.responseText : E.response,
                        status: E.status,
                        statusText: E.statusText,
                        headers: q,
                        config: t,
                        request: E
                    };
                Sn(function(K) {
                    r(K), H()
                }, function(K) {
                    a(K), H()
                }, z), E = null
            }
            "onloadend" in E ? E.onloadend = N : E.onreadystatechange = function() {
                !E || E.readyState !== 4 || E.status === 0 && !(E.responseURL && E.responseURL.indexOf("file:") === 0) || setTimeout(N)
            }, E.onabort = function() {
                E && (a(new W("Request aborted", W.ECONNABORTED, t, E)), E = null)
            }, E.onerror = function(G) {
                const z = G && G.message ? G.message : "Network Error",
                    oe = new W(z, W.ERR_NETWORK, t, E);
                oe.event = G || null, a(oe), E = null
            }, E.ontimeout = function() {
                let G = o.timeout ? "timeout of " + o.timeout + "ms exceeded" : "timeout exceeded";
                const z = o.transitional || En;
                o.timeoutErrorMessage && (G = o.timeoutErrorMessage), a(new W(G, z.clarifyTimeoutError ? W.ETIMEDOUT : W.ECONNABORTED, t, E)), E = null
            }, u === void 0 && l.setContentType(null), "setRequestHeader" in E && f.forEach(l.toJSON(), function(G, z) {
                E.setRequestHeader(z, G)
            }), f.isUndefined(o.withCredentials) || (E.withCredentials = !!o.withCredentials), d && d !== "json" && (E.responseType = o.responseType), x && ([S, g] = Ze(x, !0), E.addEventListener("progress", S)), y && E.upload && ([C, F] = Ze(y), E.upload.addEventListener("progress", C), E.upload.addEventListener("loadend", F)), (o.cancelToken || o.signal) && (p = q => {
                E && (a(!q || q.type ? new Pe(null, t, E) : q), E.abort(), E = null)
            }, o.cancelToken && o.cancelToken.subscribe(p), o.signal && (o.signal.aborted ? p() : o.signal.addEventListener("abort", p)));
            const X = Hi(o.url);
            if (X && J.protocols.indexOf(X) === -1) {
                a(new W("Unsupported protocol " + X + ":", W.ERR_BAD_REQUEST, t));
                return
            }
            E.send(u || null)
        })
    },
    Pi = (t, e) => {
        const {
            length: r
        } = t = t ? t.filter(Boolean) : [];
        if (e || r) {
            let a = new AbortController,
                o;
            const u = function(x) {
                if (!o) {
                    o = !0, d();
                    const p = x instanceof Error ? x : this.reason;
                    a.abort(p instanceof W ? p : new Pe(p instanceof Error ? p.message : p))
                }
            };
            let l = e && setTimeout(() => {
                l = null, u(new W(`timeout ${e} of ms exceeded`, W.ETIMEDOUT))
            }, e);
            const d = () => {
                t && (l && clearTimeout(l), l = null, t.forEach(x => {
                    x.unsubscribe ? x.unsubscribe(u) : x.removeEventListener("abort", u)
                }), t = null)
            };
            t.forEach(x => x.addEventListener("abort", u));
            const {
                signal: y
            } = a;
            return y.unsubscribe = () => f.asap(d), y
        }
    },
    Oi = function*(t, e) {
        let r = t.byteLength;
        if (r < e) {
            yield t;
            return
        }
        let a = 0,
            o;
        for (; a < r;) o = a + e, yield t.slice(a, o), a = o
    },
    Ui = async function*(t, e) {
        for await (const r of Ii(t)) yield* Oi(r, e)
    },
    Ii = async function*(t) {
        if (t[Symbol.asyncIterator]) {
            yield* t;
            return
        }
        const e = t.getReader();
        try {
            for (;;) {
                const {
                    done: r,
                    value: a
                } = await e.read();
                if (r) break;
                yield a
            }
        } finally {
            await e.cancel()
        }
    },
    Xt = (t, e, r, a) => {
        const o = Ui(t, e);
        let u = 0,
            l, d = y => {
                l || (l = !0, a && a(y))
            };
        return new ReadableStream({
            async pull(y) {
                try {
                    const {
                        done: x,
                        value: p
                    } = await o.next();
                    if (x) {
                        d(), y.close();
                        return
                    }
                    let C = p.byteLength;
                    if (r) {
                        let S = u += C;
                        r(S)
                    }
                    y.enqueue(new Uint8Array(p))
                } catch (x) {
                    throw d(x), x
                }
            },
            cancel(y) {
                return d(y), o.return()
            }
        }, {
            highWaterMark: 2
        })
    },
    Zt = 64 * 1024,
    {
        isFunction: Je
    } = f,
    Ni = (({
        Request: t,
        Response: e
    }) => ({
        Request: t,
        Response: e
    }))(f.global),
    {
        ReadableStream: Yt,
        TextEncoder: en
    } = f.global,
    tn = (t, ...e) => {
        try {
            return !!t(...e)
        } catch {
            return !1
        }
    },
    Di = t => {
        t = f.merge.call({
            skipUndefined: !0
        }, Ni, t);
        const {
            fetch: e,
            Request: r,
            Response: a
        } = t, o = e ? Je(e) : typeof fetch == "function", u = Je(r), l = Je(a);
        if (!o) return !1;
        const d = o && Je(Yt),
            y = o && (typeof en == "function" ? (g => H => g.encode(H))(new en) : async g => new Uint8Array(await new r(g).arrayBuffer())),
            x = u && d && tn(() => {
                let g = !1;
                const H = new r(J.origin, {
                    body: new Yt,
                    method: "POST",
                    get duplex() {
                        return g = !0, "half"
                    }
                }).headers.has("Content-Type");
                return g && !H
            }),
            p = l && d && tn(() => f.isReadableStream(new a("").body)),
            C = {
                stream: p && (g => g.body)
            };
        o && ["text", "arrayBuffer", "blob", "formData", "stream"].forEach(g => {
            !C[g] && (C[g] = (H, E) => {
                let N = H && H[g];
                if (N) return N.call(H);
                throw new W(`Response type '${g}' is not supported`, W.ERR_NOT_SUPPORT, E)
            })
        });
        const S = async g => {
                if (g == null) return 0;
                if (f.isBlob(g)) return g.size;
                if (f.isSpecCompliantForm(g)) return (await new r(J.origin, {
                    method: "POST",
                    body: g
                }).arrayBuffer()).byteLength;
                if (f.isArrayBufferView(g) || f.isArrayBuffer(g)) return g.byteLength;
                if (f.isURLSearchParams(g) && (g = g + ""), f.isString(g)) return (await y(g)).byteLength
            },
            F = async (g, H) => {
                const E = f.toFiniteNumber(g.getContentLength());
                return E ? ? S(H)
            };
        return async g => {
            let {
                url: H,
                method: E,
                data: N,
                signal: X,
                cancelToken: q,
                timeout: G,
                onDownloadProgress: z,
                onUploadProgress: oe,
                responseType: K,
                headers: Oe,
                withCredentials: He = "same-origin",
                fetchOptions: ze
            } = Rn(g), Ve = e || fetch;
            K = K ? (K + "").toLowerCase() : "text";
            let Be = Pi([X, q && q.toAbortSignal()], G),
                we = null;
            const se = Be && Be.unsubscribe && (() => {
                Be.unsubscribe()
            });
            let Ue;
            try {
                if (oe && x && E !== "get" && E !== "head" && (Ue = await F(Oe, N)) !== 0) {
                    let P = new r(H, {
                            method: "POST",
                            body: N,
                            duplex: "half"
                        }),
                        j;
                    if (f.isFormData(N) && (j = P.headers.get("content-type")) && Oe.setContentType(j), P.body) {
                        const [Se, be] = Jt(Ue, Ze(Kt(oe)));
                        N = Xt(P.body, Zt, Se, be)
                    }
                }
                f.isString(He) || (He = He ? "include" : "omit");
                const re = u && "credentials" in r.prototype,
                    _e = { ...ze,
                        signal: Be,
                        method: E.toUpperCase(),
                        headers: Oe.normalize().toJSON(),
                        body: N,
                        duplex: "half",
                        credentials: re ? He : void 0
                    };
                we = u && new r(H, _e);
                let le = await (u ? Ve(we, ze) : Ve(H, _e));
                const $e = p && (K === "stream" || K === "response");
                if (p && (z || $e && se)) {
                    const P = {};
                    ["status", "statusText", "headers"].forEach(Ie => {
                        P[Ie] = le[Ie]
                    });
                    const j = f.toFiniteNumber(le.headers.get("content-length")),
                        [Se, be] = z && Jt(j, Ze(Kt(z), !0)) || [];
                    le = new a(Xt(le.body, Zt, Se, () => {
                        be && be(), se && se()
                    }), P)
                }
                K = K || "text";
                let dt = await C[f.findKey(C, K) || "text"](le, g);
                return !$e && se && se(), await new Promise((P, j) => {
                    Sn(P, j, {
                        data: dt,
                        headers: Y.from(le.headers),
                        status: le.status,
                        statusText: le.statusText,
                        config: g,
                        request: we
                    })
                })
            } catch (re) {
                throw se && se(), re && re.name === "TypeError" && /Load failed|fetch/i.test(re.message) ? Object.assign(new W("Network Error", W.ERR_NETWORK, g, we), {
                    cause: re.cause || re
                }) : W.from(re, re && re.code, g, we)
            }
        }
    },
    Li = new Map,
    An = t => {
        let e = t && t.env || {};
        const {
            fetch: r,
            Request: a,
            Response: o
        } = e, u = [a, o, r];
        let l = u.length,
            d = l,
            y, x, p = Li;
        for (; d--;) y = u[d], x = p.get(y), x === void 0 && p.set(y, x = d ? new Map : Di(e)), p = x;
        return x
    };
An();
const Pt = {
    http: ni,
    xhr: Fi,
    fetch: {
        get: An
    }
};
f.forEach(Pt, (t, e) => {
    if (t) {
        try {
            Object.defineProperty(t, "name", {
                value: e
            })
        } catch {}
        Object.defineProperty(t, "adapterName", {
            value: e
        })
    }
});
const nn = t => `- ${t}`,
    Mi = t => f.isFunction(t) || t === null || t === !1;

function qi(t, e) {
    t = f.isArray(t) ? t : [t];
    const {
        length: r
    } = t;
    let a, o;
    const u = {};
    for (let l = 0; l < r; l++) {
        a = t[l];
        let d;
        if (o = a, !Mi(a) && (o = Pt[(d = String(a)).toLowerCase()], o === void 0)) throw new W(`Unknown adapter '${d}'`);
        if (o && (f.isFunction(o) || (o = o.get(e)))) break;
        u[d || "#" + l] = o
    }
    if (!o) {
        const l = Object.entries(u).map(([y, x]) => `adapter ${y} ` + (x === !1 ? "is not supported by the environment" : "is not available in the build"));
        let d = r ? l.length > 1 ? `since :
` + l.map(nn).join(`
`) : " " + nn(l[0]) : "as no adapter specified";
        throw new W("There is no suitable adapter to dispatch the request " + d, "ERR_NOT_SUPPORT")
    }
    return o
}
const vn = {
    getAdapter: qi,
    adapters: Pt
};

function bt(t) {
    if (t.cancelToken && t.cancelToken.throwIfRequested(), t.signal && t.signal.aborted) throw new Pe(null, t)
}

function rn(t) {
    return bt(t), t.headers = Y.from(t.headers), t.data = wt.call(t, t.transformRequest), ["post", "put", "patch"].indexOf(t.method) !== -1 && t.headers.setContentType("application/x-www-form-urlencoded", !1), vn.getAdapter(t.adapter || je.adapter, t)(t).then(function(a) {
        return bt(t), a.data = wt.call(t, t.transformResponse, a), a.headers = Y.from(a.headers), a
    }, function(a) {
        return Bn(a) || (bt(t), a && a.response && (a.response.data = wt.call(t, t.transformResponse, a.response), a.response.headers = Y.from(a.response.headers))), Promise.reject(a)
    })
}
const kn = "1.13.2",
    ut = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach((t, e) => {
    ut[t] = function(a) {
        return typeof a === t || "a" + (e < 1 ? "n " : " ") + t
    }
});
const an = {};
ut.transitional = function(e, r, a) {
    function o(u, l) {
        return "[Axios v" + kn + "] Transitional option '" + u + "'" + l + (a ? ". " + a : "")
    }
    return (u, l, d) => {
        if (e === !1) throw new W(o(l, " has been removed" + (r ? " in " + r : "")), W.ERR_DEPRECATED);
        return r && !an[l] && (an[l] = !0, console.warn(o(l, " has been deprecated since v" + r + " and will be removed in the near future"))), e ? e(u, l, d) : !0
    }
};
ut.spelling = function(e) {
    return (r, a) => (console.warn(`${a} is likely a misspelling of ${e}`), !0)
};

function ji(t, e, r) {
    if (typeof t != "object") throw new W("options must be an object", W.ERR_BAD_OPTION_VALUE);
    const a = Object.keys(t);
    let o = a.length;
    for (; o-- > 0;) {
        const u = a[o],
            l = e[u];
        if (l) {
            const d = t[u],
                y = d === void 0 || l(d, u, t);
            if (y !== !0) throw new W("option " + u + " must be " + y, W.ERR_BAD_OPTION_VALUE);
            continue
        }
        if (r !== !0) throw new W("Unknown option " + u, W.ERR_BAD_OPTION)
    }
}
const Xe = {
        assertOptions: ji,
        validators: ut
    },
    de = Xe.validators;
let Ce = class {
    constructor(e) {
        this.defaults = e || {}, this.interceptors = {
            request: new $t,
            response: new $t
        }
    }
    async request(e, r) {
        try {
            return await this._request(e, r)
        } catch (a) {
            if (a instanceof Error) {
                let o = {};
                Error.captureStackTrace ? Error.captureStackTrace(o) : o = new Error;
                const u = o.stack ? o.stack.replace(/^.+\n/, "") : "";
                try {
                    a.stack ? u && !String(a.stack).endsWith(u.replace(/^.+\n.+\n/, "")) && (a.stack += `
` + u) : a.stack = u
                } catch {}
            }
            throw a
        }
    }
    _request(e, r) {
        typeof e == "string" ? (r = r || {}, r.url = e) : r = e || {}, r = Ee(this.defaults, r);
        const {
            transitional: a,
            paramsSerializer: o,
            headers: u
        } = r;
        a !== void 0 && Xe.assertOptions(a, {
            silentJSONParsing: de.transitional(de.boolean),
            forcedJSONParsing: de.transitional(de.boolean),
            clarifyTimeoutError: de.transitional(de.boolean)
        }, !1), o != null && (f.isFunction(o) ? r.paramsSerializer = {
            serialize: o
        } : Xe.assertOptions(o, {
            encode: de.function,
            serialize: de.function
        }, !0)), r.allowAbsoluteUrls !== void 0 || (this.defaults.allowAbsoluteUrls !== void 0 ? r.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls : r.allowAbsoluteUrls = !0), Xe.assertOptions(r, {
            baseUrl: de.spelling("baseURL"),
            withXsrfToken: de.spelling("withXSRFToken")
        }, !0), r.method = (r.method || this.defaults.method || "get").toLowerCase();
        let l = u && f.merge(u.common, u[r.method]);
        u && f.forEach(["delete", "get", "head", "post", "put", "patch", "common"], g => {
            delete u[g]
        }), r.headers = Y.concat(l, u);
        const d = [];
        let y = !0;
        this.interceptors.request.forEach(function(H) {
            typeof H.runWhen == "function" && H.runWhen(r) === !1 || (y = y && H.synchronous, d.unshift(H.fulfilled, H.rejected))
        });
        const x = [];
        this.interceptors.response.forEach(function(H) {
            x.push(H.fulfilled, H.rejected)
        });
        let p, C = 0,
            S;
        if (!y) {
            const g = [rn.bind(this), void 0];
            for (g.unshift(...d), g.push(...x), S = g.length, p = Promise.resolve(r); C < S;) p = p.then(g[C++], g[C++]);
            return p
        }
        S = d.length;
        let F = r;
        for (; C < S;) {
            const g = d[C++],
                H = d[C++];
            try {
                F = g(F)
            } catch (E) {
                H.call(this, E);
                break
            }
        }
        try {
            p = rn.call(this, F)
        } catch (g) {
            return Promise.reject(g)
        }
        for (C = 0, S = x.length; C < S;) p = p.then(x[C++], x[C++]);
        return p
    }
    getUri(e) {
        e = Ee(this.defaults, e);
        const r = Wn(e.baseURL, e.url, e.allowAbsoluteUrls);
        return Cn(r, e.params, e.paramsSerializer)
    }
};
f.forEach(["delete", "get", "head", "options"], function(e) {
    Ce.prototype[e] = function(r, a) {
        return this.request(Ee(a || {}, {
            method: e,
            url: r,
            data: (a || {}).data
        }))
    }
});
f.forEach(["post", "put", "patch"], function(e) {
    function r(a) {
        return function(u, l, d) {
            return this.request(Ee(d || {}, {
                method: e,
                headers: a ? {
                    "Content-Type": "multipart/form-data"
                } : {},
                url: u,
                data: l
            }))
        }
    }
    Ce.prototype[e] = r(), Ce.prototype[e + "Form"] = r(!0)
});
let zi = class Fn {
    constructor(e) {
        if (typeof e != "function") throw new TypeError("executor must be a function.");
        let r;
        this.promise = new Promise(function(u) {
            r = u
        });
        const a = this;
        this.promise.then(o => {
            if (!a._listeners) return;
            let u = a._listeners.length;
            for (; u-- > 0;) a._listeners[u](o);
            a._listeners = null
        }), this.promise.then = o => {
            let u;
            const l = new Promise(d => {
                a.subscribe(d), u = d
            }).then(o);
            return l.cancel = function() {
                a.unsubscribe(u)
            }, l
        }, e(function(u, l, d) {
            a.reason || (a.reason = new Pe(u, l, d), r(a.reason))
        })
    }
    throwIfRequested() {
        if (this.reason) throw this.reason
    }
    subscribe(e) {
        if (this.reason) {
            e(this.reason);
            return
        }
        this._listeners ? this._listeners.push(e) : this._listeners = [e]
    }
    unsubscribe(e) {
        if (!this._listeners) return;
        const r = this._listeners.indexOf(e);
        r !== -1 && this._listeners.splice(r, 1)
    }
    toAbortSignal() {
        const e = new AbortController,
            r = a => {
                e.abort(a)
            };
        return this.subscribe(r), e.signal.unsubscribe = () => this.unsubscribe(r), e.signal
    }
    static source() {
        let e;
        return {
            token: new Fn(function(o) {
                e = o
            }),
            cancel: e
        }
    }
};

function Vi(t) {
    return function(r) {
        return t.apply(null, r)
    }
}

function _i(t) {
    return f.isObject(t) && t.isAxiosError === !0
}
const St = {
    Continue: 100,
    SwitchingProtocols: 101,
    Processing: 102,
    EarlyHints: 103,
    Ok: 200,
    Created: 201,
    Accepted: 202,
    NonAuthoritativeInformation: 203,
    NoContent: 204,
    ResetContent: 205,
    PartialContent: 206,
    MultiStatus: 207,
    AlreadyReported: 208,
    ImUsed: 226,
    MultipleChoices: 300,
    MovedPermanently: 301,
    Found: 302,
    SeeOther: 303,
    NotModified: 304,
    UseProxy: 305,
    Unused: 306,
    TemporaryRedirect: 307,
    PermanentRedirect: 308,
    BadRequest: 400,
    Unauthorized: 401,
    PaymentRequired: 402,
    Forbidden: 403,
    NotFound: 404,
    MethodNotAllowed: 405,
    NotAcceptable: 406,
    ProxyAuthenticationRequired: 407,
    RequestTimeout: 408,
    Conflict: 409,
    Gone: 410,
    LengthRequired: 411,
    PreconditionFailed: 412,
    PayloadTooLarge: 413,
    UriTooLong: 414,
    UnsupportedMediaType: 415,
    RangeNotSatisfiable: 416,
    ExpectationFailed: 417,
    ImATeapot: 418,
    MisdirectedRequest: 421,
    UnprocessableEntity: 422,
    Locked: 423,
    FailedDependency: 424,
    TooEarly: 425,
    UpgradeRequired: 426,
    PreconditionRequired: 428,
    TooManyRequests: 429,
    RequestHeaderFieldsTooLarge: 431,
    UnavailableForLegalReasons: 451,
    InternalServerError: 500,
    NotImplemented: 501,
    BadGateway: 502,
    ServiceUnavailable: 503,
    GatewayTimeout: 504,
    HttpVersionNotSupported: 505,
    VariantAlsoNegotiates: 506,
    InsufficientStorage: 507,
    LoopDetected: 508,
    NotExtended: 510,
    NetworkAuthenticationRequired: 511,
    WebServerIsDown: 521,
    ConnectionTimedOut: 522,
    OriginIsUnreachable: 523,
    TimeoutOccurred: 524,
    SslHandshakeFailed: 525,
    InvalidSslCertificate: 526
};
Object.entries(St).forEach(([t, e]) => {
    St[e] = t
});

function Pn(t) {
    const e = new Ce(t),
        r = dn(Ce.prototype.request, e);
    return f.extend(r, Ce.prototype, e, {
        allOwnKeys: !0
    }), f.extend(r, e, null, {
        allOwnKeys: !0
    }), r.create = function(o) {
        return Pn(Ee(t, o))
    }, r
}
const U = Pn(je);
U.Axios = Ce;
U.CanceledError = Pe;
U.CancelToken = zi;
U.isCancel = Bn;
U.VERSION = kn;
U.toFormData = lt;
U.AxiosError = W;
U.Cancel = U.CanceledError;
U.all = function(e) {
    return Promise.all(e)
};
U.spread = Vi;
U.isAxiosError = _i;
U.mergeConfig = Ee;
U.AxiosHeaders = Y;
U.formToJSON = t => Hn(f.isHTMLForm(t) ? new FormData(t) : t);
U.getAdapter = vn.getAdapter;
U.HttpStatusCode = St;
U.default = U;
const {
    Axios: Fa,
    AxiosError: Pa,
    CanceledError: Oa,
    isCancel: Ua,
    CancelToken: Ia,
    VERSION: Na,
    all: Da,
    Cancel: La,
    isAxiosError: Ma,
    spread: qa,
    toFormData: ja,
    AxiosHeaders: za,
    HttpStatusCode: Va,
    formToJSON: _a,
    getAdapter: $a,
    mergeConfig: Ga
} = U, xe = class xe {
    async get(e, r) {
        const a = await U.get(e, {
            headers: { ...xe.defaultHeaders,
                ...r
            }
        }).catch(o => o.response);
        return {
            statusCode: a.status,
            data: a.data
        }
    }
    async patch(e, r, a) {
        const o = await U.patch(e, r, {
            headers: { ...xe.defaultHeaders,
                ...a
            }
        }).catch(u => u.response);
        return {
            statusCode: o.status,
            data: o.data
        }
    }
    async put(e, r, a) {
        const o = await U.put(e, r, {
            headers: { ...xe.defaultHeaders,
                ...a
            }
        }).catch(u => u.response);
        return {
            statusCode: o.status,
            data: o.data
        }
    }
    async post(e, r, a) {
        const o = await U.post(e, r, {
            headers: { ...xe.defaultHeaders,
                ...a
            }
        }).catch(u => u.response);
        return {
            statusCode: o.status,
            data: o.data
        }
    }
    async delete(e, r, a) {
        const o = await U.delete(e, {
            data: r,
            headers: { ...xe.defaultHeaders,
                ...a
            }
        }).catch(u => u.response);
        return {
            statusCode: o.status,
            data: o.data
        }
    }
    resolve(e, r) {
        const a = r.startsWith("/") ? r.substring(1) : r;
        return e.endsWith("/") ? e + a : `${e}/${a}`
    }
};
b(xe, "defaultHeaders", {
    "Content-Type": "application/json",
    Accept: "application/json"
});
let Wt = xe;
const ge = new Wt;
class $i {
    async json(e) {
        return await (await fetch(e)).json()
    }
    async text(e) {
        return await (await fetch(e)).text()
    }
}
const Gi = new $i,
    pe = class pe {
        static async _baseUrl() {
            if (!this._cachedBaseUrl) {
                const e = await Gi.json("/config.json");
                this._cachedBaseUrl = e.backend_url_prod
            }
            return this._cachedBaseUrl
        }
        static async get(e, r) {
            return this.executeRequestWithTokenHandling("get", e, {}, r)
        }
        static async patch(e, r, a) {
            return this.executeRequestWithTokenHandling("patch", e, r, a)
        }
        static async put(e, r, a) {
            return this.executeRequestWithTokenHandling("put", e, r, a)
        }
        static async post(e, r, a) {
            return this.executeRequestWithTokenHandling("post", e, r, a)
        }
        static async delete(e, r, a) {
            return this.executeRequestWithTokenHandling("delete", e, r, a)
        }
        static async executeRequestWithTokenHandling(e, r, a, o) {
            let u = await this.handleHttpRequest(e, r, a, o);
            if (u.statusCode !== 401 || (u == null ? void 0 : u.data.reason) !== "Unauthorized") return u;
            const l = localStorage.getItem("user");
            if (!l || l === "null" || l === "undefined") return u;
            const d = JSON.parse(l),
                {
                    refreshToken: y
                } = d.authData;
            this.refreshTokenPromise || (this.refreshTokenPromise = this.refreshUserToken(y).finally(() => {
                this.refreshTokenPromise = null
            }));
            const x = await this.refreshTokenPromise;
            return x ? x && "statusCode" in x ? (await V.navigateTo("/sessao-expirada?title=Sess%C3%A3o%20expirada%20por%20excesso%20de%20conex%C3%B5es"), x) : (sn.update(p => p && { ...p,
                authData: { ...p.authData,
                    token: x.token
                }
            }), u = await this.handleHttpRequest(e, r, a, x), u) : u
        }
        static async handleHttpRequest(e, r, a, o) {
            const u = await pe._path(r),
                l = pe.getHeaders(o);
            switch (e) {
                case "get":
                    return ge.get(u, l);
                case "patch":
                    return ge.patch(u, a, l);
                case "put":
                    return ge.put(u, a, l);
                case "post":
                    return ge.post(u, a, l);
                case "delete":
                    return ge.delete(u, a, l);
                default:
                    throw new Error(`Unsupported request method: ${e}`)
            }
        }
        static async refreshUserToken(e) {
            var r;
            try {
                const a = await pe._path("/users/refresh-token"),
                    o = pe.getHeaders({
                        token: e
                    }),
                    u = await ge.post(a, {
                        token: e
                    }, o);
                return u.statusCode === 400 && ((r = u.data) == null ? void 0 : r.reason) === "REFRESH_TOKEN_NOT_FOUND" ? u : {
                    token: u.data.token
                }
            } catch {
                return null
            }
        }
        static getHeaders(e) {
            const r = {
                "Content-Type": "application/json; charset=UTF-8",
                Accept: "application/json"
            };
            if (e)
                if ("token" in e) {
                    const a = e;
                    r.Authorization = `Bearer ${a.token}`
                } else {
                    const a = e,
                        o = ln.Buffer.from(`${a.email}:${a.password}`, "utf8").toString("base64");
                    r.Authorization = `Basic ${o}`
                }
            return r
        }
        static async _path(e) {
            return `${ge.resolve(await this._baseUrl(),e)}`
        }
    };
b(pe, "_cachedBaseUrl", null), b(pe, "refreshTokenPromise", null);
let Rt = pe;
class Ji {
    static async execute(e) {
        var o;
        return (await Rt.post("/users/remove-refresh-token", {
            token: ((o = e.authData) == null ? void 0 : o.refreshToken) ? ? ""
        })).statusCode === 200 ? {
            status: "SUCCESS"
        } : {
            status: "UNKNOWN"
        }
    }
}
const Ki = function() {
        var t, e = window,
            r = document,
            a = r.head,
            o = {},
            u = !1,
            l = {
                parseMQ: function(x) {
                    return e.getComputedStyle(x, null).getPropertyValue("font-family").replace(/"/g, "").replace(/'/g, "")
                },
                debounce: function(x, p, C) {
                    var S;
                    return function() {
                        var F = this,
                            g = arguments;
                        clearTimeout(S), S = setTimeout(function() {
                            S = null, C || x.apply(F, g)
                        }, p), C && !S && x.apply(F, g)
                    }
                },
                isObject: function(x) {
                    return typeof x == "object"
                },
                isUndefined: function(x) {
                    return x === void 0
                }
            },
            d = {
                on: function(x, p) {
                    l.isObject(o[x]) || (o[x] = []), o[x].push(p)
                },
                emit: function(x, p) {
                    if (l.isObject(o[x]))
                        for (var C = o[x].slice(), S = 0; S < C.length; S++) C[S].call(this, p)
                }
            },
            y = {
                all: function() {
                    for (var x = {}, p = l.parseMQ(r.querySelector("title")).split(","), C = 0; C < p.length; C++) {
                        var S = p[C].trim().split(" ");
                        x[S[0]] = S[1]
                    }
                    return u ? x : null
                },
                now: function(x) {
                    var p = l.parseMQ(a).split(" "),
                        C = {
                            name: p[0],
                            width: p[1]
                        };
                    return u ? l.isUndefined(x) ? C : x(C) : null
                },
                update: function() {
                    y.now(function(x) {
                        x.name !== t && (d.emit(x.name), d.emit("change", x), t = x.name)
                    })
                }
            };
        return e.onresize = l.debounce(y.update, 100), r.addEventListener("DOMContentLoaded", function() {
            u = e.getComputedStyle(a, null).getPropertyValue("clear") !== "none", y.update()
        }), {
            fetch: {
                all: y.all,
                now: y.now
            },
            on: d.on,
            emit: d.emit,
            util: {
                debounce: l.debounce,
                isObject: l.isObject
            }
        }
    }(),
    Qi = function() {
        jQuery(".navigation").find("li").has("ul").addClass("has-sub")
    },
    Ja = function() {
        window.colors = {
                solid: {
                    primary: "#7367F0",
                    secondary: "#82868b",
                    success: "#28C76F",
                    info: "#00cfe8",
                    warning: "#FF9F43",
                    danger: "#EA5455",
                    dark: "#4b4b4b",
                    black: "#000",
                    white: "#fff",
                    body: "#f8f8f8"
                },
                light: {
                    primary: "#7367F01a",
                    secondary: "#82868b1a",
                    success: "#28C76F1a",
                    info: "#00cfe81a",
                    warning: "#FF9F431a",
                    danger: "#EA54551a",
                    dark: "#4b4b4b1a"
                }
            },
            function(t, e, r) {
                var a = r("html"),
                    o = r("body");
                r("body").attr("data-framework") === "laravel" && r("body").attr("data-asset-path"), r.fn.dataTable && r.extend(r.fn.dataTable.ext.classes, {
                    sFilterInput: "form-control",
                    sLengthSelect: "form-select"
                }), (() => {
                    var y = !1;
                    (o.hasClass("menu-collapsed") || localStorage.getItem("menuCollapsed") === "true") && (y = !0), r("html").data("textdirection") == "rtl", setTimeout(function() {
                        a.removeClass("loading").addClass("loaded")
                    }, 1200), r.app.menu.init(y);
                    var x = {
                        speed: 300
                    };
                    r.app.nav.initialized === !1 && r.app.nav.init(x), Ki.on("change", function(C) {
                        r.app.menu.change(y)
                    }), r(".main-menu-content").find("li.active").parents("li").addClass("sidebar-group-active");
                    var p = o.data("menu");
                    p != "horizontal-menu" && y === !1 && r(".main-menu-content").find("li.active").parents("li").addClass("open"), p == "horizontal-menu" && (r(".main-menu-content").find("li.active").parents("li:not(.nav-item)").addClass("open"), r(".main-menu-content").find("li.active").closest("li.nav-item").addClass("sidebar-group-active open"))
                })(), r(e).on("click", ".sidenav-overlay", function(y) {
                    return r.app.menu.hide(), !1
                }), Qi(), r("#sidebar-page-navigation").on("click", "a.nav-link", function(y) {
                    y.preventDefault(), y.stopPropagation();
                    var x = r(this),
                        p = x.attr("href"),
                        C = r(p).offset(),
                        S = C.top - 80;
                    r("html, body").animate({
                        scrollTop: S
                    }, 0), setTimeout(function() {
                        x.parent(".nav-item").siblings(".nav-item").children(".nav-link").removeClass("active"), x.addClass("active")
                    }, 100)
                });

                function l() {
                    var y = "";
                    return a.hasClass("dark-layout") ? y = "dark-layout" : a.hasClass("bordered-layout") ? y = "bordered-layout" : a.hasClass("semi-dark-layout") ? y = "semi-dark-layout" : y = "light-layout", y
                }
                var d = a.attr("data-layout") ? a.attr("data-layout") : "light-layout";
                r(".nav-link-style").on("click", function() {
                    var y = l(),
                        x = "",
                        p = localStorage.getItem(d + "-prev-skin", y);
                    y !== "dark-layout" ? x = "dark-layout" : y === p ? x = "light-layout" : x = p || "light-layout", localStorage.setItem(d + "-prev-skin", y), localStorage.setItem(d + "-current-skin", x), On(x), r(".horizontal-menu .header-navbar.navbar-fixed").css({
                        background: "inherit",
                        "box-shadow": "inherit"
                    }), r(".horizontal-menu .horizontal-menu-wrapper.header-navbar").css("background", "inherit")
                })
            }(window, document, jQuery)
    };

function On(t) {
    var e = $("html");
    $(".nav-link-style");
    var r = Xi(),
        a = $(".main-menu"),
        o = $(".header-navbar"),
        u = t || r;
    e.removeClass("semi-dark-layout dark-layout bordered-layout"), u === "dark-layout" ? (e.addClass("dark-layout"), a.removeClass("menu-light").addClass("menu-dark"), o.removeClass("navbar-light").addClass("navbar-dark")) : u === "bordered-layout" ? (e.addClass("bordered-layout"), a.removeClass("menu-dark").addClass("menu-light"), o.removeClass("navbar-dark").addClass("navbar-light")) : u === "semi-dark-layout" ? (e.addClass("semi-dark-layout"), a.removeClass("menu-dark").addClass("menu-light"), o.removeClass("navbar-dark").addClass("navbar-light")) : (e.addClass("light-layout"), a.removeClass("menu-dark").addClass("menu-light"), o.removeClass("navbar-dark").addClass("navbar-light")), $("input:radio[data-layout=" + u + "]").length > 0 && setTimeout(function() {
        $("input:radio[data-layout=" + u + "]").prop("checked", !0)
    })
}

function Xi() {
    var t = "",
        e = $("html");
    return e.hasClass("dark-layout") ? t = "dark-layout" : e.hasClass("bordered-layout") ? t = "bordered-layout" : e.hasClass("semi-dark-layout") ? t = "semi-dark-layout" : t = "light-layout", t
}
class Zi {
    static refreshVuexyTheme(e) {
        On(e === "Dark" ? "dark-layout" : "light-layout")
    }
}
const M = class M {
    static getAcceptInvite(e) {
        return `/convidado/${e}/accept`
    }
    static getRegisterByInvite(e) {
        return `/convidado/${e}/register`
    }
    static getLoginByInvite(e) {
        return `/convidado/${e}/login`
    }
    static getStart(e) {
        if (!e) return "/";
        const {
            dashboards: r
        } = e.user;
        return r.length > 0 ? `/dashboards/${r[0].id}/resumo` : "/minha-conta"
    }
    static summary(e) {
        return `/dashboards/${e}/resumo`
    }
    static campaigns(e) {
        return `/dashboards/${e}/campanhas`
    }
    static google(e) {
        return `/dashboards/${e}/google`
    }
    static kwai(e) {
        return `/dashboards/${e}/kwai`
    }
    static tikTok(e) {
        return `/dashboards/${e}/tiktok`
    }
    static investigate(e) {
        return `/dashboards/${e}/nao-trackeado`
    }
    static integrations(e) {
        return `/dashboards/${e}/integracoes`
    }
    static additionalValues(e) {
        return `/dashboards/${e}/valores-adicionais`
    }
    static customSpendings(e) {
        return `/dashboards/${e}/gastos`
    }
    static reports(e) {
        return `/dashboards/${e}/relatorios`
    }
    static utms(e) {
        return `/dashboards/${e}/utms`
    }
    static notifications(e) {
        return `/dashboards/${e}/notificacoes`
    }
    static rules(e) {
        return `/dashboards/${e}/regras`
    }
    static onboarding(e) {
        return `/dashboards/${e}/onboarding`
    }
    static current() {
        return M.removeTrailingSlash(window.location.pathname)
    }
    static equals(e, r) {
        return M.removeTrailingSlash(e) === M.removeTrailingSlash(r)
    }
    static includes(e, r) {
        return r.some(a => M.equals(a, e))
    }
    static removeTrailingSlash(e) {
        return e ? e === "/" ? e : e.replace(/\/$/, "") : ""
    }
};
b(M, "presentation", "/"), b(M, "pricing", "/precos"), b(M, "partners", "/parceiros"), b(M, "blog", "/blog"), b(M, "integrationsLanding", "/integracoes"), b(M, "login", "/login"), b(M, "register", "/register"), b(M, "subscription", "/assinatura"), b(M, "account", "/minha-conta"), b(M, "advanced", "/avancado"), b(M, "help", "/ajuda"), b(M, "app", "/aplicativo"), b(M, "affiliate", "/indique-e-ganhe"), b(M, "sessionExpired", "/sessao-expirada"), b(M, "queue", "/filas"), b(M, "news", "/novidades");
let he = M;
class V {
    static openWhatsApp(e, r) {
        window.open(V.getWhatsAppLink(e, r), "_blank")
    }
    static getWhatsAppLink(e, r) {
        return `https://wa.me/${r??"5524992281288"}?text=${encodeURIComponent(e)}`
    }
    static isLogged(e) {
        return e !== null
    }
    static openInNewTab(e) {
        window.open(e, "_blank")
    }
    static hasPageAccessFromDashboard(e, r, a) {
        var d;
        const o = this.getCurrentDashboard(r, a),
            u = jt(r).find(y => y.dashboard.id === (o == null ? void 0 : o.id));
        return ((d = u == null ? void 0 : u.access) == null ? void 0 : d[e]) ? ? !1
    }
    static navigateToAccessibleDashboard(e) {
        var o, u;
        const r = (u = (o = jt(e).find(l => {
            var d;
            return ((d = l == null ? void 0 : l.access) == null ? void 0 : d.resume) === !0
        })) == null ? void 0 : o.dashboard) == null ? void 0 : u.id;
        if (!r || typeof r != "string") return V.navigateToSessionExpired();
        const a = `/dashboards/${r}/resumo/`;
        return V.navigateTo(a)
    }
    static getCurrentDashboard(e, r) {
        var o;
        const a = V.getCurrentDashboardIndex(e, r);
        return a == null ? null : ((o = e == null ? void 0 : e.user) == null ? void 0 : o.dashboards[a]) ? ? null
    }
    static getCurrentDashboardIndex(e, r) {
        if (!e) return null;
        const a = r.params.dash_id,
            o = e.user.dashboards.findIndex(u => u.id === a);
        return o === -1 ? null : o
    }
    static addScriptToPage(e) {
        return new Promise((r, a) => {
            const o = document.createElement("script");
            o.setAttribute("src", e), o.onload = () => {
                console.log(`Script loaded successfully: ${e}`), r()
            }, o.onerror = () => {
                console.error(`Error loading script${e}`), a()
            }, document.body.appendChild(o)
        })
    }
    static getScriptElement(e) {
        return document.querySelector(`script[src="${e}"]`)
    }
    static scrollToTop() {
        window.focus(), window.scrollTo(0, 0)
    }
    static async assertNotNull(e, r = "/") {
        for (let a = 0; a < e.length; a++) e[a] == null && (await ht(), V.navigateTo(r))
    }
    static async assert(e, r = "/") {
        for (let a = 0; a < e.length; a++) e[a] || (await ht(), V.navigateTo(r))
    }
    static async assertConfirmedEmail(e) {
        var r;
        V.assert([(r = e == null ? void 0 : e.user) == null ? void 0 : r.confirmedEmail])
    }
    static async assertIsLogged(e) {
        if (e != null) {
            if (e) {
                await ht(), this.navigateTo("/home");
                return
            }
            this.logout()
        }
    }
    static back() {
        window.history.back()
    }
    static async navigateTo(e) {
        const r = `t=${+new Date}`,
            a = e.includes("?") ? `${e}&${r}` : `${e}?${r}`;
        await Vn(a), setTimeout(() => {
            V.scrollToTop()
        }, 0)
    }
    static navigateToSessionExpired() {
        V.navigateTo(he.sessionExpired)
    }
    static async navigateToStart(e) {
        const r = he.getStart(e);
        await V.navigateTo(r)
    }
    static async navigateToDashboard(e) {
        if (!e) {
            await V.navigateToStart(null);
            return
        }
        await V.navigateTo(he.summary(e.id))
    }
    static modifyQueryParams(e) {
        const r = window.location.origin + window.location.pathname + e.stringify();
        window.history.pushState({
            path: r
        }, "", r)
    }
    static navigateToLogin() {
        V.navigateTo(he.login)
    }
    static navigateToRegister() {
        V.navigateTo(he.register)
    }
    static copyToClipboard(e) {
        navigator.clipboard.writeText(e)
    }
    static async logout(e) {
        const r = e ? ? he.login,
            a = localStorage.getItem("user");
        if (a) {
            const o = JSON.parse(a);
            Ji.execute({
                authData: o.authData
            })
        }
        await V.navigateTo(r), Zi.refreshVuexyTheme(void 0), setTimeout(() => {
            V.resetLoggedStorage()
        }, 200)
    }
    static resetLoggedStorage() {
        sn.set(null)
    }
}
export {
    ba as $, A, ma as B, fa as C, ve as D, V as E, oa as F, sr as G, ga as H, Wa as I, Lt as J, er as K, R as L, Gi as M, v as N, la as O, ua as P, aa as Q, he as R, gt as S, Zi as T, Rt as U, ia as V, ya as W, on as X, ir as Y, da as Z, ar as _, Ji as a, qt as b, Tt as c, Mt as d, Ct as e, xa as f, Ra as g, or as h, pa as i, ha as j, wa as k, rr as l, Sa as m, Ki as n, jt as o, Qi as p, Ja as q, sa as r, Ta as s, Ca as t, sn as u, rt as v, Ea as w, Ha as x, Ba as y, ca as z
};