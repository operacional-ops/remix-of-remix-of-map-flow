import {
    K as s
} from "./DQmgr5XH.js";
import {
    U as k
} from "./B_DwLuOU.js";
import {
    a as A,
    d as _
} from "./DwsiLpv2.js";
import {
    g as q,
    f as D,
    b as M,
    a as g,
    c as T,
    d as V
} from "./dEV4iLZ3.js";

function h(n, e, a) {
    return A(n, e * _)
}

function R() {
    return Object.assign({}, q())
}

function I(n, e, a) {
    const t = R(),
        r = B(n, a.timeZone, a.locale ? ? t.locale);
    return "formatToParts" in r ? G(r, e) : Q(r, e)
}

function G(n, e) {
    const a = n.formatToParts(e);
    for (let t = a.length - 1; t >= 0; --t)
        if (a[t].type === "timeZoneName") return a[t].value
}

function Q(n, e) {
    const a = n.format(e).replace(/\u200E/g, ""),
        t = / [\w-+ ]+$/.exec(a);
    return t ? t[0].substr(1) : ""
}

function B(n, e, a) {
    return new Intl.DateTimeFormat(a ? [a.code, "en-US"] : void 0, {
        timeZone: e,
        timeZoneName: n
    })
}

function K(n, e) {
    const a = ae(e);
    return "formatToParts" in a ? ee(a, n) : te(a, n)
}
const J = {
    year: 0,
    month: 1,
    day: 2,
    hour: 3,
    minute: 4,
    second: 5
};

function ee(n, e) {
    try {
        const a = n.formatToParts(e),
            t = [];
        for (let r = 0; r < a.length; r++) {
            const o = J[a[r].type];
            o !== void 0 && (t[o] = parseInt(a[r].value, 10))
        }
        return t
    } catch (a) {
        if (a instanceof RangeError) return [NaN];
        throw a
    }
}

function te(n, e) {
    const a = n.format(e),
        t = /(\d+)\/(\d+)\/(\d+),? (\d+):(\d+):(\d+)/.exec(a);
    return [parseInt(t[3], 10), parseInt(t[1], 10), parseInt(t[2], 10), parseInt(t[4], 10), parseInt(t[5], 10), parseInt(t[6], 10)]
}
const w = {},
    Y = new Intl.DateTimeFormat("en-US", {
        hourCycle: "h23",
        timeZone: "America/New_York",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
    }).format(new Date("2014-06-25T04:00:00.123Z")),
    ne = Y === "06/25/2014, 00:00:00" || Y === "‎06‎/‎25‎/‎2014‎ ‎00‎:‎00‎:‎00";

function ae(n) {
    return w[n] || (w[n] = ne ? new Intl.DateTimeFormat("en-US", {
        hourCycle: "h23",
        timeZone: n,
        year: "numeric",
        month: "numeric",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
    }) : new Intl.DateTimeFormat("en-US", {
        hour12: !1,
        timeZone: n,
        year: "numeric",
        month: "numeric",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
    })), w[n]
}

function Z(n, e, a, t, r, o, i) {
    const u = new Date(0);
    return u.setUTCFullYear(n, e, a), u.setUTCHours(t, r, o, i), u
}
const H = 36e5,
    re = 6e4,
    C = {
        timezoneZ: /^(Z)$/,
        timezoneHH: /^([+-]\d{2})$/,
        timezoneHHMM: /^([+-])(\d{2}):?(\d{2})$/
    };

function y(n, e, a) {
    if (!n) return 0;
    let t = C.timezoneZ.exec(n);
    if (t) return 0;
    let r, o;
    if (t = C.timezoneHH.exec(n), t) return r = parseInt(t[1], 10), S(r) ? -(r * H) : NaN;
    if (t = C.timezoneHHMM.exec(n), t) {
        r = parseInt(t[2], 10);
        const i = parseInt(t[3], 10);
        return S(r, i) ? (o = Math.abs(r) * H + i * re, t[1] === "+" ? -o : o) : NaN
    }
    if (se(n)) {
        e = new Date(e || Date.now());
        const i = a ? e : oe(e),
            u = N(i, n);
        return -(a ? u : ie(e, u, n))
    }
    return NaN
}

function oe(n) {
    return Z(n.getFullYear(), n.getMonth(), n.getDate(), n.getHours(), n.getMinutes(), n.getSeconds(), n.getMilliseconds())
}

function N(n, e) {
    const a = K(n, e),
        t = Z(a[0], a[1] - 1, a[2], a[3] % 24, a[4], a[5], 0).getTime();
    let r = n.getTime();
    const o = r % 1e3;
    return r -= o >= 0 ? o : 1e3 + o, t - r
}

function ie(n, e, a) {
    let r = n.getTime() - e;
    const o = N(new Date(r), a);
    if (e === o) return e;
    r -= o - e;
    const i = N(new Date(r), a);
    return o === i ? o : Math.max(o, i)
}

function S(n, e) {
    return -23 <= n && n <= 23 && (e == null || 0 <= e && e <= 59)
}
const x = {};

function se(n) {
    if (x[n]) return !0;
    try {
        return new Intl.DateTimeFormat(void 0, {
            timeZone: n
        }), x[n] = !0, !0
    } catch {
        return !1
    }
}
const ue = 60 * 1e3,
    ce = {
        X: function(n, e, a) {
            const t = b(a.timeZone, n);
            if (t === 0) return "Z";
            switch (e) {
                case "X":
                    return v(t);
                case "XXXX":
                case "XX":
                    return l(t);
                case "XXXXX":
                case "XXX":
                default:
                    return l(t, ":")
            }
        },
        x: function(n, e, a) {
            const t = b(a.timeZone, n);
            switch (e) {
                case "x":
                    return v(t);
                case "xxxx":
                case "xx":
                    return l(t);
                case "xxxxx":
                case "xxx":
                default:
                    return l(t, ":")
            }
        },
        O: function(n, e, a) {
            const t = b(a.timeZone, n);
            switch (e) {
                case "O":
                case "OO":
                case "OOO":
                    return "GMT" + de(t, ":");
                case "OOOO":
                default:
                    return "GMT" + l(t, ":")
            }
        },
        z: function(n, e, a) {
            switch (e) {
                case "z":
                case "zz":
                case "zzz":
                    return I("short", n, a);
                case "zzzz":
                default:
                    return I("long", n, a)
            }
        }
    };

function b(n, e) {
    const a = n ? y(n, e, !0) / ue : (e == null ? void 0 : e.getTimezoneOffset()) ? ? 0;
    if (Number.isNaN(a)) throw new RangeError("Invalid time zone specified: " + n);
    return a
}

function p(n, e) {
    const a = n < 0 ? "-" : "";
    let t = Math.abs(n).toString();
    for (; t.length < e;) t = "0" + t;
    return a + t
}

function l(n, e = "") {
    const a = n > 0 ? "-" : "+",
        t = Math.abs(n),
        r = p(Math.floor(t / 60), 2),
        o = p(Math.floor(t % 60), 2);
    return a + r + e + o
}

function v(n, e) {
    return n % 60 === 0 ? (n > 0 ? "-" : "+") + p(Math.abs(n) / 60, 2) : l(n, e)
}

function de(n, e = "") {
    const a = n > 0 ? "-" : "+",
        t = Math.abs(n),
        r = Math.floor(t / 60),
        o = t % 60;
    return o === 0 ? a + String(r) : a + String(r) + e + p(o, 2)
}

function z(n) {
    const e = new Date(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate(), n.getHours(), n.getMinutes(), n.getSeconds(), n.getMilliseconds()));
    return e.setUTCFullYear(n.getFullYear()), +n - +e
}
const fe = /(Z|[+-]\d{2}(?::?\d{2})?| UTC| [a-zA-Z]+\/[a-zA-Z_]+(?:\/[a-zA-Z_]+)?)$/,
    O = 36e5,
    F = 6e4,
    me = 2,
    c = {
        dateTimePattern: /^([0-9W+-]+)(T| )(.*)/,
        datePattern: /^([0-9W+-]+)(.*)/,
        YY: /^(\d{2})$/,
        YYY: [/^([+-]\d{2})$/, /^([+-]\d{3})$/, /^([+-]\d{4})$/],
        YYYY: /^(\d{4})/,
        YYYYY: [/^([+-]\d{4})/, /^([+-]\d{5})/, /^([+-]\d{6})/],
        MM: /^-(\d{2})$/,
        DDD: /^-?(\d{3})$/,
        MMDD: /^-?(\d{2})-?(\d{2})$/,
        Www: /^-?W(\d{2})$/,
        WwwD: /^-?W(\d{2})-?(\d{1})$/,
        HH: /^(\d{2}([.,]\d*)?)$/,
        HHMM: /^(\d{2}):?(\d{2}([.,]\d*)?)$/,
        HHMMSS: /^(\d{2}):?(\d{2}):?(\d{2}([.,]\d*)?)$/,
        timeZone: fe
    };

function j(n, e = {}) {
    if (arguments.length < 1) throw new TypeError("1 argument required, but only " + arguments.length + " present");
    if (n === null) return new Date(NaN);
    const a = e.additionalDigits == null ? me : Number(e.additionalDigits);
    if (a !== 2 && a !== 1 && a !== 0) throw new RangeError("additionalDigits must be 0, 1 or 2");
    if (n instanceof Date || typeof n == "object" && Object.prototype.toString.call(n) === "[object Date]") return new Date(n.getTime());
    if (typeof n == "number" || Object.prototype.toString.call(n) === "[object Number]") return new Date(n);
    if (Object.prototype.toString.call(n) !== "[object String]") return new Date(NaN);
    const t = le(n),
        {
            year: r,
            restDateString: o
        } = ge(t.date, a),
        i = Te(o, r);
    if (i === null || isNaN(i.getTime())) return new Date(NaN);
    if (i) {
        const u = i.getTime();
        let d = 0,
            f;
        if (t.time && (d = he(t.time), d === null || isNaN(d))) return new Date(NaN);
        if (t.timeZone || e.timeZone) {
            if (f = y(t.timeZone || e.timeZone, new Date(u + d)), isNaN(f)) return new Date(NaN)
        } else f = z(new Date(u + d)), f = z(new Date(u + d + f));
        return new Date(u + d + f)
    } else return new Date(NaN)
}

function le(n) {
    const e = {};
    let a = c.dateTimePattern.exec(n),
        t;
    if (a ? (e.date = a[1], t = a[3]) : (a = c.datePattern.exec(n), a ? (e.date = a[1], t = a[2]) : (e.date = null, t = n)), t) {
        const r = c.timeZone.exec(t);
        r ? (e.time = t.replace(r[1], ""), e.timeZone = r[1].trim()) : e.time = t
    }
    return e
}

function ge(n, e) {
    if (n) {
        const a = c.YYY[e],
            t = c.YYYYY[e];
        let r = c.YYYY.exec(n) || t.exec(n);
        if (r) {
            const o = r[1];
            return {
                year: parseInt(o, 10),
                restDateString: n.slice(o.length)
            }
        }
        if (r = c.YY.exec(n) || a.exec(n), r) {
            const o = r[1];
            return {
                year: parseInt(o, 10) * 100,
                restDateString: n.slice(o.length)
            }
        }
    }
    return {
        year: null
    }
}

function Te(n, e) {
    if (e === null) return null;
    let a, t, r;
    if (!n || !n.length) return a = new Date(0), a.setUTCFullYear(e), a;
    let o = c.MM.exec(n);
    if (o) return a = new Date(0), t = parseInt(o[1], 10) - 1, $(e, t) ? (a.setUTCFullYear(e, t), a) : new Date(NaN);
    if (o = c.DDD.exec(n), o) {
        a = new Date(0);
        const i = parseInt(o[1], 10);
        return Me(e, i) ? (a.setUTCFullYear(e, 0, i), a) : new Date(NaN)
    }
    if (o = c.MMDD.exec(n), o) {
        a = new Date(0), t = parseInt(o[1], 10) - 1;
        const i = parseInt(o[2], 10);
        return $(e, t, i) ? (a.setUTCFullYear(e, t, i), a) : new Date(NaN)
    }
    if (o = c.Www.exec(n), o) return r = parseInt(o[1], 10) - 1, W(r) ? P(e, r) : new Date(NaN);
    if (o = c.WwwD.exec(n), o) {
        r = parseInt(o[1], 10) - 1;
        const i = parseInt(o[2], 10) - 1;
        return W(r, i) ? P(e, r, i) : new Date(NaN)
    }
    return null
}

function he(n) {
    let e, a, t = c.HH.exec(n);
    if (t) return e = parseFloat(t[1].replace(",", ".")), U(e) ? e % 24 * O : NaN;
    if (t = c.HHMM.exec(n), t) return e = parseInt(t[1], 10), a = parseFloat(t[2].replace(",", ".")), U(e, a) ? e % 24 * O + a * F : NaN;
    if (t = c.HHMMSS.exec(n), t) {
        e = parseInt(t[1], 10), a = parseInt(t[2], 10);
        const r = parseFloat(t[3].replace(",", "."));
        return U(e, a, r) ? e % 24 * O + a * F + r * 1e3 : NaN
    }
    return null
}

function P(n, e, a) {
    e = e || 0, a = a || 0;
    const t = new Date(0);
    t.setUTCFullYear(n, 0, 4);
    const r = t.getUTCDay() || 7,
        o = e * 7 + a + 1 - r;
    return t.setUTCDate(t.getUTCDate() + o), t
}
const De = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
    pe = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

function X(n) {
    return n % 400 === 0 || n % 4 === 0 && n % 100 !== 0
}

function $(n, e, a) {
    if (e < 0 || e > 11) return !1;
    if (a != null) {
        if (a < 1) return !1;
        const t = X(n);
        if (t && a > pe[e] || !t && a > De[e]) return !1
    }
    return !0
}

function Me(n, e) {
    if (e < 1) return !1;
    const a = X(n);
    return !(a && e > 366 || !a && e > 365)
}

function W(n, e) {
    return !(n < 0 || n > 52 || e != null && (e < 0 || e > 6))
}

function U(n, e, a) {
    return !(n < 0 || n >= 25 || e != null && (e < 0 || e >= 60) || a != null && (a < 0 || a >= 60))
}
const we = /([xXOz]+)|''|'(''|[^'])+('|$)/g;

function Ce(n, e, a = {}) {
    e = String(e);
    const t = e.match(we);
    if (t) {
        const r = j(a.originalDate || n, a);
        e = t.reduce(function(o, i) {
            if (i[0] === "'") return o;
            const u = o.indexOf(i),
                d = o[u - 1] === "'",
                f = o.replace(i, "'" + ce[i[0]](r, i, a) + "'");
            return d ? f.substring(0, u - 1) + f.substring(u + 1) : f
        }, e)
    }
    return D(n, e, a)
}

function be(n, e, a) {
    n = j(n, a);
    const t = y(e, n, !0),
        r = new Date(n.getTime() - t),
        o = new Date(0);
    return o.setFullYear(r.getUTCFullYear(), r.getUTCMonth(), r.getUTCDate()), o.setHours(r.getUTCHours(), r.getUTCMinutes(), r.getUTCSeconds(), r.getUTCMilliseconds()), o
}

function Oe(n, e, a, t) {
    return t = { ...t,
        timeZone: e,
        originalDate: n
    }, Ce(be(n, e, {
        timeZone: t.timeZone
    }), a, t)
}
const Ue = {
        lessThanXSeconds: {
            one: "menos de um segundo",
            other: "menos de {{count}} segundos"
        },
        xSeconds: {
            one: "1 segundo",
            other: "{{count}} segundos"
        },
        halfAMinute: "meio minuto",
        lessThanXMinutes: {
            one: "menos de um minuto",
            other: "menos de {{count}} minutos"
        },
        xMinutes: {
            one: "1 minuto",
            other: "{{count}} minutos"
        },
        aboutXHours: {
            one: "cerca de 1 hora",
            other: "cerca de {{count}} horas"
        },
        xHours: {
            one: "1 hora",
            other: "{{count}} horas"
        },
        xDays: {
            one: "1 dia",
            other: "{{count}} dias"
        },
        aboutXWeeks: {
            one: "cerca de 1 semana",
            other: "cerca de {{count}} semanas"
        },
        xWeeks: {
            one: "1 semana",
            other: "{{count}} semanas"
        },
        aboutXMonths: {
            one: "cerca de 1 mês",
            other: "cerca de {{count}} meses"
        },
        xMonths: {
            one: "1 mês",
            other: "{{count}} meses"
        },
        aboutXYears: {
            one: "cerca de 1 ano",
            other: "cerca de {{count}} anos"
        },
        xYears: {
            one: "1 ano",
            other: "{{count}} anos"
        },
        overXYears: {
            one: "mais de 1 ano",
            other: "mais de {{count}} anos"
        },
        almostXYears: {
            one: "quase 1 ano",
            other: "quase {{count}} anos"
        }
    },
    Ne = (n, e, a) => {
        let t;
        const r = Ue[n];
        return typeof r == "string" ? t = r : e === 1 ? t = r.one : t = r.other.replace("{{count}}", String(e)), a != null && a.addSuffix ? a.comparison && a.comparison > 0 ? "em " + t : "há " + t : t
    },
    ye = {
        full: "EEEE, d 'de' MMMM 'de' y",
        long: "d 'de' MMMM 'de' y",
        medium: "d MMM y",
        short: "dd/MM/yyyy"
    },
    Ie = {
        full: "HH:mm:ss zzzz",
        long: "HH:mm:ss z",
        medium: "HH:mm:ss",
        short: "HH:mm"
    },
    Ye = {
        full: "{{date}} 'às' {{time}}",
        long: "{{date}} 'às' {{time}}",
        medium: "{{date}}, {{time}}",
        short: "{{date}}, {{time}}"
    },
    He = {
        date: M({
            formats: ye,
            defaultWidth: "full"
        }),
        time: M({
            formats: Ie,
            defaultWidth: "full"
        }),
        dateTime: M({
            formats: Ye,
            defaultWidth: "full"
        })
    },
    Se = {
        lastWeek: n => {
            const e = n.getDay();
            return "'" + (e === 0 || e === 6 ? "último" : "última") + "' eeee 'às' p"
        },
        yesterday: "'ontem às' p",
        today: "'hoje às' p",
        tomorrow: "'amanhã às' p",
        nextWeek: "eeee 'às' p",
        other: "P"
    },
    xe = (n, e, a, t) => {
        const r = Se[n];
        return typeof r == "function" ? r(e) : r
    },
    ve = {
        narrow: ["AC", "DC"],
        abbreviated: ["AC", "DC"],
        wide: ["antes de cristo", "depois de cristo"]
    },
    ze = {
        narrow: ["1", "2", "3", "4"],
        abbreviated: ["T1", "T2", "T3", "T4"],
        wide: ["1º trimestre", "2º trimestre", "3º trimestre", "4º trimestre"]
    },
    Fe = {
        narrow: ["j", "f", "m", "a", "m", "j", "j", "a", "s", "o", "n", "d"],
        abbreviated: ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"],
        wide: ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]
    },
    Pe = {
        narrow: ["D", "S", "T", "Q", "Q", "S", "S"],
        short: ["dom", "seg", "ter", "qua", "qui", "sex", "sab"],
        abbreviated: ["domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado"],
        wide: ["domingo", "segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado"]
    },
    $e = {
        narrow: {
            am: "a",
            pm: "p",
            midnight: "mn",
            noon: "md",
            morning: "manhã",
            afternoon: "tarde",
            evening: "tarde",
            night: "noite"
        },
        abbreviated: {
            am: "AM",
            pm: "PM",
            midnight: "meia-noite",
            noon: "meio-dia",
            morning: "manhã",
            afternoon: "tarde",
            evening: "tarde",
            night: "noite"
        },
        wide: {
            am: "a.m.",
            pm: "p.m.",
            midnight: "meia-noite",
            noon: "meio-dia",
            morning: "manhã",
            afternoon: "tarde",
            evening: "tarde",
            night: "noite"
        }
    },
    We = {
        narrow: {
            am: "a",
            pm: "p",
            midnight: "mn",
            noon: "md",
            morning: "da manhã",
            afternoon: "da tarde",
            evening: "da tarde",
            night: "da noite"
        },
        abbreviated: {
            am: "AM",
            pm: "PM",
            midnight: "meia-noite",
            noon: "meio-dia",
            morning: "da manhã",
            afternoon: "da tarde",
            evening: "da tarde",
            night: "da noite"
        },
        wide: {
            am: "a.m.",
            pm: "p.m.",
            midnight: "meia-noite",
            noon: "meio-dia",
            morning: "da manhã",
            afternoon: "da tarde",
            evening: "da tarde",
            night: "da noite"
        }
    },
    Ze = (n, e) => {
        const a = Number(n);
        return (e == null ? void 0 : e.unit) === "week" ? a + "ª" : a + "º"
    },
    je = {
        ordinalNumber: Ze,
        era: g({
            values: ve,
            defaultWidth: "wide"
        }),
        quarter: g({
            values: ze,
            defaultWidth: "wide",
            argumentCallback: n => n - 1
        }),
        month: g({
            values: Fe,
            defaultWidth: "wide"
        }),
        day: g({
            values: Pe,
            defaultWidth: "wide"
        }),
        dayPeriod: g({
            values: $e,
            defaultWidth: "wide",
            formattingValues: We,
            defaultFormattingWidth: "wide"
        })
    },
    Xe = /^(\d+)[ºªo]?/i,
    Ee = /\d+/i,
    Le = {
        narrow: /^(ac|dc|a|d)/i,
        abbreviated: /^(a\.?\s?c\.?|d\.?\s?c\.?)/i,
        wide: /^(antes de cristo|depois de cristo)/i
    },
    ke = {
        any: [/^ac/i, /^dc/i],
        wide: [/^antes de cristo/i, /^depois de cristo/i]
    },
    Ae = {
        narrow: /^[1234]/i,
        abbreviated: /^T[1234]/i,
        wide: /^[1234](º)? trimestre/i
    },
    _e = {
        any: [/1/i, /2/i, /3/i, /4/i]
    },
    qe = {
        narrow: /^[jfmajsond]/i,
        abbreviated: /^(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)/i,
        wide: /^(janeiro|fevereiro|março|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)/i
    },
    Ve = {
        narrow: [/^j/i, /^f/i, /^m/i, /^a/i, /^m/i, /^j/i, /^j/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i],
        any: [/^ja/i, /^fev/i, /^mar/i, /^abr/i, /^mai/i, /^jun/i, /^jul/i, /^ago/i, /^set/i, /^out/i, /^nov/i, /^dez/i]
    },
    Re = {
        narrow: /^(dom|[23456]ª?|s[aá]b)/i,
        short: /^(dom|[23456]ª?|s[aá]b)/i,
        abbreviated: /^(dom|seg|ter|qua|qui|sex|s[aá]b)/i,
        wide: /^(domingo|(segunda|ter[cç]a|quarta|quinta|sexta)([- ]feira)?|s[aá]bado)/i
    },
    Ge = {
        short: [/^d/i, /^2/i, /^3/i, /^4/i, /^5/i, /^6/i, /^s[aá]/i],
        narrow: [/^d/i, /^2/i, /^3/i, /^4/i, /^5/i, /^6/i, /^s[aá]/i],
        any: [/^d/i, /^seg/i, /^t/i, /^qua/i, /^qui/i, /^sex/i, /^s[aá]b/i]
    },
    Qe = {
        narrow: /^(a|p|mn|md|(da) (manhã|tarde|noite))/i,
        any: /^([ap]\.?\s?m\.?|meia[-\s]noite|meio[-\s]dia|(da) (manhã|tarde|noite))/i
    },
    Be = {
        any: {
            am: /^a/i,
            pm: /^p/i,
            midnight: /^mn|^meia[-\s]noite/i,
            noon: /^md|^meio[-\s]dia/i,
            morning: /manhã/i,
            afternoon: /tarde/i,
            evening: /tarde/i,
            night: /noite/i
        }
    },
    Ke = {
        ordinalNumber: V({
            matchPattern: Xe,
            parsePattern: Ee,
            valueCallback: n => parseInt(n, 10)
        }),
        era: T({
            matchPatterns: Le,
            defaultMatchWidth: "wide",
            parsePatterns: ke,
            defaultParseWidth: "any"
        }),
        quarter: T({
            matchPatterns: Ae,
            defaultMatchWidth: "wide",
            parsePatterns: _e,
            defaultParseWidth: "any",
            valueCallback: n => n + 1
        }),
        month: T({
            matchPatterns: qe,
            defaultMatchWidth: "wide",
            parsePatterns: Ve,
            defaultParseWidth: "any"
        }),
        day: T({
            matchPatterns: Re,
            defaultMatchWidth: "wide",
            parsePatterns: Ge,
            defaultParseWidth: "any"
        }),
        dayPeriod: T({
            matchPatterns: Qe,
            defaultMatchWidth: "any",
            parsePatterns: Be,
            defaultParseWidth: "any"
        })
    },
    Je = {
        code: "pt-BR",
        formatDistance: Ne,
        formatLong: He,
        formatRelative: xe,
        localize: je,
        match: Ke,
        options: {
            weekStartsOn: 0,
            firstWeekContainsDate: 1
        }
    };
class m {
    static inTimeZone(e, a, t = !1) {
        t && console.log("-------------------"), t && console.log("before timeZone", e);
        const r = m.getTimeZoneOffsetInHours(),
            o = a.asInt();
        t && console.log("current, goal", r, o);
        const i = h(e, r - o);
        return t && console.log("after timeZone", i), i
    }
    static getStringFromUtcDateWithOffset(e, a, t) {
        return Oe(e, m.getTzStringFromHoursOffset(t), a)
    }
    static dateInUTC(e) {
        return new Date(e.getTime() + e.getTimezoneOffset() * 6e4)
    }
    static getHoursForOffset(e, a) {
        let t = e + a;
        return t < 0 && (t += 24), t > 23 && (t -= 24), t
    }
    static getDayOfWeekForOffset(e, a) {
        const t = e.getTime(),
            r = a * 60 * 60 * 1e3;
        return new Date(t + r).getUTCDay()
    }
    static getDateNumberForOffset(e, a) {
        const t = e.getTime(),
            r = a * 60 * 60 * 1e3;
        return new Date(t + r).getUTCDate()
    }
    static getTimeZoneOffsetInHours() {
        return new Date().getTimezoneOffset() / -60
    }
    static resetedTimeDate(e) {
        return new Date(e.getFullYear(), e.getMonth(), e.getDate(), 0, 0, 0)
    }
    static resetedTimeFromHoursOffset(e, a) {
        const t = h(e, a),
            r = t.getUTCFullYear(),
            o = m.formatDateTimeValueToString(t.getUTCMonth() + 1),
            i = m.formatDateTimeValueToString(t.getUTCDate());
        return new Date(`${r}-${o}-${i}T00:00:00.000${m.formatHoursOffsetToGmtString(a)}`)
    }
    static maxTimeDate(e) {
        return new Date(e.getFullYear(), e.getMonth(), e.getDate(), 23, 59, 59)
    }
    static maxTimeFromHoursOffset(e, a) {
        const t = h(e, a),
            r = t.getUTCFullYear(),
            o = m.formatDateTimeValueToString(t.getUTCMonth() + 1),
            i = m.formatDateTimeValueToString(t.getUTCDate());
        return new Date(`${r}-${o}-${i}T23:59:59.999${m.formatHoursOffsetToGmtString(a)}`)
    }
    static getDateInfoForHoursOffset(e, a) {
        const t = h(e, a);
        return {
            fullYear: t.getUTCFullYear(),
            month: t.getUTCMonth(),
            date: t.getUTCDate(),
            day: t.getUTCDay(),
            hours: t.getUTCHours(),
            minutes: t.getUTCMinutes(),
            seconds: t.getUTCSeconds(),
            milliseconds: t.getUTCMilliseconds()
        }
    }
    static setDateForHoursOffset(e, a, t) {
        const r = h(e, a);
        t.fullYear !== void 0 && r.setUTCFullYear(t.fullYear), t.month !== void 0 && r.setUTCMonth(t.month), t.date !== void 0 && r.setUTCDate(t.date), t.hours !== void 0 && r.setUTCHours(t.hours), t.minutes !== void 0 && r.setUTCMinutes(t.minutes), t.seconds !== void 0 && r.setUTCSeconds(t.seconds), t.milliseconds !== void 0 && r.setUTCMilliseconds(t.milliseconds);
        const o = String(r.getUTCFullYear()).padStart(4, "0"),
            i = String(r.getUTCMonth() + 1).padStart(2, "0"),
            u = String(r.getUTCDate()).padStart(2, "0"),
            d = String(r.getUTCHours()).padStart(2, "0"),
            f = String(r.getUTCMinutes()).padStart(2, "0"),
            E = String(r.getUTCSeconds()).padStart(2, "0"),
            L = String(r.getUTCMilliseconds()).padStart(3, "0");
        return new Date(`${o}-${i}-${u}T${d}:${f}:${E}.${L}${m.formatHoursOffsetToGmtString(a)}`)
    }
    static transformDateToValidFormat(e) {
        const a = e.split("/");
        return `${a[2]}-${a[1]}-${a[0]}`
    }
    static readableDate(e) {
        return e ? `${D(e,"dd")} de ${k.capitalize(D(e,"MMMM",{locale:Je}))} de ${D(e,"yyyy")}` : ""
    }
    static formatHoursOffsetToGmtString(e) {
        return `${e<0?"-":"+"}${m.formatDateTimeValueToString(Math.abs(e))}:00`
    }
    static formatDateTimeValueToString(e) {
        return `${e>9?e:`0${e}`}`
    }
    static timeZoneIanaToHoursOffset(e) {
        return {
            [s.UTC_6]: -6,
            [s.UTC_5]: -5,
            [s.UTC_4]: -4,
            [s.UTC_3]: -3,
            [s.UTC0]: 0,
            [s.UTC1]: 1,
            [s.UTC2]: 2,
            [s.UTC3]: 3,
            [s.UTC5]: 5,
            [s.UTC6]: 6,
            [s.UTC7]: 7,
            [s.UTC8]: 8
        }[e]
    }
    static hoursOffsetToTimeZoneIana(e) {
        switch (e) {
            case -6:
                return s.UTC_6;
            case -5:
                return s.UTC_5;
            case -4:
                return s.UTC_4;
            case -3:
                return s.UTC_3;
            case 0:
                return s.UTC0;
            case 1:
                return s.UTC1;
            case 2:
                return s.UTC2;
            case 3:
                return s.UTC3;
            case 5:
                return s.UTC5;
            case 6:
                return s.UTC6;
            case 7:
                return s.UTC7;
            case 8:
                return s.UTC8;
            default:
                return null
        }
    }
    static getTzStringFromHoursOffset(e) {
        return `Etc/GMT${e<=0?"+":"-"}${Math.abs(e)}`
    }
}
export {
    m as D, h as a, j as b, y as c, Oe as f, R as g, Z as n, Je as p, fe as t
};