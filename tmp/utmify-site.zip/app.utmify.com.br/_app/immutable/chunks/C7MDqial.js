var a = (s => (s.Hotmart = "Hotmart", s.Kiwify = "Kiwify", s.Cartpanda = "Cartpanda", s.Vega = "Vega", s.Kirvano = "Kirvano", s.Shopify = "Shopify", s.PerfectPay = "PerfectPay", s.Yampi = "Yampi", s.Lastlink = "Lastlink", s.Payt = "Payt", s.Logzz = "Logzz", s.Adoorei = "Adoorei", s.TriboPay = "TriboPay", s.Clickbank = "Clickbank", s.Ticto = "Ticto", s.Eduzz = "Eduzz", s.Braip = "Braip", s.Pepper = "Pepper", s.Woocommerce = "Woocommerce", s.BuyGoods = "BuyGoods", s.MundPay = "MundPay", s.Disrupty = "Disrupty", s.Greenn = "Greenn", s.Monetizze = "Monetizze", s.Guru = "Guru", s.Digistore = "Digistore", s.Hubla = "Hubla", s.Doppus = "Doppus", s.Frendz = "Frendz", s.InvictusPay = "InvictusPay", s.Appmax = "Appmax", s.NitroPagamentos = "NitroPagamentos", s.GoatPay = "GoatPay", s.Hebreus = "Hebreus", s.IExperience = "IExperience", s.PagTrust = "PagTrust", s.NuvemShop = "NuvemShop", s.FortPay = "FortPay", s.Systeme = "Systeme", s.IronPay = "IronPay", s.CinqPay = "CinqPay", s.SharkPays = "SharkPays", s.Maxweb = "Maxweb", s.Zouti = "Zouti", s.Pantherfy = "Pantherfy", s.StrivPay = "StrivPay", s.AtomoPay = "AtomoPay", s.AllPay = "AllPay", s.BullPay = "BullPay", s.OctusPay = "OctusPay", s.Zippify = "Zippify", s.Masterfy = "Masterfy", s.InovaPag = "InovaPag", s.SoutPay = "SoutPay", s.WolfPay = "WolfPay", s.SigmaPagamentos = "SigmaPagamentos", s.Nexopayt = "Nexopayt", s.WeGate = "WeGate", s.Unicornify = "Unicornify", s.Allpes = "Allpes", s.VittaPay = "VittaPay", s.FluxionPay = "FluxionPay", s.NezzyPay = "NezzyPay", s.PMHMPay = "PMHMPay", s.TrivexPay = "TrivexPay", s.GatPay = "GatPay", s.BearPay = "BearPay", s.AmandisPay = "AmandisPay", s.Orbita = "Orbita", s.DigiPag = "DigiPag", s.AlphaPay = "AlphaPay", s.AssetPay = "AssetPay", s.BrGateway = "BrGateway", s.Creedx = "Creedx", s.Hotfy = "Hotfy", s.KlivoPay = "KlivoPay", s.Plumify = "Plumify", s.PrimeGate = "PrimeGate", s.Wise2Pay = "Wise2Pay", s.VisionPay = "VisionPay", s.SharkBytePay = "SharkBytePay", s.SigmaPay = "SigmaPay", s.ZeroOnePay = "ZeroOnePay", s.Traxon = "Traxon", s.Bloo = "Bloo", s.KitePay = "KitePay", s))(a || {});
const y = ["Orbita"];
var n = (s => (s.Ativopay = "Ativopay", s))(n || {}),
    u = (s => (s.B4you = "B4you", s.Risepay = "Risepay", s.Urus = "Urus", s.Cakto = "Cakto", s.Flashpay = "Flashpay", s.DigitalMart = "DigitalMart", s.Exattus = "Exattus", s.LunarCash = "LunarCash", s.YouShop = "YouShop", s.BlackPay = "BlackPay", s.VenuzPay = "VenuzPay", s.LunaCheckout = "LunaCheckout", s.FullSale = "FullSale", s.BullsPay = "BullsPay", s.Moodi = "Moodi", s.NikaPay = "NikaPay", s.GhostsPay = "GhostsPay", s.KeedPay = "KeedPay", s.Salduu = "Salduu", s.ViperPay = "ViperPay", s.Sunize = "Sunize", s.Assiny = "Assiny", s.Wiapy = "Wiapy", s.UnicoPag = "UnicoPag", s.ImperialPay = "ImperialPay", s.Zedy = "Zedy", s.Sinix = "Sinix", s.Voomp = "Voomp", s.Ombrelone = "Ombrelone", s.PushinPay = "PushinPay", s.Genesys = "Genesys", s.OnProfit = "OnProfit", s.SacaPay = "SacaPay", s.Cloudfy = "Cloudfy", s.Kuenha = "Kuenha", s.NinjaPay = "NinjaPay", s.Xgrow = "Xgrow", s.ggCheckout = "ggCheckout", s.PanteraCheckout = "PanteraCheckout", s.NublaPay = "NublaPay", s.Cartly = "Cartly", s.Pagah = "Pagah", s.Pagsafe = "Pagsafe", s.Nomadfy = "Nomadfy", s.Sync = "Sync", s.LPQV = "LPQV", s.Auryon369 = "Auryon369", s.Paradise = "Paradise", s.FirePay = "FirePay", s.Lowify = "Lowify", s.Hyppe = "Hyppe", s.Seedpay = "Seedpay", s.Membriz = "Membriz", s.Cerefy = "Cerefy", s))(u || {}),
    p = (s => (s.Appmax = "Appmax", s.TriboPay = "TriboPay", s.Adoorei = "Adoorei", s.BuyGoods = "BuyGoods", s.Eduzz = "Eduzz", s.Guru = "Guru", s.Hotmart = "Hotmart", s.Kirvano = "Kirvano", s.Pepper = "Pepper", s.Ticto = "Ticto", s.Vega = "Vega", s.Zippify = "Zippify", s.Zouti = "Zouti", s.Lastlink = "Lastlink", s.Digistore = "Digistore", s.Logzz = "Logzz", s.MundPay = "MundPay", s.StrivPay = "StrivPay", s.Disrupty = "Disrupty", s.Pantherfy = "Pantherfy", s.CinqPay = "CinqPay", s.NitroPagamentos = "NitroPagamentos", s.SoutPay = "SoutPay", s.Maxweb = "Maxweb", s.Frendz = "Frendz", s.FortPay = "FortPay", s.Shopify = "Shopify", s.PagTrust = "PagTrust", s.NuvemShop = "NuvemShop", s.WolfPay = "WolfPay", s.BullPay = "BullPay", s.FluxionPay = "FluxionPay", s.Hebreus = "Hebreus", s.VittaPay = "VittaPay", s.InovaPag = "InovaPag", s.WeGate = "WeGate", s.PMHMPay = "PMHMPay", s.GoatPay = "GoatPay", s.KlivoPay = "KlivoPay", s.SigmaPagamentos = "SigmaPagamentos", s.InvictusPay = "InvictusPay", s.Paradise = "Paradise", s.TrivexPay = "TrivexPay", s.BearPay = "BearPay", s.GatPay = "GatPay", s.DigiPag = "DigiPag", s.AtomoPay = "AtomoPay", s.Wise2Pay = "Wise2Pay", s.Unicornify = "Unicornify", s.AmandisPay = "AmandisPay", s.SharkPays = "SharkPays", s.Nexopayt = "Nexopayt", s.AllPay = "AllPay", s.IronPay = "IronPay", s.AssetPay = "AssetPay", s.Hotfy = "Hotfy", s.BrGateway = "BrGateway", s.AlphaPay = "AlphaPay", s.Creedx = "Creedx", s.PrimeGate = "PrimeGate", s.VisionPay = "VisionPay", s.SharkBytePay = "SharkBytePay", s.SigmaPay = "SigmaPay", s.ZeroOnePay = "ZeroOnePay", s.Traxon = "Traxon", s.KitePay = "KitePay", s))(p || {});
const l = {
        Kiwify: {
            tutorial: "https://youtu.be/bBz3id02dps",
            hasToken: !0,
            hasCommissions: !0
        },
        IExperience: {
            tutorial: "https://youtu.be/5cS35EwmSTQ",
            hasToken: !0,
            hasCommissions: !0
        },
        PerfectPay: {
            tutorial: "https://youtu.be/e061GTDvFow",
            hasToken: !0,
            hasCommissions: !0
        },
        Doppus: {
            tutorial: "https://youtu.be/lJxMrGwGfyA",
            hasToken: !0,
            hasCommissions: !0
        },
        Hotmart: {
            tutorial: "https://youtu.be/ZrZKybbDpNY",
            hasToken: !0,
            hasCommissions: !0
        },
        Eduzz: {
            tutorial: "https://youtu.be/h9AkFRnufjM",
            hasToken: !0,
            hasCommissions: !0
        },
        Vega: {
            tutorial: "https://youtu.be/oThrgNCUWVY",
            hasToken: !1,
            hasCommissions: !1
        },
        Pepper: {
            tutorial: "https://youtu.be/9vrfrKQcJlA",
            hasToken: !1,
            hasCommissions: !0
        },
        Kirvano: {
            tutorial: "https://youtu.be/nbZCHv93iGo",
            hasToken: !0,
            hasCommissions: !0
        },
        Ticto: {
            tutorial: "https://youtu.be/3SQgyqfZ2nQ ",
            hasToken: !0,
            hasCommissions: !0
        },
        Monetizze: {
            tutorial: "https://youtu.be/B2BVPk7IWGM",
            hasToken: !0,
            hasCommissions: !0
        },
        Payt: {
            tutorial: "https://youtu.be/GdyYxQeWzcw",
            hasToken: !0,
            hasCommissions: !0
        },
        Zippify: {
            tutorial: "https://youtu.be/jrvxURV4NYQ",
            hasToken: !1,
            hasCommissions: !0
        },
        Greenn: {
            tutorial: "https://youtu.be/Yh5EsorNRU0",
            hasToken: !0,
            hasCommissions: !0
        },
        Yampi: {
            tutorial: "https://youtu.be/yUAKbakwX0c",
            hasToken: !0,
            hasCommissions: !1
        },
        Adoorei: {
            tutorial: "https://youtu.be/Su9mG4j8vbQ",
            hasToken: !0,
            hasCommissions: !1
        },
        Braip: {
            tutorial: "https://youtu.be/j8sNM3lTMSo",
            hasToken: !0,
            hasCommissions: !0
        },
        BuyGoods: {
            tutorial: "https://youtu.be/lJCGESZTeBg",
            hasToken: !1,
            hasCommissions: !0
        },
        OctusPay: {
            tutorial: "https://youtu.be/dmexM2L2dQo",
            hasToken: !1,
            hasCommissions: !1
        },
        Appmax: {
            tutorial: "https://youtu.be/PK8b7zcio-c",
            hasToken: !1,
            hasCommissions: !1
        },
        Guru: {
            tutorial: "https://youtu.be/l93ZLagzGig",
            hasToken: !0,
            hasCommissions: !1
        },
        Cartpanda: {
            tutorial: "https://youtu.be/3BAOpDsmSSQ",
            hasToken: !1,
            hasCommissions: !0
        },
        TriboPay: {
            tutorial: "https://youtu.be/v2mkQFptly4",
            hasToken: !1,
            hasCommissions: !0
        },
        Orbita: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !1
        },
        Woocommerce: {
            tutorial: "https://youtu.be/Ov4ssH8LTuY",
            hasToken: !1,
            hasCommissions: !1
        },
        Lastlink: {
            tutorial: "https://youtu.be/YafD9JuJ3wU",
            hasToken: !1,
            hasCommissions: !0
        },
        Hubla: {
            tutorial: "https://youtu.be/GvV_Dx-WVtw",
            hasToken: !0,
            hasCommissions: !0
        },
        Digistore: {
            tutorial: "https://youtu.be/AMsk_0cb0RU",
            hasToken: !0,
            hasCommissions: !0
        },
        Logzz: {
            tutorial: "https://youtu.be/UFO6qpLhuoM",
            hasToken: !1,
            hasCommissions: !1
        },
        MundPay: {
            tutorial: "https://youtu.be/sS19wLHu7ro",
            hasToken: !1,
            hasCommissions: !0
        },
        Clickbank: {
            tutorial: "https://youtu.be/4bp2n2gmTvE",
            hasToken: !0,
            hasCommissions: !0
        },
        StrivPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Systeme: {
            tutorial: "https://youtu.be/sZIRTJFUM4k",
            hasToken: !1,
            hasCommissions: !0
        },
        Disrupty: {
            tutorial: "https://youtu.be/f-D_bUvPdvc",
            hasToken: !1,
            hasCommissions: !0
        },
        Pantherfy: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        CinqPay: {
            tutorial: "https://youtu.be/gkpoBDtVpJc",
            hasToken: !1,
            hasCommissions: !0
        },
        Zouti: {
            tutorial: "https://youtu.be/1swEDBPhHYA",
            hasToken: !1,
            hasCommissions: !1
        },
        NitroPagamentos: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        SoutPay: {
            tutorial: "https://youtu.be/uFsR1Hsw7C0",
            hasToken: !1,
            hasCommissions: !0
        },
        Maxweb: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Frendz: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        FortPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Shopify: {
            tutorial: "https://youtu.be/ugBsWGpwAko",
            hasToken: !1,
            hasCommissions: !1
        },
        PagTrust: {
            tutorial: "https://youtu.be/8rhP6a3gZHU",
            hasToken: !1,
            hasCommissions: !0
        },
        NuvemShop: {
            tutorial: "https://youtu.be/xsEpo3jbn5E",
            hasToken: !1,
            hasCommissions: !1
        },
        WolfPay: {
            tutorial: "https://youtu.be/vxxyEACl6Ic",
            hasToken: !1,
            hasCommissions: !0
        },
        BullPay: {
            tutorial: "https://youtu.be/ctnYfku1hbg",
            hasToken: !1,
            hasCommissions: !0
        },
        FluxionPay: {
            tutorial: "https://youtu.be/krNMsDbOhEc",
            hasToken: !1,
            hasCommissions: !0
        },
        Hebreus: {
            tutorial: "https://youtu.be/3eAdKtMAh-A",
            hasToken: !1,
            hasCommissions: !0
        },
        VittaPay: {
            tutorial: "https://youtu.be/noaPD92gN_c",
            hasToken: !1,
            hasCommissions: !0
        },
        InovaPag: {
            tutorial: "https://youtu.be/1MKd-yx1mx0",
            hasToken: !1,
            hasCommissions: !0
        },
        WeGate: {
            tutorial: "https://youtu.be/tS5H1Sjv9ys",
            hasToken: !1,
            hasCommissions: !0
        },
        PMHMPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        GoatPay: {
            tutorial: "https://youtu.be/29Nal8pg5AA",
            hasToken: !1,
            hasCommissions: !0
        },
        KlivoPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        SigmaPagamentos: {
            tutorial: "https://youtu.be/aYEBtnal4dw",
            hasToken: !1,
            hasCommissions: !0
        },
        InvictusPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Plumify: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Masterfy: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        NezzyPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Allpes: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        TrivexPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        GatPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        DigiPag: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        BearPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        AtomoPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Wise2Pay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Unicornify: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        AmandisPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        SharkPays: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Nexopayt: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        AllPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        IronPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        AssetPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Hotfy: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        BrGateway: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        AlphaPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Creedx: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        PrimeGate: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        VisionPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        SharkBytePay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        SigmaPay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        ZeroOnePay: {
            tutorial: "https://youtu.be/zlurn1Tz0U0",
            hasToken: !1,
            hasCommissions: !0
        },
        Traxon: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        KitePay: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        Bloo: {
            tutorial: "",
            hasToken: !1,
            hasCommissions: !0
        },
        B4you: {
            tutorial: "https://youtu.be/UjJdL6noWsA",
            hasToken: !1,
            hasCommissions: !0
        },
        Risepay: {
            tutorial: "https://youtu.be/8YLVTWviggE",
            hasToken: !1,
            hasCommissions: !0
        },
        Urus: {
            tutorial: "https://youtu.be/2vYkzvahsds",
            hasToken: !1,
            hasCommissions: !0
        },
        Cakto: {
            tutorial: "https://youtu.be/HjJYsXqfu_4",
            hasToken: !1,
            hasCommissions: !0
        },
        Flashpay: {
            tutorial: "https://youtu.be/jfdzo-gDyeM",
            hasToken: !1,
            hasCommissions: !0
        },
        DigitalMart: {
            tutorial: "https://youtu.be/QOeDQf-RkGU",
            hasToken: !1,
            hasCommissions: !0
        },
        Exattus: {
            tutorial: "https://youtu.be/Xb5NVjooe3g",
            hasToken: !1,
            hasCommissions: !0
        },
        LunarCash: {
            tutorial: "https://youtu.be/rLj9r7SHUIQ",
            hasToken: !1,
            hasCommissions: !0
        },
        YouShop: {
            tutorial: "https://youtu.be/_itsFWyV2Aw",
            hasToken: !1,
            hasCommissions: !0
        },
        BlackPay: {
            tutorial: "https://youtu.be/fn_4sxuelGE",
            hasToken: !1,
            hasCommissions: !0
        },
        VenuzPay: {
            tutorial: "https://youtu.be/J8-GgYWN-K4",
            hasToken: !1,
            hasCommissions: !0
        },
        LunaCheckout: {
            tutorial: "https://youtu.be/sczpkQzpwcM",
            hasToken: !1,
            hasCommissions: !0
        },
        FullSale: {
            tutorial: "https://youtu.be/sVsce2wUMnM",
            hasToken: !1,
            hasCommissions: !0
        },
        BullsPay: {
            tutorial: "https://youtu.be/AGGdKHqsE9s",
            hasToken: !1,
            hasCommissions: !0
        },
        Moodi: {
            tutorial: "https://youtu.be/9FnhiEug3dc",
            hasToken: !1,
            hasCommissions: !0
        },
        NikaPay: {
            tutorial: "https://youtu.be/wlxCXGtQJu0",
            hasToken: !1,
            hasCommissions: !0
        },
        GhostsPay: {
            tutorial: "https://youtu.be/E8YF9fic8D8",
            hasToken: !1,
            hasCommissions: !0
        },
        KeedPay: {
            tutorial: "https://youtu.be/Pzasz6gVtn8",
            hasToken: !1,
            hasCommissions: !0
        },
        Salduu: {
            tutorial: "https://youtu.be/eEOMWTyaTWA",
            hasToken: !1,
            hasCommissions: !0
        },
        ViperPay: {
            tutorial: "https://youtu.be/CMR9xcwKti4",
            hasToken: !1,
            hasCommissions: !0
        },
        Sunize: {
            tutorial: "https://youtu.be/-0pT831q7Sc",
            hasToken: !1,
            hasCommissions: !0
        },
        Assiny: {
            tutorial: "https://youtu.be/KaC16LDHkG0",
            hasToken: !1,
            hasCommissions: !0
        },
        Wiapy: {
            tutorial: "https://youtu.be/gkceGI4GlSs",
            hasToken: !1,
            hasCommissions: !0
        },
        UnicoPag: {
            tutorial: "https://youtu.be/HlpTkWNHF18",
            hasToken: !1,
            hasCommissions: !0
        },
        ImperialPay: {
            tutorial: "https://youtu.be/alluNAqeMUI",
            hasToken: !1,
            hasCommissions: !0
        },
        Zedy: {
            tutorial: "https://youtu.be/Aaj50992JNc",
            hasToken: !1,
            hasCommissions: !0
        },
        Sinix: {
            tutorial: "https://youtu.be/ikzmYaIYdpQ",
            hasToken: !1,
            hasCommissions: !0
        },
        Voomp: {
            tutorial: "https://youtu.be/zEQUblE8bjs",
            hasToken: !1,
            hasCommissions: !0
        },
        Ombrelone: {
            tutorial: "https://youtu.be/DiwtzIEtCeM",
            hasToken: !1,
            hasCommissions: !0
        },
        PushinPay: {
            tutorial: "https://youtu.be/HU9iDrYwIos",
            hasToken: !1,
            hasCommissions: !0
        },
        Genesys: {
            tutorial: "https://youtu.be/7ZFwxcByBxM",
            hasToken: !1,
            hasCommissions: !0
        },
        OnProfit: {
            tutorial: "https://youtu.be/5Mh9c8QLWWU",
            hasToken: !1,
            hasCommissions: !0
        },
        SacaPay: {
            tutorial: "https://youtu.be/naBxo0pQ9oA",
            hasToken: !1,
            hasCommissions: !0
        },
        Cloudfy: {
            tutorial: "https://youtu.be/wxQf9qOoL3A",
            hasToken: !1,
            hasCommissions: !0
        },
        Kuenha: {
            tutorial: "https://youtu.be/Kz8KBZHwJMg",
            hasToken: !1,
            hasCommissions: !0
        },
        NinjaPay: {
            tutorial: "https://youtu.be/iVhMAEDeiIQ",
            hasToken: !1,
            hasCommissions: !0
        },
        Xgrow: {
            tutorial: "https://youtu.be/bsdMSGvcmls",
            hasToken: !1,
            hasCommissions: !0
        },
        ggCheckout: {
            tutorial: "https://youtu.be/10O_kuPS1v0",
            hasToken: !1,
            hasCommissions: !0
        },
        PanteraCheckout: {
            tutorial: "https://youtu.be/KWpbQGzrE1k",
            hasToken: !1,
            hasCommissions: !0
        },
        NublaPay: {
            tutorial: "https://youtu.be/nOmRzoAb_7k",
            hasToken: !1,
            hasCommissions: !0
        },
        Cartly: {
            tutorial: "https://youtu.be/RiJWYAX_6Aw",
            hasToken: !1,
            hasCommissions: !0
        },
        Pagah: {
            tutorial: "https://www.youtube.com/watch?v=ZUGKuYeGMZ4",
            hasToken: !1,
            hasCommissions: !0
        },
        Pagsafe: {
            tutorial: "https://youtu.be/rFN7Ie3QJsY",
            hasToken: !1,
            hasCommissions: !0
        },
        Nomadfy: {
            tutorial: "https://youtu.be/EKK_HEGtgQE",
            hasToken: !1,
            hasCommissions: !0
        },
        Sync: {
            tutorial: "https://youtu.be/H01itmf_4TE",
            hasToken: !1,
            hasCommissions: !0
        },
        LPQV: {
            tutorial: "https://youtu.be/KrHW8hVgRnc",
            hasToken: !1,
            hasCommissions: !0
        },
        Auryon369: {
            tutorial: "https://youtu.be/062LS29ULe0",
            hasToken: !1,
            hasCommissions: !0
        },
        Paradise: {
            tutorial: "https://www.youtube.com/watch?v=F55uOfelkE8",
            hasToken: !1,
            hasCommissions: !0
        },
        FirePay: {
            tutorial: "https://youtu.be/vBt4F25ourw",
            hasToken: !1,
            hasCommissions: !0
        },
        Lowify: {
            tutorial: "https://youtu.be/vATavJ33dQU",
            hasToken: !1,
            hasCommissions: !0
        },
        Hyppe: {
            tutorial: "https://youtu.be/g4j_xfFPMwg",
            hasToken: !1,
            hasCommissions: !0
        },
        Seedpay: {
            tutorial: "https://youtu.be/0J-Hrd76kpE",
            hasToken: !1,
            hasCommissions: !0
        },
        Membriz: {
            tutorial: "https://www.youtube.com/watch?v=WmscrslmNok",
            hasToken: !1,
            hasCommissions: !0
        },
        Cerefy: {
            tutorial: "https://www.youtube.com/watch?v=PbYrSNtRvIg",
            hasToken: !1,
            hasCommissions: !0
        }
    },
    h = (s, t = y) => {
        const e = t;
        return [...Object.values(a), ...Object.values(u)].filter(i => !e.includes(i))
    },
    C = s => ({ ...a,
        ...u
    })[s];
export {
    a as W, n as a, C as b, u as c, p as d, h as g, l as w
};