import {
    s as Y,
    d as y,
    a as P,
    m as d,
    i as C,
    b as p,
    q as V,
    c as E,
    e as A,
    g as B,
    f as O,
    h as w,
    j as z,
    t as R,
    k as Z,
    v as x,
    n as M,
    u as $,
    G as ee,
    F as Q
} from "./DDNnt9XD.js";
import {
    S as le,
    i as te,
    t as q,
    a as T,
    g as W,
    f as X,
    d as re,
    m as ne,
    c as ae,
    b as oe
} from "./qWASNxYk.js";
import {
    e as j
} from "./D4UMIlhj.js";
import {
    t as ie
} from "./BszCcFfc.js";
import {
    I as se
} from "./BtulAGCG.js";

function F(o, e, l) {
    const t = o.slice();
    return t[19] = e[l], t
}

function ce(o) {
    let e, l;
    return {
        c() {
            e = w("label"), l = R("‍"), this.h()
        },
        l(t) {
            e = E(t, "LABEL", {
                class: !0,
                for: !0
            });
            var a = A(e);
            l = O(a, "‍"), a.forEach(y), this.h()
        },
        h() {
            d(e, "class", "form-label"), d(e, "for", o[3])
        },
        m(t, a) {
            C(t, e, a), p(e, l)
        },
        p(t, a) {
            a & 8 && d(e, "for", t[3])
        },
        i: M,
        o: M,
        d(t) {
            t && y(e)
        }
    }
}

function ue(o) {
    let e, l, t, a, r, n = o[5] && G(o);
    return {
        c() {
            e = w("div"), l = w("label"), t = R(o[6]), a = z(), n && n.c(), this.h()
        },
        l(c) {
            e = E(c, "DIV", {
                class: !0
            });
            var f = A(e);
            l = E(f, "LABEL", {
                class: !0,
                for: !0
            });
            var k = A(l);
            t = O(k, o[6]), k.forEach(y), a = B(f), n && n.l(f), f.forEach(y), this.h()
        },
        h() {
            d(l, "class", "form-label overflow-x-hidden whitespace-nowrap text-ellipsis"), d(l, "for", o[3]), d(e, "class", "flex items-center !gap-1")
        },
        m(c, f) {
            C(c, e, f), p(e, l), p(l, t), p(e, a), n && n.m(e, null), r = !0
        },
        p(c, f) {
            (!r || f & 64) && P(t, c[6]), (!r || f & 8) && d(l, "for", c[3]), c[5] ? n ? (n.p(c, f), f & 32 && T(n, 1)) : (n = G(c), n.c(), T(n, 1), n.m(e, null)) : n && (W(), q(n, 1, 1, () => {
                n = null
            }), X())
        },
        i(c) {
            r || (T(n), r = !0)
        },
        o(c) {
            q(n), r = !1
        },
        d(c) {
            c && y(e), n && n.d()
        }
    }
}

function G(o) {
    let e, l, t;
    return l = new se({
        props: {
            margin: !1,
            text: o[5]
        }
    }), {
        c() {
            e = w("span"), oe(l.$$.fragment), this.h()
        },
        l(a) {
            e = E(a, "SPAN", {
                class: !0
            });
            var r = A(e);
            ae(l.$$.fragment, r), r.forEach(y), this.h()
        },
        h() {
            d(e, "class", "!-mt-[7px]")
        },
        m(a, r) {
            C(a, e, r), ne(l, e, null), t = !0
        },
        p(a, r) {
            const n = {};
            r & 32 && (n.text = a[5]), l.$set(n)
        },
        i(a) {
            t || (T(l.$$.fragment, a), t = !0)
        },
        o(a) {
            q(l.$$.fragment, a), t = !1
        },
        d(a) {
            a && y(e), re(l)
        }
    }
}

function H(o) {
    var m;
    let e, l, t, a, r, n, c, f, k, L, D, s = ((m = o[9]) == null ? void 0 : m.length) > 0 && J(o);
    return {
        c() {
            e = w("div"), l = w("label"), t = w("input"), r = z(), n = R(o[8]), f = z(), s && s.c(), this.h()
        },
        l(h) {
            e = E(h, "DIV", {
                class: !0,
                style: !0
            });
            var g = A(e);
            l = E(g, "LABEL", {
                class: !0
            });
            var _ = A(l);
            t = E(_, "INPUT", {
                type: !0,
                class: !0
            }), r = B(_), n = O(_, o[8]), _.forEach(y), f = B(g), s && s.l(g), g.forEach(y), this.h()
        },
        h() {
            var h, g;
            d(t, "type", "checkbox"), t.checked = a = o[0] == null, d(t, "class", "h-5 w-5 cursor-pointer mr-2 min-h-[16px] min-w-[16px] accent-primary"), d(l, "class", c = "flex py-1 px-[8px] cursor-pointer transition-colors duration-150 ease-in-out " + (((h = o[12]) == null ? void 0 : h.theme) === "Dark" ? "bg-card-dark  hover:bg-secondary" : "hover:bg-blue-100 hover:text-primary")), d(e, "class", k = (((g = o[12]) == null ? void 0 : g.theme) === "Dark" ? "bg-card-dark" : "bg-white") + " absolute inset-x-0 top-full z-10 w-full border border-t-0 rounded-b-sm4 -mt-0 max-h-80 overflow-y-auto"), $(e, "scrollbar-width", "thin")
        },
        m(h, g) {
            C(h, e, g), p(e, l), p(l, t), p(l, r), p(l, n), p(e, f), s && s.m(e, null), L || (D = V(t, "click", o[16]), L = !0)
        },
        p(h, g) {
            var _, I, b;
            g & 1 && a !== (a = h[0] == null) && (t.checked = a), g & 256 && P(n, h[8]), g & 4096 && c !== (c = "flex py-1 px-[8px] cursor-pointer transition-colors duration-150 ease-in-out " + (((_ = h[12]) == null ? void 0 : _.theme) === "Dark" ? "bg-card-dark  hover:bg-secondary" : "hover:bg-blue-100 hover:text-primary")) && d(l, "class", c), ((I = h[9]) == null ? void 0 : I.length) > 0 ? s ? s.p(h, g) : (s = J(h), s.c(), s.m(e, null)) : s && (s.d(1), s = null), g & 4096 && k !== (k = (((b = h[12]) == null ? void 0 : b.theme) === "Dark" ? "bg-card-dark" : "bg-white") + " absolute inset-x-0 top-full z-10 w-full border border-t-0 rounded-b-sm4 -mt-0 max-h-80 overflow-y-auto") && d(e, "class", k)
        },
        d(h) {
            h && y(e), s && s.d(), L = !1, D()
        }
    }
}

function J(o) {
    let e, l = j(o[9]),
        t = [];
    for (let a = 0; a < l.length; a += 1) t[a] = K(F(o, l, a));
    return {
        c() {
            for (let a = 0; a < t.length; a += 1) t[a].c();
            e = Q()
        },
        l(a) {
            for (let r = 0; r < t.length; r += 1) t[r].l(a);
            e = Q()
        },
        m(a, r) {
            for (let n = 0; n < t.length; n += 1) t[n] && t[n].m(a, r);
            C(a, e, r)
        },
        p(a, r) {
            if (r & 12801) {
                l = j(a[9]);
                let n;
                for (n = 0; n < l.length; n += 1) {
                    const c = F(a, l, n);
                    t[n] ? t[n].p(c, r) : (t[n] = K(c), t[n].c(), t[n].m(e.parentNode, e))
                }
                for (; n < t.length; n += 1) t[n].d(1);
                t.length = l.length
            }
        },
        d(a) {
            a && y(e), ee(t, a)
        }
    }
}

function K(o) {
    let e, l, t, a, r = o[19].label + "",
        n, c, f, k, L;

    function D() {
        return o[17](o[19])
    }
    return {
        c() {
            e = w("label"), l = w("input"), a = z(), n = R(r), c = z(), this.h()
        },
        l(s) {
            e = E(s, "LABEL", {
                class: !0
            });
            var m = A(e);
            l = E(m, "INPUT", {
                class: !0,
                type: !0
            }), a = B(m), n = O(m, r), c = B(m), m.forEach(y), this.h()
        },
        h() {
            var s;
            d(l, "class", "h-5 w-5 cursor-pointer mr-2 min-h-[16px] min-w-[16px] accent-primary"), d(l, "type", "checkbox"), l.checked = t = o[0] == null || o[0].includes(o[19].value), d(e, "class", f = "flex py-1 px-[8px] cursor-pointer transition-colors duration-150 ease-in-out " + (((s = o[12]) == null ? void 0 : s.theme) === "Dark" ? "bg-card-dark  hover:bg-secondary" : "hover:bg-blue-100 hover:text-primary"))
        },
        m(s, m) {
            C(s, e, m), p(e, l), p(e, a), p(e, n), p(e, c), k || (L = V(l, "click", D), k = !0)
        },
        p(s, m) {
            var h;
            o = s, m & 513 && t !== (t = o[0] == null || o[0].includes(o[19].value)) && (l.checked = t), m & 512 && r !== (r = o[19].label + "") && P(n, r), m & 4096 && f !== (f = "flex py-1 px-[8px] cursor-pointer transition-colors duration-150 ease-in-out " + (((h = o[12]) == null ? void 0 : h.theme) === "Dark" ? "bg-card-dark  hover:bg-secondary" : "hover:bg-blue-100 hover:text-primary")) && d(e, "class", f)
        },
        d(s) {
            s && y(e), k = !1, L()
        }
    }
}

function fe(o) {
    let e, l, t, a, r, n, c, f, k, L, D, s, m, h;
    const g = [ue, ce],
        _ = [];

    function I(u, v) {
        return u[6] ? 0 : u[4] ? 1 : -1
    }~(l = I(o)) && (t = _[l] = g[l](o));
    let b = o[11] && H(o);
    return {
        c() {
            e = w("div"), t && t.c(), a = z(), r = w("div"), n = w("button"), c = R(o[1]), k = z(), b && b.c(), this.h()
        },
        l(u) {
            e = E(u, "DIV", {
                class: !0
            });
            var v = A(e);
            t && t.l(v), a = B(v), r = E(v, "DIV", {
                class: !0,
                id: !0
            });
            var S = A(r);
            n = E(S, "BUTTON", {
                type: !0,
                class: !0
            });
            var i = A(n);
            c = O(i, o[1]), i.forEach(y), k = B(S), b && b.l(S), S.forEach(y), v.forEach(y), this.h()
        },
        h() {
            var u;
            d(n, "type", "button"), d(n, "class", f = "form-select !flex " + (o[11] ? "border-primary" : "border !border-gray") + " rounded-sm4 " + (((u = o[12]) == null ? void 0 : u.theme) === "Dark" ? "!bg-card-dark !text-[#D9DBDE]" : "!text-black") + " " + (o[10] ? "!rounded-l-none" : "") + " !font-ubermove"), d(r, "class", "relative"), d(r, "id", L = `multi-select-container-${o[7]}`), d(e, "class", D = o[2] ? "mb-1" : "")
        },
        m(u, v) {
            C(u, e, v), ~l && _[l].m(e, null), p(e, a), p(e, r), p(r, n), p(n, c), p(r, k), b && b.m(r, null), s = !0, m || (h = V(n, "click", o[15]), m = !0)
        },
        p(u, [v]) {
            var i;
            let S = l;
            l = I(u), l === S ? ~l && _[l].p(u, v) : (t && (W(), q(_[S], 1, 1, () => {
                _[S] = null
            }), X()), ~l ? (t = _[l], t ? t.p(u, v) : (t = _[l] = g[l](u), t.c()), T(t, 1), t.m(e, a)) : t = null), (!s || v & 2) && P(c, u[1]), (!s || v & 7168 && f !== (f = "form-select !flex " + (u[11] ? "border-primary" : "border !border-gray") + " rounded-sm4 " + (((i = u[12]) == null ? void 0 : i.theme) === "Dark" ? "!bg-card-dark !text-[#D9DBDE]" : "!text-black") + " " + (u[10] ? "!rounded-l-none" : "") + " !font-ubermove")) && d(n, "class", f), u[11] ? b ? b.p(u, v) : (b = H(u), b.c(), b.m(r, null)) : b && (b.d(1), b = null), (!s || v & 128 && L !== (L = `multi-select-container-${u[7]}`)) && d(r, "id", L), (!s || v & 4 && D !== (D = u[2] ? "mb-1" : "")) && d(e, "class", D)
        },
        i(u) {
            s || (T(t), s = !0)
        },
        o(u) {
            q(t), s = !1
        },
        d(u) {
            u && y(e), ~l && _[l].d(), b && b.d(), m = !1, h()
        }
    }
}

function he(o, e, l) {
    let t;
    Z(o, ie, i => l(12, t = i));
    let a = !1,
        {
            selectedValues: r = null
        } = e,
        {
            margin: n = !1
        } = e,
        {
            name: c
        } = e,
        {
            useLabelSize: f = !0
        } = e,
        {
            tooltip: k = null
        } = e,
        {
            label: L
        } = e,
        {
            id: D
        } = e,
        {
            selectAllLabel: s = "Selecionar todos"
        } = e,
        {
            placeholder: m = "Qualquer"
        } = e,
        {
            options: h
        } = e,
        {
            removeLeftRounded: g = !1
        } = e,
        {
            onChange: _ = () => {}
        } = e;

    function I(i) {
        if (i === "selectAll") {
            l(0, r = r == null ? [] : null), _(!1);
            return
        }
        const N = r ? ? h.map(U => U.value);
        if (N != null && N.includes(i)) {
            l(0, r = N.filter(U => U !== i)), _(!1);
            return
        }
        if (l(0, r = [...N, i]), (r == null ? void 0 : r.length) === h.length) {
            l(0, r = r == null ? [] : null), _(!1);
            return
        }
        _(!1)
    }

    function b(i) {
        i.target.closest(`#multi-select-container-${D}`) || (a && _(!0), l(11, a = !1))
    }
    x(() => (document.addEventListener("click", b), () => {
        document.removeEventListener("click", b)
    }));
    const u = () => {
            l(11, a = !a)
        },
        v = () => I("selectAll"),
        S = i => I(i.value);
    return o.$$set = i => {
        "selectedValues" in i && l(0, r = i.selectedValues), "margin" in i && l(2, n = i.margin), "name" in i && l(3, c = i.name), "useLabelSize" in i && l(4, f = i.useLabelSize), "tooltip" in i && l(5, k = i.tooltip), "label" in i && l(6, L = i.label), "id" in i && l(7, D = i.id), "selectAllLabel" in i && l(8, s = i.selectAllLabel), "placeholder" in i && l(1, m = i.placeholder), "options" in i && l(9, h = i.options), "removeLeftRounded" in i && l(10, g = i.removeLeftRounded), "onChange" in i && l(14, _ = i.onChange)
    }, o.$$.update = () => {
        o.$$.dirty & 1 && (r == null ? l(1, m = "Qualquer") : (r == null ? void 0 : r.length) === 0 ? l(1, m = "Nenhum") : l(1, m = `Selecionado${r.length>1?"s":""} (${r.length})`))
    }, [r, m, n, c, f, k, L, D, s, h, g, a, t, I, _, u, v, S]
}
class ke extends le {
    constructor(e) {
        super(), te(this, e, he, fe, Y, {
            selectedValues: 0,
            margin: 2,
            name: 3,
            useLabelSize: 4,
            tooltip: 5,
            label: 6,
            id: 7,
            selectAllLabel: 8,
            placeholder: 1,
            options: 9,
            removeLeftRounded: 10,
            onChange: 14
        })
    }
}
export {
    ke as S
};