import {
    n as i
} from "./CPi_hQE5.js";
import {
    d as l,
    t as f,
    e as M
} from "./DwsiLpv2.js";

function d(n) {
    return r => {
        const u = (n ? Math[n] : Math.trunc)(r);
        return u === 0 ? 0 : u
    }
}

function I(n, r, e) {
    const [u, t] = i(e == null ? void 0 : e.in, n, r), a = (+u - +t) / l;
    return d(e == null ? void 0 : e.roundingMethod)(a)
}

function c(n, r) {
    return +f(n) - +f(r)
}

function g(n, r, e) {
    const u = c(n, r) / M;
    return d(e == null ? void 0 : e.roundingMethod)(u)
}

function h(n, r, e) {
    const u = c(n, r) / 1e3;
    return d(e == null ? void 0 : e.roundingMethod)(u)
}
export {
    I as a, g as b, h as d
};