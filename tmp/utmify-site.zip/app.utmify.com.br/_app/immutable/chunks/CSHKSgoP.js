import {
    s as d,
    n as l,
    d as h,
    m as t,
    i as m,
    b as g,
    C as f,
    e as u,
    D as c
} from "./DDNnt9XD.js";
import {
    S as k,
    i as w
} from "./qWASNxYk.js";

function v(n) {
    let e, a, s;
    return {
        c() {
            e = c("svg"), a = c("path"), this.h()
        },
        l(i) {
            e = f(i, "svg", {
                xmlns: !0,
                width: !0,
                height: !0,
                fill: !0,
                viewBox: !0,
                stroke: !0,
                "stroke-width": !0,
                "stroke-linecap": !0,
                "stroke-linejoin": !0,
                class: !0
            });
            var r = u(e);
            a = f(r, "path", {
                d: !0
            }), u(a).forEach(h), r.forEach(h), this.h()
        },
        h() {
            t(a, "d", "M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"), t(e, "xmlns", "http://www.w3.org/2000/svg"), t(e, "width", n[0]), t(e, "height", n[0]), t(e, "fill", "none"), t(e, "viewBox", "0 0 24 24"), t(e, "stroke", "currentColor"), t(e, "stroke-width", n[1]), t(e, "stroke-linecap", "round"), t(e, "stroke-linejoin", "round"), t(e, "class", s = "feather feather-edit-2 " + n[2])
        },
        m(i, r) {
            m(i, e, r), g(e, a)
        },
        p(i, [r]) {
            r & 1 && t(e, "width", i[0]), r & 1 && t(e, "height", i[0]), r & 2 && t(e, "stroke-width", i[1]), r & 4 && s !== (s = "feather feather-edit-2 " + i[2]) && t(e, "class", s)
        },
        i: l,
        o: l,
        d(i) {
            i && h(e)
        }
    }
}

function _(n, e, a) {
    let {
        size: s = "24"
    } = e, {
        strokeWidth: i = 2
    } = e, {
        class: r = ""
    } = e;
    return s !== "100%" && (s = s.slice(-1) === "x" ? s.slice(0, s.length - 1) + "em" : parseInt(s) + "px"), n.$$set = o => {
        "size" in o && a(0, s = o.size), "strokeWidth" in o && a(1, i = o.strokeWidth), "class" in o && a(2, r = o.class)
    }, [s, i, r]
}
class E extends k {
    constructor(e) {
        super(), w(this, e, _, v, d, {
            size: 0,
            strokeWidth: 1,
            class: 2
        })
    }
}
export {
    E
};