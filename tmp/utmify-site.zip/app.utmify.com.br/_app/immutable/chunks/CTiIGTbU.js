import {
    s as B,
    d as A,
    i as z,
    F as H,
    a as q,
    b as i,
    q as G,
    m as _,
    c as S,
    e as T,
    f as u,
    g as X,
    h as g,
    t as m,
    j as N
} from "./DDNnt9XD.js";
import {
    S as J,
    i as K,
    t as F,
    a as O,
    g as M,
    f as Q,
    d as W,
    m as Y,
    c as Z,
    b as $
} from "./qWASNxYk.js";
import {
    S as ee
} from "./DwsiLpv2.js";
import {
    a as te
} from "./Dd0nEcXu.js";
import {
    X as ae
} from "./BtulAGCG.js";
const D = ee.createStore("tikTokSearchLimitAlert", null);
class v {
    static getObjectFromStorageOrCreate() {
        let e = null;
        if (D.subscribe(r => {
                e = r
            })(), e) return e;
        D.set({
            shouldAlert: !1,
            preventAlertUntil: null,
            alertDashboards: []
        });
        let a;
        return D.subscribe(r => {
            a = r
        })(), a
    }
    static shouldAlert(e) {
        const {
            shouldAlert: a,
            preventAlertUntil: r,
            alertDashboards: t
        } = v.getObjectFromStorageOrCreate();
        return !e || !t.includes(e) ? !1 : a && (!r || new Date().toISOString() > r)
    }
    static temporarilyCloseAlert() {
        D.set({
            shouldAlert: !1,
            preventAlertUntil: te(new Date, 24).toISOString(),
            alertDashboards: []
        })
    }
    static markDashboardAsAlertable(e) {
        if (!e) return;
        const a = v.getObjectFromStorageOrCreate();
        a.shouldAlert = !0, a.alertDashboards.includes(e) || a.alertDashboards.push(e), D.set(a)
    }
}

function R(l) {
    let e, a, r, t, s, o, d, y, w, P, I, j, x, k, f, h, p, E, L;
    return h = new ae({
        props: {
            class: "!w-[21px] !h-[21px] !cursor-pointer !stroke-[2px]"
        }
    }), {
        c() {
            e = g("div"), a = g("h4"), r = m(`Por limitações da API do TikTok Ads, buscamos somente os resultados
      das `), t = m(l[0]), s = m(" primeiras contas de anúncios que foram encontradas."), o = N(), d = g("div"), y = m("Considere filtrar apenas "), w = m(l[0]), P = m(` contas de anúncios ou deixar
      até `), I = m(l[0]), j = m(` contas de anúncios do TikTok habilitadas no dashboard
      para resultados mais precisos.`), x = N(), k = g("div"), f = g("div"), $(h.$$.fragment), this.h()
        },
        l(n) {
            e = S(n, "DIV", {
                class: !0,
                role: !0
            });
            var c = T(e);
            a = S(c, "H4", {
                class: !0
            });
            var C = T(a);
            r = u(C, `Por limitações da API do TikTok Ads, buscamos somente os resultados
      das `), t = u(C, l[0]), s = u(C, " primeiras contas de anúncios que foram encontradas."), C.forEach(A), o = X(c), d = S(c, "DIV", {
                class: !0
            });
            var b = T(d);
            y = u(b, "Considere filtrar apenas "), w = u(b, l[0]), P = u(b, ` contas de anúncios ou deixar
      até `), I = u(b, l[0]), j = u(b, ` contas de anúncios do TikTok habilitadas no dashboard
      para resultados mais precisos.`), b.forEach(A), x = X(c), k = S(c, "DIV", {
                class: !0
            });
            var V = T(k);
            f = S(V, "DIV", {
                class: !0
            });
            var U = T(f);
            Z(h.$$.fragment, U), U.forEach(A), V.forEach(A), c.forEach(A), this.h()
        },
        h() {
            _(a, "class", "alert-heading"), _(d, "class", "alert-body"), _(f, "class", "!w-[38px] !h-[38px] hover:bg-yellow-500 hover:bg-opacity-10 rounded-md flex flex-col justify-center items-center"), _(k, "class", "absolute right-2 top-0"), _(e, "class", "alert alert-warning"), _(e, "role", "alert")
        },
        m(n, c) {
            z(n, e, c), i(e, a), i(a, r), i(a, t), i(a, s), i(e, o), i(e, d), i(d, y), i(d, w), i(d, P), i(d, I), i(d, j), i(e, x), i(e, k), i(k, f), Y(h, f, null), p = !0, E || (L = G(f, "click", l[2]), E = !0)
        },
        p(n, c) {
            (!p || c & 1) && q(t, n[0]), (!p || c & 1) && q(w, n[0]), (!p || c & 1) && q(I, n[0])
        },
        i(n) {
            p || (O(h.$$.fragment, n), p = !0)
        },
        o(n) {
            F(h.$$.fragment, n), p = !1
        },
        d(n) {
            n && A(e), W(h), E = !1, L()
        }
    }
}

function se(l) {
    let e = l[0] && v.shouldAlert(l[1]),
        a, r, t = e && R(l);
    return {
        c() {
            t && t.c(), a = H()
        },
        l(s) {
            t && t.l(s), a = H()
        },
        m(s, o) {
            t && t.m(s, o), z(s, a, o), r = !0
        },
        p(s, [o]) {
            o & 3 && (e = s[0] && v.shouldAlert(s[1])), e ? t ? (t.p(s, o), o & 3 && O(t, 1)) : (t = R(s), t.c(), O(t, 1), t.m(a.parentNode, a)) : t && (M(), F(t, 1, 1, () => {
                t = null
            }), Q())
        },
        i(s) {
            r || (O(t), r = !0)
        },
        o(s) {
            F(t), r = !1
        },
        d(s) {
            s && A(a), t && t.d(s)
        }
    }
}

function re(l, e, a) {
    let {
        maxTikTokAdAccountsSearch: r
    } = e, {
        dashboardId: t
    } = e;
    const s = () => {
        v.temporarilyCloseAlert(), a(0, r = null)
    };
    return l.$$set = o => {
        "maxTikTokAdAccountsSearch" in o && a(0, r = o.maxTikTokAdAccountsSearch), "dashboardId" in o && a(1, t = o.dashboardId)
    }, [r, t, s]
}
class de extends J {
    constructor(e) {
        super(), K(this, e, re, se, B, {
            maxTikTokAdAccountsSearch: 0,
            dashboardId: 1
        })
    }
}
export {
    v as T, de as a
};