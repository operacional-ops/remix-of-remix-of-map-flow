import {
    S as t
} from "./DwsiLpv2.js";
const i = t.createStore("indication", null, {
    ttlInSeconds: 60 * 60 * 24 * 30
});
export {
    i
};