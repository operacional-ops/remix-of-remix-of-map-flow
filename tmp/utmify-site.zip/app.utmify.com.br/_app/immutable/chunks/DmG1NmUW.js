import {
    t as o
} from "./DwsiLpv2.js";

function e(t) {
    return t instanceof Date || typeof t == "object" && Object.prototype.toString.call(t) === "[object Date]"
}

function n(t) {
    return !(!e(t) && typeof t != "number" || isNaN(+o(t)))
}
export {
    n as i
};