import {
    S as r
} from "./DwsiLpv2.js";
const e = r.createStore("sidebarScroll", null);
export {
    e as s
};