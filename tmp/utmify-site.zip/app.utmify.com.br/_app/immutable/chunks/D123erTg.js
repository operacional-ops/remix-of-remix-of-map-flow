class o {
    static trackSignUpStart() {
        window.dataLayer.push({
            event: "sign_up_start"
        }), console.log("gtm sign_up_start")
    }
    static trackSignUp() {
        window.dataLayer.push({
            event: "sign_up"
        }), console.log("gtm sign_up")
    }
    static trackLogin() {
        window.dataLayer.push({
            event: "login"
        }), console.log("gtm login")
    }
    static trackConnectFacebook() {
        window.dataLayer.push({
            event: "connect_facebook"
        }), console.log("gtm connect_facebook")
    }
    static trackCreateWebhook() {
        window.dataLayer.push({
            event: "create_webhook"
        }), console.log("gtm create_webhook")
    }
    static trackCopyUtmsCode() {
        window.dataLayer.push({
            event: "copy_utms_code"
        }), console.log("gtm copy_utms_code")
    }
    static trackDownloadUtmsScript() {
        window.dataLayer.push({
            event: "download_utms_script"
        }), console.log("gtm download_utms_script")
    }
    static trackDownloadBackredirectScript() {
        window.dataLayer.push({
            event: "download_backredirect_script"
        }), console.log("gtm download_backredirect_script")
    }
    static trackWatchTutorial() {
        window.dataLayer.push({
            event: "watch_tutorial"
        }), console.log("gtm watch_tutorial")
    }
    static trackWatchTypebotTutorial() {
        window.dataLayer.push({
            event: "watch_typebot_tutorial"
        }), console.log("gtm watch_typebot_tutorial")
    }
    static trackWhatsappSupport() {
        window.dataLayer.push({
            event: "whatsapp_support"
        }), console.log("gtm whatsapp_support")
    }
    static trackHelpCenterSupport() {
        window.dataLayer.push({
            event: "help_center_support"
        }), console.log("gtm help_center_support")
    }
    static trackFinishUtmsConfig() {
        window.dataLayer.push({
            event: "finish_utms_config"
        }), console.log("gtm finish_utms_config")
    }
    static trackTalkToExpert() {
        window.dataLayer.push({
            event: "talk_to_expert"
        }), console.log("gtm talk_to_expert")
    }
    static trackEnabledAdAccount() {
        window.dataLayer.push({
            event: "enabled_ad_account"
        }), console.log("gtm enabled_ad_account")
    }
    static trackToggleAdObjectStatus() {
        window.dataLayer.push({
            event: "toggle_ad_object_status"
        }), console.log("gtm toggle_ad_object_status")
    }
    static trackDuplicateAdObject() {
        window.dataLayer.push({
            event: "duplicate_ad_object"
        }), console.log("gtm duplicate_ad_object")
    }
    static trackConfigTax() {
        window.dataLayer.push({
            event: "config_tax"
        }), console.log("gtm config_tax")
    }
    static trackConfigFee() {
        window.dataLayer.push({
            event: "config_fee"
        }), console.log("gtm config_fee")
    }
    static trackCreateDashboard() {
        window.dataLayer.push({
            event: "create_dashboard"
        }), console.log("gtm create_dashboard")
    }
    static trackPurchase(t) {
        window.dataLayer.push({
            event: "purchase",
            value: t,
            currency: "BRL"
        }), console.log(`gtm purchase: ${t} BRL`)
    }
}
export {
    o as G
};