import {
    D as s,
    g as l
} from "./BtulAGCG.js";
import {
    s as y,
    n as f,
    d as u,
    i as p,
    F as m,
    a as h,
    b as N,
    m as F,
    c as b,
    e as g,
    f as A,
    h as L,
    t as _
} from "./DDNnt9XD.js";
import {
    S as P,
    i as S
} from "./qWASNxYk.js";
class o {
    static currencyFromFloatOrDefault(r, e) {
        const t = e ? ? s.BRL;
        return r === void 0 ? `${l(t)} ...` : r === null ? "N/A" : o.formatCurrencyFromCents(r * 100, t)
    }
    static currencyFromCentsOrDefault(r, e) {
        const t = e ? ? s.BRL;
        return r === void 0 ? `${l(t)} ...` : r === null ? "N/A" : o.formatCurrencyFromCents(r, t)
    }
    static centsFromCurrencyString(r) {
        const e = r.includes("-"),
            t = o.numberFromCurrencyString(r);
        if (t === null) return null;
        const n = t * 100;
        return e ? -n : n
    }
    static numberFromCurrencyString(r) {
        const e = r.includes("R$"),
            t = r.includes("-"),
            n = r.replace(/[^\d.,]/g, ""),
            c = e ? n.replaceAll(".", "").replaceAll(",", ".") : n.replaceAll(",", ""),
            i = parseFloat(c);
        return Number.isNaN(i) ? null : t ? -i : i
    }
    static formatCurrencyFromCents(r, e) {
        if (r === void 0) return "";
        const t = typeof r == "string" ? parseFloat(r) / 100 : r / 100,
            n = o.getLocaleForCurrency(e),
            c = t.toLocaleString(n, {
                style: "currency",
                currency: e
            });
        if (c.charAt(0) === "-") {
            const i = c.split("").findIndex(C => !Number.isNaN(parseInt(C, 10)));
            return `${l(e)} -${c.substring(i)}`
        }
        return c
    }
    static getLocaleForCurrency(r) {
        switch (r) {
            case s.BRL:
                return "pt-BR";
            case s.COP:
                return "es-CO";
            case s.MXN:
                return "es-MX";
            case s.PYG:
                return "es-PY";
            case s.CLP:
                return "es-CL";
            case s.PEN:
                return "es-PE";
            case s.PLN:
                return "pl-PL";
            case s.UAH:
                return "uk-UA";
            case s.CHF:
                return "de-CH";
            case s.THB:
                return "th-TH";
            case s.AUD:
                return "en-AU";
            default:
                return "en-US"
        }
    }
}

function d(a) {
    let r, e;
    return {
        c() {
            r = L("div"), e = _(a[0]), this.h()
        },
        l(t) {
            r = b(t, "DIV", {
                class: !0
            });
            var n = g(r);
            e = A(n, a[0]), n.forEach(u), this.h()
        },
        h() {
            F(r, "class", "text-error text-sm font-normal")
        },
        m(t, n) {
            p(t, r, n), N(r, e)
        },
        p(t, n) {
            n & 1 && h(e, t[0])
        },
        d(t) {
            t && u(r)
        }
    }
}

function B(a) {
    let r, e = a[0] && d(a);
    return {
        c() {
            e && e.c(), r = m()
        },
        l(t) {
            e && e.l(t), r = m()
        },
        m(t, n) {
            e && e.m(t, n), p(t, r, n)
        },
        p(t, [n]) {
            t[0] ? e ? e.p(t, n) : (e = d(t), e.c(), e.m(r.parentNode, r)) : e && (e.d(1), e = null)
        },
        i: f,
        o: f,
        d(t) {
            t && u(r), e && e.d(t)
        }
    }
}

function D(a, r, e) {
    let {
        error: t
    } = r;
    return a.$$set = n => {
        "error" in n && e(0, t = n.error)
    }, [t]
}
class R extends P {
    constructor(r) {
        super(), S(this, r, D, B, y, {
            error: 0
        })
    }
}
export {
    o as F, R as I
};