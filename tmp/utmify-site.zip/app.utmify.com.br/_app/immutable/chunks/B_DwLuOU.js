import {
    r as on,
    b as vt,
    g as an
} from "./DwsiLpv2.js";
var ce = {
        exports: {}
    },
    se = Object,
    ln = Error,
    un = EvalError,
    fn = RangeError,
    cn = ReferenceError,
    pe = SyntaxError,
    $ = TypeError,
    sn = URIError,
    ye = Math.abs,
    ve = Math.floor,
    pn = Math.max,
    ge = Math.min,
    yn = Math.pow,
    vn = Math.round,
    Qr = Number.isNaN || function(r) {
        return r !== r
    },
    gn = Qr,
    dn = function(r) {
        return gn(r) || r === 0 ? r : r < 0 ? -1 : 1
    },
    hn = Object.getOwnPropertyDescriptor,
    ir = hn;
if (ir) try {
    ir([], "length")
} catch {
    ir = null
}
var Z = ir,
    lr = Object.defineProperty || !1;
if (lr) try {
    lr({}, "a", {
        value: 1
    })
} catch {
    lr = !1
}
var gr = lr,
    de = function() {
        if (typeof Symbol != "function" || typeof Object.getOwnPropertySymbols != "function") return !1;
        if (typeof Symbol.iterator == "symbol") return !0;
        var r = {},
            t = Symbol("test"),
            n = Object(t);
        if (typeof t == "string" || Object.prototype.toString.call(t) !== "[object Symbol]" || Object.prototype.toString.call(n) !== "[object Symbol]") return !1;
        var o = 42;
        r[t] = o;
        for (var a in r) return !1;
        if (typeof Object.keys == "function" && Object.keys(r).length !== 0 || typeof Object.getOwnPropertyNames == "function" && Object.getOwnPropertyNames(r).length !== 0) return !1;
        var i = Object.getOwnPropertySymbols(r);
        if (i.length !== 1 || i[0] !== t || !Object.prototype.propertyIsEnumerable.call(r, t)) return !1;
        if (typeof Object.getOwnPropertyDescriptor == "function") {
            var f = Object.getOwnPropertyDescriptor(r, t);
            if (f.value !== o || f.enumerable !== !0) return !1
        }
        return !0
    },
    gt = typeof Symbol < "u" && Symbol,
    mn = de,
    he = function() {
        return typeof gt != "function" || typeof Symbol != "function" || typeof gt("foo") != "symbol" || typeof Symbol("bar") != "symbol" ? !1 : mn()
    },
    br, dt;

function me() {
    return dt || (dt = 1, br = typeof Reflect < "u" && Reflect.getPrototypeOf || null), br
}
var Ar, ht;

function $e() {
    if (ht) return Ar;
    ht = 1;
    var e = se;
    return Ar = e.getPrototypeOf || null, Ar
}
var $n = "Function.prototype.bind called on incompatible ",
    Sn = Object.prototype.toString,
    bn = Math.max,
    An = "[object Function]",
    mt = function(r, t) {
        for (var n = [], o = 0; o < r.length; o += 1) n[o] = r[o];
        for (var a = 0; a < t.length; a += 1) n[a + r.length] = t[a];
        return n
    },
    wn = function(r, t) {
        for (var n = [], o = t, a = 0; o < r.length; o += 1, a += 1) n[a] = r[o];
        return n
    },
    On = function(e, r) {
        for (var t = "", n = 0; n < e.length; n += 1) t += e[n], n + 1 < e.length && (t += r);
        return t
    },
    Pn = function(r) {
        var t = this;
        if (typeof t != "function" || Sn.apply(t) !== An) throw new TypeError($n + t);
        for (var n = wn(arguments, 1), o, a = function() {
                if (this instanceof o) {
                    var y = t.apply(this, mt(n, arguments));
                    return Object(y) === y ? y : this
                }
                return t.apply(r, mt(n, arguments))
            }, i = bn(0, t.length - n.length), f = [], l = 0; l < i; l++) f[l] = "$" + l;
        if (o = Function("binder", "return function (" + On(f, ",") + "){ return binder.apply(this,arguments); }")(a), t.prototype) {
            var v = function() {};
            v.prototype = t.prototype, o.prototype = new v, v.prototype = null
        }
        return o
    },
    En = Pn,
    rr = Function.prototype.bind || En,
    Zr = Function.prototype.call,
    rt = Function.prototype.apply,
    In = typeof Reflect < "u" && Reflect && Reflect.apply,
    Fn = rr,
    Tn = rt,
    xn = Zr,
    Rn = In,
    Se = Rn || Fn.call(xn, Tn),
    Dn = rr,
    Nn = $,
    Bn = Zr,
    _n = Se,
    tt = function(r) {
        if (r.length < 1 || typeof r[0] != "function") throw new Nn("a function is required");
        return _n(Dn, Bn, r)
    },
    wr, $t;

function Cn() {
    if ($t) return wr;
    $t = 1;
    var e = tt,
        r = Z,
        t;
    try {
        t = [].__proto__ === Array.prototype
    } catch (i) {
        if (!i || typeof i != "object" || !("code" in i) || i.code !== "ERR_PROTO_ACCESS") throw i
    }
    var n = !!t && r && r(Object.prototype, "__proto__"),
        o = Object,
        a = o.getPrototypeOf;
    return wr = n && typeof n.get == "function" ? e([n.get]) : typeof a == "function" ? function(f) {
        return a(f == null ? f : o(f))
    } : !1, wr
}
var Or, St;

function Mn() {
    if (St) return Or;
    St = 1;
    var e = me(),
        r = $e(),
        t = Cn();
    return Or = e ? function(o) {
        return e(o)
    } : r ? function(o) {
        if (!o || typeof o != "object" && typeof o != "function") throw new TypeError("getProto: not an object");
        return r(o)
    } : t ? function(o) {
        return t(o)
    } : null, Or
}
var Gn = Function.prototype.call,
    Wn = Object.prototype.hasOwnProperty,
    Ln = rr,
    be = Ln.call(Gn, Wn),
    p, Un = se,
    qn = ln,
    kn = un,
    jn = fn,
    Kn = cn,
    j = pe,
    k = $,
    zn = sn,
    Hn = ye,
    Jn = ve,
    Vn = pn,
    Yn = ge,
    Xn = yn,
    Qn = vn,
    Zn = dn,
    Ae = Function,
    Pr = function(e) {
        try {
            return Ae('"use strict"; return (' + e + ").constructor;")()
        } catch {}
    },
    Q = Z,
    ro = gr,
    Er = function() {
        throw new k
    },
    to = Q ? function() {
        try {
            return arguments.callee, Er
        } catch {
            try {
                return Q(arguments, "callee").get
            } catch {
                return Er
            }
        }
    }() : Er,
    W = he(),
    h = Mn(),
    eo = $e(),
    no = me(),
    we = rt,
    tr = Zr,
    U = {},
    oo = typeof Uint8Array > "u" || !h ? p : h(Uint8Array),
    _ = {
        __proto__: null,
        "%AggregateError%": typeof AggregateError > "u" ? p : AggregateError,
        "%Array%": Array,
        "%ArrayBuffer%": typeof ArrayBuffer > "u" ? p : ArrayBuffer,
        "%ArrayIteratorPrototype%": W && h ? h([][Symbol.iterator]()) : p,
        "%AsyncFromSyncIteratorPrototype%": p,
        "%AsyncFunction%": U,
        "%AsyncGenerator%": U,
        "%AsyncGeneratorFunction%": U,
        "%AsyncIteratorPrototype%": U,
        "%Atomics%": typeof Atomics > "u" ? p : Atomics,
        "%BigInt%": typeof BigInt > "u" ? p : BigInt,
        "%BigInt64Array%": typeof BigInt64Array > "u" ? p : BigInt64Array,
        "%BigUint64Array%": typeof BigUint64Array > "u" ? p : BigUint64Array,
        "%Boolean%": Boolean,
        "%DataView%": typeof DataView > "u" ? p : DataView,
        "%Date%": Date,
        "%decodeURI%": decodeURI,
        "%decodeURIComponent%": decodeURIComponent,
        "%encodeURI%": encodeURI,
        "%encodeURIComponent%": encodeURIComponent,
        "%Error%": qn,
        "%eval%": eval,
        "%EvalError%": kn,
        "%Float16Array%": typeof Float16Array > "u" ? p : Float16Array,
        "%Float32Array%": typeof Float32Array > "u" ? p : Float32Array,
        "%Float64Array%": typeof Float64Array > "u" ? p : Float64Array,
        "%FinalizationRegistry%": typeof FinalizationRegistry > "u" ? p : FinalizationRegistry,
        "%Function%": Ae,
        "%GeneratorFunction%": U,
        "%Int8Array%": typeof Int8Array > "u" ? p : Int8Array,
        "%Int16Array%": typeof Int16Array > "u" ? p : Int16Array,
        "%Int32Array%": typeof Int32Array > "u" ? p : Int32Array,
        "%isFinite%": isFinite,
        "%isNaN%": isNaN,
        "%IteratorPrototype%": W && h ? h(h([][Symbol.iterator]())) : p,
        "%JSON%": typeof JSON == "object" ? JSON : p,
        "%Map%": typeof Map > "u" ? p : Map,
        "%MapIteratorPrototype%": typeof Map > "u" || !W || !h ? p : h(new Map()[Symbol.iterator]()),
        "%Math%": Math,
        "%Number%": Number,
        "%Object%": Un,
        "%Object.getOwnPropertyDescriptor%": Q,
        "%parseFloat%": parseFloat,
        "%parseInt%": parseInt,
        "%Promise%": typeof Promise > "u" ? p : Promise,
        "%Proxy%": typeof Proxy > "u" ? p : Proxy,
        "%RangeError%": jn,
        "%ReferenceError%": Kn,
        "%Reflect%": typeof Reflect > "u" ? p : Reflect,
        "%RegExp%": RegExp,
        "%Set%": typeof Set > "u" ? p : Set,
        "%SetIteratorPrototype%": typeof Set > "u" || !W || !h ? p : h(new Set()[Symbol.iterator]()),
        "%SharedArrayBuffer%": typeof SharedArrayBuffer > "u" ? p : SharedArrayBuffer,
        "%String%": String,
        "%StringIteratorPrototype%": W && h ? h("" [Symbol.iterator]()) : p,
        "%Symbol%": W ? Symbol : p,
        "%SyntaxError%": j,
        "%ThrowTypeError%": to,
        "%TypedArray%": oo,
        "%TypeError%": k,
        "%Uint8Array%": typeof Uint8Array > "u" ? p : Uint8Array,
        "%Uint8ClampedArray%": typeof Uint8ClampedArray > "u" ? p : Uint8ClampedArray,
        "%Uint16Array%": typeof Uint16Array > "u" ? p : Uint16Array,
        "%Uint32Array%": typeof Uint32Array > "u" ? p : Uint32Array,
        "%URIError%": zn,
        "%WeakMap%": typeof WeakMap > "u" ? p : WeakMap,
        "%WeakRef%": typeof WeakRef > "u" ? p : WeakRef,
        "%WeakSet%": typeof WeakSet > "u" ? p : WeakSet,
        "%Function.prototype.call%": tr,
        "%Function.prototype.apply%": we,
        "%Object.defineProperty%": ro,
        "%Object.getPrototypeOf%": eo,
        "%Math.abs%": Hn,
        "%Math.floor%": Jn,
        "%Math.max%": Vn,
        "%Math.min%": Yn,
        "%Math.pow%": Xn,
        "%Math.round%": Qn,
        "%Math.sign%": Zn,
        "%Reflect.getPrototypeOf%": no
    };
if (h) try {
    null.error
} catch (e) {
    var ao = h(h(e));
    _["%Error.prototype%"] = ao
}
var io = function e(r) {
        var t;
        if (r === "%AsyncFunction%") t = Pr("async function () {}");
        else if (r === "%GeneratorFunction%") t = Pr("function* () {}");
        else if (r === "%AsyncGeneratorFunction%") t = Pr("async function* () {}");
        else if (r === "%AsyncGenerator%") {
            var n = e("%AsyncGeneratorFunction%");
            n && (t = n.prototype)
        } else if (r === "%AsyncIteratorPrototype%") {
            var o = e("%AsyncGenerator%");
            o && h && (t = h(o.prototype))
        }
        return _[r] = t, t
    },
    bt = {
        __proto__: null,
        "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
        "%ArrayPrototype%": ["Array", "prototype"],
        "%ArrayProto_entries%": ["Array", "prototype", "entries"],
        "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
        "%ArrayProto_keys%": ["Array", "prototype", "keys"],
        "%ArrayProto_values%": ["Array", "prototype", "values"],
        "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
        "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
        "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
        "%BooleanPrototype%": ["Boolean", "prototype"],
        "%DataViewPrototype%": ["DataView", "prototype"],
        "%DatePrototype%": ["Date", "prototype"],
        "%ErrorPrototype%": ["Error", "prototype"],
        "%EvalErrorPrototype%": ["EvalError", "prototype"],
        "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
        "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
        "%FunctionPrototype%": ["Function", "prototype"],
        "%Generator%": ["GeneratorFunction", "prototype"],
        "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
        "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
        "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
        "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
        "%JSONParse%": ["JSON", "parse"],
        "%JSONStringify%": ["JSON", "stringify"],
        "%MapPrototype%": ["Map", "prototype"],
        "%NumberPrototype%": ["Number", "prototype"],
        "%ObjectPrototype%": ["Object", "prototype"],
        "%ObjProto_toString%": ["Object", "prototype", "toString"],
        "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
        "%PromisePrototype%": ["Promise", "prototype"],
        "%PromiseProto_then%": ["Promise", "prototype", "then"],
        "%Promise_all%": ["Promise", "all"],
        "%Promise_reject%": ["Promise", "reject"],
        "%Promise_resolve%": ["Promise", "resolve"],
        "%RangeErrorPrototype%": ["RangeError", "prototype"],
        "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
        "%RegExpPrototype%": ["RegExp", "prototype"],
        "%SetPrototype%": ["Set", "prototype"],
        "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
        "%StringPrototype%": ["String", "prototype"],
        "%SymbolPrototype%": ["Symbol", "prototype"],
        "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
        "%TypedArrayPrototype%": ["TypedArray", "prototype"],
        "%TypeErrorPrototype%": ["TypeError", "prototype"],
        "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
        "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
        "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
        "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
        "%URIErrorPrototype%": ["URIError", "prototype"],
        "%WeakMapPrototype%": ["WeakMap", "prototype"],
        "%WeakSetPrototype%": ["WeakSet", "prototype"]
    },
    er = rr,
    sr = be,
    lo = er.call(tr, Array.prototype.concat),
    uo = er.call(we, Array.prototype.splice),
    At = er.call(tr, String.prototype.replace),
    pr = er.call(tr, String.prototype.slice),
    fo = er.call(tr, RegExp.prototype.exec),
    co = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g,
    so = /\\(\\)?/g,
    po = function(r) {
        var t = pr(r, 0, 1),
            n = pr(r, -1);
        if (t === "%" && n !== "%") throw new j("invalid intrinsic syntax, expected closing `%`");
        if (n === "%" && t !== "%") throw new j("invalid intrinsic syntax, expected opening `%`");
        var o = [];
        return At(r, co, function(a, i, f, l) {
            o[o.length] = f ? At(l, so, "$1") : i || a
        }), o
    },
    yo = function(r, t) {
        var n = r,
            o;
        if (sr(bt, n) && (o = bt[n], n = "%" + o[0] + "%"), sr(_, n)) {
            var a = _[n];
            if (a === U && (a = io(n)), typeof a > "u" && !t) throw new k("intrinsic " + r + " exists, but is not available. Please file an issue!");
            return {
                alias: o,
                name: n,
                value: a
            }
        }
        throw new j("intrinsic " + r + " does not exist!")
    },
    T = function(r, t) {
        if (typeof r != "string" || r.length === 0) throw new k("intrinsic name must be a non-empty string");
        if (arguments.length > 1 && typeof t != "boolean") throw new k('"allowMissing" argument must be a boolean');
        if (fo(/^%?[^%]*%?$/, r) === null) throw new j("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
        var n = po(r),
            o = n.length > 0 ? n[0] : "",
            a = yo("%" + o + "%", t),
            i = a.name,
            f = a.value,
            l = !1,
            v = a.alias;
        v && (o = v[0], uo(n, lo([0, 1], v)));
        for (var y = 1, s = !0; y < n.length; y += 1) {
            var u = n[y],
                c = pr(u, 0, 1),
                d = pr(u, -1);
            if ((c === '"' || c === "'" || c === "`" || d === '"' || d === "'" || d === "`") && c !== d) throw new j("property names with quotes must have matching quotes");
            if ((u === "constructor" || !s) && (l = !0), o += "." + u, i = "%" + o + "%", sr(_, i)) f = _[i];
            else if (f != null) {
                if (!(u in f)) {
                    if (!t) throw new k("base intrinsic for " + r + " exists, but the property is not available.");
                    return
                }
                if (Q && y + 1 >= n.length) {
                    var g = Q(f, u);
                    s = !!g, s && "get" in g && !("originalValue" in g.get) ? f = g.get : f = f[u]
                } else s = sr(f, u), f = f[u];
                s && !l && (_[i] = f)
            }
        }
        return f
    },
    wt = gr,
    vo = pe,
    L = $,
    Ot = Z,
    et = function(r, t, n) {
        if (!r || typeof r != "object" && typeof r != "function") throw new L("`obj` must be an object or a function`");
        if (typeof t != "string" && typeof t != "symbol") throw new L("`property` must be a string or a symbol`");
        if (arguments.length > 3 && typeof arguments[3] != "boolean" && arguments[3] !== null) throw new L("`nonEnumerable`, if provided, must be a boolean or null");
        if (arguments.length > 4 && typeof arguments[4] != "boolean" && arguments[4] !== null) throw new L("`nonWritable`, if provided, must be a boolean or null");
        if (arguments.length > 5 && typeof arguments[5] != "boolean" && arguments[5] !== null) throw new L("`nonConfigurable`, if provided, must be a boolean or null");
        if (arguments.length > 6 && typeof arguments[6] != "boolean") throw new L("`loose`, if provided, must be a boolean");
        var o = arguments.length > 3 ? arguments[3] : null,
            a = arguments.length > 4 ? arguments[4] : null,
            i = arguments.length > 5 ? arguments[5] : null,
            f = arguments.length > 6 ? arguments[6] : !1,
            l = !!Ot && Ot(r, t);
        if (wt) wt(r, t, {
            configurable: i === null && l ? l.configurable : !i,
            enumerable: o === null && l ? l.enumerable : !o,
            value: n,
            writable: a === null && l ? l.writable : !a
        });
        else if (f || !o && !a && !i) r[t] = n;
        else throw new vo("This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.")
    },
    qr = gr,
    Oe = function() {
        return !!qr
    };
Oe.hasArrayLengthDefineBug = function() {
    if (!qr) return null;
    try {
        return qr([], "length", {
            value: 1
        }).length !== 1
    } catch {
        return !0
    }
};
var nt = Oe,
    go = T,
    Pt = et,
    ho = nt(),
    Et = Z,
    It = $,
    mo = go("%Math.floor%"),
    $o = function(r, t) {
        if (typeof r != "function") throw new It("`fn` is not a function");
        if (typeof t != "number" || t < 0 || t > 4294967295 || mo(t) !== t) throw new It("`length` must be a positive 32-bit integer");
        var n = arguments.length > 2 && !!arguments[2],
            o = !0,
            a = !0;
        if ("length" in r && Et) {
            var i = Et(r, "length");
            i && !i.configurable && (o = !1), i && !i.writable && (a = !1)
        }
        return (o || a || !n) && (ho ? Pt(r, "length", t, !0, !0) : Pt(r, "length", t)), r
    },
    So = rr,
    bo = rt,
    Ao = Se,
    wo = function() {
        return Ao(So, bo, arguments)
    };
(function(e) {
    var r = $o,
        t = gr,
        n = tt,
        o = wo;
    e.exports = function(i) {
        var f = n(arguments),
            l = i.length - (arguments.length - 1);
        return r(f, 1 + (l > 0 ? l : 0), !0)
    }, t ? t(e.exports, "apply", {
        value: o
    }) : e.exports.apply = o
})(ce);
var ot = ce.exports,
    Ft = Object.prototype.toString,
    Pe = function(r) {
        var t = Ft.call(r),
            n = t === "[object Arguments]";
        return n || (n = t !== "[object Array]" && r !== null && typeof r == "object" && typeof r.length == "number" && r.length >= 0 && Ft.call(r.callee) === "[object Function]"), n
    },
    Ir, Tt;

function Oo() {
    if (Tt) return Ir;
    Tt = 1;
    var e;
    if (!Object.keys) {
        var r = Object.prototype.hasOwnProperty,
            t = Object.prototype.toString,
            n = Pe,
            o = Object.prototype.propertyIsEnumerable,
            a = !o.call({
                toString: null
            }, "toString"),
            i = o.call(function() {}, "prototype"),
            f = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"],
            l = function(u) {
                var c = u.constructor;
                return c && c.prototype === u
            },
            v = {
                $applicationCache: !0,
                $console: !0,
                $external: !0,
                $frame: !0,
                $frameElement: !0,
                $frames: !0,
                $innerHeight: !0,
                $innerWidth: !0,
                $onmozfullscreenchange: !0,
                $onmozfullscreenerror: !0,
                $outerHeight: !0,
                $outerWidth: !0,
                $pageXOffset: !0,
                $pageYOffset: !0,
                $parent: !0,
                $scrollLeft: !0,
                $scrollTop: !0,
                $scrollX: !0,
                $scrollY: !0,
                $self: !0,
                $webkitIndexedDB: !0,
                $webkitStorageInfo: !0,
                $window: !0
            },
            y = function() {
                if (typeof window > "u") return !1;
                for (var u in window) try {
                    if (!v["$" + u] && r.call(window, u) && window[u] !== null && typeof window[u] == "object") try {
                        l(window[u])
                    } catch {
                        return !0
                    }
                } catch {
                    return !0
                }
                return !1
            }(),
            s = function(u) {
                if (typeof window > "u" || !y) return l(u);
                try {
                    return l(u)
                } catch {
                    return !1
                }
            };
        e = function(c) {
            var d = c !== null && typeof c == "object",
                g = t.call(c) === "[object Function]",
                m = n(c),
                S = d && t.call(c) === "[object String]",
                b = [];
            if (!d && !g && !m) throw new TypeError("Object.keys called on a non-object");
            var O = i && g;
            if (S && c.length > 0 && !r.call(c, 0))
                for (var P = 0; P < c.length; ++P) b.push(String(P));
            if (m && c.length > 0)
                for (var R = 0; R < c.length; ++R) b.push(String(R));
            else
                for (var M in c) !(O && M === "prototype") && r.call(c, M) && b.push(String(M));
            if (a)
                for (var z = s(c), D = 0; D < f.length; ++D) !(z && f[D] === "constructor") && r.call(c, f[D]) && b.push(f[D]);
            return b
        }
    }
    return Ir = e, Ir
}
var Po = Array.prototype.slice,
    Eo = Pe,
    xt = Object.keys,
    ur = xt ? function(r) {
        return xt(r)
    } : Oo(),
    Rt = Object.keys;
ur.shim = function() {
    if (Object.keys) {
        var r = function() {
            var t = Object.keys(arguments);
            return t && t.length === arguments.length
        }(1, 2);
        r || (Object.keys = function(n) {
            return Eo(n) ? Rt(Po.call(n)) : Rt(n)
        })
    } else Object.keys = ur;
    return Object.keys || ur
};
var Io = ur,
    Fo = Io,
    To = typeof Symbol == "function" && typeof Symbol("foo") == "symbol",
    xo = Object.prototype.toString,
    Ro = Array.prototype.concat,
    Dt = et,
    Do = function(e) {
        return typeof e == "function" && xo.call(e) === "[object Function]"
    },
    Ee = nt(),
    No = function(e, r, t, n) {
        if (r in e) {
            if (n === !0) {
                if (e[r] === t) return
            } else if (!Do(n) || !n()) return
        }
        Ee ? Dt(e, r, t, !0) : Dt(e, r, t)
    },
    Ie = function(e, r) {
        var t = arguments.length > 2 ? arguments[2] : {},
            n = Fo(r);
        To && (n = Ro.call(n, Object.getOwnPropertySymbols(r)));
        for (var o = 0; o < n.length; o += 1) No(e, n[o], r[n[o]], t[n[o]])
    };
Ie.supportsDescriptors = !!Ee;
var at = Ie,
    Fe = T,
    Te = tt,
    Bo = Te([Fe("%String.prototype.indexOf%")]),
    x = function(r, t) {
        var n = Fe(r, !!t);
        return typeof n == "function" && Bo(r, ".prototype.") > -1 ? Te([n]) : n
    },
    _o = T,
    xe = _o("%Array%"),
    Co = !xe.isArray && x("Object.prototype.toString"),
    Mo = xe.isArray || function(r) {
        return Co(r) === "[object Array]"
    },
    Re = Mo,
    Go = T,
    Wo = x,
    Lo = $,
    Uo = Re,
    qo = Go("%Reflect.apply%", !0) || Wo("Function.prototype.apply"),
    ko = function(r, t) {
        var n = arguments.length > 2 ? arguments[2] : [];
        if (!Uo(n)) throw new Lo("Assertion failed: optional `argumentsList`, if provided, must be a List");
        return qo(r, t, n)
    },
    it = typeof Map == "function" && Map.prototype,
    Fr = Object.getOwnPropertyDescriptor && it ? Object.getOwnPropertyDescriptor(Map.prototype, "size") : null,
    yr = it && Fr && typeof Fr.get == "function" ? Fr.get : null,
    Nt = it && Map.prototype.forEach,
    lt = typeof Set == "function" && Set.prototype,
    Tr = Object.getOwnPropertyDescriptor && lt ? Object.getOwnPropertyDescriptor(Set.prototype, "size") : null,
    vr = lt && Tr && typeof Tr.get == "function" ? Tr.get : null,
    Bt = lt && Set.prototype.forEach,
    jo = typeof WeakMap == "function" && WeakMap.prototype,
    V = jo ? WeakMap.prototype.has : null,
    Ko = typeof WeakSet == "function" && WeakSet.prototype,
    Y = Ko ? WeakSet.prototype.has : null,
    zo = typeof WeakRef == "function" && WeakRef.prototype,
    _t = zo ? WeakRef.prototype.deref : null,
    Ho = Boolean.prototype.valueOf,
    Jo = Object.prototype.toString,
    Vo = Function.prototype.toString,
    Yo = String.prototype.match,
    ut = String.prototype.slice,
    N = String.prototype.replace,
    Xo = String.prototype.toUpperCase,
    Ct = String.prototype.toLowerCase,
    De = RegExp.prototype.test,
    Mt = Array.prototype.concat,
    w = Array.prototype.join,
    Qo = Array.prototype.slice,
    Gt = Math.floor,
    kr = typeof BigInt == "function" ? BigInt.prototype.valueOf : null,
    xr = Object.getOwnPropertySymbols,
    jr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? Symbol.prototype.toString : null,
    K = typeof Symbol == "function" && typeof Symbol.iterator == "object",
    X = typeof Symbol == "function" && Symbol.toStringTag && (typeof Symbol.toStringTag === K || !0) ? Symbol.toStringTag : null,
    Ne = Object.prototype.propertyIsEnumerable,
    Wt = (typeof Reflect == "function" ? Reflect.getPrototypeOf : Object.getPrototypeOf) || ([].__proto__ === Array.prototype ? function(e) {
        return e.__proto__
    } : null);

function Lt(e, r) {
    if (e === 1 / 0 || e === -1 / 0 || e !== e || e && e > -1e3 && e < 1e3 || De.call(/e/, r)) return r;
    var t = /[0-9](?=(?:[0-9]{3})+(?![0-9]))/g;
    if (typeof e == "number") {
        var n = e < 0 ? -Gt(-e) : Gt(e);
        if (n !== e) {
            var o = String(n),
                a = ut.call(r, o.length + 1);
            return N.call(o, t, "$&_") + "." + N.call(N.call(a, /([0-9]{3})/g, "$&_"), /_$/, "")
        }
    }
    return N.call(r, t, "$&_")
}
var Kr = on,
    Ut = Kr.custom,
    qt = Ce(Ut) ? Ut : null,
    Be = {
        __proto__: null,
        double: '"',
        single: "'"
    },
    Zo = {
        __proto__: null,
        double: /(["\\])/g,
        single: /(['\\])/g
    },
    dr = function e(r, t, n, o) {
        var a = t || {};
        if (F(a, "quoteStyle") && !F(Be, a.quoteStyle)) throw new TypeError('option "quoteStyle" must be "single" or "double"');
        if (F(a, "maxStringLength") && (typeof a.maxStringLength == "number" ? a.maxStringLength < 0 && a.maxStringLength !== 1 / 0 : a.maxStringLength !== null)) throw new TypeError('option "maxStringLength", if provided, must be a positive integer, Infinity, or `null`');
        var i = F(a, "customInspect") ? a.customInspect : !0;
        if (typeof i != "boolean" && i !== "symbol") throw new TypeError("option \"customInspect\", if provided, must be `true`, `false`, or `'symbol'`");
        if (F(a, "indent") && a.indent !== null && a.indent !== "	" && !(parseInt(a.indent, 10) === a.indent && a.indent > 0)) throw new TypeError('option "indent" must be "\\t", an integer > 0, or `null`');
        if (F(a, "numericSeparator") && typeof a.numericSeparator != "boolean") throw new TypeError('option "numericSeparator", if provided, must be `true` or `false`');
        var f = a.numericSeparator;
        if (typeof r > "u") return "undefined";
        if (r === null) return "null";
        if (typeof r == "boolean") return r ? "true" : "false";
        if (typeof r == "string") return Ge(r, a);
        if (typeof r == "number") {
            if (r === 0) return 1 / 0 / r > 0 ? "0" : "-0";
            var l = String(r);
            return f ? Lt(r, l) : l
        }
        if (typeof r == "bigint") {
            var v = String(r) + "n";
            return f ? Lt(r, v) : v
        }
        var y = typeof a.depth > "u" ? 5 : a.depth;
        if (typeof n > "u" && (n = 0), n >= y && y > 0 && typeof r == "object") return zr(r) ? "[Array]" : "[Object]";
        var s = ha(a, n);
        if (typeof o > "u") o = [];
        else if (Me(o, r) >= 0) return "[Circular]";

        function u(G, nr, nn) {
            if (nr && (o = Qo.call(o), o.push(nr)), nn) {
                var yt = {
                    depth: a.depth
                };
                return F(a, "quoteStyle") && (yt.quoteStyle = a.quoteStyle), e(G, yt, n + 1, o)
            }
            return e(G, a, n + 1, o)
        }
        if (typeof r == "function" && !kt(r)) {
            var c = ua(r),
                d = or(r, u);
            return "[Function" + (c ? ": " + c : " (anonymous)") + "]" + (d.length > 0 ? " { " + w.call(d, ", ") + " }" : "")
        }
        if (Ce(r)) {
            var g = K ? N.call(String(r), /^(Symbol\(.*\))_[^)]*$/, "$1") : jr.call(r);
            return typeof r == "object" && !K ? H(g) : g
        }
        if (va(r)) {
            for (var m = "<" + Ct.call(String(r.nodeName)), S = r.attributes || [], b = 0; b < S.length; b++) m += " " + S[b].name + "=" + _e(ra(S[b].value), "double", a);
            return m += ">", r.childNodes && r.childNodes.length && (m += "..."), m += "</" + Ct.call(String(r.nodeName)) + ">", m
        }
        if (zr(r)) {
            if (r.length === 0) return "[]";
            var O = or(r, u);
            return s && !da(O) ? "[" + Hr(O, s) + "]" : "[ " + w.call(O, ", ") + " ]"
        }
        if (ea(r)) {
            var P = or(r, u);
            return !("cause" in Error.prototype) && "cause" in r && !Ne.call(r, "cause") ? "{ [" + String(r) + "] " + w.call(Mt.call("[cause]: " + u(r.cause), P), ", ") + " }" : P.length === 0 ? "[" + String(r) + "]" : "{ [" + String(r) + "] " + w.call(P, ", ") + " }"
        }
        if (typeof r == "object" && i) {
            if (qt && typeof r[qt] == "function" && Kr) return Kr(r, {
                depth: y - n
            });
            if (i !== "symbol" && typeof r.inspect == "function") return r.inspect()
        }
        if (fa(r)) {
            var R = [];
            return Nt && Nt.call(r, function(G, nr) {
                R.push(u(nr, r, !0) + " => " + u(G, r))
            }), jt("Map", yr.call(r), R, s)
        }
        if (pa(r)) {
            var M = [];
            return Bt && Bt.call(r, function(G) {
                M.push(u(G, r))
            }), jt("Set", vr.call(r), M, s)
        }
        if (ca(r)) return Rr("WeakMap");
        if (ya(r)) return Rr("WeakSet");
        if (sa(r)) return Rr("WeakRef");
        if (oa(r)) return H(u(Number(r)));
        if (ia(r)) return H(u(kr.call(r)));
        if (aa(r)) return H(Ho.call(r));
        if (na(r)) return H(u(String(r)));
        if (typeof window < "u" && r === window) return "{ [object Window] }";
        if (typeof globalThis < "u" && r === globalThis || typeof vt < "u" && r === vt) return "{ [object globalThis] }";
        if (!ta(r) && !kt(r)) {
            var z = or(r, u),
                D = Wt ? Wt(r) === Object.prototype : r instanceof Object || r.constructor === Object,
                $r = r instanceof Object ? "" : "null prototype",
                pt = !D && X && Object(r) === r && X in r ? ut.call(B(r), 8, -1) : $r ? "Object" : "",
                en = D || typeof r.constructor != "function" ? "" : r.constructor.name ? r.constructor.name + " " : "",
                Sr = en + (pt || $r ? "[" + w.call(Mt.call([], pt || [], $r || []), ": ") + "] " : "");
            return z.length === 0 ? Sr + "{}" : s ? Sr + "{" + Hr(z, s) + "}" : Sr + "{ " + w.call(z, ", ") + " }"
        }
        return String(r)
    };

function _e(e, r, t) {
    var n = t.quoteStyle || r,
        o = Be[n];
    return o + e + o
}

function ra(e) {
    return N.call(String(e), /"/g, "&quot;")
}

function C(e) {
    return !X || !(typeof e == "object" && (X in e || typeof e[X] < "u"))
}

function zr(e) {
    return B(e) === "[object Array]" && C(e)
}

function ta(e) {
    return B(e) === "[object Date]" && C(e)
}

function kt(e) {
    return B(e) === "[object RegExp]" && C(e)
}

function ea(e) {
    return B(e) === "[object Error]" && C(e)
}

function na(e) {
    return B(e) === "[object String]" && C(e)
}

function oa(e) {
    return B(e) === "[object Number]" && C(e)
}

function aa(e) {
    return B(e) === "[object Boolean]" && C(e)
}

function Ce(e) {
    if (K) return e && typeof e == "object" && e instanceof Symbol;
    if (typeof e == "symbol") return !0;
    if (!e || typeof e != "object" || !jr) return !1;
    try {
        return jr.call(e), !0
    } catch {}
    return !1
}

function ia(e) {
    if (!e || typeof e != "object" || !kr) return !1;
    try {
        return kr.call(e), !0
    } catch {}
    return !1
}
var la = Object.prototype.hasOwnProperty || function(e) {
    return e in this
};

function F(e, r) {
    return la.call(e, r)
}

function B(e) {
    return Jo.call(e)
}

function ua(e) {
    if (e.name) return e.name;
    var r = Yo.call(Vo.call(e), /^function\s*([\w$]+)/);
    return r ? r[1] : null
}

function Me(e, r) {
    if (e.indexOf) return e.indexOf(r);
    for (var t = 0, n = e.length; t < n; t++)
        if (e[t] === r) return t;
    return -1
}

function fa(e) {
    if (!yr || !e || typeof e != "object") return !1;
    try {
        yr.call(e);
        try {
            vr.call(e)
        } catch {
            return !0
        }
        return e instanceof Map
    } catch {}
    return !1
}

function ca(e) {
    if (!V || !e || typeof e != "object") return !1;
    try {
        V.call(e, V);
        try {
            Y.call(e, Y)
        } catch {
            return !0
        }
        return e instanceof WeakMap
    } catch {}
    return !1
}

function sa(e) {
    if (!_t || !e || typeof e != "object") return !1;
    try {
        return _t.call(e), !0
    } catch {}
    return !1
}

function pa(e) {
    if (!vr || !e || typeof e != "object") return !1;
    try {
        vr.call(e);
        try {
            yr.call(e)
        } catch {
            return !0
        }
        return e instanceof Set
    } catch {}
    return !1
}

function ya(e) {
    if (!Y || !e || typeof e != "object") return !1;
    try {
        Y.call(e, Y);
        try {
            V.call(e, V)
        } catch {
            return !0
        }
        return e instanceof WeakSet
    } catch {}
    return !1
}

function va(e) {
    return !e || typeof e != "object" ? !1 : typeof HTMLElement < "u" && e instanceof HTMLElement ? !0 : typeof e.nodeName == "string" && typeof e.getAttribute == "function"
}

function Ge(e, r) {
    if (e.length > r.maxStringLength) {
        var t = e.length - r.maxStringLength,
            n = "... " + t + " more character" + (t > 1 ? "s" : "");
        return Ge(ut.call(e, 0, r.maxStringLength), r) + n
    }
    var o = Zo[r.quoteStyle || "single"];
    o.lastIndex = 0;
    var a = N.call(N.call(e, o, "\\$1"), /[\x00-\x1f]/g, ga);
    return _e(a, "single", r)
}

function ga(e) {
    var r = e.charCodeAt(0),
        t = {
            8: "b",
            9: "t",
            10: "n",
            12: "f",
            13: "r"
        }[r];
    return t ? "\\" + t : "\\x" + (r < 16 ? "0" : "") + Xo.call(r.toString(16))
}

function H(e) {
    return "Object(" + e + ")"
}

function Rr(e) {
    return e + " { ? }"
}

function jt(e, r, t, n) {
    var o = n ? Hr(t, n) : w.call(t, ", ");
    return e + " (" + r + ") {" + o + "}"
}

function da(e) {
    for (var r = 0; r < e.length; r++)
        if (Me(e[r], `
`) >= 0) return !1;
    return !0
}

function ha(e, r) {
    var t;
    if (e.indent === "	") t = "	";
    else if (typeof e.indent == "number" && e.indent > 0) t = w.call(Array(e.indent + 1), " ");
    else return null;
    return {
        base: t,
        prev: w.call(Array(r + 1), t)
    }
}

function Hr(e, r) {
    if (e.length === 0) return "";
    var t = `
` + r.prev + r.base;
    return t + w.call(e, "," + t) + `
` + r.prev
}

function or(e, r) {
    var t = zr(e),
        n = [];
    if (t) {
        n.length = e.length;
        for (var o = 0; o < e.length; o++) n[o] = F(e, o) ? r(e[o], e) : ""
    }
    var a = typeof xr == "function" ? xr(e) : [],
        i;
    if (K) {
        i = {};
        for (var f = 0; f < a.length; f++) i["$" + a[f]] = a[f]
    }
    for (var l in e) F(e, l) && (t && String(Number(l)) === l && l < e.length || K && i["$" + l] instanceof Symbol || (De.call(/[^\w$]/, l) ? n.push(r(l, e) + ": " + r(e[l], e)) : n.push(l + ": " + r(e[l], e))));
    if (typeof xr == "function")
        for (var v = 0; v < a.length; v++) Ne.call(e, a[v]) && n.push("[" + r(a[v]) + "]: " + r(e[a[v]], e));
    return n
}
var ft = function(r) {
        return typeof r == "string" || typeof r == "symbol"
    },
    ma = $,
    $a = dr,
    Sa = ft,
    ba = function(r, t) {
        if (!Sa(t)) throw new ma("Assertion failed: P is not a Property Key, got " + $a(t));
        return r[t]
    },
    We = Function.prototype.toString,
    q = typeof Reflect == "object" && Reflect !== null && Reflect.apply,
    Jr, fr;
if (typeof q == "function" && typeof Object.defineProperty == "function") try {
    Jr = Object.defineProperty({}, "length", {
        get: function() {
            throw fr
        }
    }), fr = {}, q(function() {
        throw 42
    }, null, Jr)
} catch (e) {
    e !== fr && (q = null)
} else q = null;
var Aa = /^\s*class\b/,
    Vr = function(r) {
        try {
            var t = We.call(r);
            return Aa.test(t)
        } catch {
            return !1
        }
    },
    Dr = function(r) {
        try {
            return Vr(r) ? !1 : (We.call(r), !0)
        } catch {
            return !1
        }
    },
    cr = Object.prototype.toString,
    wa = "[object Object]",
    Oa = "[object Function]",
    Pa = "[object GeneratorFunction]",
    Ea = "[object HTMLAllCollection]",
    Ia = "[object HTML document.all class]",
    Fa = "[object HTMLCollection]",
    Ta = typeof Symbol == "function" && !!Symbol.toStringTag,
    xa = !(0 in [, ]),
    Yr = function() {
        return !1
    };
if (typeof document == "object") {
    var Ra = document.all;
    cr.call(Ra) === cr.call(document.all) && (Yr = function(r) {
        if ((xa || !r) && (typeof r > "u" || typeof r == "object")) try {
            var t = cr.call(r);
            return (t === Ea || t === Ia || t === Fa || t === wa) && r("") == null
        } catch {}
        return !1
    })
}
var Da = q ? function(r) {
        if (Yr(r)) return !0;
        if (!r || typeof r != "function" && typeof r != "object") return !1;
        try {
            q(r, null, Jr)
        } catch (t) {
            if (t !== fr) return !1
        }
        return !Vr(r) && Dr(r)
    } : function(r) {
        if (Yr(r)) return !0;
        if (!r || typeof r != "function" && typeof r != "object") return !1;
        if (Ta) return Dr(r);
        if (Vr(r)) return !1;
        var t = cr.call(r);
        return t !== Oa && t !== Pa && !/^\[object HTML/.test(t) ? !1 : Dr(r)
    },
    Le = Da,
    Kt = $,
    Na = ba,
    Ba = Le,
    _a = ft,
    zt = dr,
    Ca = function(r, t) {
        if (!_a(t)) throw new Kt("Assertion failed: P is not a Property Key");
        var n = Na(r, t);
        if (n != null) {
            if (!Ba(n)) throw new Kt(zt(t) + " is not a function: " + zt(n));
            return n
        }
    },
    Ma = Qr,
    Ga = function(r) {
        return (typeof r == "number" || typeof r == "bigint") && !Ma(r) && r !== 1 / 0 && r !== -1 / 0
    },
    Wa = ye,
    La = ve,
    Ua = Qr,
    qa = Ga,
    ct = function(r) {
        if (typeof r != "number" || Ua(r) || !qa(r)) return !1;
        var t = Wa(r);
        return La(t) === t
    },
    Ue = function(r) {
        return !!r && (typeof r == "function" || typeof r == "object")
    },
    ka = de,
    ja = function() {
        return ka() && !!Symbol.toStringTag
    },
    Ht = x,
    Ka = ja(),
    za = be,
    Ha = Z,
    Xr;
if (Ka) {
    var Ja = Ht("RegExp.prototype.exec"),
        Jt = {},
        Nr = function() {
            throw Jt
        },
        Vt = {
            toString: Nr,
            valueOf: Nr
        };
    typeof Symbol.toPrimitive == "symbol" && (Vt[Symbol.toPrimitive] = Nr), Xr = function(r) {
        if (!r || typeof r != "object") return !1;
        var t = Ha(r, "lastIndex"),
            n = t && za(t, "value");
        if (!n) return !1;
        try {
            Ja(r, Vt)
        } catch (o) {
            return o === Jt
        }
    }
} else {
    var Va = Ht("Object.prototype.toString"),
        Ya = "[object RegExp]";
    Xr = function(r) {
        return !r || typeof r != "object" && typeof r != "function" ? !1 : Va(r) === Ya
    }
}
var qe = Xr,
    Xa = x,
    Qa = qe,
    Za = Xa("RegExp.prototype.exec"),
    ri = $,
    ke = function(r) {
        if (!Qa(r)) throw new ri("`regex` must be a RegExp");
        return function(n) {
            return Za(r, n) !== null
        }
    },
    Yt = $,
    ti = dr,
    ei = ft,
    ni = Ue,
    oi = function(r, t) {
        if (!ni(r)) throw new Yt("Assertion failed: Type(O) is not Object");
        if (!ei(t)) throw new Yt("Assertion failed: P is not a Property Key, got " + ti(t));
        return r[t]
    },
    ai = ge,
    ii = x,
    Br = $,
    li = ct,
    ui = ii("String.prototype.slice"),
    je = function(r, t, n) {
        if (typeof r != "string") throw new Br("Assertion failed: `string` must be a String");
        if (typeof t != "string") throw new Br("Assertion failed: `searchValue` must be a String");
        if (!li(n) || n < 0) throw new Br("Assertion failed: `fromIndex` must be a non-negative integer");
        var o = r.length;
        if (t === "" && n <= o) return n;
        for (var a = t.length, i = n; i <= o - a; i += 1) {
            var f = ui(r, i, i + a);
            if (f === t) return i
        }
        return "NOT-FOUND"
    },
    fi = $,
    st = function(r) {
        if (r == null) throw new fi(arguments.length > 0 && arguments[1] || "Cannot call method on " + r);
        return r
    },
    _r, Xt;

function ci() {
    if (Xt) return _r;
    Xt = 1;
    var e = T,
        r = e("%String%"),
        t = $;
    return _r = function(o) {
        if (typeof o == "symbol") throw new t("Cannot convert a Symbol value to a string");
        return r(o)
    }, _r
}
var Cr, Qt;

function Ke() {
    if (Qt) return Cr;
    Qt = 1;
    var e = st,
        r = ci(),
        t = x,
        n = t("String.prototype.replace"),
        o = /^\s$/.test("᠎"),
        a = o ? /^[\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF]+/ : /^[\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF]+/,
        i = o ? /[\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF]+$/ : /[\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF]+$/;
    return Cr = function() {
        var l = r(e(this));
        return n(n(l, a, ""), i, "")
    }, Cr
}
var Mr, Zt;

function ze() {
    if (Zt) return Mr;
    Zt = 1;
    var e = Ke(),
        r = "​",
        t = "᠎";
    return Mr = function() {
        return String.prototype.trim && r.trim() === r && t.trim() === t && ("_" + t).trim() === "_" + t && (t + "_").trim() === t + "_" ? String.prototype.trim : e
    }, Mr
}
var Gr, re;

function si() {
    if (re) return Gr;
    re = 1;
    var e = nt(),
        r = et,
        t = ze();
    return Gr = function() {
        var o = t();
        return String.prototype.trim !== o && (e ? r(String.prototype, "trim", o, !0) : r(String.prototype, "trim", o)), o
    }, Gr
}
var Wr, te;

function pi() {
    if (te) return Wr;
    te = 1;
    var e = ot,
        r = at,
        t = st,
        n = Ke(),
        o = ze(),
        a = si(),
        i = e(o()),
        f = function(v) {
            return t(v), i(v)
        };
    return r(f, {
        getPolyfill: o,
        implementation: n,
        shim: a
    }), Wr = f, Wr
}
var He = T,
    yi = He("%RegExp%"),
    vi = $,
    ee = He("%parseInt%"),
    gi = x,
    hr = ke,
    ne = gi("String.prototype.slice"),
    di = hr(/^0b[01]+$/i),
    hi = hr(/^0o[0-7]+$/i),
    mi = hr(/^[-+]0x[0-9a-f]+$/i),
    $i = ["", "​", "￾"].join(""),
    Si = new yi("[" + $i + "]", "g"),
    bi = hr(Si),
    Ai = pi(),
    wi = function e(r) {
        if (typeof r != "string") throw new vi("Assertion failed: `argument` is not a String");
        if (di(r)) return +ee(ne(r, 2), 2);
        if (hi(r)) return +ee(ne(r, 2), 8);
        if (bi(r) || mi(r)) return NaN;
        var t = Ai(r);
        return t !== r ? e(t) : +r
    },
    Oi = $,
    oe = ct,
    Pi = x,
    Ei = Pi("String.prototype.slice"),
    Ii = function(r, t, n) {
        if (typeof r != "string" || !oe(t) || arguments.length > 2 && !oe(n)) throw new Oi("`S` must be a String, and `inclusiveStart` and `exclusiveEnd` must be integers");
        return Ei(r, t, arguments.length > 2 ? n : r.length)
    },
    Fi = T,
    Ti = Fi("%String%"),
    xi = $,
    Je = function(r) {
        if (typeof r == "symbol") throw new xi("Cannot convert a Symbol value to a string");
        return Ti(r)
    },
    Ri = function(r, t) {
        for (var n = 0; n < r.length; n += 1)
            if (!t(r[n], n, r)) return !1;
        return !0
    },
    Di = x("String.prototype.slice"),
    Ni = function(r, t) {
        return r === t ? !0 : r.length > t.length ? !1 : Di(t, 0, r.length) === r
    },
    Bi = function(r) {
        return typeof r == "string" || typeof r > "u"
    },
    E = $,
    Lr = dr,
    _i = ct,
    ae = Ue,
    Ve = ke,
    Ci = oi,
    Mi = Re,
    Gi = ai,
    Wi = je,
    ie = wi,
    I = Ii,
    Li = Je,
    Ui = Ri,
    J = Ni,
    qi = Bi,
    ki = Ve(/^\$[0-9]/),
    ji = Ve(/^\$[0-9][0-9]/),
    Ki = function(r, t, n, o, a, i) {
        if (typeof r != "string") throw new E("Assertion failed: `matched` must be a String");
        if (typeof t != "string") throw new E("Assertion failed: `str` must be a String");
        if (!_i(n) || n < 0) throw new E("Assertion failed: `position` must be a nonnegative integer, got " + Lr(n));
        if (!Mi(o) || !Ui(o, qi)) throw new E("Assertion failed: `captures` must be a possibly-empty List of Strings or `undefined`, got " + Lr(o));
        if (typeof a < "u" && !ae(a)) throw new E("Assertion failed: `namedCaptures` must be `undefined` or an Object");
        if (typeof i != "string") throw new E("Assertion failed: `replacementTemplate` must be a String");
        var f = t.length;
        if (n > f) throw new E("Assertion failed: position > stringLength, got " + Lr(n));
        for (var l = i, v = ""; l !== "";) {
            var y, s, u;
            if (J("$$", l)) y = "$$", s = "$";
            else if (J("$`", l)) y = "$`", s = I(t, 0, n);
            else if (J("$&", l)) y = "$&", s = r;
            else if (J("$'", l)) {
                y = "$'";
                var c = r.length,
                    d = n + c;
                s = I(t, Gi(d, f))
            } else if (ki(l)) {
                var g = ji(l) ? 2 : 1,
                    m = I(l, 1, 1 + g),
                    S = ie(m);
                if (S < 0 || S > 99) throw new E("Assertion failed: `index` must be >= 0 and <= 99");
                var b = o.length;
                S > b && g === 2 && (g = 1, m = I(m, 0, 1), S = ie(m)), y = I(l, 0, 1 + g), 1 <= S && S <= b ? (u = o[S - 1], typeof u > "u" ? s = "" : s = u) : s = y
            } else if (J("$<", l)) {
                var O = Wi(l, ">", 0);
                if (!(O > -1) || typeof a > "u") y = "$<", s = y;
                else {
                    y = I(l, 0, O + 1);
                    var P = I(l, 2, O);
                    if (!ae(a)) throw new E("Assertion failed: Type(namedCaptures) is not Object");
                    u = Ci(a, P), typeof u > "u" ? s = "" : s = Li(u)
                }
            } else y = I(l, 0, 1), s = y;
            var R = y.length;
            l = I(l, R), v += s
        }
        return v
    },
    Ye = T,
    Xe = ot,
    zi = Xe(Ye("String.prototype.indexOf")),
    Hi = function(r, t) {
        var n = Ye(r, !!t);
        return typeof n == "function" && zi(r, ".prototype.") > -1 ? Xe(n) : n
    },
    le = ko,
    Ji = Ca,
    Vi = Ki,
    Yi = Le,
    Xi = st,
    ar = Je,
    ue = je,
    Qi = T,
    mr = Hi,
    Zi = he(),
    rl = qe,
    tl = Qi("%Math.max%"),
    fe = $,
    el = mr("Array.prototype.push"),
    Ur = mr("String.prototype.slice"),
    nl = mr("String.prototype.indexOf"),
    ol = mr("String.prototype.replace"),
    Qe = function(r, t) {
        var n = Xi(this),
            o = rl(r);
        if (o && nl(Ur(r, r.source.length + 2), "g") === -1) throw new fe("use .replace for a non-global regex. NOTE: this may be allowed in the future.");
        if (Zi && Symbol.replace) {
            if (r != null) {
                var a = Ji(r, Symbol.replace);
                if (typeof a < "u") return le(a, r, [n, t])
            }
        } else if (o) return ol(n, r, t);
        var i = ar(n),
            f = ar(r),
            l = Yi(t);
        l || (t = ar(t));
        for (var v = f.length, y = tl(1, v), s = [], u = ue(i, f, 0); u !== "NOT-FOUND";) el(s, u), u = ue(i, f, u + y);
        for (var c = 0, d = "", g = 0; g < s.length; g += 1) {
            var m;
            if (l) m = ar(le(t, void 0, [f, s[g], i]));
            else {
                if (typeof t != "string") throw new fe("Assertion failed: `replaceValue` should be a string at this point");
                var S = [];
                m = Vi(f, i, s[g], S, void 0, t)
            }
            var b = Ur(i, c, s[g]);
            d += b + m, c = s[g] + v
        }
        return c < i.length && (d += Ur(i, c)), d
    },
    al = Qe,
    Ze = function() {
        return String.prototype.replaceAll || al
    },
    il = at,
    ll = Ze,
    ul = function() {
        var r = ll();
        return il(String.prototype, {
            replaceAll: r
        }, {
            replaceAll: function() {
                return String.prototype.replaceAll !== r
            }
        }), r
    },
    fl = ot,
    cl = at,
    rn = Qe,
    sl = Ze,
    pl = ul,
    tn = fl(rn);
cl(tn, {
    getPolyfill: sl,
    implementation: rn,
    shim: pl
});
var yl = tn;
const vl = an(yl);
vl.shim();
class A {
    static async sleep(r) {
        return new Promise(t => {
            setTimeout(() => {
                t()
            }, r)
        })
    }
    static percentageToDecimalOne(r) {
        const n = ((r == null ? void 0 : r.toString()) ? ? "").replace(/[^0-9,]/g, "").replace(",", "."),
            o = parseFloat(n);
        return Number.isNaN(o) ? null : o / 100
    }
    static decimalToPercentage100(r, t = 1) {
        return `${(r*100).toLocaleString("pt-br",{minimumFractionDigits:t,maximumFractionDigits:t})}%`
    }
    static numberFormatter(r, t = 2, n = ".") {
        var c, d;
        const o = ((c = r.split(n)[1]) == null ? void 0 : c.length) < t,
            a = ((d = r.split(n)[1]) == null ? void 0 : d.length) > t,
            l = r.replaceAll(",", ".").replace(/[^0-9.]/g, "").replace(/(\.)(?=.*\1)/g, ""),
            v = l.endsWith(".") ? `${l}0` : l,
            y = parseFloat(v);
        return Number.isNaN(y) ? this.numberFormatter("0", t, n) : (y * (o ? .1 : a ? 10 : 1)).toFixed(t).replace(".", n)
    }
    static percentageFormatter(r, t = 1) {
        const o = (r == null ? void 0 : r.includes("%")) ? r : r == null ? void 0 : r.substring(0, r.length - 1),
            i = `${A.decimalFormatter(o,t)}%`;
        return r.includes("-") ? `-${i}` : i
    }
    static decimalFormatter(r, t = 2) {
        const n = (r == null ? void 0 : r.replace(/[^0-9]/g, "")) ? ? "";
        return A.createDecimalPlaces(Number(n), t).toLocaleString("pt-br", {
            minimumFractionDigits: t,
            maximumFractionDigits: t
        })
    }
    static createDecimalPlaces(r, t = 2) {
        return r / 10 ** t
    }
    static capitalize(r) {
        return !r || r.length === 0 ? r : r.charAt(0).toUpperCase() + r.slice(1)
    }
    static removeSpacesAndAccents(r) {
        return r.toLowerCase().replace(/ /g, "-").replace(/[^\w-]+/g, "")
    }
    static range(r, t) {
        const n = r - 0;
        return [...Array(t - r + 1).keys()].map(o => o + n)
    }
    static genObject(r, t, n) {
        const o = {};
        for (let a = r; a <= t; a++) o[a] = n(a);
        return o
    }
    static clean(r) {
        return typeof r != "string" ? r : r.replaceAll(" ", "").replaceAll("-", "").replaceAll(".", "").replaceAll("/", "").replaceAll("\\", "").replaceAll("(", "").replaceAll(")", "")
    }
    static formatCpf(r) {
        if (!r) return null;
        const t = A.clean(r);
        return `${t.substring(0,3)}.${t.substring(3,6)}.${t.substring(6,9)}-${t.substring(9,11)}`
    }
    static formatCnpj(r) {
        if (!r) return null;
        const t = A.clean(r);
        return `${t.substring(0,2)}.${t.substring(2,5)}.${t.substring(5,8)}/${t.substring(8,12)}-${t.substring(12,14)}`
    }
    static formatPhone(r) {
        if (!r) return null;
        const t = A.phoneWithDdd(r);
        return `(${t.substring(0,2)}) ${t.substring(2,7)}-${t.substring(7,11)}`
    }
    static formatAsTwoDigits(r) {
        return r.toLocaleString("en-US", {
            minimumIntegerDigits: 2,
            useGrouping: !1
        })
    }
    static discoverCardBrand(r) {
        const t = {
                Visa: /^4[0-9]{12}(?:[0-9]{3})/,
                Mastercard: /^5[1-5][0-9]{14}/,
                Amex: /^3[47][0-9]{13}/,
                DinersClub: /^3(?:0[0-5]|[68][0-9])[0-9]{11}/,
                Discover: /^6(?:011|5[0-9]{2})[0-9]{12}/,
                JCB: /^(?:2131|1800|35\d{3})\d{11}/
            },
            n = Object.keys(t);
        for (let o = 0; o < n.length; o++) {
            const a = n[o];
            if (r.match(t[a])) return a
        }
        return ""
    }
    static reduceStringTo(r, t, n = "...") {
        return r.length <= t ? r : r.substring(0, t - n.length) + n
    }
    static phoneWithDdd(r) {
        const t = A.clean(r);
        return t.length < 11 ? t : t.substring(2)
    }
    static applyMask(r, t, n) {
        const o = n ? ? r.length;
        let a = null;
        t.length > o && (a = t.slice(0, -1));
        const i = A.clean(a ? ? t),
            f = "0",
            l = "a",
            v = ["[a0]", "[0a]"],
            y = "*";
        let s = "",
            u = 0;
        for (let c = 0; c < r.length && !(u >= i.length); c++)
            if (r[c] === f) A.isNumeric(i[u]) && (s += i[u]), u++;
            else if (r[c] === l) A.isAlphabetic(i[u]) && (s += i[u]), u++;
        else if (r[c] === "[") {
            const d = r.indexOf("]", c),
                g = r.substring(c, d + 1);
            v.includes(g) && (A.isAlphaNumeric(i[u]) && (s += i[u]), u++, c += g.length - 1)
        } else r[c] === y ? (s += i[u], u++) : s += r[c];
        return s
    }
    static wait(r) {
        return new Promise(t => {
            setTimeout(t, r)
        })
    }
    static isNumeric(r) {
        return /^\d+$/.test(r)
    }
    static isInt(r) {
        return !Number.isNaN(r) && function(t) {
            return (t | 0) === t
        }(parseFloat(r))
    }
    static isAlphabetic(r) {
        return r.match("^[a-zA-Z]+$")
    }
    static isAlphaNumeric(r) {
        const t = /^[\p{L}\p{N}]*$/u;
        return r.match(t)
    }
    static isValidEmail(r) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(r)
    }
    static hasMore3RepeatedNumbers(r) {
        return /(\d)\1\1/.test(r)
    }
    static removeURLParameter(r) {
        const t = window.location.href,
            n = new RegExp(`([?&])${r}=([^&#]*)`),
            o = n.exec(t);
        if (o) {
            const a = t.replace(n, o[1] === "?" ? "?" : "&");
            window.history.replaceState(null, "", a)
        }
    }
    static base64Urlencode(r) {
        const t = new TextEncoder().encode(r);
        return btoa(t.toString()).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
    }
}
export {
    A as U
};