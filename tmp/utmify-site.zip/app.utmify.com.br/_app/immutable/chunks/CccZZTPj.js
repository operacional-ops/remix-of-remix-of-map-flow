import {
    s as f,
    H as m,
    d as c,
    I as d,
    J as _,
    K as h,
    m as r,
    i as b,
    c as g,
    e as p,
    h as k,
    k as v
} from "./DDNnt9XD.js";
import {
    S as y,
    i as P,
    t as S,
    a as B
} from "./qWASNxYk.js";
import {
    t as D
} from "./BszCcFfc.js";

function w(n) {
    let t, o, s;
    const i = n[3].default,
        a = m(i, n, n[2], null);
    return {
        c() {
            t = k("body"), a && a.c(), this.h()
        },
        l(e) {
            t = g(e, "BODY", {
                id: !0,
                class: !0,
                "data-open": !0,
                "data-menu": !0,
                "data-col": !0
            });
            var l = p(t);
            a && a.l(l), l.forEach(c), this.h()
        },
        h() {
            var e;
            r(t, "id", "inset-body"), r(t, "class", o = "h-full vertical-layout vertical-menu-modern navbar-floating footer-static " + (n[0] ? "blank-page" : "") + " " + (((e = n[1]) == null ? void 0 : e.theme) === "Dark" ? "" : "bg-white")), r(t, "data-open", "click"), r(t, "data-menu", "vertical-menu-modern"), r(t, "data-col", "")
        },
        m(e, l) {
            b(e, t, l), a && a.m(t, null), s = !0
        },
        p(e, [l]) {
            var u;
            a && a.p && (!s || l & 4) && d(a, i, e, e[2], s ? h(i, e[2], l, null) : _(e[2]), null), (!s || l & 3 && o !== (o = "h-full vertical-layout vertical-menu-modern navbar-floating footer-static " + (e[0] ? "blank-page" : "") + " " + (((u = e[1]) == null ? void 0 : u.theme) === "Dark" ? "" : "bg-white"))) && r(t, "class", o)
        },
        i(e) {
            s || (B(a, e), s = !0)
        },
        o(e) {
            S(a, e), s = !1
        },
        d(e) {
            e && c(t), a && a.d(e)
        }
    }
}

function q(n, t, o) {
    let s;
    v(n, D, l => o(1, s = l));
    let {
        $$slots: i = {},
        $$scope: a
    } = t, {
        blankPage: e = !1
    } = t;
    return n.$$set = l => {
        "blankPage" in l && o(0, e = l.blankPage), "$$scope" in l && o(2, a = l.$$scope)
    }, [e, s, a, i]
}
class I extends y {
    constructor(t) {
        super(), P(this, t, q, w, f, {
            blankPage: 0
        })
    }
}
export {
    I as B
};