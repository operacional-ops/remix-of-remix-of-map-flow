var rt = Object.defineProperty;
var J = e => {
    throw TypeError(e)
};
var st = (e, n, l) => n in e ? rt(e, n, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: l
}) : e[n] = l;
var U = (e, n, l) => st(e, typeof n != "symbol" ? n + "" : n, l),
    D = (e, n, l) => n.has(e) || J("Cannot " + l);
var d = (e, n, l) => (D(e, n, "read from private field"), l ? l.call(e) : n.get(e)),
    M = (e, n, l) => n.has(e) ? J("Cannot add the same private member more than once") : n instanceof WeakSet ? n.add(e) : n.set(e, l),
    T = (e, n, l, r) => (D(e, n, "write to private field"), r ? r.call(e, l) : n.set(e, l), l),
    N = (e, n, l) => (D(e, n, "access private method"), l);
import {
    w as at
} from "./BKn_unzl.js";
var $ = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};

function wt(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}

function ot(e) {
    if (e.__esModule) return e;
    var n = e.default;
    if (typeof n == "function") {
        var l = function r() {
            return this instanceof r ? Reflect.construct(n, arguments, this.constructor) : n.apply(this, arguments)
        };
        l.prototype = n.prototype
    } else l = {};
    return Object.defineProperty(l, "__esModule", {
        value: !0
    }), Object.keys(e).forEach(function(r) {
        var s = Object.getOwnPropertyDescriptor(e, r);
        Object.defineProperty(l, r, s.get ? s : {
            enumerable: !0,
            get: function() {
                return e[r]
            }
        })
    }), l
}
var P = {};
const ct = {},
    ft = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: ct
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    K = ot(ft);
var j = {
        exports: {}
    },
    F = {
        exports: {}
    };
/**
 * @preserve
 * JS Implementation of incremental MurmurHash3 (r150) (as of May 10, 2013)
 *
 * @author <a href="mailto:jensyt@gmail.com">Jens Taylor</a>
 * @see http://github.com/homebrewing/brauhaus-diff
 * @author <a href="mailto:gary.court@gmail.com">Gary Court</a>
 * @see http://github.com/garycourt/murmurhash-js
 * @author <a href="mailto:aappleby@gmail.com">Austin Appleby</a>
 * @see http://sites.google.com/site/murmurhash/
 */
var H;

function lt() {
    return H || (H = 1, function(e) {
        (function() {
            var n;

            function l(r, s) {
                var f = this instanceof l ? this : n;
                if (f.reset(s), typeof r == "string" && r.length > 0 && f.hash(r), f !== this) return f
            }
            l.prototype.hash = function(r) {
                var s, f, _, v, w;
                switch (w = r.length, this.len += w, f = this.k1, _ = 0, this.rem) {
                    case 0:
                        f ^= w > _ ? r.charCodeAt(_++) & 65535 : 0;
                    case 1:
                        f ^= w > _ ? (r.charCodeAt(_++) & 65535) << 8 : 0;
                    case 2:
                        f ^= w > _ ? (r.charCodeAt(_++) & 65535) << 16 : 0;
                    case 3:
                        f ^= w > _ ? (r.charCodeAt(_) & 255) << 24 : 0, f ^= w > _ ? (r.charCodeAt(_++) & 65280) >> 8 : 0
                }
                if (this.rem = w + this.rem & 3, w -= this.rem, w > 0) {
                    for (s = this.h1; f = f * 11601 + (f & 65535) * 3432906752 & 4294967295, f = f << 15 | f >>> 17, f = f * 13715 + (f & 65535) * 461832192 & 4294967295, s ^= f, s = s << 13 | s >>> 19, s = s * 5 + 3864292196 & 4294967295, !(_ >= w);) f = r.charCodeAt(_++) & 65535 ^ (r.charCodeAt(_++) & 65535) << 8 ^ (r.charCodeAt(_++) & 65535) << 16, v = r.charCodeAt(_++), f ^= (v & 255) << 24 ^ (v & 65280) >> 8;
                    switch (f = 0, this.rem) {
                        case 3:
                            f ^= (r.charCodeAt(_ + 2) & 65535) << 16;
                        case 2:
                            f ^= (r.charCodeAt(_ + 1) & 65535) << 8;
                        case 1:
                            f ^= r.charCodeAt(_) & 65535
                    }
                    this.h1 = s
                }
                return this.k1 = f, this
            }, l.prototype.result = function() {
                var r, s;
                return r = this.k1, s = this.h1, r > 0 && (r = r * 11601 + (r & 65535) * 3432906752 & 4294967295, r = r << 15 | r >>> 17, r = r * 13715 + (r & 65535) * 461832192 & 4294967295, s ^= r), s ^= this.len, s ^= s >>> 16, s = s * 51819 + (s & 65535) * 2246770688 & 4294967295, s ^= s >>> 13, s = s * 44597 + (s & 65535) * 3266445312 & 4294967295, s ^= s >>> 16, s >>> 0
            }, l.prototype.reset = function(r) {
                return this.h1 = typeof r == "number" ? r : 0, this.rem = this.k1 = this.len = 0, this
            }, n = new l, e.exports = l
        })()
    }(F)), F.exports
}
var q = {},
    V = {},
    X;

function ut() {
    return X || (X = 1, function(e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.signals = void 0, e.signals = [], e.signals.push("SIGHUP", "SIGINT", "SIGTERM"), process.platform !== "win32" && e.signals.push("SIGALRM", "SIGABRT", "SIGVTALRM", "SIGXCPU", "SIGXFSZ", "SIGUSR2", "SIGTRAP", "SIGSYS", "SIGQUIT", "SIGIOT"), process.platform === "linux" && e.signals.push("SIGIO", "SIGPOLL", "SIGPWR", "SIGSTKFLT")
    }(V)), V
}
var Q;

function ht() {
    return Q || (Q = 1, function(e) {
        var C, h, i, g, t, a, o, S, k, tt;
        var n;
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.unload = e.load = e.onExit = e.signals = void 0;
        const l = ut();
        Object.defineProperty(e, "signals", {
            enumerable: !0,
            get: function() {
                return l.signals
            }
        });
        const r = c => !!c && typeof c == "object" && typeof c.removeListener == "function" && typeof c.emit == "function" && typeof c.reallyExit == "function" && typeof c.listeners == "function" && typeof c.kill == "function" && typeof c.pid == "number" && typeof c.on == "function",
            s = Symbol.for("signal-exit emitter"),
            f = globalThis,
            _ = Object.defineProperty.bind(Object);
        class v {
            constructor() {
                U(this, "emitted", {
                    afterExit: !1,
                    exit: !1
                });
                U(this, "listeners", {
                    afterExit: [],
                    exit: []
                });
                U(this, "count", 0);
                U(this, "id", Math.random());
                if (f[s]) return f[s];
                _(f, s, {
                    value: this,
                    writable: !1,
                    enumerable: !1,
                    configurable: !1
                })
            }
            on(x, u) {
                this.listeners[x].push(u)
            }
            removeListener(x, u) {
                const m = this.listeners[x],
                    p = m.indexOf(u);
                p !== -1 && (p === 0 && m.length === 1 ? m.length = 0 : m.splice(p, 1))
            }
            emit(x, u, m) {
                if (this.emitted[x]) return !1;
                this.emitted[x] = !0;
                let p = !1;
                for (const A of this.listeners[x]) p = A(u, m) === !0 || p;
                return x === "exit" && (p = this.emit("afterExit", u, m) || p), p
            }
        }
        class w {}
        const O = c => ({
            onExit(x, u) {
                return c.onExit(x, u)
            },
            load() {
                return c.load()
            },
            unload() {
                return c.unload()
            }
        });
        class R extends w {
            onExit() {
                return () => {}
            }
            load() {}
            unload() {}
        }
        class I extends w {
            constructor(u) {
                super();
                M(this, S);
                M(this, C, b.platform === "win32" ? "SIGINT" : "SIGHUP");
                M(this, h, new v);
                M(this, i);
                M(this, g);
                M(this, t);
                M(this, a, {});
                M(this, o, !1);
                T(this, i, u), T(this, a, {});
                for (const m of l.signals) d(this, a)[m] = () => {
                    const p = d(this, i).listeners(m);
                    let {
                        count: A
                    } = d(this, h);
                    const G = u;
                    if (typeof G.__signal_exit_emitter__ == "object" && typeof G.__signal_exit_emitter__.count == "number" && (A += G.__signal_exit_emitter__.count), p.length === A) {
                        this.unload();
                        const it = d(this, h).emit("exit", null, m),
                            nt = m === "SIGHUP" ? d(this, C) : m;
                        it || u.kill(u.pid, nt)
                    }
                };
                T(this, t, u.reallyExit), T(this, g, u.emit)
            }
            onExit(u, m) {
                if (!r(d(this, i))) return () => {};
                d(this, o) === !1 && this.load();
                const p = m != null && m.alwaysLast ? "afterExit" : "exit";
                return d(this, h).on(p, u), () => {
                    d(this, h).removeListener(p, u), d(this, h).listeners.exit.length === 0 && d(this, h).listeners.afterExit.length === 0 && this.unload()
                }
            }
            load() {
                if (!d(this, o)) {
                    T(this, o, !0), d(this, h).count += 1;
                    for (const u of l.signals) try {
                        const m = d(this, a)[u];
                        m && d(this, i).on(u, m)
                    } catch {}
                    d(this, i).emit = (u, ...m) => N(this, S, tt).call(this, u, ...m), d(this, i).reallyExit = u => N(this, S, k).call(this, u)
                }
            }
            unload() {
                d(this, o) && (T(this, o, !1), l.signals.forEach(u => {
                    const m = d(this, a)[u];
                    if (!m) throw new Error("Listener not defined for signal: " + u);
                    try {
                        d(this, i).removeListener(u, m)
                    } catch {}
                }), d(this, i).emit = d(this, g), d(this, i).reallyExit = d(this, t), d(this, h).count -= 1)
            }
        }
        C = new WeakMap, h = new WeakMap, i = new WeakMap, g = new WeakMap, t = new WeakMap, a = new WeakMap, o = new WeakMap, S = new WeakSet, k = function(u) {
            return r(d(this, i)) ? (d(this, i).exitCode = u || 0, d(this, h).emit("exit", d(this, i).exitCode, null), d(this, t).call(d(this, i), d(this, i).exitCode)) : 0
        }, tt = function(u, ...m) {
            const p = d(this, g);
            if (u === "exit" && r(d(this, i))) {
                typeof m[0] == "number" && (d(this, i).exitCode = m[0]);
                const A = p.call(d(this, i), u, ...m);
                return d(this, h).emit("exit", d(this, i).exitCode, null), A
            } else return p.call(d(this, i), u, ...m)
        };
        const b = globalThis.process;
        n = O(r(b) ? new I(b) : new R), e.onExit = n.onExit, e.load = n.load, e.unload = n.unload
    }(q)), q
}
var Y;

function dt() {
    if (Y) return j.exports;
    Y = 1, j.exports = C, j.exports.sync = h, j.exports._getTmpname = w, j.exports._cleanupOnExit = O;
    const e = K,
        n = lt(),
        {
            onExit: l
        } = ht(),
        r = K,
        {
            promisify: s
        } = K,
        f = {},
        _ = function() {
            try {
                return K.threadId
            } catch {
                return 0
            }
        }();
    let v = 0;

    function w(i) {
        return i + "." + n(__filename).hash(String(process.pid)).hash(String(_)).hash(String(++v)).result()
    }

    function O(i) {
        return () => {
            try {
                e.unlinkSync(typeof i == "function" ? i() : i)
            } catch {}
        }
    }

    function R(i) {
        return new Promise(g => {
            f[i] || (f[i] = []), f[i].push(g), f[i].length === 1 && g()
        })
    }

    function I(i) {
        return i.code === "ENOSYS" || (!process.getuid || process.getuid() !== 0) && (i.code === "EINVAL" || i.code === "EPERM")
    }
    async function b(i, g, t = {}) {
        typeof t == "string" && (t = {
            encoding: t
        });
        let a, o;
        const S = l(O(() => o)),
            y = r.resolve(i);
        try {
            await R(y);
            const E = await s(e.realpath)(i).catch(() => i);
            if (o = w(E), !t.mode || !t.chown) {
                const c = await s(e.stat)(E).catch(() => {});
                c && (t.mode == null && (t.mode = c.mode), t.chown == null && process.getuid && (t.chown = {
                    uid: c.uid,
                    gid: c.gid
                }))
            }
            a = await s(e.open)(o, "w", t.mode), t.tmpfileCreated && await t.tmpfileCreated(o), ArrayBuffer.isView(g) ? await s(e.write)(a, g, 0, g.length, 0) : g != null && await s(e.write)(a, String(g), 0, String(t.encoding || "utf8")), t.fsync !== !1 && await s(e.fsync)(a), await s(e.close)(a), a = null, t.chown && await s(e.chown)(o, t.chown.uid, t.chown.gid).catch(c => {
                if (!I(c)) throw c
            }), t.mode && await s(e.chmod)(o, t.mode).catch(c => {
                if (!I(c)) throw c
            }), await s(e.rename)(o, E)
        } finally {
            a && await s(e.close)(a).catch(() => {}), S(), await s(e.unlink)(o).catch(() => {}), f[y].shift(), f[y].length > 0 ? f[y][0]() : delete f[y]
        }
    }
    async function C(i, g, t, a) {
        t instanceof Function && (a = t, t = {});
        const o = b(i, g, t);
        if (a) try {
            const S = await o;
            return a(S)
        } catch (S) {
            return a(S)
        }
        return o
    }

    function h(i, g, t) {
        typeof t == "string" ? t = {
            encoding: t
        } : t || (t = {});
        try {
            i = e.realpathSync(i)
        } catch {}
        const a = w(i);
        if (!t.mode || !t.chown) try {
            const c = e.statSync(i);
            t = Object.assign({}, t), t.mode || (t.mode = c.mode), !t.chown && process.getuid && (t.chown = {
                uid: c.uid,
                gid: c.gid
            })
        } catch {}
        let o;
        const S = O(a),
            y = l(S);
        let E = !0;
        try {
            if (o = e.openSync(a, "w", t.mode || 438), t.tmpfileCreated && t.tmpfileCreated(a), ArrayBuffer.isView(g) ? e.writeSync(o, g, 0, g.length, 0) : g != null && e.writeSync(o, String(g), 0, String(t.encoding || "utf8")), t.fsync !== !1 && e.fsyncSync(o), e.closeSync(o), o = null, t.chown) try {
                e.chownSync(a, t.chown.uid, t.chown.gid)
            } catch (c) {
                if (!I(c)) throw c
            }
            if (t.mode) try {
                e.chmodSync(a, t.mode)
            } catch (c) {
                if (!I(c)) throw c
            }
            e.renameSync(a, i), E = !1
        } finally {
            if (o) try {
                e.closeSync(o)
            } catch {}
            y(), E && S()
        }
    }
    return j.exports
}
var W;

function gt() {
    return W || (W = 1, (function() {
        var e, n, l, r, s, f, _, v, w, O, R, I, b, C;
        b = K, I = K, R = K, C = dt().sync, n = "---.EMPTY_STRING.---", _ = function(h) {
            var i, g, t, a, o;
            for (a = I.readdirSync(h), o = [], i = 0, g = a.length; i < g; i++) t = a[i], o.push(w(b.join(h, t)));
            return o
        }, w = function(h) {
            return I.statSync(h).isDirectory() ? (_(h), I.rmdirSync(h)) : I.unlinkSync(h)
        }, v = function(h) {
            var i;
            return h === "" ? i = n : i = `${h}`, i
        }, s = class extends Error {
            constructor(i = "Unknown error.") {
                super(), this.message = i, Error.captureStackTrace != null && Error.captureStackTrace(this, this.constructor), this.name = this.constructor.name
            }
            toString() {
                return `${this.name}: ${this.message}`
            }
        }, f = class {
            constructor(i, g, t, a, o = "localStorage") {
                this.key = i, this.oldValue = g, this.newValue = t, this.url = a, this.storageArea = o
            }
        }, r = class z {
            constructor(i, g) {
                if (this.key = i, this.index = g, !(this instanceof z)) return new z(this.key, this.index)
            }
        }, O = function() {
            var h;
            return h = function() {}, h.prototype = Object.create(null), new h
        }, l = (function() {
            var h;
            class i extends R.EventEmitter {
                constructor(t, a = 5 * 1024 * 1024) {
                    var o;
                    return super(), this._location = t, this.quota = a, this instanceof i ? (this._location = b.resolve(this._location), h[this._location] != null ? h[this._location] : (this.length = 0, this._bytesInUse = 0, this._keys = [], this._metaKeyMap = O(), this._eventUrl = "pid:" + process.pid, this._init(), this._QUOTA_EXCEEDED_ERR = s, typeof Proxy < "u" && Proxy !== null ? (o = {
                        set: (S, y, E) => (this[y] != null ? this[y] = E : this.setItem(y, E), !0),
                        get: (S, y) => this[y] != null ? this[y] : this.getItem(y),
                        ownKeys: S => this._keys.map(function(y) {
                            return y === n ? "" : y
                        }),
                        getOwnPropertyDescriptor: (S, y) => ({
                            value: this[y],
                            enumerable: !0,
                            configurable: !0
                        })
                    }, h[this._location] = new Proxy(this, o), h[this._location]) : (h[this._location] = this, h[this._location]))) : new i(this._location, this.quota)
                }
                _init() {
                    var t, a;
                    try {
                        if (a = I.statSync(this._location), a != null && !a.isDirectory()) throw new Error(`A file exists at the location '${this._location}' when trying to create/open localStorage`);
                        this._sync()
                    } catch (o) {
                        if (t = o, t.code !== "ENOENT") throw t;
                        try {
                            I.mkdirSync(this._location, {
                                recursive: !0
                            })
                        } catch (S) {
                            if (t = S, t.code !== "EEXIST") throw t
                        }
                    }
                }
                _sync() {
                    var t, a, o, S, y, E, c, x;
                    for (this._bytesInUse = 0, this.length = 0, o = I.readdirSync(this._location), y = S = 0, c = o.length; S < c; y = ++S) E = o[y], a = decodeURIComponent(E), this._keys.push(a), t = new r(E, y), this._metaKeyMap[a] = t, x = this._getStat(E), (x != null ? x.size : void 0) != null && (t.size = x.size, this._bytesInUse += x.size);
                    return this.length = o.length
                }
                setItem(t, a) {
                    var o, S, y, E, c, x, u, m, p, A;
                    if (c = this.listenerCount("storage"), m = null, c && (m = this.getItem(t)), t = v(t), o = encodeURIComponent(t).replace(/[!'()]/g, escape).replace(/\*/g, "%2A"), E = b.join(this._location, o), p = `${a}`, A = p.length, x = this._metaKeyMap[t], y = !!x, y ? u = x.size : u = 0, this._bytesInUse - u + A > this.quota) throw new s;
                    if (C(E, p, {
                            encoding: "utf8"
                        }), y || (x = new r(o, this._keys.push(t) - 1), x.size = A, this._metaKeyMap[t] = x, this.length += 1, this._bytesInUse += A), c) return S = new f(t, m, a, this._eventUrl), this.emit("storage", S)
                }
                getItem(t) {
                    var a, o;
                    return t = v(t), o = this._metaKeyMap[t], o ? (a = b.join(this._location, o.key), I.readFileSync(a, "utf8")) : null
                }
                _getStat(t) {
                    var a;
                    t = v(t), a = b.join(this._location, encodeURIComponent(t));
                    try {
                        return I.statSync(a)
                    } catch {
                        return null
                    }
                }
                removeItem(t) {
                    var a, o, S, y, E, c, x, u;
                    if (t = v(t), c = this._metaKeyMap[t], c) {
                        S = this.listenerCount("storage"), x = null, S && (x = this.getItem(t)), delete this._metaKeyMap[t], this.length -= 1, this._bytesInUse -= c.size, o = b.join(this._location, c.key), this._keys.splice(c.index, 1), u = this._metaKeyMap;
                        for (y in u) u[y], E = this._metaKeyMap[y], E.index > c.index && (E.index -= 1);
                        if (w(o), S) return a = new f(t, x, null, this._eventUrl), this.emit("storage", a)
                    }
                }
                key(t) {
                    var a;
                    return a = this._keys[t], a === n ? "" : a
                }
                clear() {
                    var t;
                    if (_(this._location), this._metaKeyMap = O(), this._keys = [], this.length = 0, this._bytesInUse = 0, this.listenerCount("storage")) return t = new f(null, null, null, this._eventUrl), this.emit("storage", t)
                }
                _getBytesInUse() {
                    return this._bytesInUse
                }
                _deleteLocation() {
                    return delete h[this._location], w(this._location), this._metaKeyMap = {}, this._keys = [], this.length = 0, this._bytesInUse = 0
                }
            }
            return h = {}, i
        }).call(this), e = class extends l {
            setItem(i, g) {
                var t;
                return t = JSON.stringify(g), super.setItem(i, t)
            }
            getItem(i) {
                return JSON.parse(super.getItem(i))
            }
        }, P.LocalStorage = l, P.JSONStorage = e, P.QUOTA_EXCEEDED_ERR = s
    }).call($)), P
}
if (typeof localStorage > "u" || localStorage === null) {
    const e = gt().LocalStorage;
    $.localStorage = new e("./scratch")
}
const vt = 6048e5,
    bt = 864e5,
    Ot = 6e4,
    At = 36e5,
    Ct = 1e3,
    Z = Symbol.for("constructDateFrom");

function et(e, n) {
    return typeof e == "function" ? e(n) : e && typeof e == "object" && Z in e ? e[Z](n) : e instanceof Date ? new e.constructor(n) : new Date(n)
}

function B(e, n) {
    return et(n || e, e)
}

function mt(e, n, l) {
    return et(e, +B(e) + n)
}

function yt(e, n, l) {
    return mt(e, n * 1e3)
}

function St(e, n) {
    return +B(e) < +B(n)
}
class L {
    static createStore(n, l, r) {
        const s = L.storageGet(n, r);
        let f = 0;
        const _ = s != null ? JSON.parse(s) : l,
            v = at(_);
        return v.subscribe(w => {
            f++;
            const O = f <= 1;
            L.storageSet(n, JSON.stringify(w), { ...r,
                ttlInSeconds: O || r == null ? void 0 : r.ttlInSeconds
            })
        }), v
    }
    static storageGet(n, l) {
        const r = localStorage.getItem(n);
        if (l != null && l.ttlInSeconds) {
            const s = L.getExpiresAtKey(n),
                f = localStorage.getItem(s);
            if (f && St(new Date(JSON.parse(f)), new Date)) return console.log(`key ${n} expired`), localStorage.removeItem(n), localStorage.removeItem(s), null
        }
        return r
    }
    static storageSet(n, l, r) {
        if (localStorage.setItem(n, l), r != null && r.ttlInSeconds) {
            const s = yt(new Date, r.ttlInSeconds),
                f = L.getExpiresAtKey(n);
            localStorage.setItem(f, JSON.stringify(s)), console.log(`key ${n} will expire at ${s}`)
        }
    }
    static getExpiresAtKey(n) {
        return `${n}_expiresAt`
    }
}
export {
    L as S, mt as a, $ as b, et as c, At as d, Ot as e, vt as f, wt as g, Ct as h, St as i, bt as m, K as r, B as t
};