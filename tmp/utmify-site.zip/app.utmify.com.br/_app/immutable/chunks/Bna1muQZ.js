var it = Object.defineProperty;
var ht = (t, e, s) => e in t ? it(t, e, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: s
}) : t[e] = s;
var S = (t, e, s) => ht(t, typeof e != "symbol" ? e + "" : e, s);
import {
    d as x,
    b as N,
    c as V,
    e as O,
    f as lt,
    h as dt,
    i as pt,
    j as rt
} from "./B5WePDbK.js";
class m {
    constructor(e) {
        S(this, "dash");
        this.dash = e
    }
    static fromDash(e) {
        return e ? new m(e) : null
    }
    static fromDashId(e, s) {
        const n = s == null ? void 0 : s.user.dashboards.find(o => o.id === e);
        return n ? new m(n) : null
    }
    isComplete() {
        return this.getMissingSteps().length === 0
    }
    getMissingSteps() {
        var d, r, u, A, g, k;
        const e = [],
            s = x(this.dash),
            n = N(this.dash),
            o = V(this.dash),
            c = O(this.dash),
            i = ((r = (d = this.dash) == null ? void 0 : d.webhooks) == null ? void 0 : r.length) ? ? 0,
            l = ((A = (u = this.dash) == null ? void 0 : u.apiCredentials) == null ? void 0 : A.length) ? ? 0,
            h = ((k = (g = this.dash) == null ? void 0 : g.pixels) == null ? void 0 : k.length) ? ? 0;
        !s && !n && e.push("AD_PLATFORM");
        const T = s && o.length === 0,
            C = n && c.length === 0;
        return (T || C) && e.push("AD_ACCOUNT"), i === 0 && l === 0 && e.push("WEBHOOK"), h === 0 && e.push("PIXEL"), e
    }
}
var p = (t => (t.Meta = "Meta", t.Google = "Google", t.Kwai = "Kwai", t.TikTok = "TikTok", t.Others = "Others", t))(p || {}),
    a = (t => (t.SalesPage = "SalesPage", t.Typebot = "Typebot", t.NativeWhatsApp = "NativeWhatsApp", t.PresellWhatsApp = "PresellWhatsApp", t.Others = "Others", t))(a || {}),
    Z = (t => (t.Manual = "Manual", t.ZapVoice = "ZapVoice", t.Chatbot = "Chatbot", t))(Z || {});
const mt = t => {
        switch (t) {
            case "Meta":
                return "Meta";
            case "Google":
                return "Google";
            case "Kwai":
                return "Kwai";
            case "TikTok":
                return "TikTok";
            default:
                return "Outras"
        }
    },
    Tt = t => {
        switch (t) {
            case "SalesPage":
                return "Página de Vendas";
            case "Typebot":
                return "Typebot";
            case "NativeWhatsApp":
                return "Anúncio -> WhatsApp";
            case "PresellWhatsApp":
                return "Anúncio -> Pré Sell -> WhatsApp";
            default:
                return "Outras"
        }
    },
    Ct = t => {
        switch (t) {
            case "Manual":
                return "Atendimento Manual";
            case "ZapVoice":
                return "Atendimento Semi-Automático (ZapVoice)";
            case "Chatbot":
                return "Fluxo Automático (BotCoversa, Dispara.ai, etc)";
            default:
                return "Outras"
        }
    };
class b {
    constructor(e) {
        S(this, "dash");
        this.dash = e
    }
    static fromDash(e) {
        return e ? new b(e) : null
    }
    static fromDashId(e, s) {
        const n = s == null ? void 0 : s.user.dashboards.find(o => o.id === e);
        return n ? new b(n) : null
    }
    setDash(e) {
        this.dash = e
    }
    isComplete() {
        var n;
        return this.dash.onboardingOptions ? this.getNeededStepsStatus().filter(o => !o.completed).length === 0 : ((n = m.fromDash(this.dash)) == null ? void 0 : n.isComplete()) ? ? !1
    }
    areQuestionsAnswered() {
        return this.dash.onboardingOptions ? this.getMissingQuestions().length === 0 : !1
    }
    getMissingQuestions() {
        var n, o, c, i;
        const e = [];
        return (((n = this.dash.onboardingOptions) == null ? void 0 : n.adPlatforms.length) ? ? 0) <= 0 && e.push("AdPlatforms"), (((o = this.dash.onboardingOptions) == null ? void 0 : o.funnelStrategies.length) ? ? 0) <= 0 && e.push("FunnelStrategies"), [a.NativeWhatsApp, a.PresellWhatsApp].some(l => {
            var h;
            return (h = this.dash.onboardingOptions) == null ? void 0 : h.funnelStrategies.includes(l)
        }) && (((i = (c = this.dash.onboardingOptions) == null ? void 0 : c.whatsAppStrategies) == null ? void 0 : i.length) ? ? 0) <= 0 && e.push("WhatsAppStrategies"), e
    }
    getNeededStepsStatus() {
        var w, M, W, U, y, G, K, E, P, I, v, B, D;
        const e = [];
        if (!this.dash.onboardingOptions) return e;
        const {
            adPlatforms: s
        } = this.dash.onboardingOptions, {
            funnelStrategies: n
        } = this.dash.onboardingOptions, {
            whatsAppStrategies: o
        } = this.dash.onboardingOptions, c = s.includes(p.Meta), i = s.includes(p.Google), l = s.includes(p.Kwai), h = s.includes(p.TikTok), T = n.includes(a.SalesPage) || n.includes(a.PresellWhatsApp), C = n.includes(a.Typebot), d = [a.SalesPage, a.Typebot, a.PresellWhatsApp].some(f => n.includes(f)), r = c && d, u = i && d, A = l && d, g = h && d, k = [a.NativeWhatsApp, a.PresellWhatsApp].some(f => n.includes(f)), z = o == null ? void 0 : o.includes(Z.Chatbot), F = x(this.dash), L = V(this.dash).length, Q = N(this.dash), j = O(this.dash).length, H = lt(this.dash), R = dt(this.dash).length, X = pt(this.dash), q = rt(this.dash).length, J = ((M = (w = this.dash) == null ? void 0 : w.webhooks) == null ? void 0 : M.length) ? ? 0, Y = ((U = (W = this.dash) == null ? void 0 : W.apiCredentials) == null ? void 0 : U.length) ? ? 0, $ = J + Y, _ = ((y = this.dash.onboardingOptions.cache) == null ? void 0 : y.installedPageScript) ? ? !1, tt = ((G = this.dash.onboardingOptions.cache) == null ? void 0 : G.installedTypebotScript) ? ? !1, et = ((K = this.dash.onboardingOptions.cache) == null ? void 0 : K.setMetaUtms) ? ? !1, st = ((E = this.dash.onboardingOptions.cache) == null ? void 0 : E.setGoogleUtms) ? ? !1, nt = ((P = this.dash.onboardingOptions.cache) == null ? void 0 : P.setKwaiUtms) ? ? !1, ot = ((I = this.dash.onboardingOptions.cache) == null ? void 0 : I.setTikTokUtms) ? ? !1, at = ((B = (v = this.dash) == null ? void 0 : v.whatsApps) == null ? void 0 : B.length) ? ? 0, ct = ((D = this.dash.onboardingOptions.cache) == null ? void 0 : D.configuredWhatsAppBot) ? ? !1;
        return c && e.push({
            key: "ConnectMeta",
            completed: F
        }), c && e.push({
            key: "EnableMetaAdAccount",
            completed: L > 0
        }), i && e.push({
            key: "ConnectGoogle",
            completed: Q
        }), i && e.push({
            key: "EnableGoogleAdAccount",
            completed: j > 0
        }), l && e.push({
            key: "ConnectKwai",
            completed: H
        }), l && e.push({
            key: "EnableKwaiAdAccount",
            completed: R > 0
        }), h && e.push({
            key: "ConnectTikTok",
            completed: X
        }), h && e.push({
            key: "EnableTikTokAdAccount",
            completed: q > 0
        }), e.push({
            key: "ConnectSalesSource",
            completed: $ > 0
        }), T && e.push({
            key: "InstallSalesPageScript",
            completed: _
        }), C && e.push({
            key: "InstallTypebotScript",
            completed: tt
        }), r && e.push({
            key: "SetMetaUtms",
            completed: et
        }), u && e.push({
            key: "SetGoogleUtms",
            completed: st
        }), A && e.push({
            key: "SetKwaiUtms",
            completed: nt
        }), g && e.push({
            key: "SetTikTokUtms",
            completed: ot
        }), k && e.push({
            key: "ConnectWhatsApps",
            completed: at > 0
        }), z && e.push({
            key: "ConfigWhatsAppBot",
            completed: ct
        }), e
    }
}
var ut = (t => (t.AdPlatforms = "AdPlatforms", t.FunnelStrategies = "FunnelStrategies", t.WhatsAppStrategies = "WhatsAppStrategies", t))(ut || {}),
    At = (t => (t.ConnectMeta = "ConnectMeta", t.EnableMetaAdAccount = "EnableMetaAdAccount", t.ConnectGoogle = "ConnectGoogle", t.EnableGoogleAdAccount = "EnableGoogleAdAccount", t.ConnectKwai = "ConnectKwai", t.EnableKwaiAdAccount = "EnableKwaiAdAccount", t.ConnectTikTok = "ConnectTikTok", t.EnableTikTokAdAccount = "EnableTikTokAdAccount", t.ConnectSalesSource = "ConnectSalesSource", t.InstallSalesPageScript = "InstallSalesPageScript", t.InstallTypebotScript = "InstallTypebotScript", t.SetMetaUtms = "SetMetaUtms", t.SetGoogleUtms = "SetGoogleUtms", t.SetKwaiUtms = "SetKwaiUtms", t.SetTikTokUtms = "SetTikTokUtms", t.ConnectWhatsApps = "ConnectWhatsApps", t.ConfigWhatsAppBot = "ConfigWhatsAppBot", t))(At || {});
const ft = t => {
    switch (t) {
        case "ConnectMeta":
            return "Conexão Meta";
        case "EnableMetaAdAccount":
            return "Contas Meta";
        case "ConnectGoogle":
            return "Conexão Google";
        case "EnableGoogleAdAccount":
            return "Contas Google";
        case "ConnectKwai":
            return "Conexão Kwai";
        case "EnableKwaiAdAccount":
            return "Contas Kwai";
        case "ConnectTikTok":
            return "Conexão TikTok";
        case "EnableTikTokAdAccount":
            return "Contas TikTok";
        case "ConnectSalesSource":
            return "Plataforma de Vendas";
        case "InstallSalesPageScript":
            return "Página de Vendas";
        case "InstallTypebotScript":
            return "Typebot";
        case "SetMetaUtms":
            return "UTMs da Meta";
        case "SetGoogleUtms":
            return "UTMs do Google";
        case "SetKwaiUtms":
            return "UTMs do Kwai";
        case "SetTikTokUtms":
            return "UTMs do TikTok";
        case "ConnectWhatsApps":
            return "Conectar WhatsApps";
        case "ConfigWhatsAppBot":
            return "Bot de WhatsApp";
        default:
            return "Outros"
    }
};
export {
    b as O, ut as a, p as b, a as c, Tt as d, Z as e, Ct as f, ft as g, mt as h, At as i
};