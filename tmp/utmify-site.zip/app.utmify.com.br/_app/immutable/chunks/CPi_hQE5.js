import {
    c as r
} from "./DwsiLpv2.js";

function i(c, ...n) {
    const o = r.bind(null, n.find(t => typeof t == "object"));
    return n.map(o)
}
export {
    i as n
};