import {
    U as e
} from "./B5WePDbK.js";
class u {
    static async execute(t) {
        var a;
        const s = await e.put("/dashboards/complete-utms-config", {
            dashboardId: t.dashboardId
        }, {
            token: ((a = t.authData) == null ? void 0 : a.token) ? ? ""
        });
        return s.statusCode === 401 ? {
            status: "UNAUTHORIZED"
        } : s.statusCode === 200 ? {
            status: "SUCCESS"
        } : {
            status: "UNKNOWN"
        }
    }
}
export {
    u as C
};