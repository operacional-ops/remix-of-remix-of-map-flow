import {
    s as r,
    n as o,
    d,
    i as n,
    c,
    o as u,
    h as m
} from "./DDNnt9XD.js";
import {
    S as l,
    i as p
} from "./qWASNxYk.js";

function f(t) {
    let e, s = `<h1 class="text-3xl font-bold mb-2 text-center">TERMOS DE USO</h1> <p class="mb-2 text-justify text-md">Antes de utilizar o Software UTMify (&quot;Software&quot; ou &quot;Plataforma&quot;), assim como
    os serviços a ele associados, é essencial a leitura atenta deste contrato.
    Ao aceitar este Termo de Uso o Usuário, tanto na qualidade de pessoa física
    quanto jurídica, concorda e se compromete a aderir a todos os termos e
    condições aqui estabelecidos. Em caso de desconcordância, abstenha-se de
    usar a Plataforma e os Serviços oferecidos pela UTMIFY TECNOLOGIA LTDA.
    (“Contratada” e/ou “UTMify”).</p> <p class="mb-2 text-justify text-md">Este Contrato de Termo de Uso formaliza o acordo completo entre o Usuário e
    a Contratada, UTMIFY TECNOLOGIA LTDA, pessoa jurídica de direito privado,
    regularmente registrada sob o CNPJ n° 44.105.337/0001-39, com sede à Rua
    Moyses Braga Lima, n° 271, Bairro Goiabal, Barra Mansa – RJ, CEP 27.340-110.
    A Contratada é a única proprietária dos direitos de propriedade intelectual
    e detentora dos direitos sobre o Software UTMify, concedendo ao Cliente, por
    meio deste documento, a licença de uso. Este contrato define o escopo da
    relação entre as partes, sendo que o Cliente afirma ter lido, entendido e
    aceitado todas as condições apresentadas neste acordo.</p> <h2 class="text-xl font-bold mb-2">CLÁUSULA PRIMEIRA – DO OBJETO</h2> <p class="mb-2 text-justify text-md">1.1. Este documento define os termos e condições sob os quais o Cliente é
    concedido o direito de utilizar os Serviços da UTMify, por meio de uma
    licença revogável, não exclusiva e intransferível. Constituem partes
    integrantes e complementares deste Termo a Política de Privacidade e a
    Política de Cookies da UTMify, que pode ser acessada na Plataforma.</p> <h2 class="text-xl font-bold mb-2">CLÁUSULA SEGUNDA – DA PLATAFORMA E DOS SERVIÇOS</h2> <p class="mb-2 text-justify text-md">2.1. A plataforma UTMify trata-se de Software as a Service (SaaS), sendo
    projetada para oferecer aos Usuários uma identificação precisa das origens
    de vendas em campanhas de tráfego pago de diferentes plataformas, o que
    permite uma coleta eficiente e facilitada de dados, destinada a otimizar as
    estratégias de marketing ao escalar campanhas rentáveis e desativar aquelas
    que geram prejuízo, resultando em uma gestão mais eficiente, economia de
    tempo e aumento de lucratividade.</p> <p class="mb-2 text-justify text-md">2.2. A plataforma UTMify disponibiliza diversas funcionalidades essenciais,
    conforme Plano de contratação escolhido pelo Usuário, dentre outras que
    podem ser introduzidas no futuro, atualmente incluem: (a) a consolidação de
    dados de múltiplas operações e plataformas de venda, permitindo uma
    visualização unificada; (b) identificação precisa da origem das vendas por
    campanha; (c) otimização direta de campanhas a partir dos relatórios da
    UTMify, eliminando a necessidade de utilizar gerenciadores externos; (d)
    capacidade de duplicar campanhas para diferentes contas de anúncio; e (e)
    implementação de regras para a otimização automática de campanhas, visando a
    eficiência e o aumento da performance.</p> <p class="mb-2 text-justify text-md">2.3. A funcionalidade e a eficácia dos serviços disponibilizados pela
    plataforma UTMify dependem da coleta de informações e da comunicação com uma
    variedade de aplicativos e plataformas externas. Isso inclui, mas não se
    limita a, redes sociais, sistemas de processamento de pagamentos, gateways
    de pagamento, plataformas de afiliados, dentre outros sistemas. Essas
    integrações são realizadas tecnicamente através de webhooks, APIs e outras
    tecnologias de conexão, permitindo a UTMify acessar e sincronizar dados
    necessários para a otimização das campanhas de marketing digital dos
    Usuários, garantindo uma gestão de tráfego eficaz e informada.</p> <p class="mb-2 text-justify text-md">2.4. A plataforma UTMify estará acessível ao Usuário 24:00 (vinte e quatro)
    horas por dia, 07 (sete) dias por semana. Entretanto, a disponibilidade do
    serviço pode ser temporariamente suspensa pela Contratada sob certas
    condições, para garantir a qualidade e segurança do serviço oferecido, em
    casos como, mas não se limitando a:</p> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">Manutenções preventivas agendadas, para as quais os Usuários serão
      notificados com, pelo menos, 02 (dois) dias de antecedência, especificando
      a data e o horário previstos para a interrupção;</li> <li class="mb-2 text-justify text-md">Manutenções emergenciais necessárias devido a falhas técnicas inesperadas
      que comprometam o funcionamento da Plataforma;</li> <li class="mb-2 text-justify text-md">Atualizações significativas no software ou hardware vinculado a
      Plataforma, visando aprimorar funcionalidades ou corrigir vulnerabilidades
      de segurança, com comunicação prévia sempre que possível;</li> <li class="mb-2 text-justify text-md">Incidentes de segurança cibernética, como ataques de negação de serviço
      (DDoS) ou suspeitas de invasão, que exigem intervenção imediata para
      proteger os dados dos Usuários e a integridade da plataforma;</li> <li class="mb-2 text-justify text-md">Incidentes de segurança cibernética, como ataques de negação de serviço
      (DDoS) ou suspeitas de invasão, que exigem intervenção imediata para
      proteger os dados dos Usuários e a integridade da plataforma;</li> <li class="mb-2 text-justify text-md">Problemas significativos de infraestrutura de rede ou falhas de serviços
      de terceiros críticos para o funcionamento da UTMify;</li> <li class="mb-2 text-justify text-md">Solicitações legais ou judiciais que exijam a suspensão temporária dos
      serviços ou a análise de dados específicos;</li> <li class="mb-2 text-justify text-md">Eventos fora do controle da Contratada, incluindo mas não se limitando a
      eventos causados por ações ou omissões do Usuário, eventos resultantes de
      falhas de hardware, software ou outras tecnologias utilizados pelo Usuário
      e, por fim, qualquer ato ou fato que importe em caso fortuito ou força
      maior, conforme art. 393 do Código Civil.</li></ul> <p class="mb-2 text-justify text-md">2.5. Em todas essas situações, a Contratada compromete-se a reduzir ao
    mínimo o tempo de interrupção e a comunicar os Usuários com antecedência
    sempre que possível, esclarecendo os motivos da suspensão e o tempo estimado
    para a resolução.</p> <p class="mb-2 text-justify text-md">2.6. A Contratada não será responsável por quaisquer prejuízos ou danos
    causados ao Usuário ou a terceiros devido à indisponibilidade temporária da
    plataforma, quando esta estiver associada às situações delineadas na
    Cláusula 2.4 deste instrumento.</p> <p class="mb-2 text-justify text-md">2.7. A Contratada compromete-se a fornecer ao Usuário todas as novas
    versões, atualizações, melhorias e quaisquer implementações dos serviços e
    funcionalidades inclusas no plano contratado. Adicionalmente, a Contratada
    se responsabiliza por oferecer suporte técnico ao Usuário pelo período
    integral do contrato.</p> <p class="mb-2 text-justify text-md">2.8. O suporte técnico fica acessível das 8h às 18h, conforme o horário de
    Brasília, de segunda a sexta-feira, excluindo-se feriados, por meio do
    e-mail [EMAIL], sem custos extras. Todas as questões ou problemas técnicos
    relatados serão atendidos por ordem de chegada, concedendo-se atendimento
    prioritário aos usuários inscritos em planos que incluem essa vantagem.</p> <p class="mb-2 text-justify text-md">2.9. A Contratada não assegura a resolução de todas as dúvidas e
    solicitações do Usuário, nem a solução de todos os problemas, em uma única
    interação ou dentro de um prazo específico. No entanto, compromete-se a
    prestar o atendimento conforme solicitado pelo Usuário.</p> <p class="mb-2 text-justify text-md">2.10. Nenhuma das partes será responsável pelos lucros cessantes, danos
    diretos, indiretos, especiais, incidentais, consequenciais ou quaisquer
    outros prejuízos sofridos pela outra parte. Em particular, a Contratada não
    será responsável por perdas ou danos sofridos pelo Usuário devido a:</p> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">Decisões tomadas com base em informações fornecidas na Plataforma,
      provenientes de terceiros;</li> <li class="mb-2 text-justify text-md">Falhas operacionais ou de servidores que não sejam diretamente atribuíveis
      à Contratada;</li> <li class="mb-2 text-justify text-md">Interrupções no fornecimento dos serviços decorrentes das condições
      estipuladas anteriormente na Cláusula referida como Item 2.4;</li></ul> <p class="mb-2 text-justify text-md">2.11. A Contratada não será em hipótese alguma responsável por danos ou
    prejuízos de qualquer natureza decorrentes do acesso, interceptação,
    eliminação, alteração ou manipulação de arquivos e comunicações por parte de
    terceiros não autorizados ou pelo próprio Usuário, que não tenha dado causa.
    Isso inclui dados armazenados, transmitidos ou disponibilizados através dos
    serviços contratados.</p> <p class="mb-2 text-justify text-md">2.12. A Contratada não assume responsabilidade por eventuais erros ou falhas
    resultantes do funcionamento inadequado de plataformas de terceiros com as
    quais se integra, tais como, mas não se limitando a (a) discrepâncias nas
    permissões das contas vinculadas à UTMify, que podem ocasionar erros na
    duplicação; (b) possíveis instabilidades originárias das próprias
    plataformas terceiras; (c) atualizações ou alterações nos protocolos de
    integração das plataformas terceiras que possam afetar a comunicação ou a
    funcionalidade da UTMify; (d) atrasos ou falhas na transmissão de dados
    devido a sobrecarga nos servidores das plataformas terceiras; (e)
    informações incorretas ou incompletas fornecidas pelas plataformas terceiras
    devido a erros de seus próprios sistemas; (f) indisponibilidade temporária
    de recursos ou funcionalidades de plataformas terceiras em virtude de
    restrições legais, regulamentares ou de políticas internas dessas entidades.</p> <p class="mb-2 text-justify text-md">2.13. A Contratada não será responsável por dados incorretos ou resultados
    insatisfatórios causados pela má configuração de suas ferramentas pelo
    Usuário. É imperativo que os Usuários garantam a correta configuração e uso
    da Plataforma, conforme instruções fornecidas pela mesma, para assegurar a
    acurácia dos dados recebidos e o desempenho esperado dos serviços.</p> <p class="mb-2 text-justify text-md">2.14. O Usuário esta ciente da obrigação e se compromete a notificar a
    Contratada imediatamente em caso de suspeita de violação de segurança ou uso
    não autorizado de sua conta, sendo de sua única e exclusiva responsabilidade
    criar senha segura no momento do registro e manter a confidencialidade e uso
    adequado da mesma, bem como da Plataforma. A Contratada não assume
    responsabilidade por uso indevido da senha do Usuário por terceiros.</p> <p class="mb-2 text-justify text-md">2.15. A Contratada não será responsável por danos ou prejuízos sofridos pelo
    Cliente associados à corrupção, processamento inadequado ou perda de dados,
    falhas na transmissão ou recebimento de informações, resultantes ou
    relacionados ao uso inadequado ou incapacidade de uso da Plataforma.</p> <p class="mb-2 text-justify text-md">2.16. A UTMify não apoia, não consente e não é conivente com a prática de
    golpes, fraudes, condutas ilícitas, criminosas ou abusivas de qualquer
    natureza por parte de seus Usuários. Todavia, em razão das limitações
    tecnológicas atuais, não é possível à Contratada fiscalizar de forma
    automática, integral e ininterrupta todas as operações realizadas pelos
    Usuários dentro ou fora da Plataforma.</p> <p class="mb-2 text-justify text-md">2.17. Para auxiliar na prevenção e repressão de abusos, a UTMify possui
    protocolo interno de Notice Review and Takedown, por meio do qual possui
    programa de recebimento de denúncias e investigação de casos suspeitos.
    Disponibiliza um canal oficial para recebimento de denúncias, sendo ele: um
    endereço de e-mail exclusivo, denuncia@utmify.com.br.</p> <p class="mb-2 text-justify text-md">2.18. Por meio desses canais, terceiros ou quaisquer interessados poderão
    comunicar a suspeita ou comprovação de que Usuários utilizam a Plataforma
    para práticas ilícitas, criminosas ou abusivas. A denúncia deverá conter,
    obrigatoriamente: (a) nome completo do denunciante; (b) e-mail e telefone de
    contato; (c) declaração de veracidade das informações prestadas, sob as
    penas da lei; (d) identificação do cliente denunciado, por meio de URL, ID
    ou outros dados disponíveis; (e) links dos anúncios ou sites denunciados;
    (f) categoria da violação (fraude financeira, phishing, etc.); (g) descrição
    detalhada e cronológica do ocorrido; e (h) upload de evidências, como
    capturas de tela, e-mails, comprovantes de pagamento ou outros documentos
    pertinentes.</p> <p class="mb-2 text-justify text-md">2.19. Recebida a denúncia, a UTMify instaurará procedimento administrativo
    interno para apuração, reservando-se o direito de, constatada a gravidade
    inequívoca da conduta, suspender temporária ou definitivamente o acesso do
    Usuário denunciado, sem prejuízo de adoção das medidas legais cabíveis,
    incluindo comunicação às autoridades competentes.</p> <p class="mb-2 text-justify text-md">2.20. As medidas de investigação, apuração e repressão de condutas ilícitas
    adotadas pela UTMify configuram obrigação de meio, e não de resultado,
    limitando-se a Contratada a proceder com diligência razoável e proporcional.
    A UTMify não se responsabiliza por eventuais falhas, omissões ou atrasos
    decorrentes da complexidade dos fatos, preservando-se, contudo, o direito de
    encaminhar as informações coletadas às autoridades competentes.</p> <p class="mb-2 text-justify text-md">2.21. A UTMify possui Protocolo Interno de Cooperação com Autoridades, com o
    fim de cooperar com autoridades policiais, administrativas e judiciais
    mediante requisições válidas e fundamentadas na legislação aplicável,
    limitando-se ao fornecimento de dados solicitados e necessários ao
    atendimento do pedido, quando respectiva autoridade proceder a solicitação
    formal de informações de usuários destinada ao prosseguimento de
    investigações, processos oficiais, resolução de fatos ou cumprimento de
    obrigações legais.</p> <p class="mb-2 text-justify text-md">2.22. As comunicações oficiais de autoridades deverão ser encaminhadas para
    o canal exclusivo autoridades@utmify.com.br.</p> <p class="mb-2 text-justify text-md">2.23. Para fins de segurança e rastreabilidade, a UTMify poderá exigir que a
    requisição contenha, no mínimo: identificação do órgão solicitante, número
    de procedimento (ex.: inquérito/processo), autoridade signatária,
    especificação objetiva dos dados solicitados e respectiva fundamentação
    legal.</p> <p class="mb-2 text-justify text-md">2.24. Pedidos manifestamente genéricos, tecnicamente inviáveis ou que
    ultrapassem limites legais poderão ser objeto de esclarecimentos, limitação
    ou recusa justificada, sem prejuízo de posterior fornecimento das
    informações, mediante reiteração e/ou esclarecimento pela autoridade, de
    modo a possibilitar o envio das respectivas informações.</p> <h2 class="text-xl font-bold mb-2">CLÁUSULA TERCEIRA – DOS PLANOS E DAS MIGRAÇÕES</h2> <p class="mb-2 text-justify text-md">3.1. Como contrapartida pelo licenciamento e serviços fornecidos, o Usuário
    efetuará o pagamento à Contratada de acordo com a tabela de preços vigente
    no momento da contratação para o plano selecionado na Plataforma.Os
    pagamentos serão efetuados antecipadamente, segundo o modelo &quot;pague para
    usar&quot;, e de acordo com a periodicidade disponível na plataforma e escolhida
    pelo Usuário.</p> <p class="mb-2 text-justify text-md">3.2. Atualmente, os planos oferecidos são: (a) Gratuito; (b) Premium; (c)
    Avançado; (d) Monster. A Contratada reserva-se o direito de modificar, a
    qualquer momento, a composição e as funcionalidades dos planos, sempre
    respeitando as demais cláusulas destes Termos de Uso. Alterações nos planos
    serão aplicadas ao Usuário apenas após o término do ciclo vigente de seu
    plano atual. Em caso de discordância com as mudanças propostas, o Usuário
    tem o direito de cancelar o plano e rescindir o contrato.</p> <p class="mb-2 text-justify text-md">3.2.1 Cada plano disponibilizado pela Plataforma UTMify é delimitado por um
    número máximo de vendas aprovadas mensalmente, dentro do qual não serão
    aplicadas cobranças extras. Caso o número de vendas exceda o limite
    estabelecido para o plano contratado, incidirá uma taxa adicional por venda
    excedente, conforme detalhado na descrição de cada plano disponível. O valor
    devido por vendas que ultrapassem o limite será calculado ao final de cada
    mês e deverá ser quitado no ciclo de faturamento subsequente.</p> <p class="mb-2 text-justify text-md">3.2.2. Além do número de vendas por mês, cada plano possui limite específico
    de vinculação (a) contas de anúncios; (b) webhooks; (c) dashboards; (d)
    regras programadas. O Usuário que desejar expandir a quantidade destes itens
    deverá optar pela contratação de um plano superior. Apenas o plano de maior
    categoria, denominado Monster, oferece quantidades ilimitadas dos recursos
    listados.</p> <p class="mb-2 text-justify text-md">3.3. A forma de pagamento será exclusivamente via cartão de crédito, podendo
    a Contratada disponibilizar novas formas de pagamento a qualquer tempo.</p> <p class="mb-2 text-justify text-md">3.4. Ao optar pelo pagamento via cartão de crédito, o Usuário autoriza que a
    Contratada realize a cobrança automática para renovação do plano, seguindo o
    valor e a periodicidade acordados. A cobrança das parcelas subsequentes será
    efetuada na mesma data do mês da primeira cobrança, ajustando-se para o
    último dia do mês quando a data inicial ocorrer em dia 29, 30 ou 31, e
    referidos dias não estiverem presentes no seguinte mês do ano-calendário.</p> <p class="mb-2 text-justify text-md">3.5. Em caso de concessão de descontos ou benefícios pela UTMify ao Usuário
    para a contratação de serviços e/ou acesso a plataforma, referidos descontos
    promocionais: (a) não são cumulativos; (b) serão exclusivos aos planos e
    periodicidades a que se referem; (c) possuem prazo de validade conforme
    informado pela UTMify ao Usuário quando realizada a oferta de desconto; (d)
    poderá perder sua validade, caso o Usuário reduza os serviços, as
    funcionalidades ou o Plano originalmente contratado.</p> <p class="mb-2 text-justify text-md">3.6. Os preços dos serviços contínuos serão reajustados anualmente, ou na
    menor periodicidade permitida por lei, de forma automática, com base na
    variação positiva do IPCA, ou de outro índice que o substitua. A data base
    para os reajustes anuais será a data de início do primeiro plano pago
    contratado pelo Usuário, sendo não haverá ajuste de preços para o período em
    que o índice de reajuste apresentar variação negativa.</p> <p class="mb-2 text-justify text-md">3.7. A Contratada reserva-se o direito de modificar os preços dos planos a
    qualquer momento, notificando o Usuário com no mínimo 30 (trinta) dias de
    antecedência, estando o Usuário livre para cancelar o plano se em caso de
    desconcordância com o aumento de referido valor, que só será aplicado após o
    término do ciclo de pagamento atual.</p> <p class="mb-2 text-justify text-md">3.8. O não pagamento das retribuições ajustadas importará na incidência de
    multa de 2% (dois por cento), por atraso, acrescido de juros de mora de 1%
    (um por cento) ao mês.</p> <p class="mb-2 text-justify text-md">3.9. O Usuário permanecerá responsável pelo pagamento na data de vencimento,
    ainda que ocorra atrasos, por qualquer motivo, ou desvinculação do cartão de
    crédito na plataforma, até a data do pagamento, devendo contatar via e-mail
    para informar o ocorrido e realizar o pagamento pontualmente.</p> <p class="mb-2 text-justify text-md">3.10. Na hipótese de inadimplência pelo Usuário, poderá a Contratada optar,
    a seu exclusivo critério e mera liberalidade, pela resolução do presente
    contrato, ou suspensão da licença de acesso, bem como suspensão parcial ou
    total dos serviços contratados, podendo referidos acessos e serviços serem
    restabelecidos até 24 horas após o pagamento.</p> <p class="mb-2 text-justify text-md">3.11. No caso de suspensão temporária dos serviços devido a inadimplemento
    do Usuário, a Contratada ainda poderá receber dados das plataformas de
    terceiros. Se o inadimplemento for resolvido dentro de um período de até 30
    dias, o acesso aos serviços será restabelecido e os dados mantidos. Contudo,
    se a pendência não for regularizada após 30 dias, a Contratada reserva-se o
    direito de eliminar todos os dados do Usuário e cessar o recebimento de
    novas informações das plataformas terceiras.</p> <p class="mb-2 text-justify text-md">3.12. O eventual cancelamento ou redução do Plano, serviços e
    funcionalidades contratadas, antes do final do prazo de vigência contratado,
    não importará na restituição de valores pagos antecipadamente, ou
    redução/abatimento dos valores a pagar em razão da solicitação do Usuário,
    sendo disponibilizado o acesso à plataforma e ao serviço contratado ao
    Usuário até a data prevista para o encerramento do Plano.</p> <h2 class="text-xl font-bold mb-2">CLÁUSULA QUARTA – DAS OBRIGAÇÕES DO USUÁRIO</h2> <p class="mb-2 text-justify text-md">4.1. O Usuário reconhece que o acesso aos Serviços oferecidos pela UTMify
    depende da conexão à internet, e se responsabiliza pela aquisição e
    manutenção dos equipamentos necessários, bem como pelos serviços de conexão
    e configurações técnicas requeridas para o acesso e funcionamento adequado
    da Plataforma, inclusive quaisquer falhas de seus próprios dispositivos ou
    da sua conexão com a internet.</p> <p class="mb-2 text-justify text-md">4.2. O Usuário afirma e declara que seus dados e informações financeiras e
    de identificação por si inseridas na Plataforma são autênticas e precisas,
    sendo totalmente responsável pela veracidade e atualização desses dados,
    incluindo a manutenção de um endereço de e-mail válido e sob sua
    propriedade.</p> <p class="mb-2 text-justify text-md">4.3. A segurança dos Dados de Acesso à Plataforma é de exclusiva
    responsabilidade do Usuário, que deve entrar em contato com a Contratada sem
    demora caso haja qualquer suspeita de violação de segurança, sem prejuízo de
    alterar suas senhas prontamente como medida de segurança.</p> <p class="mb-2 text-justify text-md">4.4. É expressamente vedado ao Usuário:</p> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">Utilizar a Plataforma para fins alheios aos estabelecidos neste Termo, bem
      como para fins ilícitos, infringindo leis aplicáveis, direitos de
      propriedade, normas de conduta aceitáveis, direitos intelectuais, de
      privacidade ou que se relaciona à divulgação de conteúdo ilegal, imoral ou
      ofensivo;</li> <li class="mb-2 text-justify text-md">Conceder sublicenças, transferir, comercializar ou de qualquer forma
      dispor dos direitos de uso da Plataforma contrariamente ao estabelecido
      neste Termo de Uso;</li> <li class="mb-2 text-justify text-md">Modificar, adaptar ou empregar qualquer parte da Plataforma ou seu
      conteúdo para fins diversos sem prévia e expressa autorização da
      Contratada;</li> <li class="mb-2 text-justify text-md">Comprometer a segurança da Plataforma com práticas como exploração de
      vulnerabilidades, spamming, inundação de dados (flooding), falsificação de
      identidade (spoofing), travamento de sistema (crashing) ou introdução de
      rootkits;</li> <li class="mb-2 text-justify text-md">Realizar engenharia reversa dos componentes da Plataforma;</li> <li class="mb-2 text-justify text-md">Disseminar ou transmitir arquivos que contenham vírus ou qualquer outro
      elemento prejudicial que possa afetar a funcionalidade da Plataforma.</li></ul> <p class="mb-2 text-justify text-md">4.5. A Contratada reserva-se ao direito, a seu exclusivo critério:</p> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">Terminar, modificar ou suspender o acesso do Usuário à sua conta, em caso
      de constatação de qualquer violação das condições deste Termo ou à lei;</li> <li class="mb-2 text-justify text-md">Excluir informações inseridas pelo Usuário que estejam em desacordo com as
      diretrizes dos Termos de Uso e/ou da Política de Privacidade;</li> <li class="mb-2 text-justify text-md">Desativar o acesso dados, informações e/ou conteúdos que violem as
      disposições deste contrato;</li></ul> <p class="mb-2 text-justify text-md">4.6. O Usuário concorda em ressarcir, defender e isentar a Contratada e suas
    entidades associadas de quaisquer responsabilidades, custos, prejuízos ou
    demandas, incluindo honorários advocatícios e despesas judiciais, que
    decorram de mau uso da Plataforma ou de qualquer quebra dos termos deste
    contrato.</p> <p class="mb-2 text-justify text-md">4.7. O Usuário declara que empregará a Plataforma exclusivamente para
    gerenciamento de sua atividade profissional, conforme possibilidades e
    funcionalidades expressas neste contrato, assumindo a para si a
    responsabilidade por quaisquer resultados, positivos ou negativos, dela
    provenientes.</p> <p class="mb-2 text-justify text-md">4.8. É expressamente vedado ao Usuário utilizar a Plataforma para veicular,
    promover ou gerenciar campanhas de doações, arrecadação pública, vaquinhas
    virtuais ou atividades análogas. Essa vedação se justifica pelo risco
    elevado de utilização dessas campanhas como meio de fraude ou lesão a
    terceiros, não possuindo a UTMify condições técnicas de auditar a
    legitimidade e a finalidade de tais iniciativas.</p> <h2 class="text-xl font-bold mb-2">CLÁUSULA QUINTA – DA VIGÊNCIA E DA RESOLUÇÃO DE CONTRATO</h2> <p class="mb-2 text-justify text-md">5.1. O aceite destes Termos de Uso ocorrerá na própria plataforma, e de
    referido aceite conta-se o prazo de vigência deste contrato.</p> <p class="mb-2 text-justify text-md">5.2. Exceto pelas obrigações que, por determinação legal ou disposição
    contratual, devam perdurar por tempo superior aos prazos infra
    estabelecidos, a duração do prazo de vigência deste Termo será pelo tempo
    que perdurar a presente relação, ou até que outro documento venha a
    substituí-lo.</p> <p class="mb-2 text-justify text-md">5.3. O Usuário poderá cancelar qualquer plano contratado em até 7 (sete)
    dias contados de sua contratação, a título de encerramento de período de
    testes, sem a aplicação de quaisquer penalidades e com direito a recebimento
    do valor integralmente pago e, em caso de não cancelamento, correrá o plano
    normalmente. A renovação do plano escolhido ocorrerá automaticamente quando
    findo o seu período de vigência, salvo manifestação prévia e expressa do
    Usuário quanto a intenção de não o renovar, que deverá ser comunicada à
    Contratada em até 1 (um) dia útil anteriormente ao termino/renovação do
    plano vigente, por cancelamento na própria plataforma. O cancelamento
    torna-se efetivo imediatamente após o encerramento do ciclo de faturamento
    atual do plano escolhido.</p> <p class="mb-2 text-justify text-md">5.4. As informações do Cliente serão excluídas do banco de dados da
    Contratada após 60 (sessenta) dias contados do encerramento da presente
    relação, salvo se devam ser mantidas em guarda pela Contratada por obrigação
    legal, bem como por solicitação de autoridade ou órgão competente.</p> <p class="mb-2 text-justify text-md">5.5. Na hipótese de solicitação de resolução pelo Cliente durante um ciclo
    de pagamento, os termos ora presentes continuarão válidos e eficazes até o
    término do período coberto pela última parcela paga, garantindo ao Cliente
    acesso aos serviços até o final de referido prazo, sendo cancelados
    automaticamente tão somente ao fim do período, hipótese na qual não serão
    devolvidos quaisquer valores pagos antecipadamente, a qualquer título.</p> <p class="mb-2 text-justify text-md">5.6. A Contratada poderá, a qualquer tempo e por mera liberalidade, mediante
    notificação prévia e expressa com 15 (quinze) dias de antecedência, resolver
    o contrato sem a aplicação de qualquer penalidade, obrigatoriedade de
    qualquer pagamento, ou quaisquer outras reclamações pelo Usuário, exceto
    pela devolução dos valores pagos antecipadamente pelo Cliente, em proporção
    correspondente ao período remanescente de vigência contratado.</p> <p class="mb-2 text-justify text-md">5.7. Sem prejuízo das demais obrigações e responsabilidades descritas neste
    contrato, a presente relação poderá ser resolvida, por qualquer das partes e
    a qualquer tempo, mediante mera notificação prévia e por escrito, em caso
    de:</p> <ul class="list-disc ml-6"><li class="mb-2 text-justify text-md">seja verificado o não pagamento dos valores acordados no prazo, no valor e
      na forma prevista;</li> <li class="mb-2 text-justify text-md">verifique-se a inviabilidade de cumprimento das obrigações contratuais
      devido a casos fortuitos ou de força maior que se estendam por mais de 30
      (trinta) dias, sem obrigações de compensação por parte de qualquer das
      partes;</li> <li class="mb-2 text-justify text-md">fique caracterizada a utilização do presente serviço e/ou da Plataforma
      pelo Usuário para finalidade diversa da contratada e/ou expressamente
      autorizada pela Contratada, sem sua prévia, expressa e inequívoca
      autorização, sem prejuízo de perdas e danos;</li> <li class="mb-2 text-justify text-md">seja constatada a revenda de referido serviço ou a disponibilização de
      acesso a terceiros, sem prejuízo de perdas e danos;</li></ul> <p class="mb-2 text-justify text-md">5.8. Caso observada quaisquer das condições supra dispostas,
    alternativamente à resolução do contrato, pode a Contratada optar pela
    suspensão temporária dos serviços, até que o Usuário sane o problema, ao
    invés da resolução do contrato.</p> <p class="mb-2 text-justify text-md">5.9. A resolução deste Contrato não afetará o direito da Contratada em tomar
    as medidas cabíveis para a cobrança de eventuais débitos pendentes,
    vinculados e decorrentes da presente relação;</p> <p class="mb-2 text-justify text-md">5.10. Na hipótese de denúncia formal ou de identificação interna de uso da
    Plataforma para fins ilícitos, abusivos ou criminosos, a Contratada
    instaurará processo administrativo interno para investigação, assegurando ao
    Usuário o direito de ser cientificado, apresentar defesa e produzir provas.
    Constatada a infração, poderá ser determinada a suspensão ou exclusão
    definitiva da conta, sem restituição de valores já pagos, independentemente
    da adoção de medidas judiciais ou administrativas adicionais.</p> <p class="mb-2 text-justify text-md">5.11. Da decisão que aplicar a sanção de suspensão ou exclusão definitiva, o
    Usuário poderá interpor recurso administrativo ao Comitê de Análise de Abuso
    (CCA) da UTMify, cuja decisão terá caráter definitivo no âmbito interno da
    Contratada.</p> <h2 class="text-xl font-bold mb-2">CLÁUSULA SEXTA – DA PROPRIEDADE INTELECTUAL E DO USO DE MARCA</h2> <p class="mb-2 text-justify text-md">6.1. A Contratada detém todos os direitos de propriedade intelectual,
    abrangendo direitos morais e patrimoniais, sobre a Plataforma e seus
    componentes, incluindo funcionalidades, marcas registradas, software,
    domínios, e qualquer outro direito de propriedade intelectual associado à
    Plataforma e aos Serviços fornecidos.</p> <p class="mb-2 text-justify text-md">6.1.1. A UTMify é igualmente detentora de qualquer conteúdo e material
    disponível e/ou exibido na plataforma e/ou seus sites, declarando ser de sua
    propriedade intelectual, razão pela qual reserva a si todos os direitos de
    propriedade intelectual, incluindo mas não se limitando a gráficos,
    documentos, textos, imagens, ícones, fotografias, logos, gravações,
    softwares, marcas, programas de computador, banco de dados, redes, arquivos
    e códigos-fonte, dentre outros.</p> <p class="mb-2 text-justify text-md">6.2. O Usuário será detentor de licença de uso limitada, não exclusiva,
    intransferível, revogável a qualquer tempo, temporário e cuja cessão é
    expressamente vedada, restando, portanto, autorizado o Cliente a utilizar as
    funcionalidades dos Serviços manifestadamente contratadas, estando
    expressamente vedada sua comercialização ou exploração comercial que de
    qualquer forma venha a ocorrer fora dos padrões ora contratados, ou que
    importe em desvirtuação dos objetivos da presente contratação.</p> <p class="mb-2 text-justify text-md">6.3. É expressamente vedado ao usuário ceder, licenciar, sublicenciar,
    vender, locar ou sublocar, dar em garantia, doar, alienar, ou de qualquer
    forma, transferir total ou parcialmente, autorizar o uso a terceiros,
    compartilhar senha e login de acesso, sob quaisquer modalidades, gratuita ou
    onerosamente, em natureza provisória ou permanente, os direitos de uso da
    UTMify, ou de quaiquer de suas funcionalidades, informações, dados,
    Softwares de Terceiros, ou outras tecnologias que sejam de propriedade
    intelectual da Contratada ou de terceiros, e que tenha acesso em virtude da
    presente relação.</p> <p class="mb-2 text-justify text-md">6.4. A Contratada não outorga ao Usuário quaisquer direitos, expressa ou
    implicitamente, sobre seus direitos intelectuais (de natureza industrial ou
    autoral), ou sobre qualquer outro direito sob a plataforma, que não esteja
    expressamente previsto neste contrato, independentemente da natureza pela
    qual foi adquirido, antes ou após a data de vigência deste instrumento,
    igualmente, o Usuário não está autorizado, e em nem uma hipótese terá acesso
    ou poderá buscar, o código fonte da Plataforma.</p> <h2 class="text-xl font-bold mb-2">CLÁUSULA SÉTIMA – DA CONFIDENCIALIDADE E SEGURANÇA DE DADOS</h2> <p class="mb-2 text-justify text-md">7.1. São consideradas informações de natureza confidencial, sendo vedada as
    partes a divulgação de referidas informações pelo prazo que vigorar este
    contrato, e por 5 (cinco) anos contados de sua resolução, independentemente
    do motivo que a fundamenta, as seguintes, mas não se limitando a dados
    relacionados a operações comerciais, estratégias financeiras, detalhes de
    produtos, procedimentos operacionais, informações de bancos de dados,
    expertise exclusivo, descobertas inovadoras, propostas conceituais, avanços
    tecnológicos, softwares, esquemáticos, sequências operacionais, progressos
    em desenvolvimento, e registros de clientes e parceiros, ou qualquer outra
    informação de natureza técnica, econômica ou de mercado obtida durante o
    curso desta relação contratual.</p> <p class="mb-2 text-justify text-md">7.2. Não são consideradas informações de natureza confidenciais:</p> <ul class="list-disc ml-6 mb-2"><li class="mb-2 text-justify text-md">qualquer informação que se torne amplamente disponível para o público sem
      que haja o descumprimento desta disposição;</li> <li class="mb-2 text-justify text-md">qualquer informação que seja legalmente obtida pela Parte receptora de um
      terceiro ou de terceiros, sem que haja o descumprimento desta disposição
      pela Parte receptora, conforme demonstrado por documentação suficiente
      para confirmar o terceiro como a fonte da informação;</li> <li class="mb-2 text-justify text-md">qualquer informação que tenha sido conhecida pela Parte receptora antes de
      tal revelação, conforme demonstrado por documentação suficiente para
      confirmar tal conhecimento;</li> <li class="mb-2 text-justify text-md">qualquer informação cuja revelação tenha sido autorizada previamente, por
      escrito, pela outra Parte;</li> <li class="mb-2 text-justify text-md">qualquer informação que se torne disponível para qualquer das Partes de
      forma não confidencial por uma fonte, a qual, de acordo com o melhor
      conhecimento de tal Parte, após devida investigação, não esteja proibida
      de revelar tal informação por qualquer obrigação legal ou contratual;</li> <li class="mb-2 text-justify text-md">qualquer informação que esteja ou possa estar no domínio público em
      decorrência de um entendimento específico entre as Partes a esse respeito.</li></ul> <p class="mb-2 text-justify text-md">7.3. O Usuário declara-se ciente e concorda que os registros de aceitação
    destes Termos, seleções realizadas na Plataforma, e todas as formas de
    comunicação entre as partes, via e-mail ou qualquer outro meio de
    comunicação, serão armazenados no banco de dados da Contratada, incluindo
    data e hora dos eventos, sendo que referidos registros poderão ser
    utilizados como evidência documental, sem necessidade de formalidades
    adicionais, e que a Contratada poderá ter acesso às informações para
    resolução de problemas, dúvidas e/ou quaisquer requisições do Usuário ou de
    terceiro competente e legitimado para solicitar referidas informações, desde
    que exijam o conhecimento das respectivas informações, inclusive
    acessando-as por meio remoto.</p> <p class="mb-2 text-justify text-md">7.4. A Contratada garante que não cederá, transferirá, alienará,
    disponibilizará ou dará conhecimento de informações de terceiros ao Usuário,
    nem deste a terceiros, salvo se pela parte interessada for expressamente
    autorizado, para cumprimento de determinação legal e/ou de ordem judicial ou
    de órgão administrativo competente, dentro dos termos do presente contrato e
    da legislação aplicável.</p> <p class="mb-2 text-justify text-md">7.5. O Usuário expressamente autoriza a Contratada a utilizar as informações
    para (a) envio de notificações, alertas e comunicações ao Usuário; (b)
    promover o funcionamento das características dos serviços disponíveis na
    plataforma; (c) aperfeiçoar as características e funcionalidades dos
    serviços oferecidos pela Plataforma; (d) gerar estatísticas para
    monitoramento de utilização da Plataforma; (e) realizar pesquisas
    relacionadas a marketing e planejamento de projetos; (f) promover resolução
    de problemas na Plataforma ou Aplicativos, verificação e proteção das
    informações contra erros, fraudes ou qualquer outro crime
    cibernético/eletrônico.</p> <p class="mb-2 text-justify text-md">7.6. Demais questões relacionadas à confidencialidade e ao tratamento de
    dados estão dispostas e poderão ser acessadas na Política de Privacidade.</p> <p class="mb-2 text-justify text-md">7.7. Não constituirá violação de confidencialidade a divulgação de dados do
    Usuário à autoridade policial, judiciária, administrativa ou regulatória,
    sempre que houver indícios razoáveis ou comprovação de uso da Plataforma
    para a prática de ilícitos, golpes, fraudes ou condutas abusivas.</p> <h2 class="text-xl font-bold mb-2">CLÁUSULA OITAVA – DO SISTEMA DE PREMIAÇÃO POR FATURAMENTO TRACKEADO</h2> <p class="mb-2 text-justify text-md">8.1. A Contratada, por mera liberalidade e sem qualquer obrigação contratual
    ou legal, poderá oferecer aos Usuários assinantes da Plataforma UTMify um
    sistema de premiação baseado no volume de faturamento trackeado por meio da
    Plataforma, conforme metas pré-estabelecidas, sendo o principal objetivo
    reconhecer o desempenho do Usuário em suas campanhas de tráfego.</p> <p class="mb-2 text-justify text-md">8.2. A cada marca de faturamento trackeado atingida, conforme definido e
    atualizado periodicamente pela Contratada na seção específica de &quot;Progresso
    de Rastreamento&quot; da Plataforma, o Usuário poderá ser contemplado com uma
    premiação simbólica, tal como uma placa personalizada enviada pela UTMify. O
    conteúdo, forma, critérios e quantidade das premiações serão definidos
    exclusivamente pela Contratada, podendo ser modificados a qualquer tempo,
    sem necessidade de comunicação prévia.</p> <p class="mb-2 text-justify text-md">8.3. O sistema de premiação é exclusivo para Usuários assinantes ativos, ou
    seja, aqueles com planos pagos vigentes, e está vinculado ao status da conta
    e à adimplência contratual.</p> <p class="mb-2 text-justify text-md">8.4. O encerramento da conta, a solicitação de cancelamento, a suspensão da
    assinatura por inadimplemento ou qualquer interrupção na contratação ativa
    implicará na imediata perda dos valores acumulados no sistema de premiação,
    inclusive com a zeragem definitiva do histórico de faturamento trackeado
    para esse fim.</p> <p class="mb-2 text-justify text-md">8.5. A eventual reativação da conta, regularização do pagamento em atraso ou
    retorno posterior à Plataforma não restabelecerá o progresso anteriormente
    registrado, tampouco gerará qualquer direito à recuperação dos pontos,
    marcas ou premiações não alcançadas.</p> <p class="mb-2 text-justify text-md">8.6. O sistema de premiação descrito nesta cláusula não constitui promessa
    de resultado, contraprestação, obrigação contratual, direito adquirido ou
    expectativa legítima de ganho, tratando-se de mera política promocional
    opcional e revogável a qualquer tempo, a critério exclusivo da Contratada.</p> <p class="mb-2 text-justify text-md">8.7. Usuários suspensos ou excluídos em decorrência de uso ilícito,
    criminoso ou abusivo da Plataforma perderão automaticamente quaisquer
    benefícios, pontos ou premiações eventualmente acumulados, sem direito à
    restituição ou compensação.</p> <h2 class="text-xl font-bold mb-2">CLÁUSULA NONA – DAS DISPOSIÇÕES GERAIS</h2> <p class="mb-2 text-justify text-md">9.1. Obrigam-se as partes e anuentes por si, seus herdeiros e sucessores, em
    caráter irretratável e irrevogável, sendo vedada a cessão a terceiro pelo
    Usuário dos direitos, obrigações e responsabilidades oriundas do presente
    sem a prévia e expressa anuência da outra parte, sob todos os termos e
    condições expressamente previstos neste instrumento de contrato.</p> <p class="mb-2 text-justify text-md">9.2. É expressamente vedado ao Usuário a cessão parcial ou total a terceiros
    dos direitos e obrigações assumidos em virtude da presente relação, a
    qualquer título. A Contratada fica desde já autorizada a ceder a terceiros
    os direitos e obrigações do presente instrumento de contrato,
    independentemente de prévia autorização do Usuário, estando vinculada tão
    somente à informação da operação.</p> <p class="mb-2 text-justify text-md">9.3. Qualquer comunicação por e-mail ou troca de mensagens em diferentes
    meios ou plataformas, relativas às validações necessárias para a prestação
    dos serviços contratados, será considerada parte integrante deste contrato.
    Em caso de discrepância entre os termos destes documentos e o presente
    contrato, exceto no que diz respeito a detalhes técnicos, prevalecerão as
    disposições aqui contidas.</p> <p class="mb-2 text-justify text-md">9.4. O Usuário afirma ser pessoa física ou jurídica com capacidade civil
    plena, maior de 18 anos, aderindo a este contrato com plena ciência de seu
    conteúdo e de todo o serviço ofertado e a licença disponibilizada pela
    Contratada, considerando a contratação justa, adequada e equitativa, e
    assegura possuir a devida autoridade e poder para firmar referido
    compromisso.</p> <p class="mb-2 text-justify text-md">9.5. As partes reconhecem que este contrato, bem como quaisquer documentos
    gerados em decorrência desta relação contratual, são considerados títulos
    executivos extrajudiciais, nos termos do artigo 784, inciso III, do Código
    de Processo Civil brasileiro, habilitando a execução forçada caso
    necessário.</p> <p class="mb-2 text-justify text-md">9.6. A tolerância ao descumprimento de qualquer obrigação ou condição
    estipulada neste contrato, bem como o não exercício de qualquer direito
    contratual ou legal, não constitui novação ou renúncia de direito, mas tão
    somente mera liberalidade e tolerância das partes, mantendo-se íntegros,
    para exercício a qualquer tempo, os direitos assegurados por este contrato
    e/ou por força de lei.</p> <p class="mb-2 text-justify text-md">9.7. O Usuário concorda que todos os atos de comunicação formal de natureza
    judicial entre si deverão ocorrer nos endereços de e-mail informados no ato
    de cadastro na Plataforma, admitindo-se inclusive a citação e intimação
    judicial, sendo presumida a ciência no primeiro dia útil posterior ao
    recebimento, estando obrigada as partes a informar imediatamente à outra em
    caso de alteração do endereço eletrônico de comunicações oficiais, sob pena
    de serem considerados válidos os atos realizados. As partes admitem que o
    acordado constitui negócio jurídico processual, conforme permissivo legal do
    art. 190 do Código de Processo Civil.</p> <p class="mb-2 text-justify text-md">9.8. As disposições deste Termo são independentes, exceto se expressamente
    estabelecido no presente de outra forma, caso qualquer das disposições ou
    cláusulas deste Acordo seja considerada inválida, nula ou inexequível, no
    todo ou em parte, por uma autoridade governamental competente, ou
    considerada ilegal em razão de alteração na legislação vigente ou
    entendimento jurisdicional diverso, então a invalidade, ilegalidade,
    nulidade ou inexequibilidade deverá afetar somente a respectiva cláusula ou
    disposição, ou parte dela, e não deverá de maneira alguma afetar qualquer
    outra cláusula ou disposição do presente Acordo, cuja parte remanescente
    permanecerá inalterada e em pleno vigor conforme escrita e acordada
    originalmente.</p> <p class="mb-2 text-justify text-md">9.9. As partes reconhecem, admitem e concordam que o presente contrato
    estabelece uma relação de natureza empresarial entre si, na qual o Usuário,
    qualificado como profissional em seu respectivo setor de atuação, adquire o
    produto e/ou serviço oferecido pela Contratada com o objetivo de integrá-lo
    ao seu processo produtivo, aprimorando sua capacidade de prestação de
    serviços ou produção profissional, portanto o Usuário possui conhecimento
    técnico no uso de plataformas vinculadas a gateways de pagamento, mídias
    sociais e gerenciadores de anúncios, dentre outros, de modo que reconhece
    que o produto e/ou serviço contratado serve como ferramenta auxiliar em seu
    exercício profissional final. Destarte, esta relação não configura uma
    relação de consumo, visto que o Usuário não se posiciona como destinatário
    final do produto ou serviço.</p> <p class="mb-2 text-justify text-md">9.10. O Usuário admite ciência e concorda que o presente Termo de Uso poderá
    ser a qualquer tempo modificado unilateralmente pela Contratada, a seu
    exclusivo critério, sendo que o aceite do Usuário em novo Termos de Uso
    importa na vinculação dos mesmos, em todos os seus termos e condições. A
    Contratada compromete-se a comunicar referida alteração via e-mail e/ou
    plataforma. A partir da data de publicação da versão atualizada do presente,
    os Serviços passarão a ser regulados pelo documento atualizado, podendo o
    Usuário, em caso de discordância de referida alteração, solicitar a
    resolução do contrato, nos moldes da cláusula competente, sendo que a
    continuidade na utilização dos serviços será considerada como aceite nas
    novas condições contratuais.</p> <p class="mb-2 text-justify text-md">9.11. Este acordo é regido e deverá ser interpretado de acordo com as leis
    vigentes na República Federativa do Brasil, aplicando-se a todos os termos e
    condições aqui estabelecidos.</p> <p class="mb-2 text-justify text-md">9.12. Fica eleito o foro da comarca de Rio de Janeiro – RJ como o competente
    para dirimir eventuais dúvidas ou conflitos oriundos do presente contrato,
    em detrimento de todos os outros, por mais privilegiado que seja ou possa
    vir a ser.</p>`;
    return {
        c() {
            e = m("div"), e.innerHTML = s
        },
        l(a) {
            e = c(a, "DIV", {
                "data-svelte-h": !0
            }), u(e) !== "svelte-1vqlppj" && (e.innerHTML = s)
        },
        m(a, i) {
            n(a, e, i)
        },
        p: o,
        i: o,
        o,
        d(a) {
            a && d(e)
        }
    }
}
class b extends l {
    constructor(e) {
        super(), p(this, e, null, f, r, {})
    }
}
export {
    b as T
};