import {
    d as B
} from "./BCpwIhRd.js";
import {
    t as w,
    c as P,
    f as X
} from "./DwsiLpv2.js";
import {
    i as A
} from "./DmG1NmUW.js";
let R = {};

function S() {
    return R
}

function x(n, e) {
    var c, o, d, f;
    const t = S(),
        a = (e == null ? void 0 : e.weekStartsOn) ? ? ((o = (c = e == null ? void 0 : e.locale) == null ? void 0 : c.options) == null ? void 0 : o.weekStartsOn) ? ? t.weekStartsOn ? ? ((f = (d = t.locale) == null ? void 0 : d.options) == null ? void 0 : f.weekStartsOn) ? ? 0,
        r = w(n, e == null ? void 0 : e.in),
        i = r.getDay(),
        u = (i < a ? 7 : 0) + i - a;
    return r.setDate(r.getDate() - u), r.setHours(0, 0, 0, 0), r
}

function W(n, e) {
    return x(n, { ...e,
        weekStartsOn: 1
    })
}

function L(n, e) {
    const t = w(n, e == null ? void 0 : e.in),
        a = t.getFullYear(),
        r = P(t, 0);
    r.setFullYear(a + 1, 0, 4), r.setHours(0, 0, 0, 0);
    const i = W(r),
        u = P(t, 0);
    u.setFullYear(a, 0, 4), u.setHours(0, 0, 0, 0);
    const c = W(u);
    return t.getTime() >= i.getTime() ? a + 1 : t.getTime() >= c.getTime() ? a : a - 1
}

function j(n, e) {
    const t = L(n, e),
        a = P(n, 0);
    return a.setFullYear(t, 0, 4), a.setHours(0, 0, 0, 0), W(a)
}

function V(n, e) {
    const t = w(n, e == null ? void 0 : e.in);
    return t.setFullYear(t.getFullYear(), 0, 1), t.setHours(0, 0, 0, 0), t
}
const I = {
        lessThanXSeconds: {
            one: "less than a second",
            other: "less than {{count}} seconds"
        },
        xSeconds: {
            one: "1 second",
            other: "{{count}} seconds"
        },
        halfAMinute: "half a minute",
        lessThanXMinutes: {
            one: "less than a minute",
            other: "less than {{count}} minutes"
        },
        xMinutes: {
            one: "1 minute",
            other: "{{count}} minutes"
        },
        aboutXHours: {
            one: "about 1 hour",
            other: "about {{count}} hours"
        },
        xHours: {
            one: "1 hour",
            other: "{{count}} hours"
        },
        xDays: {
            one: "1 day",
            other: "{{count}} days"
        },
        aboutXWeeks: {
            one: "about 1 week",
            other: "about {{count}} weeks"
        },
        xWeeks: {
            one: "1 week",
            other: "{{count}} weeks"
        },
        aboutXMonths: {
            one: "about 1 month",
            other: "about {{count}} months"
        },
        xMonths: {
            one: "1 month",
            other: "{{count}} months"
        },
        aboutXYears: {
            one: "about 1 year",
            other: "about {{count}} years"
        },
        xYears: {
            one: "1 year",
            other: "{{count}} years"
        },
        overXYears: {
            one: "over 1 year",
            other: "over {{count}} years"
        },
        almostXYears: {
            one: "almost 1 year",
            other: "almost {{count}} years"
        }
    },
    J = (n, e, t) => {
        let a;
        const r = I[n];
        return typeof r == "string" ? a = r : e === 1 ? a = r.one : a = r.other.replace("{{count}}", e.toString()), t != null && t.addSuffix ? t.comparison && t.comparison > 0 ? "in " + a : a + " ago" : a
    };

function D(n) {
    return (e = {}) => {
        const t = e.width ? String(e.width) : n.defaultWidth;
        return n.formats[t] || n.formats[n.defaultWidth]
    }
}
const $ = {
        full: "EEEE, MMMM do, y",
        long: "MMMM do, y",
        medium: "MMM d, y",
        short: "MM/dd/yyyy"
    },
    K = {
        full: "h:mm:ss a zzzz",
        long: "h:mm:ss a z",
        medium: "h:mm:ss a",
        short: "h:mm a"
    },
    U = {
        full: "{{date}} 'at' {{time}}",
        long: "{{date}} 'at' {{time}}",
        medium: "{{date}}, {{time}}",
        short: "{{date}}, {{time}}"
    },
    z = {
        date: D({
            formats: $,
            defaultWidth: "full"
        }),
        time: D({
            formats: K,
            defaultWidth: "full"
        }),
        dateTime: D({
            formats: U,
            defaultWidth: "full"
        })
    },
    Z = {
        lastWeek: "'last' eeee 'at' p",
        yesterday: "'yesterday at' p",
        today: "'today at' p",
        tomorrow: "'tomorrow at' p",
        nextWeek: "eeee 'at' p",
        other: "P"
    },
    p = (n, e, t, a) => Z[n];

function O(n) {
    return (e, t) => {
        const a = t != null && t.context ? String(t.context) : "standalone";
        let r;
        if (a === "formatting" && n.formattingValues) {
            const u = n.defaultFormattingWidth || n.defaultWidth,
                c = t != null && t.width ? String(t.width) : u;
            r = n.formattingValues[c] || n.formattingValues[u]
        } else {
            const u = n.defaultWidth,
                c = t != null && t.width ? String(t.width) : n.defaultWidth;
            r = n.values[c] || n.values[u]
        }
        const i = n.argumentCallback ? n.argumentCallback(e) : e;
        return r[i]
    }
}
const ee = {
        narrow: ["B", "A"],
        abbreviated: ["BC", "AD"],
        wide: ["Before Christ", "Anno Domini"]
    },
    te = {
        narrow: ["1", "2", "3", "4"],
        abbreviated: ["Q1", "Q2", "Q3", "Q4"],
        wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"]
    },
    ne = {
        narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
        abbreviated: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        wide: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    },
    ae = {
        narrow: ["S", "M", "T", "W", "T", "F", "S"],
        short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
        abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
        wide: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    },
    re = {
        narrow: {
            am: "a",
            pm: "p",
            midnight: "mi",
            noon: "n",
            morning: "morning",
            afternoon: "afternoon",
            evening: "evening",
            night: "night"
        },
        abbreviated: {
            am: "AM",
            pm: "PM",
            midnight: "midnight",
            noon: "noon",
            morning: "morning",
            afternoon: "afternoon",
            evening: "evening",
            night: "night"
        },
        wide: {
            am: "a.m.",
            pm: "p.m.",
            midnight: "midnight",
            noon: "noon",
            morning: "morning",
            afternoon: "afternoon",
            evening: "evening",
            night: "night"
        }
    },
    ie = {
        narrow: {
            am: "a",
            pm: "p",
            midnight: "mi",
            noon: "n",
            morning: "in the morning",
            afternoon: "in the afternoon",
            evening: "in the evening",
            night: "at night"
        },
        abbreviated: {
            am: "AM",
            pm: "PM",
            midnight: "midnight",
            noon: "noon",
            morning: "in the morning",
            afternoon: "in the afternoon",
            evening: "in the evening",
            night: "at night"
        },
        wide: {
            am: "a.m.",
            pm: "p.m.",
            midnight: "midnight",
            noon: "noon",
            morning: "in the morning",
            afternoon: "in the afternoon",
            evening: "in the evening",
            night: "at night"
        }
    },
    se = (n, e) => {
        const t = Number(n),
            a = t % 100;
        if (a > 20 || a < 10) switch (a % 10) {
            case 1:
                return t + "st";
            case 2:
                return t + "nd";
            case 3:
                return t + "rd"
        }
        return t + "th"
    },
    ue = {
        ordinalNumber: se,
        era: O({
            values: ee,
            defaultWidth: "wide"
        }),
        quarter: O({
            values: te,
            defaultWidth: "wide",
            argumentCallback: n => n - 1
        }),
        month: O({
            values: ne,
            defaultWidth: "wide"
        }),
        day: O({
            values: ae,
            defaultWidth: "wide"
        }),
        dayPeriod: O({
            values: re,
            defaultWidth: "wide",
            formattingValues: ie,
            defaultFormattingWidth: "wide"
        })
    };

function v(n) {
    return (e, t = {}) => {
        const a = t.width,
            r = a && n.matchPatterns[a] || n.matchPatterns[n.defaultMatchWidth],
            i = e.match(r);
        if (!i) return null;
        const u = i[0],
            c = a && n.parsePatterns[a] || n.parsePatterns[n.defaultParseWidth],
            o = Array.isArray(c) ? oe(c, l => l.test(u)) : ce(c, l => l.test(u));
        let d;
        d = n.valueCallback ? n.valueCallback(o) : o, d = t.valueCallback ? t.valueCallback(d) : d;
        const f = e.slice(u.length);
        return {
            value: d,
            rest: f
        }
    }
}

function ce(n, e) {
    for (const t in n)
        if (Object.prototype.hasOwnProperty.call(n, t) && e(n[t])) return t
}

function oe(n, e) {
    for (let t = 0; t < n.length; t++)
        if (e(n[t])) return t
}

function de(n) {
    return (e, t = {}) => {
        const a = e.match(n.matchPattern);
        if (!a) return null;
        const r = a[0],
            i = e.match(n.parsePattern);
        if (!i) return null;
        let u = n.valueCallback ? n.valueCallback(i[0]) : i[0];
        u = t.valueCallback ? t.valueCallback(u) : u;
        const c = e.slice(r.length);
        return {
            value: u,
            rest: c
        }
    }
}
const he = /^(\d+)(th|st|nd|rd)?/i,
    fe = /\d+/i,
    me = {
        narrow: /^(b|a)/i,
        abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
        wide: /^(before christ|before common era|anno domini|common era)/i
    },
    le = {
        any: [/^b/i, /^(a|c)/i]
    },
    ge = {
        narrow: /^[1234]/i,
        abbreviated: /^q[1234]/i,
        wide: /^[1234](th|st|nd|rd)? quarter/i
    },
    we = {
        any: [/1/i, /2/i, /3/i, /4/i]
    },
    ye = {
        narrow: /^[jfmasond]/i,
        abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
        wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
    },
    be = {
        narrow: [/^j/i, /^f/i, /^m/i, /^a/i, /^m/i, /^j/i, /^j/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i],
        any: [/^ja/i, /^f/i, /^mar/i, /^ap/i, /^may/i, /^jun/i, /^jul/i, /^au/i, /^s/i, /^o/i, /^n/i, /^d/i]
    },
    Pe = {
        narrow: /^[smtwf]/i,
        short: /^(su|mo|tu|we|th|fr|sa)/i,
        abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
        wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
    },
    Me = {
        narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
        any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
    },
    ke = {
        narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
        any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
    },
    Oe = {
        any: {
            am: /^a/i,
            pm: /^p/i,
            midnight: /^mi/i,
            noon: /^no/i,
            morning: /morning/i,
            afternoon: /afternoon/i,
            evening: /evening/i,
            night: /night/i
        }
    },
    ve = {
        ordinalNumber: de({
            matchPattern: he,
            parsePattern: fe,
            valueCallback: n => parseInt(n, 10)
        }),
        era: v({
            matchPatterns: me,
            defaultMatchWidth: "wide",
            parsePatterns: le,
            defaultParseWidth: "any"
        }),
        quarter: v({
            matchPatterns: ge,
            defaultMatchWidth: "wide",
            parsePatterns: we,
            defaultParseWidth: "any",
            valueCallback: n => n + 1
        }),
        month: v({
            matchPatterns: ye,
            defaultMatchWidth: "wide",
            parsePatterns: be,
            defaultParseWidth: "any"
        }),
        day: v({
            matchPatterns: Pe,
            defaultMatchWidth: "wide",
            parsePatterns: Me,
            defaultParseWidth: "any"
        }),
        dayPeriod: v({
            matchPatterns: ke,
            defaultMatchWidth: "any",
            parsePatterns: Oe,
            defaultParseWidth: "any"
        })
    },
    xe = {
        code: "en-US",
        formatDistance: J,
        formatLong: z,
        formatRelative: p,
        localize: ue,
        match: ve,
        options: {
            weekStartsOn: 0,
            firstWeekContainsDate: 1
        }
    };

function We(n, e) {
    const t = w(n, e == null ? void 0 : e.in);
    return B(t, V(t)) + 1
}

function Se(n, e) {
    const t = w(n, e == null ? void 0 : e.in),
        a = +W(t) - +j(t);
    return Math.round(a / X) + 1
}

function G(n, e) {
    var f, l, M, k;
    const t = w(n, e == null ? void 0 : e.in),
        a = t.getFullYear(),
        r = S(),
        i = (e == null ? void 0 : e.firstWeekContainsDate) ? ? ((l = (f = e == null ? void 0 : e.locale) == null ? void 0 : f.options) == null ? void 0 : l.firstWeekContainsDate) ? ? r.firstWeekContainsDate ? ? ((k = (M = r.locale) == null ? void 0 : M.options) == null ? void 0 : k.firstWeekContainsDate) ? ? 1,
        u = P((e == null ? void 0 : e.in) || n, 0);
    u.setFullYear(a + 1, 0, i), u.setHours(0, 0, 0, 0);
    const c = x(u, e),
        o = P((e == null ? void 0 : e.in) || n, 0);
    o.setFullYear(a, 0, i), o.setHours(0, 0, 0, 0);
    const d = x(o, e);
    return +t >= +c ? a + 1 : +t >= +d ? a : a - 1
}

function Ye(n, e) {
    var c, o, d, f;
    const t = S(),
        a = (e == null ? void 0 : e.firstWeekContainsDate) ? ? ((o = (c = e == null ? void 0 : e.locale) == null ? void 0 : c.options) == null ? void 0 : o.firstWeekContainsDate) ? ? t.firstWeekContainsDate ? ? ((f = (d = t.locale) == null ? void 0 : d.options) == null ? void 0 : f.firstWeekContainsDate) ? ? 1,
        r = G(n, e),
        i = P((e == null ? void 0 : e.in) || n, 0);
    return i.setFullYear(r, 0, a), i.setHours(0, 0, 0, 0), x(i, e)
}

function De(n, e) {
    const t = w(n, e == null ? void 0 : e.in),
        a = +x(t, e) - +Ye(t, e);
    return Math.round(a / X) + 1
}

function s(n, e) {
    const t = n < 0 ? "-" : "",
        a = Math.abs(n).toString().padStart(e, "0");
    return t + a
}
const g = {
        y(n, e) {
            const t = n.getFullYear(),
                a = t > 0 ? t : 1 - t;
            return s(e === "yy" ? a % 100 : a, e.length)
        },
        M(n, e) {
            const t = n.getMonth();
            return e === "M" ? String(t + 1) : s(t + 1, 2)
        },
        d(n, e) {
            return s(n.getDate(), e.length)
        },
        a(n, e) {
            const t = n.getHours() / 12 >= 1 ? "pm" : "am";
            switch (e) {
                case "a":
                case "aa":
                    return t.toUpperCase();
                case "aaa":
                    return t;
                case "aaaaa":
                    return t[0];
                case "aaaa":
                default:
                    return t === "am" ? "a.m." : "p.m."
            }
        },
        h(n, e) {
            return s(n.getHours() % 12 || 12, e.length)
        },
        H(n, e) {
            return s(n.getHours(), e.length)
        },
        m(n, e) {
            return s(n.getMinutes(), e.length)
        },
        s(n, e) {
            return s(n.getSeconds(), e.length)
        },
        S(n, e) {
            const t = e.length,
                a = n.getMilliseconds(),
                r = Math.trunc(a * Math.pow(10, t - 3));
            return s(r, e.length)
        }
    },
    b = {
        midnight: "midnight",
        noon: "noon",
        morning: "morning",
        afternoon: "afternoon",
        evening: "evening",
        night: "night"
    },
    q = {
        G: function(n, e, t) {
            const a = n.getFullYear() > 0 ? 1 : 0;
            switch (e) {
                case "G":
                case "GG":
                case "GGG":
                    return t.era(a, {
                        width: "abbreviated"
                    });
                case "GGGGG":
                    return t.era(a, {
                        width: "narrow"
                    });
                case "GGGG":
                default:
                    return t.era(a, {
                        width: "wide"
                    })
            }
        },
        y: function(n, e, t) {
            if (e === "yo") {
                const a = n.getFullYear(),
                    r = a > 0 ? a : 1 - a;
                return t.ordinalNumber(r, {
                    unit: "year"
                })
            }
            return g.y(n, e)
        },
        Y: function(n, e, t, a) {
            const r = G(n, a),
                i = r > 0 ? r : 1 - r;
            if (e === "YY") {
                const u = i % 100;
                return s(u, 2)
            }
            return e === "Yo" ? t.ordinalNumber(i, {
                unit: "year"
            }) : s(i, e.length)
        },
        R: function(n, e) {
            const t = L(n);
            return s(t, e.length)
        },
        u: function(n, e) {
            const t = n.getFullYear();
            return s(t, e.length)
        },
        Q: function(n, e, t) {
            const a = Math.ceil((n.getMonth() + 1) / 3);
            switch (e) {
                case "Q":
                    return String(a);
                case "QQ":
                    return s(a, 2);
                case "Qo":
                    return t.ordinalNumber(a, {
                        unit: "quarter"
                    });
                case "QQQ":
                    return t.quarter(a, {
                        width: "abbreviated",
                        context: "formatting"
                    });
                case "QQQQQ":
                    return t.quarter(a, {
                        width: "narrow",
                        context: "formatting"
                    });
                case "QQQQ":
                default:
                    return t.quarter(a, {
                        width: "wide",
                        context: "formatting"
                    })
            }
        },
        q: function(n, e, t) {
            const a = Math.ceil((n.getMonth() + 1) / 3);
            switch (e) {
                case "q":
                    return String(a);
                case "qq":
                    return s(a, 2);
                case "qo":
                    return t.ordinalNumber(a, {
                        unit: "quarter"
                    });
                case "qqq":
                    return t.quarter(a, {
                        width: "abbreviated",
                        context: "standalone"
                    });
                case "qqqqq":
                    return t.quarter(a, {
                        width: "narrow",
                        context: "standalone"
                    });
                case "qqqq":
                default:
                    return t.quarter(a, {
                        width: "wide",
                        context: "standalone"
                    })
            }
        },
        M: function(n, e, t) {
            const a = n.getMonth();
            switch (e) {
                case "M":
                case "MM":
                    return g.M(n, e);
                case "Mo":
                    return t.ordinalNumber(a + 1, {
                        unit: "month"
                    });
                case "MMM":
                    return t.month(a, {
                        width: "abbreviated",
                        context: "formatting"
                    });
                case "MMMMM":
                    return t.month(a, {
                        width: "narrow",
                        context: "formatting"
                    });
                case "MMMM":
                default:
                    return t.month(a, {
                        width: "wide",
                        context: "formatting"
                    })
            }
        },
        L: function(n, e, t) {
            const a = n.getMonth();
            switch (e) {
                case "L":
                    return String(a + 1);
                case "LL":
                    return s(a + 1, 2);
                case "Lo":
                    return t.ordinalNumber(a + 1, {
                        unit: "month"
                    });
                case "LLL":
                    return t.month(a, {
                        width: "abbreviated",
                        context: "standalone"
                    });
                case "LLLLL":
                    return t.month(a, {
                        width: "narrow",
                        context: "standalone"
                    });
                case "LLLL":
                default:
                    return t.month(a, {
                        width: "wide",
                        context: "standalone"
                    })
            }
        },
        w: function(n, e, t, a) {
            const r = De(n, a);
            return e === "wo" ? t.ordinalNumber(r, {
                unit: "week"
            }) : s(r, e.length)
        },
        I: function(n, e, t) {
            const a = Se(n);
            return e === "Io" ? t.ordinalNumber(a, {
                unit: "week"
            }) : s(a, e.length)
        },
        d: function(n, e, t) {
            return e === "do" ? t.ordinalNumber(n.getDate(), {
                unit: "date"
            }) : g.d(n, e)
        },
        D: function(n, e, t) {
            const a = We(n);
            return e === "Do" ? t.ordinalNumber(a, {
                unit: "dayOfYear"
            }) : s(a, e.length)
        },
        E: function(n, e, t) {
            const a = n.getDay();
            switch (e) {
                case "E":
                case "EE":
                case "EEE":
                    return t.day(a, {
                        width: "abbreviated",
                        context: "formatting"
                    });
                case "EEEEE":
                    return t.day(a, {
                        width: "narrow",
                        context: "formatting"
                    });
                case "EEEEEE":
                    return t.day(a, {
                        width: "short",
                        context: "formatting"
                    });
                case "EEEE":
                default:
                    return t.day(a, {
                        width: "wide",
                        context: "formatting"
                    })
            }
        },
        e: function(n, e, t, a) {
            const r = n.getDay(),
                i = (r - a.weekStartsOn + 8) % 7 || 7;
            switch (e) {
                case "e":
                    return String(i);
                case "ee":
                    return s(i, 2);
                case "eo":
                    return t.ordinalNumber(i, {
                        unit: "day"
                    });
                case "eee":
                    return t.day(r, {
                        width: "abbreviated",
                        context: "formatting"
                    });
                case "eeeee":
                    return t.day(r, {
                        width: "narrow",
                        context: "formatting"
                    });
                case "eeeeee":
                    return t.day(r, {
                        width: "short",
                        context: "formatting"
                    });
                case "eeee":
                default:
                    return t.day(r, {
                        width: "wide",
                        context: "formatting"
                    })
            }
        },
        c: function(n, e, t, a) {
            const r = n.getDay(),
                i = (r - a.weekStartsOn + 8) % 7 || 7;
            switch (e) {
                case "c":
                    return String(i);
                case "cc":
                    return s(i, e.length);
                case "co":
                    return t.ordinalNumber(i, {
                        unit: "day"
                    });
                case "ccc":
                    return t.day(r, {
                        width: "abbreviated",
                        context: "standalone"
                    });
                case "ccccc":
                    return t.day(r, {
                        width: "narrow",
                        context: "standalone"
                    });
                case "cccccc":
                    return t.day(r, {
                        width: "short",
                        context: "standalone"
                    });
                case "cccc":
                default:
                    return t.day(r, {
                        width: "wide",
                        context: "standalone"
                    })
            }
        },
        i: function(n, e, t) {
            const a = n.getDay(),
                r = a === 0 ? 7 : a;
            switch (e) {
                case "i":
                    return String(r);
                case "ii":
                    return s(r, e.length);
                case "io":
                    return t.ordinalNumber(r, {
                        unit: "day"
                    });
                case "iii":
                    return t.day(a, {
                        width: "abbreviated",
                        context: "formatting"
                    });
                case "iiiii":
                    return t.day(a, {
                        width: "narrow",
                        context: "formatting"
                    });
                case "iiiiii":
                    return t.day(a, {
                        width: "short",
                        context: "formatting"
                    });
                case "iiii":
                default:
                    return t.day(a, {
                        width: "wide",
                        context: "formatting"
                    })
            }
        },
        a: function(n, e, t) {
            const r = n.getHours() / 12 >= 1 ? "pm" : "am";
            switch (e) {
                case "a":
                case "aa":
                    return t.dayPeriod(r, {
                        width: "abbreviated",
                        context: "formatting"
                    });
                case "aaa":
                    return t.dayPeriod(r, {
                        width: "abbreviated",
                        context: "formatting"
                    }).toLowerCase();
                case "aaaaa":
                    return t.dayPeriod(r, {
                        width: "narrow",
                        context: "formatting"
                    });
                case "aaaa":
                default:
                    return t.dayPeriod(r, {
                        width: "wide",
                        context: "formatting"
                    })
            }
        },
        b: function(n, e, t) {
            const a = n.getHours();
            let r;
            switch (a === 12 ? r = b.noon : a === 0 ? r = b.midnight : r = a / 12 >= 1 ? "pm" : "am", e) {
                case "b":
                case "bb":
                    return t.dayPeriod(r, {
                        width: "abbreviated",
                        context: "formatting"
                    });
                case "bbb":
                    return t.dayPeriod(r, {
                        width: "abbreviated",
                        context: "formatting"
                    }).toLowerCase();
                case "bbbbb":
                    return t.dayPeriod(r, {
                        width: "narrow",
                        context: "formatting"
                    });
                case "bbbb":
                default:
                    return t.dayPeriod(r, {
                        width: "wide",
                        context: "formatting"
                    })
            }
        },
        B: function(n, e, t) {
            const a = n.getHours();
            let r;
            switch (a >= 17 ? r = b.evening : a >= 12 ? r = b.afternoon : a >= 4 ? r = b.morning : r = b.night, e) {
                case "B":
                case "BB":
                case "BBB":
                    return t.dayPeriod(r, {
                        width: "abbreviated",
                        context: "formatting"
                    });
                case "BBBBB":
                    return t.dayPeriod(r, {
                        width: "narrow",
                        context: "formatting"
                    });
                case "BBBB":
                default:
                    return t.dayPeriod(r, {
                        width: "wide",
                        context: "formatting"
                    })
            }
        },
        h: function(n, e, t) {
            if (e === "ho") {
                let a = n.getHours() % 12;
                return a === 0 && (a = 12), t.ordinalNumber(a, {
                    unit: "hour"
                })
            }
            return g.h(n, e)
        },
        H: function(n, e, t) {
            return e === "Ho" ? t.ordinalNumber(n.getHours(), {
                unit: "hour"
            }) : g.H(n, e)
        },
        K: function(n, e, t) {
            const a = n.getHours() % 12;
            return e === "Ko" ? t.ordinalNumber(a, {
                unit: "hour"
            }) : s(a, e.length)
        },
        k: function(n, e, t) {
            let a = n.getHours();
            return a === 0 && (a = 24), e === "ko" ? t.ordinalNumber(a, {
                unit: "hour"
            }) : s(a, e.length)
        },
        m: function(n, e, t) {
            return e === "mo" ? t.ordinalNumber(n.getMinutes(), {
                unit: "minute"
            }) : g.m(n, e)
        },
        s: function(n, e, t) {
            return e === "so" ? t.ordinalNumber(n.getSeconds(), {
                unit: "second"
            }) : g.s(n, e)
        },
        S: function(n, e) {
            return g.S(n, e)
        },
        X: function(n, e, t) {
            const a = n.getTimezoneOffset();
            if (a === 0) return "Z";
            switch (e) {
                case "X":
                    return H(a);
                case "XXXX":
                case "XX":
                    return y(a);
                case "XXXXX":
                case "XXX":
                default:
                    return y(a, ":")
            }
        },
        x: function(n, e, t) {
            const a = n.getTimezoneOffset();
            switch (e) {
                case "x":
                    return H(a);
                case "xxxx":
                case "xx":
                    return y(a);
                case "xxxxx":
                case "xxx":
                default:
                    return y(a, ":")
            }
        },
        O: function(n, e, t) {
            const a = n.getTimezoneOffset();
            switch (e) {
                case "O":
                case "OO":
                case "OOO":
                    return "GMT" + N(a, ":");
                case "OOOO":
                default:
                    return "GMT" + y(a, ":")
            }
        },
        z: function(n, e, t) {
            const a = n.getTimezoneOffset();
            switch (e) {
                case "z":
                case "zz":
                case "zzz":
                    return "GMT" + N(a, ":");
                case "zzzz":
                default:
                    return "GMT" + y(a, ":")
            }
        },
        t: function(n, e, t) {
            const a = Math.trunc(+n / 1e3);
            return s(a, e.length)
        },
        T: function(n, e, t) {
            return s(+n, e.length)
        }
    };

function N(n, e = "") {
    const t = n > 0 ? "-" : "+",
        a = Math.abs(n),
        r = Math.trunc(a / 60),
        i = a % 60;
    return i === 0 ? t + String(r) : t + String(r) + e + s(i, 2)
}

function H(n, e) {
    return n % 60 === 0 ? (n > 0 ? "-" : "+") + s(Math.abs(n) / 60, 2) : y(n, e)
}

function y(n, e = "") {
    const t = n > 0 ? "-" : "+",
        a = Math.abs(n),
        r = s(Math.trunc(a / 60), 2),
        i = s(a % 60, 2);
    return t + r + e + i
}
const Q = (n, e) => {
        switch (n) {
            case "P":
                return e.date({
                    width: "short"
                });
            case "PP":
                return e.date({
                    width: "medium"
                });
            case "PPP":
                return e.date({
                    width: "long"
                });
            case "PPPP":
            default:
                return e.date({
                    width: "full"
                })
        }
    },
    _ = (n, e) => {
        switch (n) {
            case "p":
                return e.time({
                    width: "short"
                });
            case "pp":
                return e.time({
                    width: "medium"
                });
            case "ppp":
                return e.time({
                    width: "long"
                });
            case "pppp":
            default:
                return e.time({
                    width: "full"
                })
        }
    },
    Te = (n, e) => {
        const t = n.match(/(P+)(p+)?/) || [],
            a = t[1],
            r = t[2];
        if (!r) return Q(n, e);
        let i;
        switch (a) {
            case "P":
                i = e.dateTime({
                    width: "short"
                });
                break;
            case "PP":
                i = e.dateTime({
                    width: "medium"
                });
                break;
            case "PPP":
                i = e.dateTime({
                    width: "long"
                });
                break;
            case "PPPP":
            default:
                i = e.dateTime({
                    width: "full"
                });
                break
        }
        return i.replace("{{date}}", Q(a, e)).replace("{{time}}", _(r, e))
    },
    Ee = {
        p: _,
        P: Te
    },
    Fe = /^D+$/,
    Ce = /^Y+$/,
    qe = ["D", "DD", "YY", "YYYY"];

function Ne(n) {
    return Fe.test(n)
}

function He(n) {
    return Ce.test(n)
}

function Qe(n, e, t) {
    const a = Xe(n, e, t);
    if (console.warn(a), qe.includes(n)) throw new RangeError(a)
}

function Xe(n, e, t) {
    const a = n[0] === "Y" ? "years" : "days of the month";
    return `Use \`${n.toLowerCase()}\` instead of \`${n}\` (in \`${e}\`) for formatting ${a} to the input \`${t}\`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md`
}
const Le = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g,
    Ge = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g,
    _e = /^'([^]*?)'?$/,
    Be = /''/g,
    Ae = /[a-zA-Z]/;

function Je(n, e, t) {
    var f, l, M, k, T, E, F, C;
    const a = S(),
        r = (t == null ? void 0 : t.locale) ? ? a.locale ? ? xe,
        i = (t == null ? void 0 : t.firstWeekContainsDate) ? ? ((l = (f = t == null ? void 0 : t.locale) == null ? void 0 : f.options) == null ? void 0 : l.firstWeekContainsDate) ? ? a.firstWeekContainsDate ? ? ((k = (M = a.locale) == null ? void 0 : M.options) == null ? void 0 : k.firstWeekContainsDate) ? ? 1,
        u = (t == null ? void 0 : t.weekStartsOn) ? ? ((E = (T = t == null ? void 0 : t.locale) == null ? void 0 : T.options) == null ? void 0 : E.weekStartsOn) ? ? a.weekStartsOn ? ? ((C = (F = a.locale) == null ? void 0 : F.options) == null ? void 0 : C.weekStartsOn) ? ? 0,
        c = w(n, t == null ? void 0 : t.in);
    if (!A(c)) throw new RangeError("Invalid time value");
    let o = e.match(Ge).map(m => {
        const h = m[0];
        if (h === "p" || h === "P") {
            const Y = Ee[h];
            return Y(m, r.formatLong)
        }
        return m
    }).join("").match(Le).map(m => {
        if (m === "''") return {
            isToken: !1,
            value: "'"
        };
        const h = m[0];
        if (h === "'") return {
            isToken: !1,
            value: Re(m)
        };
        if (q[h]) return {
            isToken: !0,
            value: m
        };
        if (h.match(Ae)) throw new RangeError("Format string contains an unescaped latin alphabet character `" + h + "`");
        return {
            isToken: !1,
            value: m
        }
    });
    r.localize.preprocessor && (o = r.localize.preprocessor(c, o));
    const d = {
        firstWeekContainsDate: i,
        weekStartsOn: u,
        locale: r
    };
    return o.map(m => {
        if (!m.isToken) return m.value;
        const h = m.value;
        (!(t != null && t.useAdditionalWeekYearTokens) && He(h) || !(t != null && t.useAdditionalDayOfYearTokens) && Ne(h)) && Qe(h, e, String(n));
        const Y = q[h[0]];
        return Y(c, h, r.localize, d)
    }).join("")
}

function Re(n) {
    const e = n.match(_e);
    return e ? e[1].replace(Be, "'") : n
}
export {
    O as a, D as b, v as c, de as d, G as e, Je as f, S as g, W as h, De as i, Se as j, xe as k, Ee as l, He as m, Ne as n, x as s, Qe as w
};