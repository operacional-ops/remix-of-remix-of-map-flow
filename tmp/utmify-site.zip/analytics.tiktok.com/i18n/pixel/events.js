window[window["TiktokAnalyticsObject"]]._env = {
    "env": "external",
    "key": ""
};
window[window["TiktokAnalyticsObject"]]._variation_id = 'default::canary';
window[window["TiktokAnalyticsObject"]]._vids = '';
window[window["TiktokAnalyticsObject"]]._cc = 'BR';
window[window.TiktokAnalyticsObject]._li || (window[window.TiktokAnalyticsObject]._li = {}), window[window.TiktokAnalyticsObject]._li["D1I6JCRC77U15B5SKE70"] = "a8bf77c0-0c5d-11f1-9c2b-946dae034988";
window[window["TiktokAnalyticsObject"]]._cde = 390;;
if (!window[window["TiktokAnalyticsObject"]]._server_unique_id) window[window["TiktokAnalyticsObject"]]._server_unique_id = 'a8bf8eed-0c5d-11f1-9c2b-946dae034988';
window[window["TiktokAnalyticsObject"]]._plugins = {
    "AdvancedMatching": true,
    "AutoAdvancedMatching": true,
    "AutoClick": true,
    "AutoConfig": true,
    "Callback": true,
    "DiagnosticsConsole": true,
    "EnableLPV": true,
    "EnrichIpv6": true,
    "EnrichIpv6V2": true,
    "EventBuilder": true,
    "EventBuilderRuleEngine": false,
    "HistoryObserver": true,
    "Identify": true,
    "JSBridge": false,
    "Metadata": true,
    "Monitor": false,
    "PageData": true,
    "PerformanceInteraction": false,
    "RuntimeMeasurement": false,
    "Shopify": true,
    "WebFL": false
};
window[window["TiktokAnalyticsObject"]]._csid_config = {
    "enable": true
};
window[window["TiktokAnalyticsObject"]]._ttls_config = {
    "key": "ttoclid"
};
window[window["TiktokAnalyticsObject"]]._aam = {
    "in_form": false,
    "selectors": {
        "[class*=Btn]": 9,
        "[class*=Button]": 11,
        "[class*=btn]": 8,
        "[class*=button]": 10,
        "[id*=Btn]": 14,
        "[id*=Button]": 16,
        "[id*=btn]": 13,
        "[id*=button]": 15,
        "[role*=button]": 12,
        "button[type='button']": 6,
        "button[type='menu']": 7,
        "button[type='reset']": 5,
        "button[type='submit']": 4,
        "input[type='button']": 1,
        "input[type='image']": 2,
        "input[type='submit']": 3
    },
    "exclude_selectors": ["[class*=cancel]", "[role*=cancel]", "[id*=cancel]", "[class*=back]", "[role*=back]", "[id*=back]", "[class*=return]", "[role*=return]", "[id*=return]"],
    "phone_regex": "^\\+?[0-9\\-\\.\\(\\)\\s]{7,25}$",
    "phone_selectors": ["phone", "mobile", "contact", "pn"],
    "restricted_keywords": ["ssn", "unique", "cc", "card", "cvv", "cvc", "cvn", "creditcard", "billing", "security", "social", "pass", "zip", "address", "license", "gender", "health", "age", "nationality", "party", "sex", "political", "affiliation", "appointment", "politics", "family", "parental"]
};
window[window["TiktokAnalyticsObject"]]._auto_config = {
    "open_graph": ["audience"],
    "microdata": ["audience"],
    "json_ld": ["audience"],
    "meta": null
};
! function(e, n, i, d, o, l) {
    var t, u, a = c()._static_map || [{
            id: "MWIwNzUxMTllMA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllMQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllMg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllMw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllNA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllNQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllNg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllNw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllOA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllOQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllMTA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllMTE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllMTI",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllMTM",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllMTQ",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllMTU",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MWIwNzUxMTllMTY",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMTc",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMTg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMTk",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMjA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMjE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMjI",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMjM",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMjQ",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMjU",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMjY",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMjc",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMjg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMjk",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMzA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MWIwNzUxMTllMzE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }],
        e = (c()._static_map = a, u = "https://analytics.tiktok.com/i18n/pixel/static/", null == (e = t = {
            "info": {
                "pixelCode": "D1I6JCRC77U15B5SKE70",
                "name": "UTMify Web Pixel",
                "status": 0,
                "setupMode": 0,
                "partner": "GoogleTagManagerServer",
                "advertiserID": "0",
                "is_onsite": false,
                "firstPartyCookieEnabled": true
            },
            "plugins": {
                "Shopify": false,
                "AdvancedMatching": {
                    "email": true,
                    "phone_number": true,
                    "first_name": true,
                    "last_name": true,
                    "city": true,
                    "state": true,
                    "country": true,
                    "zip_code": true
                },
                "AutoAdvancedMatching": {
                    "auto_email": true,
                    "auto_phone_number": true
                },
                "Callback": true,
                "Identify": true,
                "Monitor": true,
                "PerformanceInteraction": true,
                "WebFL": true,
                "AutoConfig": {
                    "form_rules": null,
                    "vc_rules": {}
                },
                "PageData": {
                    "performance": false,
                    "interaction": true
                },
                "DiagnosticsConsole": true,
                "CompetitorInsight": true,
                "EventBuilder": true,
                "EnrichIpv6": true,
                "HistoryObserver": {
                    "dynamic_web_pageview": true
                },
                "RuntimeMeasurement": true,
                "JSBridge": true,
                "EventBuilderRuleEngine": true,
                "RemoveUnusedCode": true,
                "EnableLPV": true,
                "AutoConfigV2": false,
                "EnableDatalayerVisiter": true
            },
            "rules": []
        }) || null == (n = e.info) ? void 0 : n.pixelCode);

    function M() {
        return window && window.TiktokAnalyticsObject || "ttq"
    }

    function c() {
        return window && window[M()]
    }

    function g(e, n) {
        n = c()[n];
        return n && n[e] || {}
    }
    var r, v, n = c();
    n || (n = [], window && (window[M()] = n)), Object.assign(t, {
        options: g(e, "_o")
    }), r = t, n._i || (n._i = {}), (v = r.info.pixelCode) && (n._i[v] || (n._i[v] = []), Object.assign(n._i[v], r), n._i[v]._load = +new Date), Object.assign(t.info, {
        loadStart: g(e, "_t"),
        loadEnd: g(e, "_i")._load,
        loadId: n._li && n._li[e] || ""
    }), null != (i = (d = n).instance) && null != (o = i.call(d, e)) && null != (l = o.setPixelInfo) && l.call(o, t.info), r = function(e, n, i) {
        var l = 0 < arguments.length && void 0 !== e ? e : {},
            t = 1 < arguments.length ? n : void 0,
            e = 2 < arguments.length ? i : void 0,
            n = function(e, n) {
                for (var i = 0; i < e.length; i++)
                    if (n.call(null, e[i], i)) return e[i]
            }(a, function(e) {
                for (var i = e.map, n = Object.keys(i), d = function(e) {
                        var n;
                        return "JSBridge" === e ? "external" !== (null == (n = c()._env) ? void 0 : n.env) === i[e] : !(!l[e] || !t[e]) === i[e]
                    }, o = 0; o < n.length; o++)
                    if (!d.call(null, n[o], o)) return !1;
                return !0
            });
        return n ? "".concat(e, "main.").concat(n.id, ".js") : "".concat(e, "main.").concat(a[0].id, ".js")
    }(n._plugins, t.plugins, u), v = e, (void 0 !== self.DedicatedWorkerGlobalScope ? self instanceof self.DedicatedWorkerGlobalScope : "DedicatedWorkerGlobalScope" === self.constructor.name) ? self.importScripts && self.importScripts(r) : ((i = document.createElement("script")).type = "text/javascript", i.async = !0, i.src = r, i.setAttribute("data-id", v), (r = document.getElementsByTagName("script")[0]) && r.parentNode && r.parentNode.insertBefore(i, r))
}();